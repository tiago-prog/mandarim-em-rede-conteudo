# Mandarim em Rede 01
## Fundamentos de Transferência Oral

### Companion visual independente e não oficial para estudantes brasileiros de mandarim que utilizam Pimsleur

---

## Como usar este material

Este material é uma camada visual de apoio. Realize primeiro sua sessão principal de áudio sem acompanhar este documento. Depois, use os mapas para organizar o padrão ouvido, tente reconstruí-lo e produza variações sem olhar a resposta.

A sequência de cada aula é:

```text
OUVIR → TENTAR RESPONDER → CONSULTAR O MAPA → RECOMBINAR → PRODUZIR SEM OLHAR
```

O pinyin aparece com marcas tonais. Os caracteres simplificados são usados como apoio visual, não como requisito para iniciar a produção oral. A tradução em português mostra o sentido natural da expressão; ela não deve ser interpretada como correspondência palavra por palavra.

### Legenda visual para a diagramação

- **Azul-escuro:** intenção comunicativa.
- **Azul-claro:** estrutura fixa e ordem.
- **Verde:** elemento substituível.
- **Laranja:** som, pinyin e tom.
- **Vermelho:** contraste ou erro provável.
- **Cinza:** tradução e apoio removível.
- **Dourado:** revisão e transferência.

Cada aula trabalha uma função principal. O domínio exige produção oral, não apenas reconhecimento visual.

---

# MÓDULO 1 — ENTRAR NA INTERAÇÃO

## AULA 1 – Cumprimentar e dizer o próprio nome

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir cumprimentar uma pessoa, perguntar seu nome e dizer o próprio nome em uma troca curta, sem ler a resposta.

### 2. Mapa Mental Principal

**Tipo:** mapa de intenção comunicativa + padrão estrutural.

**Núcleo azul-escuro:** iniciar uma interação e identificar pessoas.

**Ramos primários:**

1. **Saudação — azul-claro**
   - 你好 — forma básica de cumprimento.
   - 你好吗？— pergunta sobre como a pessoa está.

2. **Perguntar o nome — azul-claro**
   - 你叫什么名字？— padrão completo.
   - 你叫什 么？— forma curta e natural em contexto informal.

3. **Dizer o próprio nome — verde**
   - 我叫 + nome.
   - Meu nome pode substituir o elemento variável.

4. **Pronúncia — laranja**
   - 你 nǐ: terceiro tom em forma isolada.
   - 好 hǎo: terceiro tom.
   - 叫 jiào: quarto tom.
   - 名字 míngzi: segundo tom + tom neutro.

5. **Transferência — dourado**
   - Cumprimentar alguém novo.
   - Perguntar o nome.
   - Responder com o próprio nome.

**Ramo vermelho:** não usar a ordem portuguesa “como você chama seu nome”. O padrão é uma estrutura própria do mandarim.

### 3. Padrões e Frases-Chave

#### Padrão A — Saudação

```text
你好。
Nǐ hǎo.
Olá.
```

#### Padrão B — Perguntar o nome

```text
你叫什么名字？
Nǐ jiào shénme míngzi?
Qual é o seu nome?
```

#### Padrão C — Responder

```text
我叫 + [nome]。
Wǒ jiào + [nome].
Eu me chamo + [nome].
```

#### Frases de alta frequência

1. 你好。  
   **Nǐ hǎo.**  
   Olá.

2. 你好吗？  
   **Nǐ hǎo ma?**  
   Tudo bem com você?

3. 我很好。  
   **Wǒ hěn hǎo.**  
   Estou bem.

4. 你叫什么名字？  
   **Nǐ jiào shénme míngzi?**  
   Qual é o seu nome?

5. 我叫安娜。  
   **Wǒ jiào Ānnà.**  
   Eu me chamo Ana.

6. 你呢？  
   **Nǐ ne?**  
   E você?

7. 我叫保罗。  
   **Wǒ jiào Bǎoluó.**  
   Eu me chamo Paulo.

8. 很高兴认识你。  
   **Hěn gāoxìng rènshi nǐ.**  
   Prazer em conhecer você.

### 4. Vocabulário Funcional

**Pessoas e identificação:**

- 你 — **nǐ** — você
- 我 — **wǒ** — eu
- 叫 — **jiào** — chamar-se; chamar
- 什么 — **shénme** — o que; qual
- 名字 — **míngzi** — nome
- 呢 — **ne** — partícula para devolver a pergunta
- 很 — **hěn** — muito; marcador comum em “estar bem”
- 高兴 — **gāoxìng** — contente; feliz
- 认识 — **rènshi** — conhecer

### 5. Pontos Críticos de Pronúncia e Tons

- **nǐ hǎo:** os dois itens aparecem com terceiro tom na forma lexical, mas na fala conectada o primeiro costuma ser realizado como segundo tom: **ní hǎo**. O aluno deve priorizar ouvir e imitar a sequência, não aplicar uma regra mecanicamente.
- **叫 jiào:** quarto tom, curto e descendente. Não transforme em uma sílaba alongada ou interrogativa.
- **名字 míngzi:** a segunda sílaba é normalmente neutra. Não dê a **zi** a mesma força de **míng**.
- Falantes de português tendem a interpretar pinyin como português. **q**, **x**, **zh** e **j** não devem ser lidos pelos valores ortográficos do português.

### 6. Exercícios de Recombinação

Produza oralmente, sem olhar a resposta completa:

1. Cumprimente alguém e diga que está bem.
2. Pergunte o nome de uma mulher chamada Ana.
3. Pergunte o nome de um homem chamado Paulo.
4. Diga seu nome e devolva a pergunta com **你呢？**
5. Cumprimente alguém, pergunte seu nome e diga “prazer em conhecer você”.

### 7. Tarefa de Produção Oral (sem olhar)

Imagine que você acabou de conhecer uma pessoa. Produza uma troca de quatro falas:

```text
saudação → pergunta do nome → resposta → devolução da pergunta
```

Faça duas vezes, usando nomes diferentes. Grave a segunda tentativa, se possível, e verifique se você não consultou o texto durante a produção.

### 8. Critério de Domínio

Avance quando conseguir:

- produzir a saudação sem hesitação prolongada;
- perguntar o nome sem traduzir palavra por palavra;
- responder com dois nomes diferentes;
- usar **你呢？** para devolver a pergunta;
- manter a diferença entre **叫 jiào** e **好 hǎo**.

### 9. Conexões com Aulas Anteriores

Esta é a aula inicial. Ela estabelece:

- 你 e 我 como participantes da conversa;
- o padrão **[pronome] + [verbo] + [informação]**;
- a regra de tentar responder antes de consultar;
- o primeiro mapa de intenção comunicativa.

---

## AULA 2 – Dizer de onde você é e que língua fala

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir dizer sua nacionalidade ou origem, perguntar a origem de outra pessoa e informar qual idioma fala.

### 2. Mapa Mental Principal

**Tipo:** mapa de intenção comunicativa + mapa de padrão substituível.

**Núcleo azul-escuro:** identificar origem e idioma.

**Ramos primários:**

1. **Origem — azul-claro**
   - 你是哪国人？
   - 我是 + [país] + 人。

2. **País e nacionalidade — verde**
   - 巴西 — Brasil.
   - 中国 — China.
   - 美国 — Estados Unidos.
   - 巴西人 — brasileiro(a).
   - 中国人 — chinês/chinesa.

3. **Idioma — azul-claro/verde**
   - 你说什么语言？
   - 我说葡萄牙语。
   - 我会说一点中文。

4. **Pronúncia — laranja**
   - 哪 nǎ e 国 guó.
   - 人 rén.
   - 说 shuō.
   - 中文 Zhōngwén.

5. **Contraste — vermelho**
   - **是 shì** identifica ou classifica.
   - **说 shuō** indica falar um idioma.

### 3. Padrões e Frases-Chave

#### Padrão A — Origem

```text
你是哪国人？
Nǐ shì nǎ guó rén?
De que país você é?
```

#### Padrão B — Resposta de origem

```text
我是 + [país]人。
Wǒ shì + [país] rén.
Eu sou + [nacionalidade].
```

#### Padrão C — Idioma

```text
我说 + [idioma]。
Wǒ shuō + [idioma].
Eu falo + [idioma].
```

#### Frases de alta frequência

1. 你是哪国人？  
   **Nǐ shì nǎ guó rén?**  
   De que país você é?

2. 我是巴西人。  
   **Wǒ shì Bāxī rén.**  
   Eu sou brasileiro(a).

3. 你是中国人吗？  
   **Nǐ shì Zhōngguó rén ma?**  
   Você é chinês(a)?

4. 我不是中国人。  
   **Wǒ bú shì Zhōngguó rén.**  
   Eu não sou chinês(a).

5. 你说什么语言？  
   **Nǐ shuō shénme yǔyán?**  
   Que idioma você fala?

6. 我说葡萄牙语。  
   **Wǒ shuō Pútáoyáyǔ.**  
   Eu falo português.

7. 我会说一点中文。  
   **Wǒ huì shuō yìdiǎn Zhōngwén.**  
   Eu sei falar um pouco de chinês.

8. 你会说英语吗？  
   **Nǐ huì shuō Yīngyǔ ma?**  
   Você fala inglês?

### 4. Vocabulário Funcional

- 哪 — **nǎ** — qual
- 国 — **guó** — país
- 人 — **rén** — pessoa; sufixo de nacionalidade
- 巴西 — **Bāxī** — Brasil
- 中国 — **Zhōngguó** — China
- 美国 — **Měiguó** — Estados Unidos
- 是 — **shì** — ser; identificar
- 说 — **shuō** — falar; dizer
- 语言 — **yǔyán** — idioma; língua
- 中文 — **Zhōngwén** — chinês
- 葡萄牙语 — **Pútáoyáyǔ** — português
- 英语 — **Yīngyǔ** — inglês

### 5. Pontos Críticos de Pronúncia e Tons

- **不是** é normalmente pronunciado **bú shì**, porque **不 bù** muda para segundo tom antes de uma sílaba de quarto tom.
- **哪 nǎ** e **那 nà** não são a mesma palavra. Nesta aula, use **哪** para perguntar “qual”.
- **说 shuō** começa com um som que não deve ser tratado como o “s” do português. Escute a gravação e evite inserir uma vogal antes da sílaba.
- **人 rén** não é “rém” do português. O inicial é retroflexo/aproximante do mandarim e precisa ser imitado do áudio.

### 6. Exercícios de Recombinação

1. Diga que você é brasileiro(a).
2. Pergunte se a outra pessoa é chinesa.
3. Negue que você seja americano(a).
4. Diga que fala português.
5. Diga que fala um pouco de chinês.
6. Pergunte se a outra pessoa fala inglês.

### 7. Tarefa de Produção Oral (sem olhar)

Imagine que você está conversando com alguém pela primeira vez. Produza:

```text
pergunta de origem → sua resposta → pergunta de idioma → sua resposta
```

Faça uma segunda rodada trocando o país e o idioma da outra pessoa.

### 8. Critério de Domínio

Avance quando conseguir:

- diferenciar **是** de **说**;
- perguntar a origem sem recorrer ao português palavra por palavra;
- produzir uma frase afirmativa e uma negativa;
- dizer dois idiomas diferentes;
- manter **bú shì** em vez de pronunciar **bù shì** de forma isolada.

### 9. Conexões com Aulas Anteriores

Recicla:

- 你, 我, 什么 e 呢;
- o padrão de pergunta direta;
- apresentação pessoal da Aula 1;
- substituição de nomes por países e idiomas.

Expande a rede de identidade: **nome → origem → idioma**.

---

## AULA 3 – Dizer que entende, não entende e pedir repetição

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir indicar se entende uma fala, dizer que não entende e pedir que a pessoa repita ou fale mais devagar.

### 2. Mapa Mental Principal

**Tipo:** mapa de contraste e reparo comunicativo.

**Núcleo azul-escuro:** manter a conversa quando a compreensão falha.

**Ramos primários:**

1. **Compreender — azul-claro**
   - 听懂 — entender ao ouvir.
   - 我听懂了 — entendi.

2. **Não compreender — vermelho**
   - 我没听懂 — não entendi.
   - 我不明白 — não entendo/não compreendo.

3. **Pedir repetição — verde**
   - 请再说一遍。
   - 请问，你能再说一遍吗？

4. **Pedir velocidade menor — verde**
   - 请说慢一点。

5. **Pronúncia — laranja**
   - 听 tīng, 懂 dǒng, 明白 míngbai, 再 zài, 慢 màn.

### 3. Padrões e Frases-Chave

#### Padrão A — Resultado da compreensão

```text
我 + [ação de compreensão] + 了。
Wǒ + [ação de compreensão] + le.
Eu consegui / eu entendi.
```

#### Padrão B — Falha de compreensão

```text
我没 + [ação] + 懂。
Wǒ méi + [ação] + dǒng.
Eu não consegui entender.
```

#### Frases de alta frequência

1. 我听懂了。  
   **Wǒ tīng dǒng le.**  
   Eu entendi.

2. 我没听懂。  
   **Wǒ méi tīng dǒng.**  
   Eu não entendi.

3. 我不明白。  
   **Wǒ bù míngbai.**  
   Eu não compreendo.

4. 请再说一遍。  
   **Qǐng zài shuō yí biàn.**  
   Por favor, diga novamente.

5. 请说慢一点。  
   **Qǐng shuō màn yìdiǎn.**  
   Por favor, fale um pouco mais devagar.

6. 你能再说一遍吗？  
   **Nǐ néng zài shuō yí biàn ma?**  
   Você pode dizer novamente?

7. 你能说慢一点吗？  
   **Nǐ néng shuō màn yìdiǎn ma?**  
   Você pode falar um pouco mais devagar?

8. 现在我明白了。  
   **Xiànzài wǒ míngbai le.**  
   Agora eu entendi.

### 4. Vocabulário Funcional

- 听 — **tīng** — ouvir
- 懂 — **dǒng** — entender
- 明白 — **míngbai** — compreender
- 了 — **le** — marcador de mudança/estado concluído
- 没 — **méi** — não ter ocorrido; não ter conseguido
- 再 — **zài** — novamente
- 说 — **shuō** — falar
- 一遍 — **yí biàn** — uma vez; uma repetição completa
- 慢 — **màn** — devagar
- 一点 — **yìdiǎn** — um pouco
- 能 — **néng** — poder; conseguir
- 请 — **qǐng** — por favor

### 5. Pontos Críticos de Pronúncia e Tons

- **没 méi** tem segundo tom. Não confundir com **每 měi**, que significa “cada/todo”.
- **懂 dǒng** começa com um som retroflexo/oclusivo que não deve ser lido como “d” português puro.
- **再 zài** é quarto tom. **在 zài**, que será usado em outra função, tem a mesma pronúncia, mas significado diferente; o contexto determina a palavra.
- Em **一遍 yí biàn**, **一** aparece como segundo tom antes de uma sílaba de quarto tom. Priorize a pronúncia da expressão inteira.
- Evite produzir **请 qǐng** como “tching” português. O som inicial exige uma combinação específica do mandarim; use o áudio como referência.

### 6. Exercícios de Recombinação

1. Diga que entendeu.
2. Diga que não entendeu.
3. Peça para a pessoa repetir.
4. Peça para a pessoa falar mais devagar.
5. Faça a pergunta usando **能**.
6. Diga que agora entendeu.

### 7. Tarefa de Produção Oral (sem olhar)

Ouça uma frase em mandarim ou imagine que alguém falou algo rápido. Responda em três etapas:

```text
não entendi → peça repetição → peça velocidade menor
```

Depois, produza a resposta inversa: diga que entendeu e agradeça mentalmente à pessoa.

### 8. Critério de Domínio

Avance quando conseguir:

- escolher espontaneamente entre **我听懂了** e **我没听懂**;
- pedir repetição sem consultar a estrutura;
- produzir uma solicitação com **能**;
- manter **méi** e **bù** em funções diferentes;
- usar a expressão completa com ritmo natural suficiente.

### 9. Conexões com Aulas Anteriores

Recicla:

- 你, 我, 说, 一点 e 吗;
- o uso de **请** como marcador de pedido;
- a lógica de reparo na conversa.

Expande a rede de apresentação para **manutenção da interação**: o aluno agora consegue continuar mesmo quando não entende.

---

## AULA 4 – Perguntar o que é e confirmar uma informação

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir perguntar o que é uma coisa, confirmar uma informação simples e responder afirmativa ou negativamente.

### 2. Mapa Mental Principal

**Tipo:** mapa de intenção comunicativa + mapa de contraste.

**Núcleo azul-escuro:** identificar e confirmar informação.

**Ramos primários:**

1. **Identificação — azul-claro**
   - 这是什么？
   - 那是什么？

2. **Resposta — verde**
   - 这是 + [objeto].
   - 那是 + [objeto].

3. **Confirmação — azul-claro**
   - 这是你的书吗？
   - 对，是我的。

4. **Negação/ajuste — vermelho**
   - 不，不是我的。
   - 不是，这是他的。

5. **Pronúncia — laranja**
   - 这 zhè, 那 nà, 书 shū, 对 duì, 他 tā.

### 3. Padrões e Frases-Chave

#### Padrão A — Perguntar “o que é isto?”

```text
这是什么？
Zhè shì shénme?
O que é isto?
```

#### Padrão B — Identificar

```text
这是 + [objeto]。
Zhè shì + [objeto].
Isto é + [objeto].
```

#### Padrão C — Confirmar posse/identidade

```text
这是 + [pessoa] + 的 + [objeto] + 吗？
Zhè shì + [pessoa] + de + [objeto] ma?
Isto é o(a) [objeto] de [pessoa]?
```

#### Frases de alta frequência

1. 这是什么？  
   **Zhè shì shénme?**  
   O que é isto?

2. 那是什么？  
   **Nà shì shénme?**  
   O que é aquilo?

3. 这是书。  
   **Zhè shì shū.**  
   Isto é um livro.

4. 这是我的手机。  
   **Zhè shì wǒ de shǒujī.**  
   Este é o meu celular.

5. 这是你的水吗？  
   **Zhè shì nǐ de shuǐ ma?**  
   Esta é a sua água?

6. 对，是我的。  
   **Duì, shì wǒ de.**  
   Sim, é minha.

7. 不，不是我的。  
   **Bù, bú shì wǒ de.**  
   Não, não é minha.

8. 那是他的包。  
   **Nà shì tā de bāo.**  
   Aquela é a bolsa/mochila dele.

### 4. Vocabulário Funcional

- 这 — **zhè** — isto; este/esta
- 那 — **nà** — aquilo; aquele/aquela
- 是 — **shì** — ser; tratar-se de
- 的 — **de** — marcador de relação/posse
- 对 — **duì** — correto; sim
- 我的 — **wǒ de** — meu/minha
- 你的 — **nǐ de** — seu/sua
- 他的 — **tā de** — dele
- 书 — **shū** — livro
- 手机 — **shǒujī** — celular
- 水 — **shuǐ** — água
- 包 — **bāo** — bolsa; mochila

### 5. Pontos Críticos de Pronúncia e Tons

- **这 zhè** e **那 nà** são contrastes importantes. **这** começa com som diferente de **zh** português; não simplifique para “zé”.
- **水 shuǐ** combina o som inicial com uma final que não corresponde diretamente ao português. Evite produzir “suê” sem referência ao áudio.
- **书 shū** tem primeiro tom. Mantenha altura relativamente estável, sem transformá-lo em sílaba descendente.
- Em **不是**, use **bú shì** na fala conectada. O primeiro item muda de tom diante de quarto tom.

### 6. Exercícios de Recombinação

1. Pergunte o que é um livro.
2. Identifique um celular.
3. Pergunte se uma água é da outra pessoa.
4. Responda que é sua.
5. Negue que uma bolsa seja sua.
6. Diga que a bolsa é dele.

### 7. Tarefa de Produção Oral (sem olhar)

Coloque mentalmente três objetos ao seu redor. Para cada objeto:

```text
pergunte “o que é isto?” → responda → confirme ou negue a posse
```

Faça a tarefa usando **这** para um objeto próximo e **那** para um objeto distante.

### 8. Critério de Domínio

Avance quando conseguir:

- perguntar e responder com **这** e **那**;
- usar **的** para indicar posse;
- confirmar e negar sem hesitar;
- distinguir **这** de **那** ao ouvir;
- produzir pelo menos três combinações de objeto e pessoa.

### 9. Conexões com Aulas Anteriores

Recicla:

- 你, 我, 什么, 是 e 吗;
- pedido de confirmação da Aula 3;
- vocabulário de identificação e apresentação.

Expande a rede para **objetos, posse e confirmação**.

---

## AULA DE CONSOLIDAÇÃO 1 – Entrar, identificar e reparar

### 1. Objetivo de Fala

Ao final da consolidação, o aluno deve conseguir iniciar uma conversa curta, apresentar-se, informar origem/idioma, identificar um objeto e reparar uma falha de compreensão.

### 2. Mapa Mental Principal

**Tipo:** mapa de consolidação integrador.

**Núcleo dourado:** primeira interação funcional.

**Ramos:**

```text
[N] iniciar conversa
 ├── [A] cumprimentar e dizer nome
 ├── [B] dizer origem e idioma
 ├── [C] pedir repetição
 ├── [D] identificar objeto
 └── [R] transferir para situação nova
```

**Código:**

- Azul-escuro: intenção de cada bloco.
- Azul-claro: padrões já dominados.
- Verde: nomes, países, idiomas e objetos.
- Laranja: pontos tonais já trabalhados.
- Vermelho: **是/说**, **这/那**, **不/没**.
- Dourado: sequência conversacional completa.

### 3. Padrões e Frases-Chave

Use as estruturas das quatro primeiras aulas. As combinações prioritárias são:

1. 你好，我叫安娜。  
   **Nǐ hǎo, wǒ jiào Ānnà.**  
   Olá, eu me chamo Ana.

2. 你是哪国人？  
   **Nǐ shì nǎ guó rén?**  
   De que país você é?

3. 我是巴西人，我说葡萄牙语。  
   **Wǒ shì Bāxī rén, wǒ shuō Pútáoyáyǔ.**  
   Sou brasileiro(a), falo português.

4. 你能再说一遍吗？  
   **Nǐ néng zài shuō yí biàn ma?**  
   Você pode repetir?

5. 这是什么？  
   **Zhè shì shénme?**  
   O que é isto?

6. 这是我的手机。  
   **Zhè shì wǒ de shǒujī.**  
   Este é o meu celular.

### 4. Vocabulário Funcional

Recupere somente os itens necessários das Aulas 1–4:

- 你好 — **nǐ hǎo** — olá
- 叫 — **jiào** — chamar-se
- 哪国人 — **nǎ guó rén** — de que país; nacionalidade
- 说 — **shuō** — falar
- 听懂 — **tīng dǒng** — entender ao ouvir
- 再说一遍 — **zài shuō yí biàn** — repetir
- 这 — **zhè** — isto
- 那 — **nà** — aquilo
- 我的 — **wǒ de** — meu/minha
- 手机 — **shǒujī** — celular

### 5. Pontos Críticos de Pronúncia e Tons

A consolidação não deve introduzir um novo foco tonal. Revise somente:

- **nǐ hǎo** em fala conectada;
- **bú shì**;
- **yí biàn**;
- **这 zhè** versus **那 nà**;
- o tom neutro de **名字 míngzi**.

### 6. Exercícios de Recombinação

1. Faça uma apresentação completa para uma pessoa chinesa.
2. Troque Brasil por Estados Unidos.
3. Troque português por inglês.
4. Diga que não entendeu e peça repetição.
5. Identifique um livro próximo e pergunte se é da outra pessoa.
6. Negue e corrija a posse de um objeto.

### 7. Tarefa de Produção Oral (sem olhar)

Faça uma simulação de 60 segundos. A sequência deve conter:

```text
cumprimento → nome → origem → idioma → identificação de objeto → reparo de compreensão
```

Repita em uma segunda situação, alterando pelo menos três elementos.

### 8. Critério de Domínio

O Módulo 1 está consolidado quando o aluno consegue executar a simulação sem consultar o mapa completo e quando a consulta passa a ocorrer apenas para verificar um ponto específico.

### 9. Conexões com Aulas Anteriores

Integra todas as Aulas 1–4. O aluno deve perceber a rede:

```text
pessoa → origem → idioma → compreensão → objeto → posse
```

---

# MÓDULO 2 — PEDIR, LOCALIZAR E ORGANIZAR UMA SITUAÇÃO

## AULA 5 – Dizer o que quer e fazer um pedido simples

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir dizer o que quer, pedir um item simples e indicar que não quer algo.

### 2. Mapa Mental Principal

**Tipo:** mapa de intenção comunicativa + padrão de pedido.

**Núcleo azul-escuro:** expressar vontade e pedir algo.

**Ramos primários:**

1. **Vontade — azul-claro**
   - 我想 + [ação/objeto].
   - 我想要 + [objeto].

2. **Pedido — verde**
   - 我要 + [objeto].
   - 请给我 + [objeto].

3. **Negação — vermelho**
   - 我不要 + [objeto].
   - 我不想 + [ação].

4. **Cortesia — azul-claro**
   - 请.
   - 谢谢.

5. **Pronúncia — laranja**
   - 想 xiǎng, 要 yào, 给 gěi, 不要 bú yào.

### 3. Padrões e Frases-Chave

#### Padrão A — Querer fazer

```text
我想 + [ação]。
Wǒ xiǎng + [ação].
Eu quero / gostaria de + [ação].
```

#### Padrão B — Querer um item

```text
我想要 + [objeto]。
Wǒ xiǎng yào + [objeto].
Eu quero + [objeto].
```

#### Padrão C — Pedir diretamente

```text
请给我 + [objeto]。
Qǐng gěi wǒ + [objeto].
Por favor, me dê + [objeto].
```

#### Frases de alta frequência

1. 我想喝水。  
   **Wǒ xiǎng hē shuǐ.**  
   Quero beber água.

2. 我想喝咖啡。  
   **Wǒ xiǎng hē kāfēi.**  
   Quero beber café.

3. 我想吃饭。  
   **Wǒ xiǎng chīfàn.**  
   Quero comer.

4. 我想要一杯茶。  
   **Wǒ xiǎng yào yì bēi chá.**  
   Quero uma xícara de chá.

5. 请给我水。  
   **Qǐng gěi wǒ shuǐ.**  
   Por favor, me dê água.

6. 我要这个。  
   **Wǒ yào zhège.**  
   Quero isto.

7. 我不要咖啡。  
   **Wǒ bú yào kāfēi.**  
   Não quero café.

8. 谢谢。  
   **Xièxie.**  
   Obrigado(a).

### 4. Vocabulário Funcional

- 想 — **xiǎng** — querer; estar pensando em
- 要 — **yào** — querer; precisar
- 给 — **gěi** — dar; para
- 喝 — **hē** — beber
- 吃 — **chī** — comer
- 水 — **shuǐ** — água
- 咖啡 — **kāfēi** — café
- 茶 — **chá** — chá
- 饭 — **fàn** — refeição; arroz cozido
- 杯 — **bēi** — medida para copos/xícaras
- 这个 — **zhège** — isto; este item
- 谢谢 — **xièxie** — obrigado(a)

### 5. Pontos Críticos de Pronúncia e Tons

- **想 xiǎng** é terceiro tom. Evite reduzi-lo a uma sílaba descendente de quarto tom.
- **要 yào** é quarto tom. Em **不要**, pronuncie normalmente **bú yào**, pois **不** muda antes do quarto tom.
- **给 gěi** é terceiro tom. Não confunda com **几 jǐ**, que aparecerá em perguntas de quantidade.
- **谢谢 xièxie:** a primeira sílaba recebe mais destaque; a segunda é normalmente neutra.

### 6. Exercícios de Recombinação

1. Diga que quer água.
2. Diga que quer café.
3. Peça chá.
4. Peça uma xícara de café.
5. Diga que não quer água.
6. Aponte mentalmente para um objeto e diga que o quer.

### 7. Tarefa de Produção Oral (sem olhar)

Imagine que está em um café. Produza cinco pedidos diferentes, sem ler:

```text
quero beber → quero comer → quero um item → não quero um item → agradeço
```

### 8. Critério de Domínio

Avance quando conseguir:

- distinguir **想** e **要** em uso funcional;
- fazer um pedido com **请给我**;
- negar um pedido com **不要**;
- produzir cinco combinações sem consultar o padrão completo;
- manter **bú yào** em fala conectada.

### 9. Conexões com Aulas Anteriores

Recicla:

- 这 e 这个;
- água e objetos da Aula 4;
- **不** como negação;
- **请** e **吗** como recursos interacionais.

Expande a rede para **identificação → desejo → pedido**.

---

## AULA 6 – Perguntar onde algo está e dizer onde você está

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir perguntar onde uma pessoa ou objeto está e responder com uma localização simples.

### 2. Mapa Mental Principal

**Tipo:** mapa de padrão espacial.

**Núcleo azul-escuro:** localizar pessoa ou objeto.

**Ramos primários:**

1. **Pergunta — azul-claro**
   - 在哪儿？
   - 你在哪儿？
   - 洗手间在哪儿？

2. **Localização — verde**
   - 在 + [lugar].
   - 在这里 / 在那里.

3. **Pessoa/objeto — verde**
   - 我, 你, 他.
   - 手机, 书, 车.

4. **Contraste — vermelho**
   - 在 indica localização.
   - 是 identifica algo.

5. **Pronúncia — laranja**
   - 在 zài, 哪儿 nǎr, 里 lǐ, 这儿 zhèr.

### 3. Padrões e Frases-Chave

#### Padrão A — Perguntar localização

```text
[Pessoa/objeto] 在哪儿？
[Pessoa/objeto] zài nǎr?
Onde está [pessoa/objeto]?
```

#### Padrão B — Responder localização

```text
[Pessoa/objeto] 在 + [lugar]。
[Pessoa/objeto] zài + [lugar].
[Pessoa/objeto] está em + [lugar].
```

#### Frases de alta frequência

1. 你在哪儿？  
   **Nǐ zài nǎr?**  
   Onde você está?

2. 我在这里。  
   **Wǒ zài zhèlǐ.**  
   Estou aqui.

3. 他在哪里？  
   **Tā zài nǎlǐ?**  
   Onde ele está?

4. 他在那里。  
   **Tā zài nàlǐ.**  
   Ele está ali.

5. 洗手间在哪儿？  
   **Xǐshǒujiān zài nǎr?**  
   Onde fica o banheiro?

6. 手机在哪里？  
   **Shǒujī zài nǎlǐ?**  
   Onde está o celular?

7. 手机在包里。  
   **Shǒujī zài bāo lǐ.**  
   O celular está na bolsa.

8. 书在这里。  
   **Shū zài zhèlǐ.**  
   O livro está aqui.

### 4. Vocabulário Funcional

- 在 — **zài** — estar em; localizar-se em
- 哪儿 — **nǎr** — onde
- 哪里 — **nǎlǐ** — onde
- 这里 — **zhèlǐ** — aqui
- 那里 — **nàlǐ** — ali; lá
- 里 — **lǐ** — dentro; em
- 洗手间 — **xǐshǒujiān** — banheiro
- 包 — **bāo** — bolsa; mochila
- 手机 — **shǒujī** — celular
- 书 — **shū** — livro
- 车 — **chē** — carro
- 他 — **tā** — ele

### 5. Pontos Críticos de Pronúncia e Tons

- **在 zài** é quarto tom e não deve ser confundido funcionalmente com **是 shì**.
- **哪儿 nǎr** pode soar diferente de **哪里 nǎlǐ** em variedades de fala. Pratique uma forma por vez antes de alterná-las.
- **这里 zhèlǐ** e **那里 nàlǐ** têm a segunda sílaba com terceiro tom lexical, mas a realização em sequência pode ser reduzida. Imite o áudio.
- O **r** de **儿 ér/nǎr** não corresponde ao r do português brasileiro em todas as posições. Evite exagerar um “r” gutural.

### 6. Exercícios de Recombinação

1. Pergunte onde a pessoa está.
2. Diga que está aqui.
3. Pergunte onde está o banheiro.
4. Diga que o celular está na bolsa.
5. Pergunte onde está o livro.
6. Diga que o livro está ali.

### 7. Tarefa de Produção Oral (sem olhar)

Escolha mentalmente três objetos e dois lugares. Faça seis trocas:

```text
pergunte localização → responda com aqui, ali ou dentro de um lugar
```

Não use tradução durante a produção.

### 8. Critério de Domínio

Avance quando conseguir:

- usar **在** para localização sem substituí-lo por **是**;
- perguntar com **哪儿** ou **哪里**;
- produzir respostas com três lugares diferentes;
- manter o contraste entre **这里** e **那里**;
- responder após um prompt em português sem consultar o mapa completo.

### 9. Conexões com Aulas Anteriores

Recicla:

- objetos da Aula 4;
- 你, 我, 他;
- 这 e 那;
- perguntas de identificação.

Expande a rede para **objeto → posse → localização**.

---

## AULA 7 – Dizer quando algo acontece e combinar um encontro

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir perguntar quando uma ação acontece, dizer um horário simples e combinar um encontro.

### 2. Mapa Mental Principal

**Tipo:** mapa de intenção comunicativa + sequência temporal.

**Núcleo azul-escuro:** organizar tempo e encontro.

**Ramos primários:**

1. **Perguntar quando — azul-claro**
   - 什么时候？
   - 你什么时候有时间？

2. **Dia e horário — verde**
   - 今天, 明天, 现在.
   - 上午, 下午, 晚上.
   - 点, 分.

3. **Disponibilidade — azul-claro**
   - 有时间.
   - 没有时间.

4. **Combinar — verde**
   - 我们明天见。
   - 明天上午九点，可以吗？

5. **Pronúncia — laranja**
   - 什么 shénme, 时候 shíhou, 明天 míngtiān, 时间 shíjiān.

### 3. Padrões e Frases-Chave

#### Padrão A — Perguntar quando

```text
[ação] 什么时候？
[ação] shénme shíhou?
Quando [ação]?
```

#### Padrão B — Perguntar disponibilidade

```text
你什么时候有时间？
Nǐ shénme shíhou yǒu shíjiān?
Quando você tem tempo?
```

#### Padrão C — Propor horário

```text
[tempo] + [horário]，可以吗？
[tempo] + [horário], kěyǐ ma?
[tempo] às [horas], pode ser?
```

#### Frases de alta frequência

1. 现在几点？  
   **Xiànzài jǐ diǎn?**  
   Que horas são agora?

2. 现在九点。  
   **Xiànzài jiǔ diǎn.**  
   Agora são nove horas.

3. 你什么时候有时间？  
   **Nǐ shénme shíhou yǒu shíjiān?**  
   Quando você tem tempo?

4. 我明天有时间。  
   **Wǒ míngtiān yǒu shíjiān.**  
   Tenho tempo amanhã.

5. 我今天没有时间。  
   **Wǒ jīntiān méiyǒu shíjiān.**  
   Hoje não tenho tempo.

6. 我们明天见。  
   **Wǒmen míngtiān jiàn.**  
   Nos vemos amanhã.

7. 明天上午九点，可以吗？  
   **Míngtiān shàngwǔ jiǔ diǎn, kěyǐ ma?**  
   Amanhã às nove da manhã, pode ser?

8. 可以，没问题。  
   **Kěyǐ, méi wèntí.**  
   Pode ser, sem problema.

### 4. Vocabulário Funcional

- 什么时候 — **shénme shíhou** — quando
- 时候 — **shíhou** — momento; hora
- 时间 — **shíjiān** — tempo; horário disponível
- 现在 — **xiànzài** — agora
- 今天 — **jīntiān** — hoje
- 明天 — **míngtiān** — amanhã
- 上午 — **shàngwǔ** — manhã
- 下午 — **xiàwǔ** — tarde
- 晚上 — **wǎnshang** — noite
- 点 — **diǎn** — hora em ponto
- 有 — **yǒu** — ter; haver
- 可以 — **kěyǐ** — poder; ser possível

### 5. Pontos Críticos de Pronúncia e Tons

- **明天 míngtiān:** mantenha o contraste entre o segundo tom de **míng** e o primeiro tom de **tiān**.
- **时间 shíjiān:** não transforme **jiān** em uma sílaba com “j” português. Use o áudio para localizar o som inicial.
- **可以 kěyǐ:** as duas sílabas têm terceiro tom lexical, mas a fala conectada pode reduzir o primeiro. Imite o ritmo real.
- **没有 méiyǒu:** **没** é segundo tom e **有** é terceiro tom. Não trate a expressão como duas sílabas igualmente fortes.

### 6. Exercícios de Recombinação

1. Pergunte que horas são.
2. Diga que agora são nove horas.
3. Diga que você tem tempo amanhã.
4. Diga que hoje não tem tempo.
5. Proponha amanhã de manhã.
6. Confirme que pode ser.

### 7. Tarefa de Produção Oral (sem olhar)

Escolha três horários mentalmente. Para cada um:

```text
pergunte disponibilidade → proponha o horário → confirme ou recuse
```

Use **今天**, **明天** e **现在** em rodadas diferentes.

### 8. Critério de Domínio

Avance quando conseguir:

- perguntar e responder horários básicos;
- combinar um encontro com **可以吗？**;
- negar disponibilidade com **没有**;
- manter o padrão temporal sem copiar a ordem do português;
- produzir três horários novos sem olhar o mapa.

### 9. Conexões com Aulas Anteriores

Recicla:

- perguntas com **什么**;
- afirmação/negação;
- **吗** e **呢** como recursos interacionais;
- intenção de combinar uma ação com outra pessoa.

Expande a rede para **pessoa → lugar → tempo → encontro**.

---

## AULA 8 – Dizer o que sabe fazer e o que prefere

### 1. Objetivo de Fala

Ao final da aula, o aluno deve conseguir dizer que sabe ou não sabe fazer algo, perguntar sobre a habilidade de outra pessoa e expressar uma preferência simples.

### 2. Mapa Mental Principal

**Tipo:** mapa de capacidade, preferência e contraste.

**Núcleo azul-escuro:** dizer o que consegue fazer e escolher entre opções.

**Ramos primários:**

1. **Capacidade — azul-claro**
   - 我会 + [ação].
   - 我不会 + [ação].

2. **Perguntar capacidade — verde**
   - 你会说中文吗？
   - 你会不会说中文？

3. **Preferência — azul-claro**
   - 我喜欢 + [objeto/ação].
   - 我不喜欢 + [objeto/ação].

4. **Escolha — verde**
   - 你喜欢茶还是咖啡？
   - 我喜欢茶。

5. **Contraste — vermelho**
   - 会: saber fazer; ter habilidade.
   - 能: poder/conseguir em determinada situação.

6. **Pronúncia — laranja**
   - 会 huì, 喜欢 xǐhuan, 还是 háishi, 咖啡 kāfēi.

### 3. Padrões e Frases-Chave

#### Padrão A — Capacidade

```text
我会 + [ação]。
Wǒ huì + [ação].
Eu sei/consigo + [ação].
```

#### Padrão B — Incapacidade

```text
我不会 + [ação]。
Wǒ bú huì + [ação].
Eu não sei/não consigo + [ação].
```

#### Padrão C — Preferência

```text
我喜欢 + [opção]。
Wǒ xǐhuan + [opção].
Eu gosto de + [opção].
```

#### Frases de alta frequência

1. 我会说中文。  
   **Wǒ huì shuō Zhōngwén.**  
   Eu sei falar chinês.

2. 我会说一点中文。  
   **Wǒ huì shuō yìdiǎn Zhōngwén.**  
   Eu sei falar um pouco de chinês.

3. 我不会说得很快。  
   **Wǒ bú huì shuō de hěn kuài.**  
   Eu não consigo falar rápido.

4. 你会说英语吗？  
   **Nǐ huì shuō Yīngyǔ ma?**  
   Você fala inglês?

5. 我喜欢喝茶。  
   **Wǒ xǐhuan hē chá.**  
   Eu gosto de beber chá.

6. 我不喜欢喝咖啡。  
   **Wǒ bù xǐhuan hē kāfēi.**  
   Eu não gosto de beber café.

7. 你喜欢茶还是咖啡？  
   **Nǐ xǐhuan chá háishi kāfēi?**  
   Você prefere chá ou café?

8. 我喜欢茶。  
   **Wǒ xǐhuan chá.**  
   Eu prefiro chá.

### 4. Vocabulário Funcional

- 会 — **huì** — saber fazer; conseguir por habilidade
- 不会 — **bú huì** — não saber fazer
- 喜欢 — **xǐhuan** — gostar; preferir
- 不喜欢 — **bù xǐhuan** — não gostar
- 还是 — **háishi** — ou, em pergunta de escolha
- 快 — **kuài** — rápido
- 慢 — **màn** — devagar
- 说 — **shuō** — falar
- 中文 — **Zhōngwén** — chinês
- 英语 — **Yīngyǔ** — inglês
- 茶 — **chá** — chá
- 咖啡 — **kāfēi** — café

### 5. Pontos Críticos de Pronúncia e Tons

- **会 huì** é quarto tom e deve soar distinto de **回 huí**, que significa voltar. O contexto também ajuda, mas o tom é parte da diferença.
- **喜欢 xǐhuan:** a segunda sílaba é frequentemente neutra. Não dê a **huan** a mesma força de **xǐ**.
- **还是 háishi:** não use **或者** nesta aula. Para uma pergunta de escolha, mantenha o padrão apresentado.
- **不会 bú huì:** **不** muda para segundo tom antes de **会**, que é quarto tom.
- **茶 chá** é segundo tom. Evite produzir como um primeiro tom estável ou como o “chá” português com a mesma configuração articulatória.

### 6. Exercícios de Recombinação

1. Diga que sabe falar chinês.
2. Diga que sabe falar um pouco de chinês.
3. Diga que não consegue falar rápido.
4. Pergunte se a pessoa fala inglês.
5. Diga que gosta de chá.
6. Pergunte se a pessoa prefere chá ou café.

### 7. Tarefa de Produção Oral (sem olhar)

Faça uma autoentrevista:

```text
O que você sabe fazer? → O que não consegue fazer? → Do que gosta? →
Qual opção prefere?
```

Produza respostas diferentes em duas rodadas. Na segunda, altere idioma, bebida e velocidade.

### 8. Critério de Domínio

Avance quando conseguir:

- diferenciar **会** de uma simples expressão de desejo;
- produzir afirmação e negação de capacidade;
- perguntar preferência com **还是**;
- produzir quatro frases sem pinyin visível;
- manter o contraste tonal de **huì**, **chá** e **kāfēi**.

### 9. Conexões com Aulas Anteriores

Recicla:

- idiomas da Aula 2;
- pedidos e bebidas da Aula 5;
- negação das Aulas 2, 3 e 5;
- perguntas de escolha e confirmação.

Expande a rede para **capacidade → preferência → escolha social**.

---

## AULA DE CONSOLIDAÇÃO 2 – Organizar uma interação completa

### 1. Objetivo de Fala

Ao final da consolidação, o aluno deve conseguir conduzir uma interação curta que envolva pedido, localização, horário, capacidade e preferência, usando o mapa somente como apoio inicial.

### 2. Mapa Mental Principal

**Tipo:** mapa integrador de situação.

**Núcleo dourado:** resolver uma necessidade cotidiana em mandarim.

```text
[N] situação cotidiana
 ├── [A] pedir algo
 ├── [B] localizar pessoa/objeto
 ├── [C] combinar horário
 ├── [D] dizer o que consegue fazer
 ├── [E] escolher uma opção
 └── [R] concluir sem mapa
```

**Código:**

- Azul-escuro: objetivo da interação.
- Azul-claro: padrões de cada função.
- Verde: itens, lugares, horários e opções.
- Laranja: tons e pontos fonéticos já trabalhados.
- Vermelho: **在/是**, **会/想**, **还是** em perguntas de escolha, **不/没**.
- Dourado: transferência final.

### 3. Padrões e Frases-Chave

1. 我想要一杯茶。  
   **Wǒ xiǎng yào yì bēi chá.**  
   Quero uma xícara de chá.

2. 洗手间在哪儿？  
   **Xǐshǒujiān zài nǎr?**  
   Onde fica o banheiro?

3. 我们明天上午九点见，可以吗？  
   **Wǒmen míngtiān shàngwǔ jiǔ diǎn jiàn, kěyǐ ma?**  
   Nos vemos amanhã às nove da manhã, pode ser?

4. 我会说一点中文。  
   **Wǒ huì shuō yìdiǎn Zhōngwén.**  
   Sei falar um pouco de chinês.

5. 你喜欢茶还是咖啡？  
   **Nǐ xǐhuan chá háishi kāfēi?**  
   Você prefere chá ou café?

6. 我没听懂，请再说一遍。  
   **Wǒ méi tīng dǒng, qǐng zài shuō yí biàn.**  
   Não entendi, por favor repita.

### 4. Vocabulário Funcional

- 想要 — **xiǎng yào** — querer
- 一杯 — **yì bēi** — uma xícara/copo
- 茶 — **chá** — chá
- 洗手间 — **xǐshǒujiān** — banheiro
- 在哪儿 — **zài nǎr** — onde fica
- 明天 — **míngtiān** — amanhã
- 可以吗 — **kěyǐ ma** — pode ser?
- 会说 — **huì shuō** — saber falar
- 还是 — **háishi** — ou, em escolha
- 听懂 — **tīng dǒng** — entender ao ouvir

### 5. Pontos Críticos de Pronúncia e Tons

A consolidação deve testar transferência, não introduzir nova teoria. Revise:

- **bú yào**, **bú huì** e **bú shì**;
- **méi tīng dǒng**;
- **yì bēi** e **yí biàn**;
- **zài nǎr**;
- **chá**, **huì**, **kěyǐ** e **kāfēi**.

A pergunta tonal principal é: o aluno consegue reconhecer e produzir a expressão quando ela aparece dentro de uma frase maior?

### 6. Exercícios de Recombinação

1. Troque chá por café.
2. Troque amanhã por hoje.
3. Troque o horário das nove para as três.
4. Troque “falo um pouco de chinês” por “falo inglês”.
5. Diga que não entendeu e peça repetição.
6. Diga onde está um objeto antes de fazer o pedido.

### 7. Tarefa de Produção Oral (sem olhar)

Escolha uma das situações:

- você está em um café;
- você está encontrando uma pessoa;
- você está procurando um banheiro;
- você está conversando com alguém que fala rápido.

Produza um diálogo de 90 segundos contendo pelo menos quatro funções:

```text
pedido + localização + tempo/encontro + capacidade/preferência + reparo
```

Faça uma segunda rodada sem consultar o mapa completo e altere três elementos.

### 8. Critério de Domínio

O PDF 01 está dominado quando o aluno consegue:

- executar a situação durante 90 segundos;
- produzir pelo menos oito frases funcionais;
- recombinar três elementos sem retornar ao exemplo original;
- reparar uma falha de compreensão;
- manter pronúncia funcional nos contrastes principais;
- consultar, no máximo, o prompt mínimo durante a segunda rodada.

### 9. Conexões com Aulas Anteriores

Integra as Aulas 1–8 em uma única rede:

```text
pessoa → identidade → compreensão → objeto → pedido →
localização → tempo → capacidade → preferência → transferência
```

---

# Protocolo final de revisão de 14 dias

## Dia 1

Revisar o mapa completo das Aulas 1 e 2. Produzir uma apresentação de 30 segundos.

## Dia 2

Usar mapas lacunados das Aulas 1–3. Fazer um pedido de repetição sem olhar.

## Dia 3

Revisar a Aula 4 e identificar três objetos. Produzir perguntas e respostas.

## Dia 4

Fazer a Consolidação 1 com mapa mínimo.

## Dia 5

Revisar a Aula 5 e produzir cinco pedidos.

## Dia 6

Revisar a Aula 6 com objetos e locais reais.

## Dia 7

Revisar Aulas 5 e 6 sem tradução visível.

## Dia 8

Revisar a Aula 7 e combinar dois horários diferentes.

## Dia 9

Revisar a Aula 8 e fazer a autoentrevista.

## Dia 10

Usar mapas lacunados das Aulas 5–8.

## Dia 11

Fazer a Consolidação 2 com o mapa integrador.

## Dia 12

Repetir a Consolidação 2 com apenas prompts mínimos.

## Dia 13

Gravar uma interação de 90 segundos sem consultar o material.

## Dia 14

Avaliar domínio nas quatro dimensões:

```text
compreensão auditiva
recuperação oral
pronúncia funcional
transferência
```

---

# Ficha de autoavaliação

Para cada aula, marque de 0 a 2:

```text
0 = ainda não consigo
1 = consigo com hesitação ou apoio
2 = consigo sem apoio relevante
```

| Aula | Compreensão | Recuperação | Pronúncia funcional | Transferência | Total |
|---|---:|---:|---:|---:|---:|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |
| 4 |  |  |  |  |  |
| 5 |  |  |  |  |  |
| 6 |  |  |  |  |  |
| 7 |  |  |  |  |  |
| 8 |  |  |  |  |  |

### Regra de avanço

Considere uma aula funcionalmente dominada quando obtiver pelo menos:

- **2** em compreensão;
- **2** em recuperação;
- **1** ou **2** em pronúncia funcional;
- **2** em transferência.

Se a pronúncia ficar em **0**, não compense com mais leitura. Retorne ao áudio, reduza a velocidade quando apropriado, escute o contraste e grave uma nova tentativa. Um PDF organiza a prática, mas não substitui feedback auditivo ou humano.

---

# Encerramento

O objetivo deste primeiro PDF não é fazer o aluno decorar mais frases. É fazê-lo perceber que uma estrutura ouvida pode ser reconstruída, modificada e usada em uma situação nova.

```text
O ÁUDIO INTRODUZ.
A RECUPERAÇÃO DISPONIBILIZA.
O MAPA ORGANIZA.
A RECOMBINAÇÃO EXPANDE.
A TRANSFERÊNCIA COMPROVA.
```

Mandarim em Rede é um companion independente e não oficial. O áudio Pimsleur continua sendo o motor principal de escuta, antecipação e produção. Este material existe para tornar as relações mais visíveis e a fala mais transferível, sem transformar o estudo em releitura passiva.
