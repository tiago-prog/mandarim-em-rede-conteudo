# Banco pedagógico — Mandarim em Rede
## Fundamentos de transferência oral para estudantes brasileiros de mandarim

**Versão editorial final.** Documento independente, não oficial e complementar ao estudo auditivo.

> **Posicionamento obrigatório:** Mandarim em Rede não é afiliado, endossado, patrocinado nem autorizado pela Pimsleur. O nome Pimsleur aparece apenas para indicar um percurso de uso compatível. Este banco não reproduz diálogos, transcrições, roteiros, vozes, áudios ou qualquer material proprietário de terceiros.

---

## 1. Finalidade e limite do banco

Mandarim em Rede é uma camada de **transferência oral**. Seu trabalho começa depois que o estudante ouviu e tentou recuperar uma estrutura em seu curso ou áudio principal. O material torna visíveis as relações entre intenção, ordem, componentes variáveis, som e contexto; em seguida, retira o suporte até que o estudante produza uma resposta nova sem depender do mapa.

A promessa é deliberadamente limitada: **ouvir uma estrutura, reconstruí-la, recombiná-la e usá-la em uma situação não ensaiada**. O banco não promete fluência, sotaque nativo, correção automática de tons, retenção garantida ou substituição de áudio, professor, interlocutor, ferramenta de pronúncia ou contato social.

O usuário primário é o adulto brasileiro iniciante ou falso iniciante que já pratica mandarim com áudio estruturado, consegue repetir parte do repertório, mas ainda depende da ordem original para falar. O conteúdo também pode ser usado por estudantes de outros cursos auditivos, desde que o áudio continue sendo a fonte primária de escuta e antecipação.

O banco ocupa uma posição diferente de uma biblioteca multimídia, de um deck de repetição espaçada, de uma comunidade de conversação ou de um curso paralelo. Esses formatos já cumprem funções próprias.[1] [2] [3] [4] Aqui, o foco é a passagem entre **lembrar uma frase** e **usar um padrão em outra situação**.

### 1.1 O ciclo de uso

```text
ÁUDIO PRINCIPAL → TENTATIVA → MAPA DE ORIENTAÇÃO → RECUPERAÇÃO
→ RECOMBINAÇÃO → TRANSFERÊNCIA → PRODUÇÃO SEM MAPA
```

O áudio deve ser realizado sem o PDF aberto. A consulta visual acontece depois da tentativa inicial. O mapa é um meio de organização e diagnóstico; o resultado é a produção oral sem o mapa.

### 1.2 O que entra e o que fica fora

| Entra neste banco | Fica fora deste banco |
|---|---|
| Funções comunicativas iniciais de alto uso | Transcrição integral ou parcial de lições de terceiros |
| Padrões produtivos com componentes identificados | Reprodução de diálogos, roteiros, vozes ou áudios proprietários |
| Caracteres simplificados como apoio visual | Curso completo de escrita de hanzi |
| Pinyin com marcas tonais quando necessário | Promessa de correção fonética por leitura |
| Tradução funcional em português brasileiro | Tradução palavra por palavra tratada como regra |
| Prompts de recuperação e transferência | Exercícios baseados apenas em reconhecimento visual |
| Contrastes que previnem decisões erradas | Lista extensa de vocabulário sem função de uso |
| Revisão cumulativa com suporte decrescente | Scheduler ou sistema SRS concorrente com o Anki |
| Preparação para interação social | Comunidade, interlocutor ou feedback humano incorporado |
| Autoavaliação por compreensão, recuperação, pronúncia funcional e transferência | Promessa de HSK, fluência geral ou domínio de todos os tons |

---

## 2. Unidade editorial: a célula de transferência

A menor unidade do banco é a **célula de transferência**. Uma célula contém uma única intenção comunicativa, um padrão central, poucos slots, uma extensão opcional, um contraste relevante, um prompt de recuperação, um prompt de transferência e critérios de domínio.

A pergunta editorial que testa uma célula é: **“Que ação oral o estudante está treinando para executar?”** Se a resposta contiver duas ações principais, a célula deve ser dividida. Por exemplo, “perguntar o nome e dizer de onde é” pode aparecer na consolidação, mas não deve ser tratado como uma única célula de introdução.

### 2.1 Exemplo, slot, extensão e contraste

Os quatro termos não são intercambiáveis.

| Rótulo | Definição operacional | O que o estudante faz | Exemplo neste banco |
|---|---|---|---|
| **Exemplo [E]** | Frase completa que mostra uma escolha linguística concreta | Observa depois de tentar e identifica a função | `我叫安娜。 Wǒ jiào Ānnà. Eu me chamo Ana.` |
| **Slot [S]** | Espaço substituível dentro de um padrão já estável | Troca um item sem alterar a operação central | `[nome]` em `我叫 + [nome]` |
| **Extensão [O]** | Recurso opcional que amplia a função depois que o núcleo está estável | Acrescenta informação ou cortesia sem ser necessário ao primeiro êxito | `很高兴认识你。 Hěn gāoxìng rènshi nǐ. Prazer em conhecer você.` |
| **Contraste [X]** | Duas opções que exigem decisões diferentes ou tendem a ser confundidas | Escolhe a forma adequada ao sentido e explica a diferença funcional | `是 shì` identifica; `说 shuō` indica falar um idioma |

Um exemplo não é automaticamente um padrão. `我叫安娜` é um exemplo até que o estudante consiga trocar o nome. Um slot não é uma lista aberta de palavras: ele deve ter limites semânticos e fonológicos. Uma extensão não pode ser cobrada antes do padrão-base. Um contraste só entra quando previne uma decisão real de compreensão ou produção.

### 2.2 Notação editorial

O material usa a seguinte notação quando ela ajuda a leitura:

- `[N]` — intenção ou operação central;
- `[F]` — componente fixo e ordem estável;
- `[S]` — componente substituível;
- `[O]` — extensão opcional;
- `[A]` — alerta auditivo, tonal ou fonético;
- `[X]` — contraste ou erro previsível;
- `[T]` — tradução funcional de apoio, removível;
- `[R]` — recuperação, transferência ou domínio.

A notação não deve virar uma nova matéria para o iniciante. Na versão diagramada, rótulos escritos e forma dos blocos devem acompanhar as cores, para que o sentido não dependa apenas da cor ou da impressão colorida.

### 2.3 Estados de suporte

Cada célula existe em quatro estados de uso. O conteúdo linguístico é o mesmo; o apoio diminui.

| Estado | O que aparece | Momento | Evidência buscada |
|---|---|---|---|
| **Orientação** | Caracteres, pinyin tonal, tradução funcional, padrão, slots e contraste | Após o áudio e a primeira tentativa | O estudante entende a função e a arquitetura |
| **Recuperação** | Intenção, componentes fixos e lacunas nos slots | Na mesma sessão ou no dia seguinte | O estudante reconstrói antes de consultar a resposta |
| **Transferência** | Situação, intenção e poucos gatilhos | Depois de três recombinações controladas | O estudante usa o padrão fora do exemplo |
| **Independência** | Apenas situação, prompt oral ou estímulo auditivo | Revisão tardia e consolidação | O estudante responde sem depender do mapa |

A regra de design é simples: **o mapa começa completo e termina dispensável**. Se o estudante precisa do mesmo mapa cheio para continuar respondendo, o suporte não foi retirado corretamente.

---

## 3. Protocolo diário de uso

A sessão visual e oral de cada aula deve caber, em geral, em **12 a 20 minutos**, além do áudio principal realizado separadamente. Uma rotina completa pode durar de 25 a 35 minutos quando inclui ativação e registro.

1. **Ativação — 2 a 3 minutos.** Recupere uma célula anterior com um prompt curto. Não reabra o mapa completo automaticamente.
2. **Áudio principal.** Ouça e tente responder sem acompanhar o PDF. Não transforme a escuta em leitura guiada.
3. **Registro de falha.** Anote somente a função ou o contraste que falhou. Não pause para consultar cada palavra.
4. **Orientação — 2 minutos.** Consulte o mapa completo após a tentativa. Localize o fixo, os slots, a extensão e o contraste.
5. **Recuperação — 3 a 5 minutos.** Feche a resposta completa. Produza a estrutura a partir da intenção e preencha as lacunas.
6. **Recombinação — 3 a 5 minutos.** Faça pelo menos três substituições controladas. Não introduza vocabulário novo apenas para “variar”.
7. **Transferência — 2 a 4 minutos.** Use um prompt que mude o contexto, a pessoa, o objeto, o tempo ou a necessidade.
8. **Registro — 1 minuto.** Marque compreensão, recuperação, pronúncia funcional e transferência. Um campo não substitui outro.

Se o estudante falhar na compreensão, volta ao áudio. Se falhar na recuperação, volta ao mapa lacunado. Se falhar em um contraste tonal, volta à escuta e à imitação com áudio. Se falhar na transferência, reduz o número de slots, não aumenta a explicação.

---

## 4. Política linguística e de representação

### 4.1 Caracteres simplificados

Os caracteres desta versão são **simplificados**. Eles aparecem como apoio visual e como forma de associar som, sentido e palavra, mas não são pré-requisito para começar a falar. Durante a primeira tentativa, o estudante não deve receber a frase completa em caracteres, pinyin e português ao mesmo tempo.

A sequência recomendada é:

```text
intenção/contexto → tentativa oral → caracteres + pinyin → tradução funcional
```

A grafia serve para organizar a rede depois da recuperação. Ela não substitui a escuta.

### 4.2 Pinyin e tons

Todo pinyin apresentado como modelo recebe marcas tonais, salvo quando a sílaba estiver explicitamente indicada como neutra. O pinyin não deve ser lido pelos valores ortográficos do português brasileiro. Em especial, `q`, `x`, `j`, `zh`, `ch`, `sh`, `r`, `ü` e finais como `-ng` exigem referência auditiva.

As regras de mudança tonal são instruções de escuta, não promessas de correção por texto:

- em `你好`, a forma lexical é `nǐ hǎo`, mas a primeira sílaba costuma ser realizada como segundo tom em fala conectada: `ní hǎo`;
- `不 bù` costuma ser realizado como `bú` antes de uma sílaba de quarto tom: `不是 bú shì`, `不要 bú yào`, `不会 bú huì`;
- `一 yī` muda de realização de acordo com a sílaba seguinte: `一杯 yì bēi`, `一遍 yí biàn`;
- terceiros tons em sequência e tons neutros devem ser aprendidos na expressão completa, não por aplicação mecânica de uma regra isolada;
- uma marca tonal impressa informa o alvo lexical. Ela não substitui a percepção do áudio nem a avaliação de uma pessoa ou ferramenta adequada.

**Limite obrigatório:** sem áudio, não se deve declarar que o estudante “corrigiu” a pronúncia. O material pode apontar o contraste, indicar o alvo e pedir uma gravação ou comparação auditiva; a confirmação exige escuta, feedback humano ou ferramenta validada.

### 4.3 Tradução natural brasileira

A tradução informa a função que o brasileiro usaria em situação equivalente. Ela não promete correspondência palavra por palavra. Quando a tradução literal explicar uma decisão importante, ela pode ser apresentada como nota curta, nunca como a única tradução “correta”.

Exemplos:

- `你叫什么名字？` recebe **“Qual é o seu nome?”**, não “Você se chama qual nome?”;
- `你呢？` recebe **“E você?”**, porque a partícula devolve o foco ao interlocutor;
- `我没听懂。` recebe **“Eu não entendi.”**, embora a estrutura codifique uma falha em uma tentativa de compreensão;
- `可以吗？` recebe **“Pode ser?”**, não apenas “Pode?” quando a função é propor e pedir confirmação.

### 4.4 Partículas e marcadores: explicar por operação

A explicação só entra quando muda uma decisão de compreensão ou produção. Não se deve apresentar uma definição abstrata que não resulte em uma tarefa oral.

| Forma | Operação nesta etapa | Exemplo | Tradução funcional | O que não prometer |
|---|---|---|---|---|
| `吗 ma` | Transforma uma afirmação em pergunta polar de sim/não | `你好吗？ Nǐ hǎo ma?` | Você está bem? | Não é um marcador universal de qualquer pergunta |
| `呢 ne` | Devolve a pergunta ao interlocutor ou mantém o tópico aberto | `你呢？ Nǐ ne?` | E você? | Não deve ser traduzida sempre pela mesma palavra |
| `的 de` | Liga pessoa/entidade a um nome; pode permitir omitir o nome já conhecido | `我的书 wǒ de shū` / `我的 wǒ de` | meu livro / o meu | Não é uma tradução automática de “de” em qualquer frase |
| `了 le` | Marca mudança de estado ou resultado relevante agora | `我听懂了。 Wǒ tīng dǒng le.` | Agora eu entendi. | Não equivale simplesmente a “passado” |
| `不 bù` | Nega estado, hábito, vontade ou ação não realizada como regra do padrão | `我不喜欢咖啡。` | Não gosto de café. | Não deve substituir `没` em toda negação |
| `没 méi` | Nega ocorrência, resultado ou posse em uma construção específica | `我没听懂。` / `我没有时间。` | Não entendi / não tenho tempo | Não é apenas uma versão “mais forte” de `不` |
| `还是 háishi` | Oferece alternativas em pergunta de escolha | `茶还是咖啡？` | chá ou café? | Não é a escolha padrão para toda ocorrência de “ou” |

A tabela é operacional. Ela não pretende cobrir todas as funções gramaticais dessas formas no idioma.

---

## 5. Matriz de prioridade das dez primeiras aulas

O primeiro ciclo tem **oito aulas de função** e **duas consolidações**. As consolidações não introduzem uma nova teoria: combinam células já praticadas em situações novas.

| Prioridade | Aula | Operação principal | Pré-requisito | Núcleo fixo | Slots prioritários | Extensão controlada | Contraste central | Evidência de saída |
|---|---:|---|---|---|---|---|---|---|
| P0 | 1 | iniciar contato e dizer o nome | nenhum | `我叫 + nome` | nomes | `你呢？`; `很高兴认识你` | `我` × `你`; `叫` × `名字` | troca de quatro falas sem leitura |
| P0 | 2 | identificar origem e idioma | Aula 1 | `我是 + nacionalidade`; `我说 + idioma` | países, nacionalidades, idiomas | `一点中文` | `是` × `说` | origem e idioma com dois slots |
| P0 | 3 | reparar falha de compreensão | Aula 2 | `我没听懂`; `请再说一遍` | tipo de reparo | `你能...吗？` | `没` × `不`; `了` como mudança/resultado | pedir repetição sem colapsar a intenção |
| P0 | 4 | identificar e confirmar posse | Aulas 1–3 | `这是 + nome`; `X 的 Y` | objeto, pessoa | `那是他的...` | `这` × `那`; `是` × `在` | três objetos e duas posses |
| P1 | 5 | expressar desejo e pedir item | Aula 4 | `我想 + ação`; `请给我 + item` | bebida, comida, item apontado | `我想要一杯...` | `想` × `要`; `不要` | cinco pedidos com uma recusa |
| P1 | 6 | localizar pessoa ou objeto | Aula 4 | `X 在哪儿？`; `X 在 lugar` | pessoa, objeto, aqui, ali, dentro | `哪里` como variante | `在` × `是` | seis perguntas/respostas espaciais |
| P1 | 7 | organizar horário e encontro | Aulas 3–6 | `tempo + horário，可以吗？` | hoje, amanhã, horas | manhã, tarde, noite | `有时间` × `没有时间`; `吗` | três propostas e uma recusa |
| P1 | 8 | indicar capacidade e preferência | Aulas 2 e 5 | `我会 + ação`; `我喜欢 + opção` | idiomas, bebidas | pergunta A-not-A; `还是` | `会` × `能`; `还是` × `或者` | quatro respostas e uma escolha |
| P0 de consolidação | 9 | integrar identidade, objeto e reparo | Aulas 1–4 | combinações anteriores | slots já dominados | contexto de primeiro encontro | `是/说`, `这/那`, `不/没` | simulação de 60 segundos |
| P0 de consolidação | 10 | resolver situação cotidiana | Aulas 1–8 | combinações anteriores | itens, lugares, horários, opções | cenário social novo | `在/是`, `会/想`, `还是` | interação de 90 segundos sem mapa completo |

A prioridade não indica quantidade de páginas. Indica dependência pedagógica. Uma aula posterior não deve ser usada para encobrir uma falha estrutural de uma aula anterior.

---

# 6. Banco de células e aulas

## Aula 1 — Cumprimentar e dizer o próprio nome

### Ficha da célula

- **Função:** iniciar uma interação e identificar as pessoas.
- **Objetivo observável:** cumprimentar, perguntar o nome, responder com o próprio nome e devolver a pergunta sem ler.
- **Pré-requisito:** nenhum.
- **Carga:** um padrão central e uma extensão de cortesia.
- **Mapa:** função + padrão.

### Mapa de orientação

```text
[N] iniciar contato
 ├── [F] 你好。                  saudação
 ├── [F] 你叫什么名字？          pergunta de nome
 ├── [S] 我叫 + [nome]           resposta
 ├── [O] 你呢？                  devolução da pergunta
 ├── [O] 很高兴认识你。          cortesia
 └── [X] 你/我 e 叫/名字         decisão de referência
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `你好。` | **Nǐ hǎo.** | Olá. |
| `你叫什么名字？` | **Nǐ jiào shénme míngzi?** | Qual é o seu nome? |
| `我叫安娜。` | **Wǒ jiào Ānnà.** | Eu me chamo Ana. |
| `你呢？` | **Nǐ ne?** | E você? |

### Slots [S]

| Slot | Valores controlados | Observação |
|---|---|---|
| `[nome]` | `安娜 Ānnà`, `保罗 Bǎoluó` ou o nome do estudante | Troque apenas o nome; preserve `我叫`. |
| `[participante]` | `我 wǒ`, `你 nǐ` | O pronome muda quem fala ou quem é perguntado. |

### Extensões [O]

- `你好吗？ Nǐ hǎo ma? — Tudo bem com você?` Use apenas depois de a saudação estar estável.
- `很高兴认识你。 Hěn gāoxìng rènshi nǐ. — Prazer em conhecer você.` A extensão acrescenta cortesia; não é necessária para cumprir a função inicial.

### Contrastes [X]

- `我 wǒ` significa **eu**; `你 nǐ` significa **você**. O erro mais provável é trocar o participante ao recuperar a pergunta.
- `叫 jiào` integra o padrão de nome; `名字 míngzi` nomeia a informação perguntada. A pergunta não deve ser montada pela ordem do português.
- `你呢？` devolve o foco ao interlocutor. Não é uma nova pergunta lexical completa.

### Foco auditivo [A]

- `nǐ hǎo` é escrito com dois terceiros tons, mas a primeira sílaba costuma soar como segundo tom em fala conectada: ouça a expressão inteira.
- `叫 jiào` é quarto tom; compare a queda curta com o áudio.
- Em `名字 míngzi`, `zi` costuma ser neutro e não recebe o mesmo peso de `míng`.
- O pinyin não informa sozinho como produzir `n`, `j` ou `q` para um brasileiro. Não declare correção sem ouvir a produção.

### Prompt de recuperação [R]

Feche o mapa e responda oralmente. Só depois confira o gabarito.

1. Cumprimente uma pessoa.
2. Pergunte o nome dela.
3. Diga: “Eu me chamo Ana.”
4. Devolva a pergunta: “E você?”
5. Repita a troca usando Paulo em vez de Ana.

**Gabarito para conferência posterior:**

```text
你好。Nǐ hǎo. — Olá.
你叫什么名字？Nǐ jiào shénme míngzi? — Qual é o seu nome?
我叫安娜。Wǒ jiào Ānnà. — Eu me chamo Ana.
你呢？Nǐ ne? — E você?
```

### Prompt de transferência [R]

Você entrou em uma aula on-line e ainda não conhece a pessoa. Faça duas rodadas de quatro falas: saudação, pergunta de nome, resposta e devolução da pergunta. Na segunda rodada, mude o nome e acrescente a extensão de cortesia. Não consulte o mapa completo.

### Critério de domínio

A célula está pronta para a Aula 2 quando o estudante:

- reconhece a função de saudação e nome em um estímulo auditivo;
- produz a pergunta e a resposta sem traduzir palavra por palavra;
- usa pelo menos dois nomes;
- devolve a pergunta com `你呢？`;
- registra o foco tonal a partir do áudio, sem considerar a leitura como prova de pronúncia.

---

## Aula 2 — Dizer de onde é e que idioma fala

### Ficha da célula

- **Função:** identificar origem e idioma.
- **Objetivo observável:** perguntar a origem, responder com país/nacionalidade e dizer um idioma.
- **Pré-requisito:** `你`, `我`, pergunta de nome e estrutura sujeito-verbo-informação.
- **Carga:** dois padrões próximos, mantidos separados por operação.
- **Mapa:** função + padrão + contraste.

### Mapa de orientação

```text
[N] identificar origem e idioma
 ├── [F] 你是哪国人？           origem
 ├── [S] 我是 + [país]人         nacionalidade
 ├── [F] 你说什么语言？          idioma
 ├── [S] 我说 + [idioma]         fala
 ├── [O] 我说一点中文。          pequena extensão
 └── [X] 是 shì × 说 shuō       ser/identificar × falar
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `你是哪国人？` | **Nǐ shì nǎ guó rén?** | De que país você é? |
| `我是巴西人。` | **Wǒ shì Bāxī rén.** | Sou brasileiro(a). |
| `你说什么语言？` | **Nǐ shuō shénme yǔyán?** | Que idioma você fala? |
| `我说葡萄牙语。` | **Wǒ shuō Pútáoyáyǔ.** | Eu falo português. |

### Slots [S]

| Slot | Valores controlados | Construção |
|---|---|---|
| `[país]` | `巴西 Bāxī`, `中国 Zhōngguó`, `美国 Měiguó` | `我是 + [país]人` |
| `[idioma]` | `葡萄牙语 Pútáoyáyǔ`, `中文 Zhōngwén`, `英语 Yīngyǔ` | `我说 + [idioma]` |

A nacionalidade é formada aqui pelo país seguido de `人 rén`: `巴西人 Bāxī rén`, `中国人 Zhōngguó rén`, `美国人 Měiguó rén`. Isso é um padrão de uso desta célula, não uma regra para todas as palavras que terminam em “-ano” no português.

### Extensões [O]

- `我说一点中文。 Wǒ shuō yìdiǎn Zhōngwén. — Eu falo um pouco de chinês.` O item `一点` reduz a afirmação; não é necessário na primeira resposta.
- `我不是中国人。 Wǒ bú shì Zhōngguó rén. — Eu não sou chinês/chinesa.` Use para testar negação depois de a afirmativa estar automatizada.

### Contrastes [X]

- `是 shì` identifica/classifica: `我是巴西人。`;
- `说 shuō` indica o idioma falado: `我说葡萄牙语。`;
- `哪 nǎ` significa “qual” nesta pergunta; não trocar por `那 nà`, “aquele/aquela”.

### Foco auditivo [A]

- `不是` costuma ser **bú shì**, porque `不` muda antes de quarto tom.
- `哪 nǎ` e `那 nà` devem ser discriminados pelo sentido e pelo áudio.
- `人 rén` não deve ser aproximado automaticamente pelo `r` do português brasileiro.
- `中文 Zhōngwén` e `英语 Yīngyǔ` precisam ser praticados em palavras completas; pinyin isolado não valida produção.

### Prompt de recuperação [R]

1. Pergunte de que país a pessoa é.
2. Responda: “Sou brasileiro(a).”
3. Pergunte que idioma a pessoa fala.
4. Responda: “Falo português.”
5. Troque Brasil por China e português por inglês.
6. Produza uma resposta negativa: “Não sou chinês/chinesa.”

**Gabarito para conferência posterior:**

```text
你是哪国人？Nǐ shì nǎ guó rén? — De que país você é?
我是巴西人。Wǒ shì Bāxī rén. — Sou brasileiro(a).
你说什么语言？Nǐ shuō shénme yǔyán? — Que idioma você fala?
我说葡萄牙语。Wǒ shuō Pútáoyáyǔ. — Eu falo português.
```

### Prompt de transferência [R]

Você conheceu alguém em um encontro internacional. Diga seu país e idioma sem usar o padrão da Aula 1. Em seguida, troque os dois slots como se estivesse interpretando outra pessoa. A segunda rodada deve incluir uma afirmação negativa.

### Critério de domínio

- compreende a diferença entre perguntar origem e perguntar idioma;
- produz duas nacionalidades e dois idiomas;
- usa `是` para identidade e `说` para idioma;
- produz uma afirmativa e uma negativa;
- mantém os contrastes-alvo ao ouvir e ao repetir com apoio de áudio.

---

## Aula 3 — Dizer que entendeu, pedir repetição e pedir velocidade menor

### Ficha da célula

- **Função:** reparar a comunicação quando a compreensão falha.
- **Objetivo observável:** dizer que entendeu ou não entendeu, pedir repetição e pedir fala mais lenta.
- **Pré-requisito:** `我`, `你`, `说`, pergunta polar e noção de pedido.
- **Carga:** um caminho positivo, um negativo e dois pedidos de reparo.
- **Mapa:** contraste + reparo.

### Mapa de orientação

```text
[N] manter a interação quando não entendeu
 ├── [F] 我听懂了。             resultado de compreensão
 ├── [F] 我没听懂。             falha de compreensão
 ├── [F] 请再说一遍。           pedir repetição
 ├── [F] 请说慢一点。           pedir menor velocidade
 ├── [O] 你能……吗？            pedido em forma de pergunta
 └── [X] 没 méi × 不 bù; 了 le  operação diferente
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `我听懂了。` | **Wǒ tīng dǒng le.** | Agora eu entendi. |
| `我没听懂。` | **Wǒ méi tīng dǒng.** | Eu não entendi. |
| `请再说一遍。` | **Qǐng zài shuō yí biàn.** | Por favor, repita. |
| `请说慢一点。` | **Qǐng shuō màn yìdiǎn.** | Por favor, fale um pouco mais devagar. |

### Slots [S]

O núcleo desta aula tem poucos slots. A produtividade está na escolha do reparo, não na troca indiscriminada de vocabulário.

| Slot | Valores | Função |
|---|---|---|
| `[reparo]` | `再说一遍` repetir; `说慢一点` falar mais devagar | Escolher a ajuda necessária |
| `[estado]` | `听懂了` entendi; `没听懂` não entendi | Marcar resultado ou falha |

### Extensões [O]

- `你能再说一遍吗？ Nǐ néng zài shuō yí biàn ma? — Você pode repetir?`
- `你能说慢一点吗？ Nǐ néng shuō màn yìdiǎn ma? — Você pode falar um pouco mais devagar?`
- `现在我明白了。 Xiànzài wǒ míngbai le. — Agora eu entendi.` Use `现在` somente depois da distinção entre falha e mudança de estado.

### Contrastes [X]

- `没` nega uma ocorrência ou resultado nesta situação: `我没听懂` = não consegui entender o que foi dito.
- `不` pode aparecer em um estado ou avaliação mais geral: `我不明白` = eu não compreendo/não estou entendendo.
- `了` em `我听懂了` marca a mudança para o estado “entendi” ou o resultado alcançado. Não ensinar como simples passado.
- `一遍` é uma repetição completa, não apenas “uma palavra”.

### Foco auditivo [A]

- `一遍` aparece como **yí biàn** antes de quarto tom; `一点` como **yìdiǎn** antes de terceiro tom.
- `没 méi` não é `每 měi`, “cada”.
- `请 qǐng`, `听 tīng` e `懂 dǒng` exigem áudio. Uma aproximação ortográfica não é critério de correção.

### Prompt de recuperação [R]

1. Diga que entendeu.
2. Diga que não entendeu.
3. Peça repetição de forma direta.
4. Peça que a pessoa fale mais devagar.
5. Transforme o pedido de repetição em pergunta com `能` e `吗`.
6. Diga que agora entendeu.

**Gabarito para conferência posterior:**

```text
我听懂了。Wǒ tīng dǒng le. — Agora eu entendi.
我没听懂。Wǒ méi tīng dǒng. — Eu não entendi.
请再说一遍。Qǐng zài shuō yí biàn. — Por favor, repita.
请说慢一点。Qǐng shuō màn yìdiǎn. — Fale um pouco mais devagar.
你能再说一遍吗？Nǐ néng zài shuō yí biàn ma? — Você pode repetir?
```

### Prompt de transferência [R]

Imagine que uma pessoa acabou de dar uma instrução rápida. Faça a sequência **não entendi → peça repetição → peça velocidade menor**. Em uma segunda rodada, comece por `我听懂了` e explique que a conversa pode continuar. A tarefa mede reparo, não memorização da ordem do exemplo.

### Critério de domínio

- escolhe entre entendimento e não entendimento de acordo com a situação;
- pede repetição sem traduzir a frase do português;
- diferencia `没` e `不` na operação trabalhada;
- usa a extensão interrogativa somente depois do pedido direto;
- usa o áudio para avaliar `méi`, `tīng`, `dǒng`, `zài` e `yí biàn`.

---

## Aula 4 — Perguntar o que é, identificar e confirmar posse

### Ficha da célula

- **Função:** identificar objeto e confirmar a quem ele pertence.
- **Objetivo observável:** perguntar “o que é isto?”, identificar objeto, confirmar posse e corrigir uma identificação.
- **Pré-requisito:** `什么`, `是`, `吗`, `你`, `我`.
- **Carga:** um padrão de identificação e um padrão de posse.
- **Mapa:** função + contraste espacial + relação nominal.

### Mapa de orientação

```text
[N] identificar e confirmar
 ├── [F] 这是什么？             pergunta de identificação
 ├── [F] 这是 + [objeto]         resposta
 ├── [S] [pessoa] 的 [objeto]    posse/relacão
 ├── [F] ……吗？                 confirmação polar
 ├── [O] 那是他的……             referência distante/terceira pessoa
 └── [X] 这 zhè × 那 nà; 是 × 在
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `这是什么？` | **Zhè shì shénme?** | O que é isto? |
| `这是我的书。` | **Zhè shì wǒ de shū.** | Este é o meu livro. |
| `这是你的水吗？` | **Zhè shì nǐ de shuǐ ma?** | Esta água é sua? |
| `对，是我的。` | **Duì, shì wǒ de.** | Sim, é minha. |
| `不是我的，是他的。` | **Bú shì wǒ de, shì tā de.** | Não é minha; é dele. |

### Slots [S]

| Slot | Valores controlados | Exemplos |
|---|---|---|
| `[objeto]` | `书 shū` livro; `手机 shǒujī` celular; `水 shuǐ` água; `包 bāo` bolsa/mochila | `这是我的书。` |
| `[possuidor]` | `我 wǒ`, `你 nǐ`, `他 tā` | `你的手机`, `他的包` |
| `[distância]` | `这 zhè` perto; `那 nà` distante | `这是什么？` / `那是什么？` |

### Extensões [O]

- `那是他的包。 Nà shì tā de bāo. — Aquela é a bolsa/mochila dele.`
- `这是我的手机吗？ Zhè shì wǒ de shǒujī ma? — Este é o meu celular?`
- `对，是你的。 Duì, shì nǐ de. — Sim, é seu.`

### Contrastes [X]

- `这` aponta para algo próximo; `那` aponta para algo mais distante. A escolha depende da situação, não da tradução fixa “este/aquele”.
- `的` liga possuidor e nome: `我的书` = meu livro. Em `我的`, o nome pode ser omitido quando já está claro: “o meu”.
- `是` identifica; `在` localiza. A Aula 6 fará a localização como operação principal.
- `吗` transforma a afirmação em pergunta de confirmação. Ele não fornece o conteúdo da resposta.

### Foco auditivo [A]

- `这 zhè` não deve ser lido como o “zé” do português.
- `水 shuǐ` precisa de áudio; uma transliteração brasileira não é alvo confiável.
- `书 shū` mantém primeiro tom relativamente estável.
- Em `不是`, a realização esperada é **bú shì** em fala conectada.

### Prompt de recuperação [R]

1. Pergunte o que é um livro.
2. Diga que este é o seu celular.
3. Pergunte se a água é da outra pessoa.
4. Responda que sim, é sua.
5. Negue que a bolsa seja sua e diga que é dele.
6. Repita com `那` para um objeto distante.

**Gabarito para conferência posterior:**

```text
这是什么？Zhè shì shénme? — O que é isto?
这是我的手机。Zhè shì wǒ de shǒujī. — Este é o meu celular.
这是你的水吗？Zhè shì nǐ de shuǐ ma? — Esta água é sua?
对，是我的。Duì, shì wǒ de. — Sim, é minha.
不是我的，是他的。Bú shì wǒ de, shì tā de. — Não é minha; é dele.
```

### Prompt de transferência [R]

Escolha três objetos reais perto de você e um objeto distante. Para cada um, pergunte o que é e responda. Em dois casos, acrescente uma pergunta de posse e corrija a resposta. Não introduza nomes de objetos que não estejam no banco.

### Critério de domínio

- usa `这` e `那` de acordo com a distância contextual;
- produz posse com `的` e consegue omitir o nome em `我的/你的/他的` quando o referente está claro;
- confirma e corrige uma informação;
- diferencia identificação de localização;
- produz três combinações de pessoa e objeto sem mapa completo.

---

## Aula 5 — Dizer o que quer e fazer um pedido simples

### Ficha da célula

- **Função:** expressar vontade e obter um item.
- **Objetivo observável:** dizer o que quer fazer, pedir um item, aceitar um item apontado e recusar algo.
- **Pré-requisito:** objetos, `请`, negação básica e identificação.
- **Carga:** intenção com ação + pedido com item.
- **Mapa:** pedido e contraste de intenção.

### Mapa de orientação

```text
[N] expressar vontade e pedir
 ├── [F] 我想 + [ação]           quero fazer
 ├── [F] 请给我 + [item]          pedido direto cortês
 ├── [S] 我想要 + [item]          quero um item
 ├── [O] 我要这个。                escolho este item
 ├── [O] 一杯 + [bebida]           medida para copo/xícara
 └── [X] 想 xiǎng × 要 yào; 不要
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `我想喝水。` | **Wǒ xiǎng hē shuǐ.** | Quero beber água. |
| `我想吃饭。` | **Wǒ xiǎng chīfàn.** | Quero comer. |
| `请给我一杯茶。` | **Qǐng gěi wǒ yì bēi chá.** | Por favor, me dê uma xícara de chá. |
| `我要这个。` | **Wǒ yào zhège.** | Quero este aqui. |
| `我不要咖啡。` | **Wǒ bú yào kāfēi.** | Não quero café. |
| `谢谢。` | **Xièxie.** | Obrigado(a). |

### Slots [S]

| Slot | Valores controlados | Construção |
|---|---|---|
| `[ação]` | `喝水 hē shuǐ` beber água; `吃饭 chīfàn` comer | `我想 + [ação]` |
| `[item]` | `水 shuǐ`, `茶 chá`, `咖啡 kāfēi`, `这个 zhège` | `请给我 + [item]` / `我要 + [item]` |
| `[bebida]` | `茶 chá`, `咖啡 kāfēi` | `一杯 + [bebida]` |

### Extensões [O]

- `我想要一杯咖啡。 Wǒ xiǎng yào yì bēi kāfēi. — Quero um café/uma xícara de café.`
- `请给我水。 Qǐng gěi wǒ shuǐ. — Por favor, me dê água.`
- `谢谢。 Xièxie. — Obrigado(a).` A cortesia fecha o pedido, mas não substitui a clareza do item.

### Contrastes [X]

- `想` orienta a vontade ou intenção de fazer algo: `我想喝水`.
- `要` pode expressar desejo, necessidade ou escolha direta de um item: `我要这个`.
- Esta distinção é um atalho pedagógico para esta unidade, não uma separação absoluta de todos os usos.
- `不要` nega a escolha/desejo do item. Não tratar como sinônimo geral de `没有`.

### Foco auditivo [A]

- `想 xiǎng` é terceiro tom; `要 yào` é quarto tom.
- `不要` aparece como **bú yào**.
- `给 gěi` não deve ser confundido com `几 jǐ`, que tem outra função e será deixado fora desta célula.
- Em `谢谢`, a segunda sílaba costuma ser neutra; não dê a ela a mesma força da primeira.

### Prompt de recuperação [R]

1. Diga que quer beber água.
2. Diga que quer comer.
3. Peça uma xícara de chá.
4. Escolha este item.
5. Diga que não quer café.
6. Feche o pedido com agradecimento.

**Gabarito para conferência posterior:**

```text
我想喝水。Wǒ xiǎng hē shuǐ. — Quero beber água.
我想吃饭。Wǒ xiǎng chīfàn. — Quero comer.
请给我一杯茶。Qǐng gěi wǒ yì bēi chá. — Por favor, me dê uma xícara de chá.
我要这个。Wǒ yào zhège. — Quero este aqui.
我不要咖啡。Wǒ bú yào kāfēi. — Não quero café.
```

### Prompt de transferência [R]

Você está em um café. Faça cinco pedidos usando dois verbos, duas bebidas e um item apontado. Inclua uma recusa e uma forma de cortesia. Na segunda rodada, altere o contexto para uma loja e use apenas o prompt **vontade → item → pedido → recusa**.

### Critério de domínio

- distingue vontade de ação e escolha de item no contexto desta aula;
- produz três pedidos com slots diferentes;
- usa `请给我` sem inserir uma ordem portuguesa;
- recusa um item com `不要`;
- reconhece `xiǎng`, `yào`, `gěi`, `chá` e `kāfēi` no áudio;
- não considera a leitura de pinyin prova de correção tonal.

---

## Aula 6 — Perguntar onde algo está

### Ficha da célula

- **Função:** localizar pessoa ou objeto.
- **Objetivo observável:** perguntar onde algo está e responder com localização próxima, distante ou interna.
- **Pré-requisito:** pessoas, objetos, `这/那` e identificação.
- **Carga:** um padrão de pergunta e um padrão de resposta.
- **Mapa:** padrão espacial + contraste com `是`.

### Mapa de orientação

```text
[N] localizar
 ├── [F] [pessoa/objeto] 在哪儿？     perguntar onde
 ├── [F] [pessoa/objeto] 在 + lugar    responder
 ├── [S] 我/你/他; 手机/书/车         referente
 ├── [S] 这里/那里/包里               lugar
 ├── [O] 哪里 nǎlǐ                    variante de “onde”
 └── [X] 在 zài × 是 shì              localizar × identificar
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `你在哪儿？` | **Nǐ zài nǎr?** | Onde você está? |
| `我在这里。` | **Wǒ zài zhèlǐ.** | Estou aqui. |
| `他在哪里？` | **Tā zài nǎlǐ?** | Onde ele está? |
| `他在那里。` | **Tā zài nàlǐ.** | Ele está ali. |
| `洗手间在哪儿？` | **Xǐshǒujiān zài nǎr?** | Onde fica o banheiro? |
| `手机在包里。` | **Shǒujī zài bāo lǐ.** | O celular está na bolsa. |

### Slots [S]

| Slot | Valores controlados | Construção |
|---|---|---|
| `[referente]` | `我 wǒ`, `你 nǐ`, `他 tā`, `手机 shǒujī`, `书 shū`, `洗手间 xǐshǒujiān` | `[referente] 在哪儿？` |
| `[lugar]` | `这里 zhèlǐ`, `那里 nàlǐ`, `包里 bāo lǐ` | `[referente] 在 + [lugar]` |

`哪儿` e `哪里` podem cumprir a função de “onde” em muitas variedades. Para o primeiro treino, escolha uma forma principal; só depois alterne as duas. `儿` não deve ser tratado como uma letra portuguesa que se pronuncia sempre do mesmo modo.

### Extensões [O]

- `书在这里。 Shū zài zhèlǐ. — O livro está aqui.`
- `手机在包里。 Shǒujī zài bāo lǐ. — O celular está na bolsa.`
- `你在哪里？ Nǐ zài nǎlǐ? — Onde você está?` Use como variante depois de estabilizar `哪儿`.

### Contrastes [X]

- `在` localiza: `手机在包里`.
- `是` identifica: `这是手机`.
- `这里` aponta para o local do falante; `那里` aponta para outro local. A escolha depende do contexto.
- A estrutura não exige um equivalente separado de “estar” antes de `在`.

### Foco auditivo [A]

- `在 zài` é quarto tom; não confunda sua operação com `是 shì`, mesmo que ambas apareçam em frases nominais.
- `这里 zhèlǐ` e `那里 nàlǐ` podem ter redução de tons em fala conectada. Ouça o bloco inteiro.
- `哪儿 nǎr` e `哪里 nǎlǐ` variam na realização. Pratique uma forma por vez.
- O `r` de `儿` não deve ser substituído por um “r” gutural brasileiro sem referência ao áudio.

### Prompt de recuperação [R]

1. Pergunte onde a outra pessoa está.
2. Responda: “Estou aqui.”
3. Pergunte onde ele está.
4. Responda: “Ele está ali.”
5. Pergunte onde fica o banheiro.
6. Diga que o celular está na bolsa.

**Gabarito para conferência posterior:**

```text
你在哪儿？Nǐ zài nǎr? — Onde você está?
我在这里。Wǒ zài zhèlǐ. — Estou aqui.
他在哪里？Tā zài nǎlǐ? — Onde ele está?
他在那里。Tā zài nàlǐ. — Ele está ali.
洗手间在哪儿？Xǐshǒujiān zài nǎr? — Onde fica o banheiro?
手机在包里。Shǒujī zài bāo lǐ. — O celular está na bolsa.
```

### Prompt de transferência [R]

Escolha três objetos reais, uma pessoa e dois locais. Para cada referente, faça uma pergunta e uma resposta. Inclua uma resposta com `这里`, uma com `那里` e uma com `里`. Na segunda rodada, troque o referente sem trocar o padrão.

### Critério de domínio

- pergunta e responde com `在` sem substituí-lo por `是`;
- usa `哪儿` ou `哪里` de forma consistente;
- produz três localizações diferentes;
- distingue `这里` e `那里` no contexto;
- responde a um prompt em português sem reconstruir a frase palavra por palavra.

---

## Aula 7 — Dizer quando algo acontece e combinar um encontro

### Ficha da célula

- **Função:** organizar tempo e disponibilidade.
- **Objetivo observável:** perguntar horário, dizer quando tem tempo e propor um encontro.
- **Pré-requisito:** perguntas com `什么`, afirmação/negação e interação com outra pessoa.
- **Carga:** tempo do evento + disponibilidade + proposta.
- **Mapa:** sequência temporal e confirmação.

### Mapa de orientação

```text
[N] organizar tempo e encontro
 ├── [F] 现在几点？                 perguntar hora
 ├── [S] 现在/今天/明天              referência temporal
 ├── [S] 九点/三点                   horário
 ├── [F] 你什么时候有时间？          disponibilidade
 ├── [F] [tempo] [horário]，可以吗？   proposta
 ├── [O] 上午/下午/晚上              parte do dia
 └── [X] 有时间 × 没有时间; 可以吗？
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `现在几点？` | **Xiànzài jǐ diǎn?** | Que horas são agora? |
| `现在九点。` | **Xiànzài jiǔ diǎn.** | Agora são nove horas. |
| `你什么时候有时间？` | **Nǐ shénme shíhou yǒu shíjiān?** | Quando você tem tempo? |
| `我明天有时间。` | **Wǒ míngtiān yǒu shíjiān.** | Tenho tempo amanhã. |
| `我今天没有时间。` | **Wǒ jīntiān méiyǒu shíjiān.** | Hoje não tenho tempo. |
| `明天上午九点，可以吗？` | **Míngtiān shàngwǔ jiǔ diǎn, kěyǐ ma?** | Amanhã às nove da manhã, pode ser? |
| `可以，没问题。` | **Kěyǐ, méi wèntí.** | Pode ser, sem problema. |

### Slots [S]

| Slot | Valores controlados | Construção |
|---|---|---|
| `[tempo]` | `现在 xiànzài`, `今天 jīntiān`, `明天 míngtiān` | posição inicial ou contexto |
| `[horário]` | `九点 jiǔ diǎn`, `三点 sān diǎn` | hora em ponto |
| `[período]` | `上午 shàngwǔ`, `下午 xiàwǔ`, `晚上 wǎnshang` | antes do horário |
| `[disponibilidade]` | `有时间 yǒu shíjiān`, `没有时间 méiyǒu shíjiān` | resposta de disponibilidade |

### Extensões [O]

- `我们明天见。 Wǒmen míngtiān jiàn. — Nos vemos amanhã.`
- `下午三点，可以吗？ Xiàwǔ sān diǎn, kěyǐ ma? — Às três da tarde, pode ser?`
- `没问题。 Méi wèntí. — Sem problema.`

A extensão acrescenta encontro ou confirmação; não deve ser cobrada antes de o estudante localizar dia e hora.

### Contrastes [X]

- `有时间` afirma disponibilidade; `没有时间` nega posse/disponibilidade na construção `有`.
- `可以吗？` propõe e pede confirmação. Não é apenas uma pergunta abstrata sobre capacidade.
- `什么时候` pergunta quando; `几点` pergunta qual é a hora.
- Em horário, os elementos vêm em blocos de tempo. Não force a ordem do português.

### Foco auditivo [A]

- `明天 míngtiān` mantém segundo tom em `míng` e primeiro tom em `tiān`.
- `时间 shíjiān` e `上午 shàngwǔ` devem ser ouvidos em expressão, não soletrados pelo português.
- `可以 kěyǐ` traz duas sílabas lexicalmente marcadas com terceiro tom, mas a fala conectada pode reduzir a primeira.
- `没有 méiyǒu` tem ritmo próprio; não dê o mesmo peso às duas sílabas.

### Prompt de recuperação [R]

1. Pergunte que horas são.
2. Diga que agora são nove horas.
3. Pergunte quando a pessoa tem tempo.
4. Diga que você tem tempo amanhã.
5. Diga que hoje não tem tempo.
6. Proponha amanhã às nove da manhã.
7. Confirme que pode ser.

**Gabarito para conferência posterior:**

```text
现在几点？Xiànzài jǐ diǎn? — Que horas são agora?
现在九点。Xiànzài jiǔ diǎn. — Agora são nove horas.
你什么时候有时间？Nǐ shénme shíhou yǒu shíjiān? — Quando você tem tempo?
我明天有时间。Wǒ míngtiān yǒu shíjiān. — Tenho tempo amanhã.
我今天没有时间。Wǒ jīntiān méiyǒu shíjiān. — Hoje não tenho tempo.
明天上午九点，可以吗？Míngtiān shàngwǔ jiǔ diǎn, kěyǐ ma? — Amanhã às nove, pode ser?
可以，没问题。Kěyǐ, méi wèntí. — Pode ser, sem problema.
```

### Prompt de transferência [R]

Escolha três horários que não apareceram nos exemplos. Para cada um, pergunte sobre disponibilidade, proponha o horário e aceite ou recuse. Use `今天`, `明天` e um período do dia em rodadas diferentes. Não repita a mesma ordem de horários do exemplo.

### Critério de domínio

- pergunta e responde a horários básicos;
- produz três propostas novas;
- usa `没有时间` para recusar disponibilidade;
- formula uma proposta com `可以吗？`;
- reconhece a ordem temporal no áudio sem depender da tradução.

---

## Aula 8 — Dizer o que sabe fazer e expressar preferência

### Ficha da célula

- **Função:** indicar capacidade e escolher uma opção.
- **Objetivo observável:** dizer o que sabe fazer, negar uma habilidade, dizer do que gosta e responder a uma escolha.
- **Pré-requisito:** idiomas, bebidas, pedidos e negação.
- **Carga:** capacidade e preferência como operações separadas.
- **Mapa:** capacidade + escolha + contraste modal.

### Mapa de orientação

```text
[N] indicar capacidade e preferência
 ├── [F] 我会 + [ação]              saber fazer
 ├── [F] 我不会 + [ação]            não saber fazer
 ├── [S] 我喜欢 + [opção]            gostar/preferir
 ├── [S] 我不喜欢 + [opção]          não gostar
 ├── [F] [opção A] 还是 [opção B]？  escolha
 ├── [O] 会不会……？                 pergunta A-não-A
 └── [X] 会 huì × 能 néng; 还是 × 或者
```

### Exemplos [E]

| Caracteres | Pinyin | Tradução funcional |
|---|---|---|
| `我会说中文。` | **Wǒ huì shuō Zhōngwén.** | Eu sei falar chinês. |
| `我会说一点中文。` | **Wǒ huì shuō yìdiǎn Zhōngwén.** | Sei falar um pouco de chinês. |
| `我不会说得很快。` | **Wǒ bú huì shuō de hěn kuài.** | Não consigo falar rápido. |
| `我喜欢喝茶。` | **Wǒ xǐhuan hē chá.** | Gosto de beber chá. |
| `你喜欢茶还是咖啡？` | **Nǐ xǐhuan chá háishi kāfēi?** | Você prefere chá ou café? |
| `我喜欢茶。` | **Wǒ xǐhuan chá.** | Prefiro chá. |

### Slots [S]

| Slot | Valores controlados | Construção |
|---|---|---|
| `[ação]` | `说中文 shuō Zhōngwén`, `说英语 shuō Yīngyǔ`, `说得很快 shuō de hěn kuài` | `我会/不会 + [ação]` |
| `[opção]` | `茶 chá`, `咖啡 kāfēi`, `喝茶 hē chá`, `喝咖啡 hē kāfēi` | `我喜欢/不喜欢 + [opção]` |
| `[A/B]` | duas opções conhecidas | `[A] 还是 [B]？` |

### Extensões [O]

- `你会不会说中文？ Nǐ huì bu huì shuō Zhōngwén? — Você sabe falar chinês?` Use depois de estabilizar a afirmativa e a negativa.
- `我不喜欢喝咖啡。 Wǒ bù xǐhuan hē kāfēi. — Não gosto de beber café.`
- `我会说一点中文。 Wǒ huì shuō yìdiǎn Zhōngwén. — Sei falar um pouco de chinês.`

### Contrastes [X]

- `会` indica habilidade aprendida ou capacidade habitual: `我会说中文`.
- `能` será usado como “poder/conseguir” em uma situação específica, como no reparo `你能再说一遍吗？`.
- `还是` oferece alternativas em pergunta de escolha. Não substituir automaticamente por `或者`, que fica fora desta aula.
- `喜欢` expressa gosto/preferência; `想` da Aula 5 expressa vontade ou intenção.

### Foco auditivo [A]

- `会 huì` é quarto tom; não confunda com `回 huí`, “voltar”.
- Em `喜欢 xǐhuan`, `huan` costuma ser neutra ou menos proeminente.
- `不会` aparece como **bú huì**.
- `茶 chá` e `咖啡 kāfēi` devem ser conferidos no áudio. Ler as marcas tonais não corrige a articulação.

### Prompt de recuperação [R]

1. Diga que sabe falar chinês.
2. Diga que sabe falar um pouco de chinês.
3. Diga que não consegue falar rápido.
4. Pergunte se a pessoa sabe falar inglês.
5. Diga que gosta de chá.
6. Pergunte se a pessoa prefere chá ou café.
7. Responda com uma preferência diferente.

**Gabarito para conferência posterior:**

```text
我会说中文。Wǒ huì shuō Zhōngwén. — Sei falar chinês.
我会说一点中文。Wǒ huì shuō yìdiǎn Zhōngwén. — Sei falar um pouco de chinês.
我不会说得很快。Wǒ bú huì shuō de hěn kuài. — Não consigo falar rápido.
你喜欢茶还是咖啡？Nǐ xǐhuan chá háishi kāfēi? — Você prefere chá ou café?
我喜欢茶。Wǒ xǐhuan chá. — Prefiro chá.
```

### Prompt de transferência [R]

Faça uma autoentrevista em duas rodadas. Na primeira, responda o que sabe fazer e do que gosta. Na segunda, escolha entre duas bebidas e troque o idioma. Use uma resposta negativa e uma pergunta de escolha. Não use o exemplo completo como roteiro.

### Critério de domínio

- diferencia capacidade de vontade;
- produz afirmação e negação de capacidade;
- formula uma preferência e uma pergunta com `还是`;
- cria pelo menos quatro frases com pinyin oculto;
- reconhece `huì`, `chá` e `kāfēi` no áudio;
- registra qualquer dúvida de pronúncia como necessidade de escuta/feedback, não como falha corrigível por mais leitura.

---

## Aula 9 — Consolidação: entrar, identificar e reparar

### Função integradora

Esta consolidação integra as Aulas 1–4. Não introduz novo vocabulário obrigatório. O objetivo é manter uma interação inicial quando o tema muda de identidade para objeto e depois para compreensão.

### Mapa de consolidação

```text
[N] primeiro contato funcional
 ├── [A1] saudação + nome
 ├── [A2] origem + idioma
 ├── [A3] reparo de compreensão
 ├── [A4] objeto + posse
 ├── [X] 是/说; 这/那; 不/没
 └── [R] situação nova sem mapa completo
```

### Recombinação cumulativa

Use somente combinações de células já introduzidas:

- `你好，我叫安娜。 Nǐ hǎo, wǒ jiào Ānnà. — Olá, eu me chamo Ana.`
- `我是巴西人，我说葡萄牙语。 Wǒ shì Bāxī rén, wǒ shuō Pútáoyáyǔ. — Sou brasileiro(a) e falo português.`
- `我没听懂，请再说一遍。 Wǒ méi tīng dǒng, qǐng zài shuō yí biàn. — Não entendi; por favor, repita.`
- `这是什么？Zhè shì shénme? — O que é isto?`
- `这是我的手机。 Zhè shì wǒ de shǒujī. — Este é o meu celular.`

Essas frases são exemplos de combinação, não um diálogo para decorar ou reproduzir. A tarefa deve alterar nomes, país, idioma, objeto e ponto de falha.

### Prompt de transferência

Simule 60 segundos em uma primeira conversa. Inclua, sem consultar o mapa completo:

```text
saudação → nome → origem → idioma → objeto → reparo de compreensão
```

Faça uma segunda rodada alterando pelo menos três elementos. Se a tarefa virar uma repetição da sequência, pare, volte ao prompt mínimo e recomece com outra intenção.

### Critério de domínio

A consolidação está funcional quando o estudante:

- executa a simulação sem o mapa de orientação;
- usa a forma adequada de `是` e `说`;
- muda `这` e `那` conforme a situação;
- repara a compreensão sem abandonar a interação;
- produz uma segunda rodada com três alterações;
- identifica se a falha foi de compreensão, recuperação ou pronúncia.

---

## Aula 10 — Consolidação: resolver uma situação cotidiana

### Função integradora

Esta consolidação integra as Aulas 1–8. Ela avalia se o estudante consegue selecionar uma função, recuperar seu padrão e combinar células sem reproduzir a ordem de uma lição ou de um exemplo.

### Mapa de consolidação

```text
[N] resolver uma necessidade cotidiana
 ├── pedir item
 ├── localizar pessoa/objeto
 ├── organizar horário
 ├── indicar capacidade
 ├── escolher preferência
 ├── reparar compreensão
 └── [R] concluir sem mapa completo
```

### Prompts de situação

Escolha um cenário. Não entregue ao estudante uma sequência de frases.

1. **Café:** peça uma bebida, diga que não quer outra e confirme uma escolha.
2. **Encontro:** pergunte onde a pessoa está, proponha um horário e confirme.
3. **Primeiro contato:** diga nome, origem e idioma; depois peça repetição.
4. **Conversa rápida:** diga que não entendeu, peça que repitam e diga o que consegue falar.
5. **Objeto perdido:** pergunte onde está o celular, identifique a bolsa e confirme a posse.

### Recombinação controlada

Antes da situação livre, faça três trocas de um único eixo:

- `茶` → `咖啡`;
- `明天` → `今天`;
- `九点` → `三点`;
- `中文` → `英语`;
- `手机` → `书`;
- `这里` → `那里`.

Depois combine dois eixos. Não introduza uma terceira troca se a primeira combinação ainda exigir consulta ao mapa completo.

### Critério de domínio

O ciclo está funcionalmente consolidado quando o estudante:

- sustenta uma situação por aproximadamente 90 segundos;
- produz pelo menos oito frases funcionais sem ler um diálogo;
- faz três recombinações que não repetem o exemplo;
- repara uma falha de compreensão;
- seleciona `是/在`, `会/想`, `还是` e `不/没` pela operação necessária;
- realiza uma segunda rodada usando apenas o prompt mínimo ou nenhum suporte visual.

A contagem de frases não basta. Uma produção longa com repetição literal não é transferência.

---

# 7. Revisão cumulativa e protocolo de 14 dias

A revisão é distribuída por **desempenho e intervalo**, não por repetição automática do mesmo exemplo. A sequência recomendada é **mesmo dia → dia seguinte → três a sete dias depois → consolidação**.[5] [6]

| Dia | Tarefa | Suporte permitido | Falha que orienta a próxima ação |
|---:|---|---|---|
| 1 | Aulas 1–2: apresentação, origem e idioma | orientação após tentativa; recuperação lacunada | se não recuperar, manter os slots; não adicionar vocabulário |
| 2 | Aulas 1–3: nome + reparo | lacunas; sem tradução durante a fala | se falhar em `没/不`, revisar a operação |
| 3 | Aula 4: três objetos e duas posses | mapa lacunado | se trocar `这/那`, usar objetos reais e distância visível |
| 4 | Consolidação 1 | prompt mínimo | se depender do mapa, retornar à célula específica |
| 5 | Aula 5: cinco pedidos | orientação só para conferência | se trocar `想/要`, reduzir a tarefa a ação × item |
| 6 | Aula 6: localizações reais | mapa reduzido | se trocar `在/是`, contrastar localização × identificação |
| 7 | Aulas 5–6 combinadas | sem tradução visível | se a fluência cair, manter os slots e reduzir a velocidade do estímulo |
| 8 | Aula 7: três propostas de horário | mapa lacunado | se falhar em disponibilidade, recuperar `有/没有时间` |
| 9 | Aula 8: autoentrevista | prompt mínimo | se confundir `会/想`, produzir habilidade × vontade |
| 10 | Aulas 5–8: revisão cruzada | lacunas, sem mapa completo | se uma célula isolada falhar, corrigir a célula antes da consolidação |
| 11 | Consolidação 2, cenário escolhido | prompt mínimo | se repetir o roteiro, trocar o cenário e os slots |
| 12 | Consolidação 2, cenário novo | sem tradução; mapa fechado | registrar latência até a primeira resposta |
| 13 | Gravação de 90 segundos | nenhum mapa | usar áudio de referência ou feedback adequado para pronúncia |
| 14 | Avaliação das quatro dimensões | ficha de autoavaliação | reprogramar apenas os componentes que falharam |

### 7.1 Alternância de recuperação

Cada revisão deve variar a direção da tarefa:

- intenção → mandarim;
- áudio → função;
- significado → produção;
- padrão → slot;
- contraste → escolha;
- contexto novo → transferência.

Não se deve repetir todos os dias a mesma ordem nem considerar familiaridade visual como domínio.

### 7.2 Regra de retorno

- **Compreensão = 0:** voltar ao áudio e identificar a função; não começar pela transcrição.
- **Recuperação = 0:** usar o mapa lacunado e reduzir os slots.
- **Pronúncia funcional = 0:** ouvir o contraste, imitar e gravar; procurar feedback adequado. Mais leitura não resolve uma falha auditiva.
- **Transferência = 0:** manter a intenção, trocar apenas um slot e repetir em contexto novo.

---

# 8. Critérios de domínio e ficha de registro

A autoavaliação separa quatro dimensões. Cada dimensão recebe **0, 1 ou 2**:

- **0 — ainda não consigo:** não reconheço ou não produzo a operação;
- **1 — com apoio:** consigo com hesitação, pinyin, mapa lacunado ou repetição do exemplo;
- **2 — funcional:** consigo sem apoio relevante e em uma situação alterada.

| Célula/aula | Compreensão auditiva | Recuperação oral | Pronúncia funcional* | Transferência | Próxima ação |
|---|---:|---:|---:|---:|---|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |
| 4 |  |  |  |  |  |
| 5 |  |  |  |  |  |
| 6 |  |  |  |  |  |
| 7 |  |  |  |  |  |
| 8 |  |  |  |  |  |
| 9 |  |  |  |  |  |
| 10 |  |  |  |  |  |

\* **Pronúncia funcional** não significa pronúncia nativa ou correção certificada. Significa que o estudante consegue produzir uma forma compreensível para a tarefa, com o áudio ou feedback disponível, sem o material afirmar que fez uma correção automática.

### Regra de avanço

Considere uma célula funcionalmente dominada quando obtiver:

- **2 em compreensão**;
- **2 em recuperação**;
- **1 ou 2 em pronúncia funcional**, sempre com a ressalva de que a confirmação depende de áudio/feedback;
- **2 em transferência**;
- pelo menos três recombinações corretas;
- desempenho mantido em revisão após intervalo;
- consulta limitada ao prompt mínimo na segunda rodada.

Se a pronúncia ficar em 0, não compense com mais texto. Retorne ao áudio, reduza a unidade, escute o contraste e busque feedback. Se a transferência ficar em 0, não avance apenas porque a frase original parece familiar.

### Métricas de acompanhamento

Para testar a utilidade do banco sem transformar metas internas em prova científica, registre:

| Métrica | Como observar |
|---|---|
| Retenção tardia | desempenho no Dia 4, 7 ou 14 sem reensino |
| Latência de recuperação | tempo até começar uma resposta funcional |
| Recombinação | número de slots trocados corretamente |
| Transferência | sucesso em prompt que muda situação, não só palavra |
| Dependência visual | frequência de consulta ao mapa completo |
| Compreensão do fluxo | execução sem explicação oral adicional |

Essas medidas apoiam decisões editoriais e de produto. Não permitem afirmar, sozinhas, que o mapa causou melhora. Estudos sobre prática de recuperação e mapas conceituais sugerem potencial, mas o resultado depende da tarefa ativa, do desenho e da avaliação concreta.[5] [6]

---

# 9. Regras editoriais de produção e controle de qualidade

Antes de publicar uma nova célula, o editor deve responder “sim” a todas as perguntas aplicáveis:

| Verificação | Pergunta de aprovação |
|---|---|
| Função | Existe uma única operação comunicativa central? |
| Padrão | O exemplo mostra uma ordem produtiva, e não uma frase isolada sem uso? |
| Slots | Cada componente substituível tem valores limitados e úteis? |
| Extensão | A informação opcional aparece depois do núcleo e está claramente marcada? |
| Contraste | O contraste previne um erro de compreensão ou produção observável? |
| Antecipação | O estudante pode tentar antes de ver caracteres, pinyin e tradução completos? |
| Pinyin | Todas as sílabas exibidas têm marcas tonais ou indicação de tom neutro quando necessário? |
| Caracteres | Os caracteres estão simplificados e revisados? |
| Tradução | A tradução é natural no português brasileiro e não induz ordem literal? |
| Pronúncia | A nota aponta o que ouvir sem prometer correção por leitura? |
| Partícula | A partícula está explicada pela operação desta célula? |
| Recuperação | Há um prompt fechado antes do gabarito? |
| Transferência | Há um contexto novo que não copia o exemplo? |
| Domínio | O critério separa compreensão, recuperação, pronúncia e transferência? |
| Cumulatividade | Pelo menos uma célula anterior reaparece em combinação nova? |
| Suporte | Existe versão completa, lacunada e mínima? |
| Carga | A célula cabe em uma sessão curta sem sobrecarregar o iniciante? |
| Não oficialidade | Nenhum texto sugere endosso, afiliação ou autorização? |
| Direitos | Não há diálogo, transcrição, roteiro, áudio ou reprodução reconhecível de terceiros? |

### 9.1 Regras de exclusão

Remova qualquer item que seja apenas:

- uma lista de vocabulário sem operação;
- uma explicação gramatical sem tarefa oral;
- um segundo exemplo que não informe nova escolha;
- uma variante regional apresentada como universal;
- uma nota tonal sem relevância para a célula;
- uma tradução literal que piore a decisão do estudante;
- uma extensão que exija mais vocabulário do que o padrão-base;
- um ornamento visual sem função diagnóstica.

### 9.2 Acessibilidade visual

As cores seguem uma semântica estável, mas nunca são o único sinal:

- **azul-escuro:** intenção ou operação;
- **azul-claro:** fixo e ordem;
- **verde:** slot substituível;
- **laranja:** som, pinyin, tom e escuta;
- **vermelho:** contraste e erro previsível;
- **cinza:** tradução e apoio removível;
- **dourado:** revisão, transferência e domínio.

Cada bloco colorido deve ter rótulo, símbolo ou forma consistente. O material deve continuar compreensível em escala de cinza, em tela pequena e sem depender de uma legenda consultada a todo momento.

---

# 10. Encerramento editorial

O objetivo deste banco não é fazer o estudante decorar mais frases. É fazer com que uma estrutura ouvida se torne **recuperável, visível, modificável e transferível**.

```text
O ÁUDIO INTRODUZ.
A ANTECIPAÇÃO EXIGE UMA TENTATIVA.
A RECUPERAÇÃO TORNA A ESTRUTURA DISPONÍVEL.
O MAPA ORGANIZA AS RELAÇÕES.
A RECOMBINAÇÃO TESTA OS SLOTS.
A TRANSFERÊNCIA MUDA O CONTEXTO.
A INDEPENDÊNCIA DISPENSA O MAPA.
```

Mandarim em Rede é um companion independente e não oficial. O áudio continua sendo o motor principal de escuta, antecipação e produção. Este banco acrescenta uma camada de organização e transferência para brasileiros, sem prometer substituir o áudio, o professor, o interlocutor, a avaliação fonética ou o estudo sistemático.

> **Frase-âncora:** o mapa torna a estrutura visível; a recuperação torna a estrutura disponível; a transferência mostra se ela pode ser usada.

---

## Referências

[1]: https://www.pimsleur.com/the-pimsleur-method/ "Pimsleur — The Pimsleur Method"

[2]: https://apps.ankiweb.net/ "Anki — Official Website"

[3]: https://www.chinesepod.com/ "ChinesePod — Official Website"

[4]: https://www.hellotalk.com/en "HelloTalk — Official Website"

[5]: https://link.springer.com/article/10.1186/s40862-025-00331-2 "Concept Mapping in Second-Language Learning — Meta-analysis"

[6]: https://pmc.ncbi.nlm.nih.gov/articles/PMC3827082/ "Retrieval Practice and Mind Mapping — Experimental Study"
