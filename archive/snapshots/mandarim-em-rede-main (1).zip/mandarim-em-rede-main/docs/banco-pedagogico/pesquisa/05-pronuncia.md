# 05 — Pronúncia e tons

## Escopo e decisão editorial

Este bloco é uma **camada pós-áudio de transferência oral**. Ele não deve ser aberto para acompanhar a sessão principal de escuta. A sequência recomendada é:

> **Ouvir sem o mapa → tentar responder → consultar o contraste → repetir com apoio reduzido → recombinar → transferir sem olhar.**

O recorte atende ao iniciante e ao intermediário inicial. O foco não é cobrir toda a fonética do mandarim. O foco é corrigir decisões que mudam a compreensão ou a produção: **tons lexicais, tom neutro, sandhi, leitura funcional do pinyin, aspiração, contrastes de iniciais e finais e interferência provável do português brasileiro**.

O pinyin é tratado como **sistema de romanização**, não como uma leitura portuguesa da escrita latina. Ele foi criado para representar os sons do chinês padrão e contém convenções que precisam ser aprendidas; letras conhecidas não conservam necessariamente os valores ortográficos do português.[1] [2]

Os exemplos abaixo são frases e combinações independentes, criadas para fins pedagógicos. Não reproduzem diálogos, transcrições ou áudios proprietários. Os exemplos servem para **fala e recombinação**, e não para leitura silenciosa ou memorização de listas.

## Princípios de uso para brasileiros

### O que o aluno precisa ouvir e produzir

No mandarim padrão, a sílaba combina uma inicial opcional, uma final e um tom. Há quatro tons lexicais principais e um tom neutro. O tom não é apenas emoção ou entonação global: pode distinguir palavras ou morfemas com a mesma inicial e final.[1] [3]

| Tom | Descrição operacional para o iniciante | Exemplo | Tradução natural |
|---|---|---|---|
| 1º | alto e relativamente estável; não é simplesmente “mais forte” | 妈 **mā** | mãe |
| 2º | sobe de médio para alto; não é uma pergunta inteira | 麻 **má** | cânhamo;麻 em palavras |
| 3º | baixo, com possível contorno de queda e subida em isolamento | 马 **mǎ** | cavalo |
| 4º | cai rapidamente de alto para baixo | 骂 **mà** | xingar |
| neutro | curto, leve e sem marca tonal; depende do contexto | 吗 **ma** | partícula de pergunta |

A descrição do terceiro tom precisa ser ajustada à fala conectada. O contorno completo de queda e subida é útil para o treino isolado, mas em frases o terceiro tom frequentemente se realiza sobretudo como **baixo**. O aluno não deve inserir uma grande curva em cada sílaba marcada com `ˇ`.[3] [9]

### O que não deve ser prometido

Um mapa não corrige a voz por si só. A leitura do pinyin pode orientar a tentativa, mas não comprova a qualidade acústica. O domínio deve ser verificado com **escuta de modelo**, gravação própria e, quando possível, professor, interlocutor ou ferramenta de feedback. O material deve declarar “pronúncia funcional no ponto treinado”, e não “sotaque nativo” ou “correção automática”.

A literatura mostra que adultos podem desenvolver percepção dos tons com exposição e instrução. Um estudo encontrou melhora significativa após um mês de aula, e aprendizes avançados alcançaram desempenho perceptivo comparável ao de nativos.[4] Outro estudo mostrou que aprendizes imitavam tons melhor do que os identificavam por rótulos ou por leitura, sugerindo que a sequência deve começar por **ouvir e imitar**, e só depois nomear e recombinar.[5] Isso apoia a arquitetura do projeto, mas não autoriza prometer ganho automático de fala a partir de um PDF.

### Regra de apoio progressivo

Cada célula deve existir em quatro estados:

1. **Apoio:** caracteres, pinyin tonal, tradução funcional e alerta.
2. **Recuperação:** intenção, estrutura lacunada e poucos gatilhos.
3. **Transferência:** situação nova, sem tradução pronta.
4. **Independência:** apenas intenção, contraste ou prompt oral.

A ortografia conserva, em geral, o tom lexical de referência mesmo quando a fala aplica sandhi. O material pode anotar a pronúncia realizada entre parênteses para o iniciante, mas não deve reescrever todas as palavras como se o tom alterado fosse o tom lexical.[3]

---

# Células de transferência

## Item 1 — Quatro tons como contraste de significado

**Nível:** iniciante absoluto.  
**Operação oral:** ouvir uma sílaba ou palavra, distinguir o contorno e reproduzir a intenção sem trocar o tom.

### Intenção

Quero que o aluno perceba que mudar o tom pode mudar a palavra. A meta inicial não é produzir curvas perfeitas. É deixar de tratar o tom como decoração e passar a usá-lo como parte da identidade da sílaba.

### Padrão ou função

```text
[mesma inicial + mesma final] + [tom diferente] → [palavra ou significado diferente]
```

O primeiro treino deve usar uma sílaba estável e curta, com escuta, imitação e contraste. O professor ou áudio apresenta o modelo; o mapa não deve ser a fonte sonora.

### Exemplos

| Caractere | Pinyin | Tradução natural | Ação oral |
|---|---|---|---|
| 妈 | **mā** | mãe | mantenha o tom alto e estável |
| 麻 | **má** | cânhamo; parte de palavras | faça uma subida clara |
| 马 | **mǎ** | cavalo | produza o baixo; a curva completa cabe melhor em isolamento |
| 骂 | **mà** | xingar | faça uma queda curta e firme |

Para ligar o contraste a fala funcional, use palavras e frases já significativas, sem criar um exercício de trava-língua:

- 你好吗？ — **Nǐ hǎo ma?** — Você está bem?
- 我很好。 — **Wǒ hěn hǎo.** — Estou bem.
- 我叫马丁。 — **Wǒ jiào Mǎdīng.** — Eu me chamo Martin.

A frase não deve ser avaliada como uma soma de sílabas isoladas. O aluno deve primeiro ouvir a expressão inteira e depois localizar o ponto tonal que altera o sentido.

### Slots substituíveis

- `[sílaba-alvo]`: mā, má, mǎ, mà ou outra sílaba conhecida.
- `[palavra funcional]`: 好 **hǎo**, 叫 **jiào**, 很 **hěn**, 名字 **míngzi**.
- `[intenção]`: cumprimentar, dizer o nome, dizer que está bem.
- `[posição]`: sílaba isolada, palavra curta, frase curta.

### Extensões

1. Compare dois tons por vez, começando por **2º × 3º**, que costuma exigir atenção à direção do contorno, e depois **1º × 4º**, que exige estabilidade versus queda.
2. Faça o aluno escolher qual intenção ouviu antes de pedir a repetição.
3. Passe de sílaba isolada para pares curtos: **hěn hǎo**, **nǐ jiào**, **wǒ shì**.
4. Intercale produção sem rótulo: o aluno recebe “cumprimente” ou “diga seu nome”, não “produza o terceiro tom”.

### Observação pedagógica

Não ensine os tons apenas como gestos musicais ou números abstratos. Use a direção da voz como pista inicial, mas faça a recuperação voltar sempre para uma palavra ou função. A hipótese “português não tem tons” deve ser formulada com cuidado: o português brasileiro usa variações de altura e entonação, mas não usa o tom lexical da mesma maneira. O risco é o aluno aplicar uma melodia de pergunta ou de ênfase à sílaba inteira e perder o contraste lexical.[6]

Não peça que o aluno associe cada tom a uma emoção universal. O 2º tom não é “surpresa” e o 4º não é “raiva”; são contrastes de pitch dentro da sílaba, modulados pelo contexto.

### Potencial de mapa

**Mapa de contraste auditivo:**

```text
[N] intenção → [A] direção tonal → [V] palavra-alvo → [X] tom que não pode ser trocado → [R] produção
```

- Estado completo: os quatro contornos, uma palavra e tradução.
- Estado lacunado: dois contornos e a palavra sem marca tonal.
- Prompt mínimo: “Diga que está bem” ou “Diga seu nome”.
- Não usar: um pôster com dezenas de sílabas sem tarefa de escuta.

### Prompt de recuperação

“Você quer dizer que está bem. Produza **我很好** sem olhar o pinyin. Depois diga qual sílaba recebeu o foco tonal e repita a frase em ritmo natural.”

### Prompt de transferência

“Você acabou de conhecer alguém. Cumprimente, diga que está bem e depois diga um nome diferente do exemplo. Faça a troca duas vezes sem consultar caracteres ou pinyin.”

### Critério de domínio

O aluno identifica corretamente o contraste solicitado em pelo menos **8 de 10 tentativas auditivas** e produz quatro frases curtas com intenção correta, sem trocar o tom-alvo em mais de duas tentativas consecutivas. A decisão final deve considerar uma gravação comparada com um modelo, não apenas a forma visual do pinyin.

---

## Item 2 — Terceiro tom em fala conectada: baixo antes de curva completa

**Nível:** iniciante.  
**Operação oral:** evitar transformar todo `ˇ` em uma grande queda-subida e manter o terceiro tom funcional dentro da frase.

### Intenção

Quero que o aluno produza o terceiro tom de modo econômico em palavras e frases, preservando o ponto baixo sem interromper o fluxo. Isso reduz uma dificuldade comum: alongar cada terceiro tom como se fosse uma sílaba isolada.

### Padrão ou função

```text
[terceiro tom em palavra ou frase] → alvo prático = baixo e curto
[terceiro tom em isolamento] → curva de referência pode ser mais completa
```

O desenho do pinyin não informa sozinho a realização de superfície. O aluno deve ouvir o modelo e usar o contexto prosódico.

### Exemplos

- 我很好。— **Wǒ hěn hǎo.** — Estou bem.
- 你很忙吗？— **Nǐ hěn máng ma?** — Você está muito ocupado(a)?
- 我想买水。— **Wǒ xiǎng mǎi shuǐ.** — Quero comprar água.
- 很好。— **Hěn hǎo.** — Muito bom; estou bem.

Em uma sílaba isolada, compare:

- 好 — **hǎo** — bom.
- 很 — **hěn** — muito; marcador frequente em frases descritivas.

Em uma frase, o objetivo não é fazer cada uma dessas sílabas descer e subir de modo teatral. O aluno deve manter o terceiro tom audível e continuar para a sílaba seguinte.

### Slots substituíveis

- `[sujeito]`: 我 **wǒ**, 你 **nǐ**, 他 **tā**.
- `[terceiro tom]`: 很 **hěn**, 好 **hǎo**, 想 **xiǎng**, 买 **mǎi**, 水 **shuǐ**.
- `[extensão]`: 吗 **ma**, 一点 **yìdiǎn**, 现在 **xiànzài**.
- `[intenção]`: descrever estado, perguntar estado, expressar desejo.

### Extensões

1. Contraste “terceiro tom baixo” com o 2º tom em palavras conhecidas, sem exigir nomenclatura.
2. Faça uma rodada com o terceiro tom em posição inicial e outra em posição não final.
3. Peça uma repetição em velocidade confortável e depois uma segunda tentativa mais curta.
4. Mude apenas o slot lexical: **很好**, **很忙**, **想买**, **买水**.

### Observação pedagógica

A formulação “o terceiro tom é sempre uma curva em V” é pouco natural para fala corrente. A descrição normativa de isolamento é útil para criar uma referência, mas a fala conectada exige redução e coordenação. O aluno brasileiro pode confundir duração, intensidade e pitch: “falar mais forte” não substitui produzir a direção tonal. Em vez de pedir “exagere o tom”, peça “mantenha o ponto baixo e não pare entre as sílabas”.

### Potencial de mapa

**Mapa de redução controlada:**

```text
[N] continuar falando → [F] terceiro tom → [A] baixo curto → [X] não fazer V completo em toda sílaba → [R] frase recombinada
```

- Apoio: exibir `hǎo` com uma seta descendente-subida discreta e um áudio-modelo.
- Recuperação: mostrar apenas `h__ h__` dentro de uma frase.
- Transferência: retirar as setas e deixar a intenção.

### Prompt de recuperação

“Diga ‘estou bem’ e depois ‘estou muito ocupado(a)’. Faça duas frases contínuas sem alongar o terceiro tom.”

### Prompt de transferência

“Escolha uma pessoa e um estado: ‘ele está bem’, ‘ela está ocupada’ ou ‘eu quero água’. Produza a frase sem traduzir palavra por palavra.”

### Critério de domínio

O aluno mantém o terceiro tom baixo e funcional em **três frases diferentes**, sem inserir pausa entre inicial e final da sílaba, e consegue alternar entre uma produção isolada e uma produção conectada. Um observador deve conseguir reconhecer a palavra pretendida em pelo menos quatro de cinco tentativas.

---

## Item 3 — Sandhi do terceiro tom: 3º + 3º

**Nível:** iniciante a intermediário inicial.  
**Operação oral:** aplicar a mudança de superfície sem reescrever mentalmente o vocabulário.

### Intenção

Quero que o aluno reconheça e produza sequências em que o primeiro terceiro tom se realiza como segundo tom antes de outro terceiro tom. A regra deve ser recuperada como um comportamento de fala, não como uma exceção para decorar em uma lista.

### Padrão ou função

```text
3º + 3º → fala aproximadamente 2º + 3º
escrita lexical → mantém as marcas de 3º + 3º
```

O sandhi é uma mudança regular de pronúncia. Em pinyin didático, os tons lexicais normalmente permanecem escritos para que o aluno saiba qual é o tom de cada item fora daquele contexto.[3]

### Exemplos

| Escrita | Pinyin lexical | Fala-alvo aproximada | Tradução natural |
|---|---|---|---|
| 你好 | **Nǐ hǎo** | **Ní hǎo** | Olá |
| 很好 | **Hěn hǎo** | **Hén hǎo** | Muito bom; estou bem |
| 你想买水吗？ | **Nǐ xiǎng mǎi shuǐ ma?** | aplique sandhi local onde houver sequência 3+3 | Você quer comprar água? |

Na frase longa, não force uma substituição mecânica de todas as sílabas marcadas com `ˇ`. A divisão prosódica e o agrupamento de sentido importam. Para o iniciante, trabalhe primeiro pares claros, como **nǐ hǎo**, e só depois sequências maiores.

### Slots substituíveis

- `[primeiro 3º]`: 你 **nǐ**, 很 **hěn**, 我 **wǒ**, 想 **xiǎng**.
- `[segundo 3º]`: 好 **hǎo**, 买 **mǎi**, 水 **shuǐ**, 哪 **nǎ**.
- `[moldura]`: saudação, pergunta, resposta, pedido.
- `[tamanho do grupo]`: duas sílabas → frase curta → frase com uma pausa de sentido.

### Extensões

1. Alternar **你好** e **你好吗？** para evitar a memorização de uma única gravação.
2. Recuperar primeiro o pinyin lexical e somente depois perguntar “como isso soa aqui?”.
3. Usar gravações de professores ou recursos licenciados do próprio aluno; o PDF pode orientar a escuta, mas não precisa conter áudio proprietário.
4. Explorar sequências de três sílabas apenas depois de o aluno produzir dois exemplos de 3+3 com estabilidade.

### Observação pedagógica

Não represente a regra como “todo terceiro tom vira segundo tom”. Ele muda em um domínio apropriado antes de outro terceiro tom; fora dessa configuração, a realização pode ser baixa, reduzida ou influenciada pelo agrupamento. Também não apresente a forma alterada como nova entrada lexical. O aluno precisa reconhecer **nǐ** como terceiro tom no vocabulário, mas falar **ní** em **你好**.

O erro brasileiro provável é ler o diacrítico como uma obrigação visual e pronunciar cada sílaba isoladamente. A intervenção deve ser oral: ouvir o par, repetir a unidade inteira, esconder a resposta e recombinar com outro slot.

### Potencial de mapa

**Mapa de sandhi e contraste:**

```text
[N] cumprimentar ou perguntar → [F] 3º + 3º → [A] primeiro sobe na fala → [X] escrita não muda → [R] novo par
```

- Completo: `nǐ + hǎo → ní hǎo`.
- Lacunado: `n__ hǎo → ?`.
- Mínimo: “cumprimente alguém” ou “diga que está muito bem”.

### Prompt de recuperação

“Você quer dizer ‘olá’. Recupere **你好**. Primeiro diga a forma lexical que você estudaria no dicionário; depois produza a forma natural da expressão.”

### Prompt de transferência

“Cumprimente uma pessoa nova e diga uma frase curta com dois terceiros tons diferentes do exemplo. Não altere a escrita mental dos tons lexicais; altere somente a fala quando a sequência exigir.”

### Critério de domínio

O aluno aplica corretamente o sandhi em **8 de 10 pares 3+3**, mantém a escrita lexical correta em pelo menos quatro itens e produz duas frases novas sem ser lembrado da regra. Se ele somente reconhece `ní hǎo` mas não consegue recombinar, a célula não está dominada.

---

## Item 4 — Sandhi de 不: negação antes de quarto tom

**Nível:** iniciante.  
**Operação oral:** negar uma informação sem pronunciar **不** sempre com quarto tom.

### Intenção

Quero que o aluno produza uma negação curta e natural, distinguindo o tom lexical de **不** da forma realizada antes de uma sílaba de quarto tom.

### Padrão ou função

```text
不 bù + não-4º tom → bù [tom seguinte]
不 bù + 4º tom → bú + [4º tom]
```

A forma escrita continua sendo **不 bù**. Antes de quarto tom, a fala é **bú**.[3] [7]

### Exemplos

- 不是。— **Bú shì.** — Não é; não sou.
- 不对。— **Bú duì.** — Não está certo.
- 不要。— **Bú yào.** — Não queira; não faça.
- 不好。— **Bù hǎo.** — Não é bom.
- 不明白。— **Bù míngbai.** — Não entendo.

Contraste funcional:

- **我不是中国人。— Wǒ bú shì Zhōngguó rén. — Eu não sou chinês/chinesa.**
- **我不明白。— Wǒ bù míngbai. — Eu não entendo.**

### Slots substituíveis

- `[不 + 4º tom]`: 是 **shì**, 对 **duì**, 要 **yào**.
- `[不 + outro tom]`: 好 **hǎo**, 明白 **míngbai**, 懂 **dǒng**.
- `[função]`: negar identidade, corrigir, recusar, dizer que não entende.
- `[sujeito]`: 我 **wǒ**, 你 **nǐ**, 他 **tā**.

### Extensões

1. Faça o aluno escolher entre **bú shì** e **bù hǎo** a partir de uma intenção em português.
2. Troque somente a sílaba seguinte: **shì**, **duì**, **yào**.
3. Insira a negação em estruturas já conhecidas: **我不是…**, **我不要…**, **不是我的**.
4. Treine a expressão inteira, não o `bú` isolado como se fosse uma nova palavra independente.

### Observação pedagógica

O erro mais previsível é repetir **bù** em todas as posições porque o aluno recupera a entrada do dicionário, não o som contextual. O erro oposto é ensinar que **不** “é sempre bú”; isso apaga o tom lexical e gera novas confusões. A unidade de ensino deve ser “negação + palavra seguinte”.

### Potencial de mapa

**Mapa de função e sandhi:**

```text
[N] negar → [F] 不 + predicado → [A] bú antes de 4º → [X] não trocar a escrita lexical → [R] correção nova
```

O ramo vermelho deve conter somente a decisão acionável: **“a próxima sílaba é quarto tom?”**. Não incluir uma tabela extensa de exceções.

### Prompt de recuperação

“Alguém diz que você é chinês. Corrija: ‘Eu não sou chinês’. Depois diga ‘não está certo’.”

### Prompt de transferência

“Negue duas informações novas: uma com uma palavra de quarto tom e outra com uma palavra que não seja de quarto tom. Faça a escolha sem olhar o pinyin.”

### Critério de domínio

O aluno seleciona a forma falada correta em **9 de 10 itens** e produz **bú shì**, **bú duì** e **bù hǎo** em frases próprias, sem pausar para consultar a regra. A pronúncia precisa ser confirmada auditivamente; a forma visual `bù` sozinha não conta como evidência.

---

## Item 5 — Sandhi de 一: um, uma vez e quantidade

**Nível:** iniciante a intermediário inicial.  
**Operação oral:** ajustar **一** de acordo com o contexto e não aplicar a regra de modo cego a todos os usos numéricos.

### Intenção

Quero que o aluno use **一** em números e expressões frequentes sem manter o primeiro tom em todas as posições, mas também sem apagar a diferença entre “contar” e “usar 一 dentro de uma expressão”.

### Padrão ou função

Regra inicial para fala conectada:

```text
一 yī isolado, contado ou em uso numérico → yī
一 + 4º tom → yí
一 + 1º/2º/3º tom → yì
```

As marcas lexicais continuam sendo mostradas no pinyin de referência. Em expressões com sílaba neutra, como **一个**, o aluno deve aprender a unidade frequente pelo áudio e pelo uso; não deve deduzir automaticamente uma nova regra apenas olhando a ausência de marca na sílaba seguinte.[2] [3]

### Exemplos

- 一、二、三。— **Yī, èr, sān.** — Um, dois, três.
- 一次。— **Yí cì.** — Uma vez.
- 一定。— **Yídìng.** — Com certeza; necessariamente.
- 一点。— **Yìdiǎn.** — Um pouco.
- 一杯水。— **Yì bēi shuǐ.** — Um copo de água.
- 一个人。— **Yí ge rén.** — Uma pessoa.

O último exemplo deve ser tratado como **expressão de alta frequência**: a forma natural é ouvida e recuperada como unidade, sem transformar a regra em um cálculo absoluto para toda sequência com tom neutro.

### Slots substituíveis

- `[quantificador]`: 个 **ge**, 杯 **bēi**, 点 **diǎn**, 次 **cì**.
- `[substantivo]`: 人 **rén**, 水 **shuǐ**, 茶 **chá**, 时间 **shíjiān**.
- `[função]`: contar, pedir um pouco, pedir uma unidade, indicar uma vez.
- `[modo]`: número isolado, expressão curta, frase completa.

### Extensões

1. Alternar **yī** em contagem, **yí cì**, **yìdiǎn** e **yí ge**.
2. Produzir frases de pedido: **请给我一点水。— Qǐng gěi wǒ yìdiǎn shuǐ. — Por favor, me dê um pouco de água.**
3. Fazer o aluno ouvir primeiro e só depois explicar a regra.
4. No intermediário inicial, registrar expressões em que o uso é lexicalizado ou variável, em vez de impor uma tabela universal.

### Observação pedagógica

**一** é uma célula de alto risco para excesso de regra. A forma mais segura é ensinar três padrões frequentes e deixar casos raros para a escuta. O aluno brasileiro pode pronunciar a palavra como se o primeiro tom fosse uma sílaba forte de contagem em qualquer contexto. A intervenção é trocar o slot seguinte mantendo a intenção: “um pouco”, “uma vez”, “uma pessoa”.

Não usar a ortografia alterada `yí` ou `yì` como se fossem caracteres diferentes. O objetivo é preservar a entrada **一 yī** e reconhecer a realização contextual.

### Potencial de mapa

**Mapa de decisão contextual:**

```text
[N] quantificar → [F] 一 → [V] próximo item → [A] yī/yí/yì → [X] número contado ≠ expressão conectada → [R] pedido
```

O ramo de decisão deve ter no máximo três perguntas: “está contando?”, “o próximo tom é 4º?”, “é uma expressão frequente que ouvi inteira?”.

### Prompt de recuperação

“Diga ‘um copo de água’, ‘uma vez’ e ‘um pouco’. Depois conte de um a três. Não veja a resposta enquanto produz.”

### Prompt de transferência

“Você está em uma cafeteria. Peça uma xícara de chá, um pouco de água e diga que quer repetir uma vez. Use os quantificadores que você lembrar, sem repetir o exemplo na mesma ordem.”

### Critério de domínio

O aluno produz corretamente **yī** na contagem, **yí** antes de quarto tom, **yì** antes de terceiro ou primeiro tom e a expressão frequente **yí ge** em pelo menos **8 de 10 tentativas**, além de recombinar três substantivos sem apoio visual.

---

## Item 6 — Tom neutro: leveza, ritmo e dependência do contexto

**Nível:** iniciante a intermediário inicial.  
**Operação oral:** reduzir sílabas neutras sem apagá-las e sem transformar toda sílaba final em tom neutro.

### Intenção

Quero que o aluno reconheça que uma sílaba sem marca tonal pode ser curta e leve, especialmente em partículas, sufixos e palavras frequentes. A meta é melhorar o ritmo e a naturalidade da expressão, não falar de modo inaudível.

### Padrão ou função

```text
sílaba forte + sílaba neutra → segunda sílaba curta, leve e dependente do contexto
```

O tom neutro não é simplesmente “tom zero”. Estudos acústicos mostram que sua duração e seu contorno dependem da estrutura silábica e do tom precedente; muitas sílabas neutras tendem a convergir para uma região baixa, mas há variação.[8] [9]

### Exemplos

- 名字 — **míngzi** — nome.
- 什么 — **shénme** — o que; qual.
- 明白 — **míngbai** — compreender.
- 我的吗？— **Wǒ de ma?** — É meu/minha?
- 你好吗？— **Nǐ hǎo ma?** — Tudo bem com você?
- 现在 — **xiànzài** — agora. Aqui, **zài** conserva seu quarto tom; não neutralize por estar no fim da palavra.

Contrastes úteis:

- **名字 míngzi**: a sílaba final costuma ser leve.
- **字 zì** em uma palavra ou resposta isolada: pode carregar seu tom lexical de referência.
- **吗 ma**: partícula neutra; a pergunta não precisa transformar **ma** em um quinto tom cheio.

### Slots substituíveis

- `[sílaba forte]`: míng, shén, míng, hǎo.
- `[sílaba neutra]`: zi, me, bai, ma, de, le.
- `[função]`: perguntar, devolver pergunta, marcar posse, indicar mudança de estado.
- `[posição]`: final de palavra, partícula de frase, sufixo.

### Extensões

1. Treinar palavras em pares: **míngzi**, **shénme**, **míngbai**.
2. Inserir as partículas em frases novas, sem ler a sílaba neutra como uma sílaba com a mesma força.
3. Fazer shadowing curto: ouvir uma unidade, pausar e imitar ritmo e duração.
4. No intermediário inicial, comparar o mesmo morfema em uso neutro e uso mais enfatizado, sem afirmar que a neutralização é obrigatória em todos os dialetos e estilos.

### Observação pedagógica

O português brasileiro tem acento lexical e redução vocálica em certos contextos, mas isso não corresponde automaticamente ao sistema do tom neutro do mandarim. O aluno pode cometer dois erros opostos: dar o mesmo peso a todas as sílabas ou engolir a sílaba neutra até ela desaparecer. Use a instrução “curta e clara”, não “fraca e inaudível”.

Não chame toda sílaba não marcada de neutra. A ausência de diacrítico em materiais inconsistentes pode ser erro editorial. O pinyin do material deve marcar tons lexicais e deixar sem marca somente o neutro que foi intencionalmente selecionado.

### Potencial de mapa

**Mapa de ritmo e função:**

```text
[N] manter expressão natural → [F] sílaba lexical → [A] sílaba neutra leve → [X] não apagar / não dar peso igual → [R] frase nova
```

- Completo: `míng + zi → 名字 míngzi`.
- Lacunado: `shén + __ → 什么`.
- Mínimo: “pergunte qual é o nome” ou “pergunte se está tudo bem”.

### Prompt de recuperação

“Pergunte o nome de alguém e pergunte se a pessoa está bem. Produza **名字** e **吗** sem dar à sílaba neutra a mesma duração da primeira.”

### Prompt de transferência

“Imagine que você não ouviu o nome de uma pessoa. Pergunte novamente usando **什么**, depois confirme se entendeu. Faça a troca em ritmo contínuo, sem soletrar.”

### Critério de domínio

O aluno mantém a sílaba neutra audível, curta e subordinada à sílaba forte em **8 de 10 tentativas**, sem transformar **ma**, **zi**, **me** ou **bai** em sílabas longas com tom cheio. Também deve usar duas expressões com neutro em contexto novo.

---

## Item 7 — Pinyin como decodificação: marca tonal e convenções de escrita

**Nível:** iniciante.  
**Operação oral:** ler pinyin para chegar ao som do mandarim, sem aplicar os valores ortográficos do português.

### Intenção

Quero que o aluno use o pinyin para recuperar uma pronúncia já ouvida, não para inventar uma pronúncia a partir de letras familiares.

### Padrão ou função

```text
caractere → pinyin = inicial + final + tom → som-modelo → produção
```

O pinyin tem regras de escrita que incluem `y` e `w` em certas posições, redução ortográfica de `iu`, `ui` e `un`, e uso de `u` para representar `ü` depois de `j`, `q` e `x`.[1] [2]

Para marcar tons, use a vogal principal conforme a convenção ortográfica: priorize `a` ou `e`; em `ou`, marque `o`; nos demais casos, marque a vogal apropriada da final. Não transforme a regra de posição da marca em uma pronúncia nova.

### Exemplos

- 你 — **nǐ** — você.
- 我 — **wǒ** — eu.
- 叫 — **jiào** — chamar-se; chamar.
- 学 — **xué** — estudar.
- 去 — **qù** — ir.
- 水 — **shuǐ** — água.
- 朋友 — **péngyou** — amigo(a); a segunda sílaba pode ser leve conforme o contexto.

Convenções que exigem escuta:

| Escrita | Não inferir pelo português | Ação |
|---|---|---|
| `q` | não é o valor de `qu` em português | ouvir o início aspirado de **qǐng** |
| `x` | não é /ks/ | produzir o som palatal de **xué** |
| `j` | não é o `j` de “jantar” | produzir **jiào** com a língua à frente |
| `zh` | não é simplesmente `z` + `h` | ouvir o grupo retroflexo de **zhè** |
| `c` | não é o `c` português | manter a africada aspirada de **cài** |

### Slots substituíveis

- `[inicial]`: j/q/x, zh/ch/sh, z/c/s, b/p/d/t/g/k.
- `[final]`: -i, -iao, -üe, -an, -ang, -ing.
- `[tom]`: 1, 2, 3, 4 ou neutro.
- `[função]`: nomear, pedir, identificar, localizar, reparar compreensão.

### Extensões

1. Cobrir no máximo três convenções por sessão; o aluno não precisa estudar a tabela inteira antes de falar.
2. Fazer a passagem `caractere → pinyin → som → intenção`, e nunca terminar em leitura silenciosa.
3. Ocultar o caractere e deixar pinyin tonal apenas na etapa de apoio; depois ocultar o pinyin.
4. Usar um quadro de pinyin com áudio como ferramenta externa de referência, não como substituto de produção em frases.[10]

### Observação pedagógica

Pinyin é suporte removível. O aluno brasileiro pode desenvolver dependência da letra e continuar pronunciando uma sílaba errada com muita confiança. A intervenção deve exigir uma decisão oral: “essa sequência significa qual ação?” e “qual som você ouviu?”, não apenas “qual letra vem depois?”.

### Potencial de mapa

**Mapa de decodificação e retirada:**

```text
[N] recuperar som → [F] inicial + final → [A] tom → [X] falsa leitura portuguesa → [R] palavra em frase
```

O mapa deve mostrar uma cadeia curta, com exemplos coloridos por função. Não incluir o inventário completo de pinyin numa página que também exige recuperação tonal.

### Prompt de recuperação

“Veja apenas **我叫** e diga a expressão. Depois cubra o pinyin e repita olhando apenas os caracteres.”

### Prompt de transferência

“Diga seu nome, peça o nome de outra pessoa e diga que você fala um pouco de chinês. Use o pinyin somente na primeira rodada; faça a segunda sem ele.”

### Critério de domínio

O aluno lê e produz **10 itens funcionais** sem aplicar valores portugueses às letras críticas, acerta o tom lexical em pelo menos oito e consegue repetir três expressões olhando apenas caracteres. Se só consegue falar com pinyin visível, ainda está no estado de apoio.

---

## Item 8 — Aspiração: b/p, d/t, g/k, z/c, zh/ch e j/q

**Nível:** iniciante a intermediário inicial.  
**Operação oral:** controlar a saída de ar sem substituir aspiração por vozeamento.

### Intenção

Quero que o aluno perceba que pares como `b/p`, `d/t`, `g/k`, `z/c`, `zh/ch` e `j/q` se distinguem principalmente pela aspiração e pelo ponto de articulação. Não se deve explicar o contraste apenas como “surdo versus sonoro”.

### Padrão ou função

```text
não aspirado → bloqueio e soltura com pouco sopro audível
aspirado → mesmo ponto geral, com sopro de ar mais perceptível
```

No mandarim padrão, as séries escritas com `b d g` não correspondem simplesmente às consoantes sonoras do português, e `p t k` carregam mais aspiração. A descrição articulatória deve ser demonstrada com um papel fino ou a mão diante da boca, sem prometer que esse teste substitui escuta.[1] [11]

### Exemplos

- 八 — **bā** — oito.
- 怕 — **pà** — ter medo.
- 到 — **dào** — chegar.
- 套 — **tào** — conjunto; capa; item lexical.
- 高 — **gāo** — alto.
- 看 — **kàn** — olhar; ver.
- 叫 — **jiào** — chamar-se.
- 请 — **qǐng** — por favor.
- 这 — **zhè** — isto; este/esta.
- 车 — **chē** — carro; veículo.

As primeiras pares podem ser pseudo-minimais ou palavras de vocabulário. O objetivo é produzir o gesto e ouvir a diferença, não decorar uma lista sem função.

### Slots substituíveis

- `[par]`: b/p, d/t, g/k, z/c, zh/ch, j/q.
- `[final]`: -ā, -ào, -īng, -ǐng.
- `[função]`: pedir, agradecer, indicar, dizer nome, localizar.
- `[teste]`: papel, mão, gravação, repetição de palavra em frase.

### Extensões

1. Treinar o par sem tom primeiro por poucas repetições e reinserir o tom imediatamente.
2. Levar o contraste a frases: **请说** — **Qǐng shuō** — Por favor, fale; **请看** — **Qǐng kàn** — Por favor, olhe.
3. Alternar consoante e slot final: **bā/pà**, **dào/tào**, **jiào/qǐng**.
4. No nível inicial-intermediário, usar gravação em velocidade normal, porque a aspiração pode mudar com o estilo e a posição.

### Observação pedagógica

O português brasileiro tende a oferecer ao aluno categorias conhecidas de vozeamento, o que pode levar a produzir `b d g` com vibração laríngea de português ou a perder o sopro de `p t k`. Isso é uma **hipótese de interferência articulatória**, não um diagnóstico universal de todos os brasileiros. A instrução deve ser concreta: “sinta o sopro” e “não faça vibrar a garganta no não aspirado”.

### Potencial de mapa

**Mapa de contraste de fluxo de ar:**

```text
[N] ser entendido → [F] inicial → [A] sopro ou ausência de sopro → [X] voz portuguesa ≠ oposição mandarim → [R] palavra funcional
```

Um mapa pode mostrar apenas uma série por vez. Misturar seis pares com quatro tons cria carga cognitiva excessiva.

### Prompt de recuperação

“Diga **八** e **怕**; depois diga que você tem medo. Faça o sopro de **pà** sem alterar o quarto tom.”

### Prompt de transferência

“Peça educadamente que alguém olhe e depois peça que a pessoa fale. Produza duas frases com **请**, alternando os sons aspirados e não aspirados.”

### Critério de domínio

O aluno distingue o par-alvo em **8 de 10 escutas** e produz três palavras com aspiração audível, sem vozeamento indevido, mantendo o tom. O critério não é “soar como nativo”; é tornar o contraste recuperável para um interlocutor treinado.

---

## Item 9 — Palatais, retroflexas e a vogal ü

**Nível:** iniciante a intermediário inicial.  
**Operação oral:** separar regiões articulatórias que o português brasileiro tende a aproximar e manter `ü` como vogal arredondada anterior.

### Intenção

Quero que o aluno reconheça e produza os contrastes de maior risco perceptivo entre `j/q/x` e `zh/ch/sh/r`, além de não converter `ü` em `u` português.

### Padrão ou função

```text
j q x → língua à frente, ponta baixa, articulação palatal
zh ch sh r → língua retraída/retroflexa
j q x + u escrito → som de ü, não de u comum
```

As descrições articulatórias não devem ser substituídas por equivalentes portugueses aproximados. `x` não é simplesmente “ch” nem `j` é o `j` de “jantar”; `q` inclui aspiração; depois de `j`, `q` e `x`, o `u` ortográfico representa a vogal `ü`.[12]

### Exemplos

- 叫 — **jiào** — chamar-se.
- 请 — **qǐng** — por favor.
- 学 — **xué** — estudar.
- 这 — **zhè** — isto.
- 是 — **shì** — ser; é.
- 人 — **rén** — pessoa.
- 去 — **qù** — ir.
- 女 — **nǚ** — mulher; feminino.
- 绿 — **lǜ** — verde.

Contrastes de intenção:

- **请说慢一点。— Qǐng shuō màn yìdiǎn. — Por favor, fale um pouco mais devagar.**
- **去中国。— Qù Zhōngguó. — Ir para a China.**
- **这是书。— Zhè shì shū. — Isto é um livro.**

### Slots substituíveis

- `[série]`: j/q/x ou zh/ch/sh/r.
- `[final]`: -i, -üe, -uan, -ün.
- `[palavra]`: 请 **qǐng**, 学 **xué**, 去 **qù**, 女 **nǚ**, 书 **shū**.
- `[função]`: pedir, dizer destino, identificar, descrever.

### Extensões

1. Faça o aluno sorrir levemente e manter a ponta da língua baixa para experimentar `x`; em seguida compare com `sh`, cuja articulação é mais retraída.[12]
2. Pratique `qi/xī` e `chī/shī` como contrastes articulatórios, sem transformar o exercício em tradução.
3. Use `去 qù`, `学 xué`, `女 nǚ`, `绿 lǜ` para manter o arredondamento anterior de `ü`.
4. Retire a descrição articulatória e deixe apenas a intenção: pedir, ir, estudar, identificar.

### Observação pedagógica

A aproximação “x = chi”, “q = tchi” ou “zh = j” pode funcionar como alerta inicial, mas é perigosa como regra de produção. Para brasileiros, `j`, `x`, `ch`, `sh` e `r` já acionam categorias ortográficas e fonéticas do português; o material deve apresentar o contraste como **novo gesto** e remeter ao áudio. Não use transliterações brasileiras como solução permanente.

A vogal `ü` é especialmente importante porque a escrita após `j/q/x` esconde os dois pontos. O aluno deve ouvir e produzir arredondamento dos lábios com a língua em posição anterior, sem substituí-la por `u` de “tu”.

### Potencial de mapa

**Mapa articulatório de contraste:**

```text
[N] ser compreendido → [F] série inicial → [A] posição da língua + arredondamento → [X] falsa equivalência portuguesa → [R] pedido ou frase
```

Usar dois mapas pequenos, não um inventário único:

- mapa A: `j/q/x` versus `zh/ch/sh/r`;
- mapa B: `u` ortográfico após `j/q/x` = `ü` fonético.

### Prompt de recuperação

“Peça que a pessoa fale mais devagar. Produza **请说慢一点**. Depois diga **去中国**. Mantenha o início de **qǐng** aspirado e a vogal de **qù** arredondada.”

### Prompt de transferência

“Diga que você quer estudar, que vai para a China e que uma pessoa é mulher. Faça três frases novas usando **学**, **去** e **女**, sem ler a romanização.”

### Critério de domínio

O aluno diferencia `q/x` de `zh/sh` em **8 de 10 pares auditivos**, mantém `ü` em três palavras e produz duas frases funcionais sem inserir uma vogal portuguesa antes da inicial. O domínio exige compreensão por contraste, não somente uma descrição consciente da posição da língua.

---

## Item 10 — Finais, nasais e vogais: -n, -ng, -an/-ang e -in/-ing

**Nível:** iniciante a intermediário inicial.  
**Operação oral:** terminar a sílaba no lugar correto e não transformar contrastes de final em uma única nasalização portuguesa.

### Intenção

Quero que o aluno preserve as finais do mandarim em palavras de alta frequência. A meta é evitar que `-n` e `-ng`, ou `-en` e `-eng`, sejam neutralizados numa vogal nasal vaga.

### Padrão ou função

```text
final = núcleo vocálico + coda ou glide
-an ≠ -ang; -en ≠ -eng; -in ≠ -ing
```

O mandarim possui finais que não correspondem diretamente às sequências ortográficas do português. O aluno precisa ouvir a parte final como informação, não como um detalhe descartável.[1]

### Exemplos

- 很 — **hěn** — muito.
- 红 — **hóng** — vermelho.
- 人 — **rén** — pessoa.
- 朋 — **péng** — amigo, em 朋友.
- 新 — **xīn** — novo.
- 星 — **xīng** — estrela.
- 安 — **ān** — seguro; parte de nomes e palavras.
- 商 — **shāng** — comércio; parte de palavras.

Frases funcionais:

- 我很好。— **Wǒ hěn hǎo.** — Estou bem.
- 这是红色的。— **Zhè shì hóngsè de.** — Isto é vermelho.
- 他是我的朋友。— **Tā shì wǒ de péngyou.** — Ele é meu amigo.
- 今天很忙。— **Jīntiān hěn máng.** — Hoje estou muito ocupado(a).

### Slots substituíveis

- `[final]`: -n, -ng, -an, -ang, -en, -eng, -in, -ing.
- `[palavra]`: 很, 红, 人, 朋, 新, 星, 安, 商.
- `[função]`: descrever estado, identificar cor, dizer relação, falar do dia.
- `[posição]`: palavra isolada, final de palavra, frase curta.

### Extensões

1. Comece por pares que o aluno já precise usar: **hěn/hóng**, **péng/péngyou**, **xīn/xīng**.
2. Faça uma tarefa de escolha de imagem ou intenção antes da repetição.
3. Treine a coda final sem alongar a vogal até ela virar uma vogal nasal portuguesa.
4. Introduza `-ian`, `-iang`, `-ing` somente depois de o aluno ouvir o contraste simples.

### Observação pedagógica

Falantes de português brasileiro podem nasalizar a vogal e não realizar a diferença consonantal de maneira clara. Isso deve ser tratado como **hipótese de interferência para diagnóstico**, não como defeito inevitável de todos os alunos. A instrução acionável é: “termine a língua em `n`” versus “leve o fechamento para trás em `ng`”, sempre com áudio de referência.

Não ensine `ang` como “ã” nem `eng` como “ẽ”. A aproximação pode ajudar uma primeira percepção, mas não serve para produção controlada. O contraste final precisa sobreviver em uma frase.

### Potencial de mapa

**Mapa de final e contraste:**

```text
[N] transmitir informação → [F] núcleo + final → [A] lugar da coda → [X] nasalização portuguesa sem coda ≠ final mandarim → [R] frase nova
```

O mapa pode usar uma linha visual da boca: frente para `-n`, parte posterior para `-ng`, sem apresentar diagramas anatômicos complexos.

### Prompt de recuperação

“Diga que está muito bem; depois diga que hoje está ocupado(a). Produza **hěn hǎo** e **jīntiān hěn máng**, mantendo o final de **hěn** e o de **máng**.”

### Prompt de transferência

“Escolha uma pessoa, uma cor e um estado. Diga ‘meu amigo é…’, ‘isto é vermelho’ ou ‘hoje estou ocupado(a)’. Use pelo menos um final em `-n` e outro em `-ng`.”

### Critério de domínio

O aluno distingue os finais-alvo em **8 de 10 escutas**, produz quatro palavras com coda reconhecível e mantém o contraste em duas frases novas. Se a frase só é entendida quando o interlocutor vê o pinyin, a célula ainda não está dominada.

---

## Item 11 — Interferência prosódica do português: acento, entonação e ritmo

**Nível:** iniciante a intermediário inicial.  
**Operação oral:** manter tons lexicais dentro da frase sem substituí-los por acento forte, melodia de pergunta ou ritmo de leitura portuguesa.

### Intenção

Quero que o aluno perceba que o mandarim não deve ser falado como português com uma curva geral de pergunta ou com uma sílaba tônica dominante. O objetivo é coordenar **pitch lexical, duração, intensidade e entonação de frase**.

### Padrão ou função

```text
cada sílaba lexical mantém sua categoria tonal
+ a frase recebe sua entonação global
+ sílabas neutras podem reduzir
```

O português brasileiro possui organização prosódica baseada em acento e ritmo; estudos descrevem hierarquia rítmica, graus de acento e redução de sílabas pós-tônicas.[6] [13] No mandarim, a altura também participa da identidade lexical. Portanto, um aluno pode transportar para o mandarim a estratégia de destacar uma sílaba e enfraquecer o restante, apagando contrastes tonais.

### Exemplos

- 你好吗？— **Nǐ hǎo ma?** — Você está bem?
- 你叫安娜吗？— **Nǐ jiào Ānnà ma?** — Você se chama Ana?
- 我很好。— **Wǒ hěn hǎo.** — Estou bem.
- 你呢？— **Nǐ ne?** — E você?
- 请再说一遍。— **Qǐng zài shuō yí biàn.** — Por favor, diga novamente.

A pergunta pode ter entonação de pergunta, mas isso não substitui os tons de **nǐ**, **hǎo**, **jiào** ou **biàn**. A partícula **ma** é leve; não precisa carregar sozinha toda a subida da pergunta.

### Slots substituíveis

- `[função]`: perguntar, responder, devolver pergunta, pedir repetição.
- `[moldura]`: `你…吗？`, `我…`, `请…`.
- `[palavra tonal]`: 好 **hǎo**, 叫 **jiào**, 再 **zài**, 遍 **biàn**.
- `[partícula leve]`: 吗 **ma**, 呢 **ne**, 的 **de**, 了 **le**.

### Extensões

1. Grave a mesma frase como afirmação e pergunta, mantendo os tons lexicais e mudando somente a entonação global.
2. Faça uma rodada de imitação e outra de recuperação sem o modelo.
3. Peça ao aluno para bater levemente um dedo por sílaba apenas na primeira rodada; depois retire o apoio e mantenha o fluxo natural.
4. No intermediário inicial, aplique a frase a contexto novo, porque o domínio não é recitar uma única entonação.

### Observação pedagógica

Evite dizer “mandarim não tem estresse” ou “toda sílaba dura igual”. Essas simplificações apagam o tom neutro, a prosódia e a variação real. A intervenção mais útil para brasileiros é: “não coloque uma sílaba tônica portuguesa sobre todas as frases; mantenha a informação tonal e deixe a entonação de pergunta ser um movimento adicional”.

O erro de leitura pode aparecer quando o aluno vê quatro marcas tonais e fala cada uma como se fosse uma palavra isolada. A solução é trabalhar **unidades de sentido** e reduzir progressivamente caracteres, pinyin e tradução.

### Potencial de mapa

**Mapa de prosódia em camadas:**

```text
[N] intenção da frase → [A1] tons lexicais → [A2] ritmo e sílabas neutras → [A3] entonação global → [X] acento português dominante → [R] situação nova
```

O mapa precisa separar visualmente três níveis:

1. tom dentro da sílaba;
2. ritmo e redução dentro do grupo;
3. entonação de pergunta ou afirmação na frase.

### Prompt de recuperação

“Pergunte se alguém está bem e responda que você está bem. Faça a mesma troca como afirmação e como pergunta, sem mudar **jiào**, **hǎo** ou **ma** por causa do português.”

### Prompt de transferência

“Você não entendeu uma frase. Peça para a pessoa repetir, depois diga que agora entendeu. Faça a solicitação em uma situação nova e sem marcar uma única sílaba como se fosse o centro
da frase.”

### Critério de domínio

O aluno produz uma afirmação e uma pergunta com a mesma base lexical, preserva os tons-alvo em **8 de 10 itens** e mantém as partículas leves sem transformar a frase em leitura silabada. Em uma situação nova, ele deve ser compreendido sem apoio do pinyin; a entonação pode ainda variar entre regiões e estilos sem invalidar o domínio tonal funcional.

---

# Síntese de desenho instrucional

## Ordem recomendada do bloco

A sequência não deve ser uma lista linear de regras declarativas. Ela deve seguir a operação que o aluno precisa executar:

| Etapa | Pergunta oral | Conteúdo prioritário | Suporte que aparece | Evidência de aprendizagem |
|---|---|---|---|---|
| 1 | “Ouço uma diferença?” | quatro tons e pares selecionados | áudio/modelo, caracteres e pinyin | escolha da intenção ou palavra |
| 2 | “Consigo manter o terceiro tom em fluxo?” | terceiro tom baixo em fala conectada | seta simples e frase curta | frase reconhecível sem pausas artificiais |
| 3 | “O som muda neste contexto?” | 3º + 3º, **不**, **一** | regra curta e exemplo funcional | recombinação com slot novo |
| 4 | “A sílaba é leve ou lexical?” | tom neutro | pinyin sem marca, ritmo e duração | expressão audível, sem peso igual |
| 5 | “Como leio este pinyin?” | iniciais, finais e convenções | pinyin tonal e contraste ortográfico | fala sem leitura portuguesa |
| 6 | “Onde está o gesto articulatório?” | aspiração, palatais, retroflexas, `ü` | alerta de boca/fluxo de ar | contraste entendido em palavra |
| 7 | “A frase ainda conserva seus tons?” | ritmo, acento e entonação | grupo de sentido e prompt | afirmação/pergunta e transferência |

## Política de contraste para brasileiros

A nota contrastiva entra somente quando muda uma decisão de fala ou compreensão. As prioridades são:

1. **Não usar acento de palavra portuguesa como substituto do tom.** O aluno deve preservar o contorno lexical e depois acrescentar a entonação da frase.
2. **Não ler pinyin como português.** `q`, `x`, `j`, `zh`, `ch`, `sh`, `r`, `c` e as finais nasais exigem escuta e gesto específico.
3. **Não confundir aspiração com vozeamento.** `b d g` não devem ser ensinados como o mesmo tipo de oposição de “b/p” do português brasileiro.
4. **Não transformar todo terceiro tom em uma curva completa.** Em fala conectada, o ponto baixo e o fluxo são mais importantes que o desenho exagerado.
5. **Não neutralizar tudo o que não tem acento gráfico.** Tom neutro é uma propriedade contextual da sílaba, não uma licença para apagar finais ou vogais.
6. **Não tratar sandhi como troca lexical.** A escrita conserva o tom de referência; a fala ajusta a realização quando o contexto exige.

Esses alertas são hipóteses de diagnóstico. O editor deve testá-los com gravações de alunos brasileiros, porque não existe um único “erro brasileiro” obrigatório. A unidade deve ser mantida somente se o alerta produzir uma melhora observável na escolha, percepção ou produção.

## Critério global de domínio

Uma célula deste bloco só pode ser aprovada quando o aluno consegue executar os quatro passos abaixo:

1. **Compreender:** identifica a intenção ou o contraste ao ouvir.
2. **Recuperar:** produz o padrão antes de ver a resposta.
3. **Pronunciar funcionalmente:** mantém o ponto tonal, a mudança contextual ou o contraste fonético trabalhado.
4. **Transferir:** usa o padrão com pelo menos três substituições ou em uma situação não apresentada no exemplo.

O critério global recomendado é:

- pelo menos **80% de acerto auditivo** no contraste trabalhado;
- pelo menos **três produções recombinadas** sem consulta;
- uma produção em contexto novo, com compreensão por um interlocutor treinado;
- registro explícito do tipo de falha: tom lexical, sandhi, inicial, final, ritmo, pinyin ou recuperação.

A aprovação não deve depender de uma curva visual perfeita, de leitura do pinyin ou de imitação de uma única gravação. O alvo é fala **compreensível, contrastiva e reutilizável**.

## Prompts cumulativos de revisão

Para preservar a arquitetura do projeto, as revisões devem misturar pronúncia com função comunicativa:

- **Mesmo dia:** “Ouça uma frase; repita mantendo o tom-alvo e a sílaba neutra leve.”
- **Dia seguinte:** “Diga a intenção sem pinyin; confira somente depois.”
- **Três a sete dias:** “Troque o sujeito, o objeto ou o contexto sem mudar a operação.”
- **Revisão cumulativa:** “Cumprimente, diga que está bem, negue uma informação, peça repetição e finalize com uma frase nova. Mantenha pelo menos um caso de sandhi e uma sílaba neutra.”

A revisão deve alternar `áudio → significado`, `intenção → mandarim`, `padrão → substituição` e `contexto → transferência`. Repetir a mesma lista na mesma ordem mede reconhecimento e não domínio.

## Limites editoriais

Este bloco não deve:

- substituir o áudio principal ou o feedback de um professor;
- prometer redução de sotaque ou pronúncia nativa apenas pela leitura;
- reproduzir diálogos, transcrições ou áudios de cursos proprietários;
- apresentar transliterações portuguesas como resposta final;
- cobrir todo o inventário fonético do mandarim em uma única página;
- esconder a diferença entre tom lexical, tom neutro e entonação de frase;
- exigir que o aluno domine caracteres antes de conseguir falar.

A camada visual deve permanecer independente e não oficial. O áudio é o motor; o mapa torna a relação entre som, intenção, contraste e recombinação visível. O resultado desejado é o desaparecimento progressivo do mapa.

---

## Referências

[1]: https://laulima.hawaii.edu/access/content/group/613e6b40-7843-4d5c-94ca-41a9e0831b95/CBasic1/u1/u1_p1.html "Basic Chinese 1 — Syllables, initials, finals and tones, University of Hawaiʻi"

[2]: https://resources.allsetlearning.com/chinese/pronunciation/Introduction_to_pinyin "Introduction to Pinyin, Chinese Pronunciation Wiki"

[3]: https://govt.chinadaily.com.cn/s/201803/27/WS5c063171498eefb3fe46e16d/what-are-tones.html "What are tones?, China Daily Government Portal"

[4]: https://pmc.ncbi.nlm.nih.gov/articles/PMC7954216/ "Plasticity in second language learning: The case of Mandarin tones, Language Learning and Development"

[5]: https://doi.org/10.1016/j.wocn.2011.11.001 "Second language acquisition of Mandarin Chinese tones by tonal and non-tonal language speakers, Journal of Phonetics"

[6]: https://doi.org/10.2307/414145 "Stress and rhythm in Brazilian Portuguese, Language"

[7]: https://resources.allsetlearning.com/chinese/pronunciation/Tone_change_rules "Tone change rules, Chinese Pronunciation Wiki"

[8]: https://www.isca-archive.org/speechprosody_2020/xu20_speechprosody.pdf "Revisiting Neutral Tone in Mandarin Broadcast News Speech, Speech Prosody 2020"

[9]: https://www.repository.cam.ac.uk/bitstreams/cd6d3251-33ee-4712-8daf-e44bb6fb8185/download "Neutral Tone in Mandarin: Representation and Interaction with Utterance-level Prosody, University of Cambridge doctoral thesis"

[10]: https://clp.hsites.harvard.edu/pronunciation-study "Pronunciation Study, Harvard Chinese Language Curriculum"

[11]: https://pressbooks.uiowa.edu/zheng/chapter/lesson-3/ "Learning initial consonants — z, c, s, zh, ch, sh, r, University of Iowa Pressbooks"

[12]: https://resources.allsetlearning.com/chinese/pronunciation/The_%22j%22_%22q%22_and_%22x%22_sounds "The j, q and x sounds, Chinese Pronunciation Wiki"

[13]: https://doi.org/10.1080/15475441.2020.1737072 "Plasticity in second language learning: The case of Mandarin tones, Lang Learn Dev."

> **Nota de verificação:** [4] e [13] apontam para o mesmo estudo de Wang, Potter e Saffran. A referência [13] foi mantida somente para registrar o DOI do artigo; em uma versão diagramada, pode-se consolidar as duas citações em [4] e remover [13].

> **Nota de escopo:** a evidência diretamente centrada em aprendizes brasileiros de mandarim ainda é limitada nas fontes públicas consultadas. As recomendações específicas para brasileiros combinam descrições contrastivas do português brasileiro com pesquisa geral de aquisição de tons e devem ser validadas por teste beta com gravações de usuários do projeto.
