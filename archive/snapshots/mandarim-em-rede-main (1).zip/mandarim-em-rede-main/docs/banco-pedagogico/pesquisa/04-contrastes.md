# Bloco Contrastes para brasileiros

## Escopo editorial

Este documento compila **somente contrastes que alteram uma decisão de fala** para brasileiros no nível iniciante a intermediário inicial. O foco não é listar gramática, mas mostrar como escolher uma forma, montar um padrão recombinável e evitar uma produção que soe errada, ambígua ou inadequada ao contexto.

O recorte segue a arquitetura do projeto: o áudio continua sendo a fonte primária; o mapa entra depois da tentativa; cada célula parte de uma intenção única; e o suporte deve diminuir de **mapa completo → mapa lacunado → prompt mínimo → independência**. O conteúdo não reproduz diálogos, roteiros, transcrições ou áudios proprietários. Os exemplos abaixo são frases originais, criadas para testar decisões contrastivas.

A seleção foi filtrada por quatro perguntas:

1. **O brasileiro tende a transferir uma oposição do português que não funciona em mandarim?**
2. **A escolha muda o sentido, o registro, a naturalidade ou a compreensão?**
3. **É possível treinar a escolha em uma frase curta e recombinável?**
4. **Existe uma tarefa oral observável para verificar domínio?**

As descrições gramaticais foram conferidas em referências públicas de gramática e pronúncia. A organização por níveis iniciante e intermediário inicial dialoga com a classificação pública da principal referência gramatical consultada.[1] A adaptação para brasileiros — incluindo tradução natural, alertas de interferência e desenho de prompts — é uma decisão pedagógica do projeto, não uma afirmação de que todo erro ocorrerá com todos os falantes.

## Matriz de prioridade

| ID | Contraste | Decisão de produção | Prioridade | Família de mapa |
|---|---|---|---|---|
| C1 | 是 / 在 / 有 | identidade, localização ou posse/existência | essencial | função + padrão |
| C2 | 不 / 没（有） | não querer/habitar/avaliar ou não ter ocorrido | essencial | contraste + tempo |
| C3 | 会 / 能 / 可以 | habilidade, possibilidade/capacidade ou permissão | essencial | contraste modal |
| C4 | 想 / 要 | desejo/intenção ou necessidade/decisão/pedido | essencial | intenção + registro |
| C5 | 还是 / 或者 | escolha exigida ou alternativa aberta | essencial | pergunta + alternativa |
| C6 | 来 / 去 | movimento para ou para longe do ponto de referência | essencial | perspectiva |
| C7 | 知道 / 认识 | informação ou familiaridade pessoal/reconhecimento | alta | tipo de objeto |
| C8 | 听懂 / 明白 | compreensão auditiva ou entendimento do sentido | alta | reparo |
| C9 | 再 / 又 | repetição ainda por fazer ou repetição já ocorrida | alta | tempo + recorrência |
| C10 | 了 / 过 | evento delimitado/mudança ou experiência anterior | alta | aspecto |
| C11 | 一点 / 有点 | um pouco a mais/quantidade ou um tanto, frequentemente com incômodo | alta | grau + posição |
| C12 | 二 / 两 | número/etiqueta ou quantidade com medida | média-alta | quantidade |
| C13 | 这 / 那 / 哪 + medida | perto, longe ou pergunta de escolha | essencial | referência + classificador |
| C14 | 也 / 都 | também ou todos | média-alta | escopo |
| C15 | 吗 / 呢 | pergunta sim/não ou devolução/continuidade | média-alta | interação |
| C16 | j/q/x / zh/ch/sh | articulação e aspiração que preservam a palavra | essencial | som |

---

## C1 — 是, 在 e 有: identidade, localização e posse/existência

### Intenção
Dizer **quem ou o que algo é**, **onde alguém/algo está** ou **o que alguém tem / existe em um lugar**.

### Padrão ou função

| Função | Padrão | Tradução funcional |
|---|---|---|
| identidade/classificação | `[sujeito] + 是 + [identidade]` | ser, tratar-se de |
| localização | `[sujeito] + 在 + [lugar]` | estar em, ficar em |
| posse | `[sujeito] + 有 + [objeto]` | ter |
| existência | `[lugar] + 有 + [coisa]` | haver, existir |

### Exemplos

- **我是巴西人。**  
  *Wǒ shì Bāxī rén.*  
  Sou brasileiro/brasileira.
- **我在家。**  
  *Wǒ zài jiā.*  
  Estou em casa.
- **我有一个问题。**  
  *Wǒ yǒu yí ge wèntí.*  
  Tenho uma pergunta.
- **这里有咖啡。**  
  *Zhèlǐ yǒu kāfēi.*  
  Aqui tem café.
- **他是老师，不在办公室。**  
  *Tā shì lǎoshī, bú zài bàngōngshì.*  
  Ele é professor; não está no escritório.

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| identidade | 巴西人 *Bāxī rén* brasileiro; 学生 *xuéshēng* estudante; 老师 *lǎoshī* professor |
| lugar | 家 *jiā* casa; 公司 *gōngsī* empresa; 这里 *zhèlǐ* aqui |
| posse/objeto | 手机 *shǒujī* celular; 钱 *qián* dinheiro; 问题 *wèntí* pergunta |
| existência | 水 *shuǐ* água; 咖啡 *kāfēi* café; 人 *rén* pessoas |

### Extensões

- Negação de identidade: **他不是学生。** *Tā bú shì xuéshēng.* — Ele não é estudante.
- Negação de localização: **我不在家。** *Wǒ bú zài jiā.* — Não estou em casa.
- Negação de posse/existência: **我没有钱。** *Wǒ méiyǒu qián.* — Não tenho dinheiro.
- Pergunta de localização: **洗手间在哪儿？** *Xǐshǒujiān zài nǎr?* — Onde fica o banheiro?

### Observação pedagógica
O português brasileiro usa **ser** e **estar** como formas do mesmo verbo, mas o mandarim exige uma decisão diferente. **是** identifica ou classifica; **在** localiza; **有** indica posse ou existência. Não ensine “是 = ser” e “在 = estar” como equivalência suficiente: o aluno deve decidir primeiro **qual relação está comunicando**. O cruzamento com **不/没** é intencional: “não estou” é **不在**, enquanto “não tenho” é **没有**, não *不有*.

### Potencial de mapa
Centro: **qual relação quero expressar?** Primeiro anel: identidade / lugar / posse-existência. Segundo anel: 是 / 在 / 有. Alerta vermelho: “estar em” não é **是**; “ter” não é **是**. O mapa lacunado deve mostrar apenas `[sujeito] + ___ + [slot]` e um desenho de pessoa, lugar ou objeto. No prompt mínimo, fica somente a situação.

### Prompt de recuperação
“Diga: ‘Estou em casa’, ‘sou brasileiro(a)’ e ‘tenho uma pergunta’.” O aluno deve escolher os três verbos sem ver a resposta.

### Prompt de transferência
Você está em uma chamada: informe sua identidade, diga onde está e avise que tem um problema. Troque casa por escritório e problema por pergunta.

### Critério de domínio
Produz **seis frases** em duas rodadas, usando 是, 在 e 有 corretamente; nega pelo menos uma localização e uma posse; responde a um prompt em português sem traduzir “ser/estar/ter” palavra por palavra; e mantém *shì*, *zài* e *yǒu* distinguíveis.

---

## C2 — 不 e 没（有）: negação de intenção/hábito versus não ocorrência/posse

### Intenção
Negar uma vontade, hábito, avaliação ou decisão atual/futura; ou informar que uma ação não aconteceu, que uma experiência não existe ou que alguém não tem algo.

### Padrão ou função

| Decisão | Padrão | Exemplo de sentido |
|---|---|---|
| hábito, vontade, decisão ou avaliação | `[sujeito] + 不 + verbo/adjetivo` | não faço; não quero; não é |
| evento não ocorrido | `[sujeito] + 没(有) + verbo` | não fiz; não aconteceu |
| ausência de posse/existência | `[sujeito/lugar] + 没有 + objeto` | não tenho; não há |
| passado experiencial negativo | `[sujeito] + 没 + verbo + 过` | nunca tive a experiência de |

### Exemplos

- **我不喝咖啡。**  
  *Wǒ bù hē kāfēi.*  
  Eu não bebo café / não costumo beber café.
- **我昨天没喝咖啡。**  
  *Wǒ zuótiān méi hē kāfēi.*  
  Ontem eu não bebi café.
- **我不想去。**  
  *Wǒ bù xiǎng qù.*  
  Não quero ir.
- **我没去。**  
  *Wǒ méi qù.*  
  Eu não fui.
- **我没有钱。**  
  *Wǒ méiyǒu qián.*  
  Não tenho dinheiro.
- **我不在家。**  
  *Wǒ bú zài jiā.*  
  Não estou em casa.

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| ação/hábito | 喝咖啡 *hē kāfēi* beber café; 吃肉 *chī ròu* comer carne; 学中文 *xué Zhōngwén* estudar chinês |
| evento passado | 去 *qù* ir; 看电影 *kàn diànyǐng* ver filme; 听见 *tīngjiàn* ouvir/perceber |
| posse | 钱 *qián* dinheiro; 时间 *shíjiān* tempo; 手机 *shǒujī* celular |
| avaliação/identidade | 是 *shì* ser; 好 *hǎo* bom; 忙 *máng* ocupado |

### Extensões

- **不是** *bú shì* — não ser; **不在** *bú zài* — não estar em; **不想** *bù xiǎng* — não querer.
- **没有** *méiyǒu* — não ter/não haver; **没去** *méi qù* — não ter ido; **没听懂** *méi tīng dǒng* — não ter entendido.
- **我没学过中文。** *Wǒ méi xué guo Zhōngwén.* — Nunca estudei chinês.
- Antes de uma sílaba de quarto tom, **不 bù** costuma realizar-se como **bú**: *bú shì*, *bú zài*, *bú qù*. A escrita pinyin de referência pode manter *bù* para mostrar o tom lexical; neste material, o alerta registra a forma falada.

### Observação pedagógica
O português “não” cobre várias decisões. O aluno deve perguntar: **estou negando uma disposição/hábito/estado, ou estou negando a ocorrência de um evento?** Com **有**, a escolha é ainda mais restrita: “não ter” é **没有**, não *不有*. Evite a regra simplista “不 = presente, 没 = passado”; ela ajuda no primeiro contato, mas falha quando a frase expressa intenção, hábito, posse ou experiência.

### Potencial de mapa
Centro: **o que exatamente está sendo negado?** Ramos: intenção/hábito/avaliação → 不; evento não ocorrido/posse/experiência → 没(有). Margem laranja: *bù/bú* e *méi*. A versão de recuperação deve retirar apenas o marcador negativo, mantendo tempo e intenção visíveis.

### Prompt de recuperação
Escolha e produza: “Eu não quero ir”; “Eu não fui ontem”; “Eu não tenho tempo”; “Eu não estudo à noite”.

### Prompt de transferência
Uma pessoa pergunta por que você não está no escritório. Responda com uma razão simples, negue uma ação de hoje e diga que ontem não fez outra ação. Não use o mesmo verbo duas vezes.

### Critério de domínio
Classifica corretamente **oito de oito** situações entre 不 e 没（有）; produz pares contrastivos como *我不喝咖啡 / 我昨天没喝咖啡*; usa **没有** com posse; e aplica pelo menos uma forma falada **bú** antes de quarto tom sem depender do pinyin.

---

## C3 — 会, 能 e 可以: habilidade, capacidade situacional e permissão

### Intenção
Dizer que sabe fazer algo, que consegue em uma circunstância concreta ou que tem autorização para fazer algo.

### Padrão ou função

| Forma | Núcleo funcional | Exemplo de pergunta |
|---|---|---|
| 会 *huì* | habilidade aprendida; também futuro em outros contextos | 你会说中文吗？ — Você sabe falar chinês? |
| 能 *néng* | capacidade/possibilidade condicionada | 你今天能来吗？ — Você consegue vir hoje? |
| 可以 *kěyǐ* | permissão ou possibilidade aceita | 我可以坐这里吗？ — Posso sentar aqui? |

As áreas se sobrepõem. **能** também pode pedir permissão, e **可以** pode expressar possibilidade; a tabela marca o foco mais útil para a primeira decisão oral. Essa sobreposição é descrita em referências de gramática modal.[4]

### Exemplos

- **我会说中文。**  
  *Wǒ huì shuō Zhōngwén.*  
  Sei falar chinês.
- **我今天不能去。**  
  *Wǒ jīntiān bù néng qù.*  
  Hoje não consigo ir.
- **我可以用你的手机吗？**  
  *Wǒ kěyǐ yòng nǐ de shǒujī ma?*  
  Posso usar seu celular?
- **他会游泳，但是今天不能游。**  
  *Tā huì yóuyǒng, dànshì jīntiān bù néng yóu.*  
  Ele sabe nadar, mas hoje não consegue nadar.
- **这里不可以抽烟。**  
  *Zhèlǐ bù kěyǐ chōuyān.*  
  Não é permitido fumar aqui.

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| habilidade | 说中文 *shuō Zhōngwén* falar chinês; 游泳 *yóuyǒng* nadar; 开车 *kāichē* dirigir |
| condição | 今天 *jīntiān* hoje; 现在 *xiànzài* agora; 太晚 *tài wǎn* tarde demais |
| permissão | 用手机 *yòng shǒujī* usar o celular; 坐这里 *zuò zhèlǐ* sentar aqui; 进来 *jìnlái* entrar |

### Extensões

- **我不会开车。** *Wǒ bú huì kāichē.* — Não sei dirigir.
- **我今天不能来。** *Wǒ jīntiān bù néng lái.* — Hoje não consigo ir até aí/vir.
- **你可以再说一遍吗？** *Nǐ kěyǐ zài shuō yí biàn ma?* — Você pode repetir?
- **会下雨吗？** *Huì xiàyǔ ma?* — Vai chover? Aqui **会** indica previsão/probabilidade futura, não habilidade.

### Observação pedagógica
O erro brasileiro nasce da tradução única “poder/saber”. Treine primeiro a pergunta de controle: **foi aprendido, é possível nesta situação ou foi permitido?** Não transforme a distinção em fronteira absoluta. Em frases de pedido, **能** e **可以** frequentemente se aproximam; o objetivo é escolher um foco comunicativo claro, não corrigir toda nuance de registro no nível inicial.

### Potencial de mapa
Centro: **por que consigo?** Primeiro anel: treino → 会; condição → 能; autorização → 可以. Segundo anel: 不会 / 不能 / 不可以. Alerta: **会** também pode ser futuro. O mapa reduzido deve mostrar somente três cartões: “aprendi”, “consigo agora”, “tenho permissão”.

### Prompt de recuperação
Produza três frases: “Sei nadar”; “Hoje não consigo ir”; “Posso usar este celular?”.

### Prompt de transferência
Você sabe dirigir, mas hoje não pode ir porque está ocupado; peça autorização para usar um telefone. Troque dirigir por falar chinês na segunda rodada.

### Critério de domínio
Escolhe a forma adequada em **nove de dez** cenários; produz uma afirmação e uma negação para habilidade, capacidade situacional e permissão; e explica oralmente, em português, qual decisão guiou cada escolha sem transformar a explicação em tradução palavra por palavra.

---

## C4 — 想 e 要: desejo/intenção versus necessidade, decisão ou pedido

### Intenção
Expressar o que se gostaria de fazer ou obter, ou declarar uma decisão/necessidade/pedido mais direto.

### Padrão ou função

| Forma | Padrão produtivo | Tradução natural |
|---|---|---|
| 想 *xiǎng* | `[sujeito] + 想 + ação` | querer/gostaria de fazer |
| 想要 *xiǎng yào* | `[sujeito] + 想要 + objeto` | gostaria de/querer um item |
| 要 *yào* | `[sujeito] + 要 + objeto/ação` | querer, precisar, decidir, pedir |

A oposição é de **foco e força**, não uma regra binária. *想* costuma deixar o desejo mais aberto ou atenuado; *要* pode soar mais decidido, necessário ou diretivo. A descrição de *想* como “would like to” e sua negação com **不** é apresentada em material didático universitário aberto.[3]

### Exemplos

- **我想喝茶。**  
  *Wǒ xiǎng hē chá.*  
  Gostaria de beber chá.
- **我要一杯茶。**  
  *Wǒ yào yì bēi chá.*  
  Quero uma xícara de chá. / Pode me trazer uma xícara de chá.
- **我想去北京。**  
  *Wǒ xiǎng qù Běijīng.*  
  Tenho vontade de ir a Pequim.
- **我明天要去北京。**  
  *Wǒ míngtiān yào qù Běijīng.*  
  Amanhã vou/preciso ir a Pequim.
- **我不想吃饭。**  
  *Wǒ bù xiǎng chīfàn.*  
  Não quero comer.
- **不要这个，谢谢。**  
  *Bú yào zhège, xièxie.*  
  Não quero este, obrigado(a).

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| ação | 喝茶 *hē chá* beber chá; 去北京 *qù Běijīng* ir a Pequim; 看电影 *kàn diànyǐng* ver filme |
| objeto | 一杯水 *yì bēi shuǐ* um copo de água; 这个 *zhège* isto; 手机 *shǒujī* celular |
| força/contexto | 明天 *míngtiān* amanhã; 现在 *xiànzài* agora; 请 *qǐng* por favor |

### Extensões

- **你想不想喝咖啡？** *Nǐ xiǎng bu xiǎng hē kāfēi?* — Você quer tomar café?
- **你要不要这个？** *Nǐ yào bu yào zhège?* — Você quer isto ou não?
- Para um pedido explícito e cortês, combine a intenção com **请**: **请给我水。** *Qǐng gěi wǒ shuǐ.* — Por favor, me dê água.
- **要** também aparece em obrigação/necessidade: **我现在要走了。** *Wǒ xiànzài yào zǒu le.* — Agora preciso ir/já vou.

### Observação pedagógica
O brasileiro tende a usar **要** sempre que pensa em “quero”. Isso pode produzir um pedido mais direto do que pretendia. Não proíba **我要**: ensine o aluno a escolher entre **desejo aberto**, **decisão/necessidade** e **pedido no balcão**. A tradução brasileira deve mostrar a função, não uma equivalência fixa.

### Potencial de mapa
Centro: **estou desejando ou decidindo/pedindo?** Ramos: desejo → 想; item desejado → 想要; decisão/necessidade/pedido → 要. Margem vermelha: 不想 ≠ 不要 em muitos contextos. O estado mínimo deve apresentar apenas a situação: “gostaria de”, “vou/preciso”, “recuso este item”.

### Prompt de recuperação
Diga: “Gostaria de beber chá”; “Amanhã preciso ir”; “Não quero este item”.

### Prompt de transferência
Em um café, peça uma bebida de forma direta e depois reformule o mesmo desejo de forma mais aberta. Na segunda rodada, troque bebida por uma ação.

### Critério de domínio
Produz **três pares** com 想/要, mantém o objeto depois de 想要, usa **不想** para recusar uma ação e **不要** para recusar um item, e ajusta a força do pedido sem precisar de explicação longa.

---

## C5 — 还是 e 或者: escolha exigida versus alternativa aberta

### Intenção
Perguntar qual opção a pessoa escolhe ou apresentar possibilidades sem exigir uma decisão naquele momento.

### Padrão ou função

| Situação | Padrão | Tradução natural |
|---|---|---|
| pergunta de escolha | `[A] + 还是 + [B]？` | A ou B? |
| declaração de alternativas | `[A] + 或者 + [B]` | A ou B; talvez A ou B |
| pergunta incorporada | `我不知道/想知道 + A 还是 B` | não sei/quero saber se A ou B |

A distinção é pragmática: **还是** apresenta uma escolha para resposta; **或者** mantém alternativas dentro de uma afirmação ou possibilidade aberta.[5]

### Exemplos

- **你喝茶还是咖啡？**  
  *Nǐ hē chá háishì kāfēi?*  
  Você toma chá ou café?
- **我们坐出租车还是坐地铁？**  
  *Wǒmen zuò chūzūchē háishì zuò dìtiě?*  
  Vamos de táxi ou metrô?
- **周末我想在家看书或者看电影。**  
  *Zhōumò wǒ xiǎng zài jiā kànshū huòzhě kàn diànyǐng.*  
  No fim de semana quero ler ou ver um filme em casa.
- **我不知道他来还是不来。**  
  *Wǒ bù zhīdào tā lái háishì bù lái.*  
  Não sei se ele vem ou não.

### Slots substituíveis

| Slot A/B | Opções iniciais |
|---|---|
| bebida | 茶 *chá* chá; 咖啡 *kāfēi* café; 水 *shuǐ* água |
| transporte | 出租车 *chūzūchē* táxi; 地铁 *dìtiě* metrô; 公共汽车 *gōnggòng qìchē* ônibus |
| ação | 看书 *kànshū* ler; 看电影 *kàn diànyǐng* ver filme; 在家休息 *zài jiā xiūxi* descansar em casa |

### Extensões

- Pergunta com ação repetida para manter a estrutura paralela: **你想去北京还是上海？** *Nǐ xiǎng qù Běijīng háishì Shànghǎi?* — Você quer ir a Pequim ou Xangai?
- Declaração com opções de contato: **我们可以电话或者邮件联系。** *Wǒmen kěyǐ diànhuà huòzhě yóujiàn liánxì.* — Podemos nos contactar por telefone ou e-mail.
- **还是** em pergunta incorporada: **我想知道你喜欢茶还是咖啡。** *Wǒ xiǎng zhīdào nǐ xǐhuan chá háishì kāfēi.* — Quero saber se você prefere chá ou café.

### Observação pedagógica
O português usa “ou” nos dois ambientes. O aluno deve decidir se está **pedindo seleção** ou **descrevendo alternativas**. Não corrija *或者* em toda frase interrogativa de maneira mecânica sem observar a intenção; para o iniciante, porém, a regra operacional “pergunta com escolha → 还是; declaração → 或者” é uma boa âncora.

### Potencial de mapa
Centro: **quero uma resposta agora?** Ramos: sim → 还是; não, apenas apresento possibilidades → 或者. Alerta vermelho: a interrogação em português não é o único sinal; a intenção de escolha é o núcleo. O prompt mínimo mostra duas imagens e a ação “pergunte” ou “afirme”.

### Prompt de recuperação
Pergunte “chá ou café?”; depois diga “no fim de semana posso ler ou ver um filme”.

### Prompt de transferência
Você precisa escolher um horário para uma reunião; em seguida, informe a alguém duas maneiras possíveis de chegar ao local, sem pedir que escolha imediatamente.

### Critério de domínio
Usa 还是 em **quatro perguntas de escolha** e 或者 em **três declarações de alternativa**; produz uma pergunta incorporada com 还是; e não precisa traduzir “ou” antes de falar.

---

## C6 — 来 e 去: direção em relação ao ponto de referência

### Intenção
Convidar, descrever ou pedir movimento **em direção ao ponto de referência da cena** ou **para longe dele**.

### Padrão ou função

| Forma | Decisão | Exemplo de sentido |
|---|---|---|
| 来 *lái* | movimento para o ponto de referência | vir para cá / para o local em foco |
| 去 *qù* | movimento para longe do ponto de referência | ir para lá / sair do local em foco |

O ponto de referência pode ser o falante, o interlocutor ou o lugar que a conversa estabeleceu como centro. A distinção não é simplesmente “movimento do corpo do falante”; é perspectiva espacial.[6]

### Exemplos

- **你来我家吗？**  
  *Nǐ lái wǒ jiā ma?*  
  Você vem à minha casa?
- **我去你家。**  
  *Wǒ qù nǐ jiā.*  
  Eu vou à sua casa.
- **请进来。**  
  *Qǐng jìnlái.*  
  Pode entrar [vindo para cá].
- **请进去。**  
  *Qǐng jìnqù.*  
  Pode entrar [indo para dentro/lá].
- **你什么时候来中国？**  
  *Nǐ shénme shíhou lái Zhōngguó?*  
  Quando você vem para a China?

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| destino | 我家 *wǒ jiā* minha casa; 公司 *gōngsī* escritório/empresa; 中国 *Zhōngguó* China |
| ação | 吃饭 *chīfàn* comer; 工作 *gōngzuò* trabalhar; 见面 *jiànmiàn* encontrar-se |
| ponto de referência | casa do falante; local do interlocutor; sala já estabelecida |

### Extensões

- **我想去北京。** *Wǒ xiǎng qù Běijīng.* — Quero ir a Pequim.
- **你可以来我家吃饭。** *Nǐ kěyǐ lái wǒ jiā chīfàn.* — Você pode vir comer na minha casa.
- Com verbos direcionais: **回来** *huílái* voltar para cá; **回去** *huíqù* voltar para lá.

### Observação pedagógica
Brasileiros frequentemente escolhem pelo ponto de partida (“estou aqui, então sempre uso ir”) e não pelo centro da cena. Antes de produzir, faça o gesto mental: **o movimento chega ao lugar que está em foco ou sai dele?** A escolha pode mudar quando o ponto de referência muda, mesmo que a pessoa seja a mesma.

### Potencial de mapa
Centro: **para onde a cena aponta?** Primeiro anel: centro → 来; afastamento → 去. Segundo anel: entrar/sair, voltar, convite. Alerta: não traduzir automaticamente “vir” e “ir” a partir do português sem reconstruir o centro deíctico.

### Prompt de recuperação
Diga: “Venha à minha casa”; “Vou à sua casa”; “Entre vindo para cá”; “Volte para lá”.

### Prompt de transferência
Você está em casa e chama alguém; depois, a pessoa está em casa dela e convida você. Repita a mesma situação trocando o local de referência.

### Critério de domínio
Produz **oito movimentos** com dois pontos de referência diferentes, escolhe 来/去 corretamente em convites e deslocamentos, e explica a mudança de perspectiva sem usar “vir = 来, ir = 去” como única justificativa.

---

## C7 — 知道 e 认识: informação versus familiaridade pessoal ou reconhecimento

### Intenção
Dizer que se sabe uma informação, que se conhece alguém pessoalmente ou que se reconhece uma pessoa, lugar ou caractere.

### Padrão ou função

| Forma | Objeto prototípico | Tradução natural |
|---|---|---|
| 知道 *zhīdào* | fato, nome, número, informação, oração | saber |
| 认识 *rènshi* | pessoa, rosto, lugar, caminho, caractere | conhecer pessoalmente; reconhecer |

### Exemplos

- **我知道他的名字。**  
  *Wǒ zhīdào tā de míngzi.*  
  Eu sei o nome dele.
- **我认识他。**  
  *Wǒ rènshi tā.*  
  Eu conheço ele pessoalmente.
- **我知道这个人，但是不认识他。**  
  *Wǒ zhīdào zhège rén, dànshì bú rènshi tā.*  
  Sei quem é essa pessoa, mas não a conheço pessoalmente.
- **你认识这个字吗？**  
  *Nǐ rènshi zhège zì ma?*  
  Você reconhece/consegue ler este caractere?
- **我不知道他住在哪儿。**  
  *Wǒ bù zhīdào tā zhù zài nǎr.*  
  Não sei onde ele mora.

### Slots substituíveis

| Slot | Escolha preferencial |
|---|---|
| informação | 名字 *míngzi* nome; 电话号码 *diànhuà hàomǎ* número de telefone; 地址 *dìzhǐ* endereço |
| pessoa | 老师 *lǎoshī* professor; 王老师 *Wáng lǎoshī* professor Wang; 他 *tā* ele |
| reconhecimento | 这个字 *zhège zì* este caractere; 这条路 *zhè tiáo lù* esta estrada; 那个人 *nàge rén* aquela pessoa |

### Extensões

- Para “entender” uma explicação, prefira **懂** ou **明白**, não 知道/认识: **我明白了。** *Wǒ míngbai le.* — Entendi.
- **不知道** *bù zhīdào* — não sei uma informação.
- **不认识** *bú rènshi* — não conheço/não reconheço.
- O contraste **知道他 / 认识他** é produtivo: “sei quem ele é” versus “tenho relação ou contato com ele”.

### Observação pedagógica
O português separa “saber” e “conhecer”, mas a interferência aparece quando o aluno escolhe pelo substantivo de forma superficial. Use a pergunta-guia: **o objeto é uma informação ou alguém/algo reconhecido por contato?** Uma pessoa pode aparecer com os dois verbos, mas com sentidos diferentes. A distinção factual e de familiaridade é documentada em referência pública de gramática de mandarim.[7]

### Potencial de mapa
Centro: **o que sei do objeto?** Ramos: informação/fato → 知道; contato/reconhecimento → 认识. Terceiro ramo: entendimento → 懂/明白, para impedir um falso terceiro polo. O mapa reduzido mostra ícones de “dado”, “pessoa” e “sentido”.

### Prompt de recuperação
Produza: “Sei o endereço”; “Conheço a professora”; “Sei quem ele é, mas não o conheço pessoalmente”.

### Prompt de transferência
Alguém pergunta sobre uma pessoa nova. Diga que sabe o nome dela, mas ainda não a conhece. Depois, mostre um caractere e diga se o reconhece.

### Critério de domínio
Escolhe 知道 ou 认识 em **dez objetos**; produz o contraste “sei quem é, mas não conheço”; usa 认识 para pessoa e caractere; e não usa nenhum dos dois para dizer “não entendi”.

---

## C8 — 听懂 e 明白: entender o que se ouviu versus captar o sentido

### Intenção
Informar se a fala foi compreendida auditivamente ou se a ideia, instrução ou explicação ficou clara.

### Padrão ou função

| Forma | Foco | Tradução natural |
|---|---|---|
| 听懂 *tīngdǒng* | resultado de compreender uma fala ouvida | entender ao ouvir |
| 明白 *míngbai* | clareza do sentido, instrução ou raciocínio | entender; sacar; ficar claro |
| 听不清 *tīng bù qīng* | som não ouvido com nitidez | não ouvir direito |

### Exemplos

- **我听懂了。**  
  *Wǒ tīngdǒng le.*  
  Entendi o que você falou.
- **我没听懂。**  
  *Wǒ méi tīngdǒng.*  
  Não entendi o que ouvi.
- **我明白了。**  
  *Wǒ míngbai le.*  
  Agora entendi / saquei.
- **我不明白这个问题。**  
  *Wǒ bù míngbai zhège wèntí.*  
  Não entendo este problema.
- **我听不清，请再说一遍。**  
  *Wǒ tīng bù qīng, qǐng zài shuō yí biàn.*  
  Não consigo ouvir direito; por favor, repita.

### Slots substituíveis

| Slot | Opções |
|---|---|
| fonte auditiva | 你说的话 *nǐ shuō de huà* o que você disse; 这个句子 *zhège jùzi* esta frase; 录音 *lùyīn* gravação |
| sentido/ideia | 这个问题 *zhège wèntí* este problema; 这个意思 *zhège yìsi* este sentido; 你的意思 *nǐ de yìsi* o que você quer dizer |
| reparo | 再说一遍 *zài shuō yí biàn* repetir; 说慢一点 *shuō màn yìdiǎn* falar mais devagar |

### Extensões

- **看懂** *kàndǒng* — entender ao ler/ver: **我看懂了。** *Wǒ kàndǒng le.* — Entendi lendo.
- **听不懂** *tīng bù dǒng* — não conseguir entender a fala, como dificuldade geral ou do conteúdo.
- **明白了吗？** *Míngbai le ma?* — Ficou claro?
- Combine reparo e retomada: **我没听懂，请再说一遍。现在我明白了。** *Wǒ méi tīngdǒng, qǐng zài shuō yí biàn. Xiànzài wǒ míngbai le.* — Não entendi; repita, por favor. Agora entendi.

### Observação pedagógica
Não trate “não entendi” como uma única resposta. O aluno precisa diagnosticar: **não captei o som**, **não entendi a fala** ou **não compreendi a ideia**. Essa escolha gera um reparo melhor. **了** em *听懂了* e *明白了* marca a mudança para um estado de compreensão; não deve ser ensinado apenas como “passado”.

### Potencial de mapa
Centro: **onde está a falha?** Ramos: som → 听不清; fala ouvida → 听懂; sentido/explicação → 明白. Margem de ação: repetir, desacelerar ou explicar. O mapa mínimo mostra apenas a situação “som”, “frase” ou “ideia”.

### Prompt de recuperação
Responda a três situações: a pessoa falou rápido; você ouviu a frase mas não entendeu; alguém explicou de novo e ficou claro.

### Prompt de transferência
Em uma conversa, peça repetição por não ter entendido; depois diga que agora entendeu a ideia. Em outra rodada, diga que o problema foi o volume, não o sentido.

### Critério de domínio
Escolhe o reparo adequado em **seis de seis cenários**; usa **没听懂**, **听不清** e **明白了** com sentidos diferentes; e mantém o fluxo “diagnóstico → pedido → confirmação” sem ler.

---

## C9 — 再 e 又: repetição futura versus repetição já ocorrida

### Intenção
Pedir ou planejar que uma ação aconteça novamente, ou comentar que uma ação já voltou a acontecer.

### Padrão ou função

| Forma | Núcleo | Padrão |
|---|---|---|
| 再 *zài* | repetição ainda por fazer; “de novo depois” | `[sujeito] + 再 + verbo` |
| 又 *yòu* | repetição já ocorrida; “de novo outra vez” | `[sujeito] + 又 + verbo + 了` |
| 再 em sequência | ação posterior |

### Exemplos

- **请再说一遍。**  
  *Qǐng zài shuō yí biàn.* — Por favor, repita.
- **我们下次再来。**  
  *Wǒmen xià cì zài lái.* — Voltamos na próxima vez.
- **你又迟到了。**  
  *Nǐ yòu chídào le.* — Você se atrasou de novo.
- **他又打电话来了。**  
  *Tā yòu dǎ diànhuà lái le.* — Ele ligou de novo.
- **我们先吃饭，再看电影。**  
  *Wǒmen xiān chīfàn, zài kàn diànyǐng.* — Primeiro vamos comer; depois vemos um filme.

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| ação a repetir | 说一遍 *shuō yí biàn* dizer uma vez; 来 *lái* vir; 看 *kàn* ver; 打电话 *dǎ diànhuà* telefonar |
| tempo | 下次 *xià cì* da próxima vez; 明天 *míngtiān* amanhã; 刚才 *gāngcái* agora há pouco; 昨天 *zuótiān* ontem |
| sequência | 吃饭 *chīfàn* comer; 回家 *huí jiā* voltar para casa; 休息 *xiūxi* descansar |

### Extensões

- **我想再看一下。** *Wǒ xiǎng zài kàn yíxià.* — Quero dar mais uma olhada.
- **你怎么又忘了？** *Nǐ zěnme yòu wàng le?* — Como você esqueceu de novo?
- Em uma sequência, **再** não significa necessariamente “novamente”: **先做作业，再玩。** *Xiān zuò zuòyè, zài wán.* — Primeiro faça a lição; depois brinque.
- **又** pode aparecer com um evento futuro já recorrente e carregar irritação, surpresa ou expectativa: **明天又要开会。** *Míngtiān yòu yào kāihuì.* — Amanhã tem reunião de novo. Para o primeiro treino, priorize **再 = ainda por fazer** e **又 = já aconteceu outra vez**.

### Observação pedagógica

O português “de novo” não obriga o falante a marcar se a repetição já ocorreu. Em mandarim, a linha do tempo guia a escolha.[13] A regra operacional é forte para a produção inicial, mas não deve virar proibição absoluta de **又** com futuro recorrente. **再** também organiza a sequência “primeiro A, depois B”.

### Potencial de mapa

Centro: **a segunda ocorrência já aconteceu?** Ramos: não, ainda vou fazê-la → 再; sim, aconteceu novamente → 又; ordenação → 先…再…. O mapa lacunado mostra uma linha do tempo com um ponto passado e um ponto futuro. O alerta vermelho deve impedir *又* em pedidos como “repita, por favor”.

### Prompt de recuperação

Escolha e produza: “Repita”; “Na próxima semana volto”; “Você se atrasou de novo”; “Primeiro vou comer, depois vou estudar”.

### Prompt de transferência

Você pede duas ações em sequência e depois comenta que alguém repetiu um erro. Na segunda rodada, troque as ações e o erro.

### Critério de domínio

Escolhe 再/又 corretamente em **oito de oito** situações; usa 再 em uma sequência sem sentido de repetição; produz um pedido de repetição espontâneo; e entende que a escrita conserva o tom lexical de **再 zài**, mesmo que o contexto decida a função.

---

## C10 — 了 e 过: evento delimitado ou mudança versus experiência

### Intenção

Dizer que uma ação ocorreu em uma situação delimitada, marcar uma mudança de estado ou relatar que alguém já teve uma experiência em algum momento.

### Padrão ou função

| Forma | Foco produtivo | Padrão inicial |
|---|---|---|
| 了 *le* | evento apresentado como concluído ou mudança de estado | `[sujeito] + verbo + 了`; `[novo estado] + 了` |
| 过 *guo* | experiência anterior, sem especificar a ocasião | `[sujeito] + verbo + 过 + objeto` |

### Exemplos

- **我吃了饭。** *Wǒ chī le fàn.* — Eu comi / já fiz a refeição.
- **电影开始了。** *Diànyǐng kāishǐ le.* — O filme começou / está começando agora.
- **我去过北京。** *Wǒ qù guo Běijīng.* — Já estive em Pequim.
- **你看过这个电影吗？** *Nǐ kàn guo zhège diànyǐng ma?* — Você já viu este filme?
- **我以前不会，现在会了。** *Wǒ yǐqián bú huì, xiànzài huì le.* — Antes eu não sabia; agora sei.
- **我没去过中国。** *Wǒ méi qù guo Zhōngguó.* — Nunca fui à China.

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| evento delimitado | 吃饭 *chīfàn* fazer refeição; 看电影 *kàn diànyǐng* ver filme; 到家 *dào jiā* chegar em casa |
| mudança | 忙 *máng* ocupado; 懂 *dǒng* entender; 会 *huì* saber fazer |
| experiência | 去中国 *qù Zhōngguó* ir à China; 吃四川菜 *chī Sìchuān cài* comer comida de Sichuan; 学中文 *xué Zhōngwén* estudar chinês |

### Extensões

- **你吃饭了吗？** *Nǐ chīfàn le ma?* — Você já comeu? Aqui a pergunta verifica um estado relevante agora.
- **我看过，但是今天没看。** *Wǒ kàn guo, dànshì jīntiān méi kàn.* — Já vi, mas hoje não assisti.
- **天气冷了。** *Tiānqì lěng le.* — O tempo ficou frio / agora está frio.
- A negação usual de experiência é **没（有）…过**, não *不…过*: **我没坐过飞机。** *Wǒ méi zuò guo fēijī.* — Nunca andei de avião.

### Observação pedagógica

Evite ensinar **了 = passado** e **过 = passado**. O contraste oral é mais útil assim: **há um evento ou mudança relevante nesta situação?** Use 了; **estou perguntando se a pessoa já teve essa experiência alguma vez?** Use 过. A função de 了 depende de contexto e inclui conclusão, mudança e estado atual; 过 focaliza a experiência anterior.[11] [12]

### Potencial de mapa

Centro: **o que quero destacar: esta ocorrência/mudança ou o histórico de experiência?** Primeiro anel: agora/evento → 了; alguma vez → 过. Segundo anel: negação com 没. O mapa mínimo usa duas perguntas: “aconteceu nesta situação?” e “já aconteceu alguma vez?”.

### Prompt de recuperação

Produza: “Já comi”; “Já fui à China”; “O filme começou”; “Nunca andei de avião”.

### Prompt de transferência

Pergunte a alguém se já viu um filme e, depois, diga o que aconteceu hoje. Na rodada seguinte, troque filme por comida e o evento por uma mudança de estado.

### Critério de domínio

Distingue **oito pares** de evento e experiência; usa 了 para uma mudança de estado e 过 para uma experiência; nega 过 com 没; e não traduz automaticamente 了 como um marcador de passado português.

---

## C11 — 一点 e 有点: quantidade/ajuste versus grau com avaliação

### Intenção

Pedir uma pequena alteração, indicar uma pequena quantidade ou dizer que algo está um pouco — frequentemente um pouco demais — de determinada maneira.

### Padrão ou função

| Forma | Posição | Função |
|---|---|---|
| 一点 *yìdiǎn* | antes de substantivo ou depois de adjetivo/verbo em certos pedidos | uma pequena quantidade; um pouco mais/menos |
| 有点 *yǒudiǎn* | antes de adjetivo ou estado | um tanto; um pouco, com possível queixa ou avaliação negativa |

### Exemplos

- **请说慢一点。** *Qǐng shuō màn yìdiǎn.* — Por favor, fale um pouco mais devagar.
- **这个菜有点咸。** *Zhège cài yǒudiǎn xián.* — Este prato está um pouco salgado.
- **给我一点水。** *Gěi wǒ yìdiǎn shuǐ.* — Me dê um pouco de água.
- **这个贵一点。** *Zhège guì yìdiǎn.* — Este é um pouco mais caro.
- **我有点累。** *Wǒ yǒudiǎn lèi.* — Estou meio cansado(a).

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| ajuste depois de adjetivo | 慢一点 *màn yìdiǎn* um pouco mais devagar; 便宜一点 *piányi yìdiǎn* um pouco mais barato; 快一点 *kuài yìdiǎn* um pouco mais rápido |
| estado avaliativo | 累 *lèi* cansado; 饿 *è* com fome; 贵 *guì* caro; 咸 *xián* salgado |
| pequena quantidade | 水 *shuǐ* água; 钱 *qián* dinheiro; 时间 *shíjiān* tempo |

### Extensões

- **便宜点吧。** *Piányi diǎn ba.* — Um pouco mais barato, por favor. Aqui **点** é uma forma reduzida comum de 一点.
- **一点也不辣。** *Yìdiǎn yě bù là.* — Não é nem um pouco apimentado.
- **有一点水。** *Yǒu yìdiǎn shuǐ.* — Tem um pouco de água. Nesta leitura de quantidade, 有一点 funciona como “há uma pequena quantidade”.
- **有点不舒服。** *Yǒudiǎn bù shūfu.* — Estou meio indisposto(a). O conjunto mantém uma avaliação negativa/indesejada.

### Observação pedagógica

O erro mais produtivo de diagnosticar é a posição: **有点 + adjetivo**, mas **adjetivo + 一点** em pedidos e comparações. **一点** antes de um substantivo expressa quantidade; não substitua por **有点** nesse ambiente. A carga avaliativa de **有点** deve ser apresentada como tendência pragmática, não como tradução obrigatória de “um pouco”.[14]

### Potencial de mapa

Centro: **estou ajustando algo ou avaliando um estado?** Ajuste/quantidade → 一点; estado um pouco indesejado → 有点. O mapa lacunado alterna posições: `说慢 ___` versus `___ 累`. O prompt mínimo mostra uma situação de pedido ou uma expressão facial de incômodo.

### Prompt de recuperação

Diga: “Fale mais devagar”; “Estou meio cansado(a)”; “Me dê um pouco de água”; “Este está um pouco mais barato”.

### Prompt de transferência

Em uma loja, peça três ajustes diferentes e depois avalie dois itens como “um pouco caros” ou “um pouco salgados”. Troque os adjetivos na segunda rodada.

### Critério de domínio

Coloca 一点 na posição correta em **cinco pedidos/comparações**, usa 有点 antes de **quatro adjetivos/estados**, expressa quantidade com 一点 e não usa *一点累* para dizer “estou meio cansado”.

---

## C12 — 二 e 两: numeral/etiqueta versus quantidade contável

### Intenção

Dizer o número dois em uma sequência, código, andar ou ordinal, ou contar duas unidades de algo.

### Padrão ou função

| Forma | Contexto | Exemplo |
|---|---|---|
| 二 *èr* | algarismo, número de série, ordinal, mês, andar, parte de número composto | 二楼 *èr lóu*, segundo andar |
| 两 *liǎng* | “dois” antes de classificador ou unidade de contagem | 两个人 *liǎng ge rén*, duas pessoas |

### Exemplos

- **我有两本书。** *Wǒ yǒu liǎng běn shū.* — Tenho dois livros.
- **我住在二楼。** *Wǒ zhù zài èr lóu.* — Moro no segundo andar.
- **现在两点。** *Xiànzài liǎng diǎn.* — Agora são duas horas.
- **请拨二二零。** *Qǐng bō èr èr líng.* — Disque 220.
- **第二次。** *Dì èr cì.* — A segunda vez.
- **两个月。** *Liǎng ge yuè.* — Dois meses.

### Slots substituíveis

| Slot | Opções iniciais |
|---|---|
| quantidade com medida | 两个人 *liǎng ge rén* duas pessoas; 两杯茶 *liǎng bēi chá* duas xícaras de chá; 两天 *liǎng tiān* dois dias |
| etiqueta/número | 二楼 *èr lóu* segundo andar; 二号 *èr hào* número 2; 二月 *èr yuè* fevereiro |
| número composto | 十二 *shí’èr* doze; 二十二 *èrshí’èr* vinte e dois; 二百 *èrbǎi* duzentos |

### Extensões

- **两点半。** *Liǎng diǎn bàn.* — Duas e meia.
- **第二个人。** *Dì èr ge rén.* — A segunda pessoa. Aqui 二 é ordinal; o classificador aparece depois de 二 por causa da estrutura ordinal.
- Em números compostos como **十二个人** *shí’èr ge rén* (“doze pessoas”), mantém-se 二 dentro do número; não se troca automaticamente por 两.
- **两** costuma aparecer com classificadores e unidades de tempo; a escolha de medida continua necessária em contextos contáveis.

### Observação pedagógica

O português tem apenas “dois”, então a escolha precisa ser automatizada por ambiente. A heurística inicial é: **há um classificador/unidade para contar duas coisas?** use 两; **estou nomeando o número, o andar, o mês ou um ordinal?** use 二. Ela não cobre todas as exceções de fala, mas evita o erro mais frequente sem sobrecarregar o iniciante.[15]

### Potencial de mapa

Centro: **estou contando unidades ou nomeando um número?** Contagem → 两; rótulo/sequência → 二. O mapa deve destacar **两 + medida** e **第 + 二 + medida** como estruturas diferentes.

### Prompt de recuperação

Produza: “duas pessoas”; “segundo andar”; “duas horas”; “segunda vez”; “doze pessoas”.

### Prompt de transferência

Você informa o andar, agenda um horário e compra duas bebidas. Na segunda rodada, troque andar por linha de metrô e bebidas por livros.

### Critério de domínio

Escolhe 二/两 em **dez estímulos** com pelo menos quatro tipos de contexto; usa dois classificadores diferentes; produz 12 com 二; e não usa *二个人* para “duas pessoas” no padrão-alvo.

---

## C13 — 这, 那 e 哪 + classificador: referência próxima, distante e escolha

### Intenção

Apontar/identificar algo próximo ou distante, ou perguntar qual item entre alternativas.

### Padrão ou função

| Função | Padrão | Tradução funcional |
|---|---|---|
| identificação predicativa | `这/那 + 是 + substantivo` | isto/aquilo é… |
| referência antes de substantivo | `这/那 + classificador + substantivo` | este/aquele… |
| pergunta de escolha | `哪 + classificador + substantivo` | qual…? |

Quando 这, 那 ou 哪 determinam um substantivo, o classificador normalmente vem entre o demonstrativo/interrogativo e o substantivo. O padrão é descrito para 这/那 em referência aberta de gramática.[10]

### Exemplos

- **这是什么？** *Zhè shì shénme?* — O que é isto?
- **这是我的书。** *Zhè shì wǒ de shū.* — Este é o meu livro.
- **这本书很好。** *Zhè běn shū hěn hǎo.* — Este livro é muito bom.
- **那个人是谁？** *Nàge rén shì shéi?* — Quem é aquela pessoa?
- **你要哪杯咖啡？** *Nǐ yào nǎ bēi kāfēi?* — Qual café você quer?
- **哪个手机是你的？** *Nǎge shǒujī shì nǐ de?* — Qual celular é o seu?

### Slots substituíveis

| Slot | Classificador/objeto |
|---|---|
| pessoa | 个 *ge* + 人 *rén*; 那个人 *nàge rén* aquela pessoa |
| livro | 本 *běn* + 书 *shū*; 这本书 *zhè běn shū* este livro |
| bebida | 杯 *bēi* + 茶/咖啡; 哪杯咖啡 *nǎ bēi kāfēi* qual café |
| celular/máquina | 部 *bù* ou 个 *ge* em fala cotidiana + 手机; 这个手机 *zhège shǒujī* este celular |

### Extensões

- Forma coloquial frequente: **这个** *zhège* este/isto; **那个** *nàge* aquele/aquilo. O *ge* pode ficar reduzido e neutro na fala.
- Distância também pode ser discursiva: **这件事** *zhè jiàn shì* este assunto em foco; **那件事** *nà jiàn shì* aquele assunto já mencionado ou afastado.
- **哪儿/哪里** *nǎr/nǎlǐ* significa “onde” e não é o mesmo padrão de **哪个** *nǎge* “qual”.

### Observação pedagógica

Há dois erros diferentes: usar 这/那 diretamente antes do substantivo sem classificador e confundir **哪** (“qual/onde”, conforme a construção) com **那** (“aquele”). Não corrija **这是书** com classificador: ali o substantivo é predicativo (“isto é um livro”). O classificador é exigido no ramo atributivo **这本书**.

### Potencial de mapa

Centro: **estou identificando, apontando ou escolhendo?** Ramos: 这 = perto/em foco; 那 = afastado; 哪 = escolha; depois, classificador adequado. O mapa lacunado deve retirar o classificador, não o objeto, para testar a decisão de forma.

### Prompt de recuperação

Diga: “Este livro”; “aquela pessoa”; “qual xícara de café?”; “isto é um livro”.

### Prompt de transferência

Aponte para três objetos reais: um próximo, um distante e dois entre os quais alguém deve escolher. Produza as frases sem traduzir “this/that/which”.

### Critério de domínio

Usa 这/那/哪 em **nove de dez** estímulos; inclui classificadores em referências nominais; mantém a diferença entre **这是什么** e **这本书**; e distingue **哪** de **那** em escuta e produção funcional.

---

## C14 — 也 e 都: também versus todos

### Intenção

Adicionar uma pessoa ou situação semelhante, ou generalizar uma afirmação para todos os membros de um conjunto.

### Padrão ou função

| Forma | Escopo | Padrão inicial |
|---|---|---|
| 也 *yě* | também, igualmente em relação a outro elemento | `[sujeito] + 也 + predicado` |
| 都 *dōu* | todos, sem exceção relevante no conjunto | `[sujeito plural] + 都 + predicado` |
| 也都 | todos também | `[sujeito] + 也都 + predicado` |

### Exemplos

- **我也喝茶。** *Wǒ yě hē chá.* — Eu também bebo chá.
- **我们都喜欢茶。** *Wǒmen dōu xǐhuan chá.* — Todos nós gostamos de chá.
- **他们也都想去。** *Tāmen yě dōu xiǎng qù.* — Todos eles também querem ir.
- **我不喝咖啡，他也不喝。** *Wǒ bù hē kāfēi, tā yě bù hē.* — Eu não bebo café; ele também não.
- **我们都没去过北京。** *Wǒmen dōu méi qù guo Běijīng.* — Nenhum de nós já foi a Pequim.

### Slots substituíveis

| Slot | Opções |
|---|---|
| sujeito de adição | 我 *wǒ* eu; 他 *tā* ele; 我们 *wǒmen* nós |
| conjunto | 他们 *tāmen* eles; 两个人 *liǎng ge rén* duas pessoas; 学生们 *xuéshēngmen* os alunos |
| predicado | 喜欢茶 *xǐhuan chá* gostar de chá; 会说中文 *huì shuō Zhōngwén* saber falar chinês; 想去 *xiǎng qù* querer ir |

### Extensões

- Negação mantém os advérbios antes do marcador negativo: **他们也都不喜欢。** *Tāmen yě dōu bù xǐhuan.* — Eles também não gostam, todos eles.
- **也** pode aparecer com sujeito singular: **我也不知道。** *Wǒ yě bù zhīdào.* — Eu também não sei.
- Para “todos” em uma pergunta, **都** pode aparecer mesmo sem tradução explícita: **你们都好吗？** *Nǐmen dōu hǎo ma?* — Vocês estão todos bem?

### Observação pedagógica

O brasileiro pode usar **也** como “também” e esquecer que **都** não significa “muito” nem “também”: ele marca abrangência do conjunto. A decisão precisa ser feita pelo escopo: **estou adicionando um participante à informação anterior ou cobrindo todo o grupo?** Em **也都**, a ordem é 也 antes de 都 no padrão descrito pelas referências.[17]

### Potencial de mapa

Centro: **qual é o escopo?** Adição → 也; totalidade → 都; adição + totalidade → 也都. O mapa deve representar um indivíduo destacado e um grupo completo, não apenas traduzir as palavras.

### Prompt de recuperação

Produza: “Eu também sei”; “todos nós sabemos”; “todos eles também querem ir”; “eu também não sei”.

### Prompt de transferência

Uma pessoa declara que gosta de chá. Responda que você também gosta; depois diga que todos os seus amigos gostam. Na segunda rodada, use uma negação.

### Critério de domínio

Distingue 也/都 em **oito de oito** situações de escopo; coloca ambos na posição correta; produz uma frase com 也都; e não interpreta 都 como “também” quando o conjunto é o foco.

---

## C15 — 吗 e 呢: pergunta polar versus devolução, tópico ou item ausente

### Intenção

Perguntar se uma proposição é verdadeira ou devolver/abrir uma pergunta curta sobre uma pessoa, objeto ou alternativa.

### Padrão ou função

| Forma | Função | Padrão |
|---|---|---|
| 吗 *ma* | pergunta sim/não sobre uma frase declarativa | `[frase] + 吗？` |
| 呢 *ne* | “e você?”, “e este?”, item em foco ou localização esperada | `[tópico] + 呢？` |

### Exemplos

- **你好吗？** *Nǐ hǎo ma?* — Tudo bem com você?
- **你会说中文吗？** *Nǐ huì shuō Zhōngwén ma?* — Você sabe falar chinês?
- **我很好，你呢？** *Wǒ hěn hǎo, nǐ ne?* — Estou bem; e você?
- **这个很好，那个呢？** *Zhège hěn hǎo, nàge ne?* — Este é muito bom; e aquele?
- **我的手机呢？** *Wǒ de shǒujī ne?* — E o meu celular? / Cadê meu celular?
- **你呢？** *Nǐ ne?* — E você?

### Slots substituíveis

| Slot | Opções |
|---|---|
| frase polar | 你忙 *nǐ máng* você está ocupado; 他在家 *tā zài jiā* ele está em casa; 你会说中文 *nǐ huì shuō Zhōngwén* você sabe falar chinês |
| tópico devolvido | 你 *nǐ* você; 那个 *nàge* aquele; 明天 *míngtiān* amanhã |
| item esperado | 钱 *qián* dinheiro; 手机 *shǒujī* celular; 你的书 *nǐ de shū* seu livro |

### Extensões

- **你呢？** devolve uma pergunta sem repetir o predicado completo; isso não é uma omissão “errada”, mas uma estratégia conversacional.
- **今天呢？** *Jīntiān ne?* — E hoje? / E quanto a hoje?
- **谁呢？** *Shéi ne?* — E quem? / Quem, então?
- Para uma pergunta polar completa, prefira **吗** no nível inicial: **你在家吗？** *Nǐ zài jiā ma?* — Você está em casa?

### Observação pedagógica

O português brasileiro pode usar “e você?” e “cadê?” como formas muito diferentes. **呢** cobre essas ações interacionais quando o tópico já está disponível ou é esperado. Não ensine 呢 como um simples equivalente de “né?”; o uso inicial mais transferível é **devolver a pergunta, contrastar tópicos e procurar um item**. O material de referência descreve 呢 como pergunta recíproca e “e quanto a…?”.[18]

### Potencial de mapa

Centro: **preciso validar uma frase ou abrir/devolver um tópico?** Validação sim/não → 吗; continuidade/devolução/item ausente → 呢. O mapa reduzido mostra duas setas: “responda sim/não” e “continue a rede”.

### Prompt de recuperação

Pergunte: “Você está em casa?”; diga “Estou bem; e você?”; pergunte “E o celular?”; pergunte “E amanhã?”.

### Prompt de transferência

Receba três respostas sobre nome, origem e localização. Para cada uma, devolva a pergunta com 呢 sem repetir o predicado. Depois, procure mentalmente um objeto perdido.

### Critério de domínio

Usa 吗 em **quatro perguntas polares**, 呢 em **quatro devoluções/tópicos**, produz **我的手机呢？** com naturalidade e não troca 呢 por 吗 quando o objetivo é “e você?”.

---

## C16 — j/q/x versus zh/ch/sh: pinyin não é ortografia portuguesa

### Intenção

Produzir e reconhecer iniciais que distinguem palavras frequentes, mantendo posição da língua, aspiração e qualidade do som.

### Padrão ou função

| Grupo | Decisão articulatória operacional | Exemplos |
|---|---|---|
| j/q/x | língua com a ponta baixa atrás dos dentes inferiores; região anterior do palato; q com aspiração mais forte | **叫 jiào** chamar; **去 qù** ir; **谢谢 xièxie** obrigado(a) |
| zh/ch/sh | língua retraída/retroflexa, com outra configuração; ch é aspirado | **中国 Zhōngguó** China; **吃 chī** comer; **是 shì** ser |

A fonte de pronúncia destaca que j, q e x não devem ser lidos pelos valores de outras línguas; descreve a ponta da língua baixa para o grupo e a diferença de aspiração de q.[9]

### Exemplos

- **叫** — *jiào* — chamar-se/chamar. Não leia o **j** como o “j” de *jantar*.
- **去** — *qù* — ir. Não leia o **q** como “qu” do português; há uma inicial aspirada específica.
- **谢谢** — *xièxie* — obrigado(a). Não leia **x** como “x” de *xícara* nem como “ch” português.
- **中国** — *Zhōngguó* — China. O **zh** é retroflexo; não é o mesmo som de **j**.
- **吃** — *chī* — comer. O **ch** é aspirado e não corresponde simplesmente ao “tch” brasileiro.
- **是** — *shì* — ser/estar em identificação. O **sh** exige outra posição da língua que o **x**.

### Slots substituíveis

| Contraste | Pares/itens de produção |
|---|---|
| j versus zh | 叫 *jiào* chamar; 中国 *Zhōngguó* China; 知道 *zhīdào* saber |
| q versus ch | 去 *qù* ir; 吃 *chī* comer; 请 *qǐng* por favor |
| x versus sh | 谢谢 *xièxie* obrigado; 是 *shì* ser; 学习 *xuéxí* estudar |
| aspiração | q/ch aspirados; j/zh não aspirados no mesmo grau |

### Extensões

- O grupo j/q/x combina com a série escrita **u** que representa som de **ü** em formas como **去 qù**, **句 jù** e outras sílabas da série. Não introduza a regra gráfica como prioridade antes do contraste auditivo.
- A posição da língua é uma instrução de tentativa, não uma promessa de autocorreção. O aluno precisa comparar com áudio legítimo e, quando necessário, receber feedback de pessoa ou ferramenta apropriada.
- Tons continuam relevantes: **叫 jiào** é quarto tom; **去 qù** é quarto tom; **吃 chī** é primeiro tom; **是 shì** é quarto tom. Não transforme um erro tonal em erro de inicial nem vice-versa.

### Observação pedagógica

Para brasileiros, o risco não é apenas “pronunciar com sotaque”: pinyin convida a aplicar valores ortográficos do português. O ensino deve começar pela **ação articulatória e pelo contraste dentro de palavras de uso**, não por uma lista de equivalências (“x = ch”, “q = tch”). A aspiração deve ser testada com um papel leve ou com a própria percepção de fluxo de ar, mas isso não substitui escuta e feedback.

### Potencial de mapa

Centro: **qual configuração de língua e qual aspiração preservam a palavra?** Primeiro anel: língua baixa → j/q/x; língua retraída → zh/ch/sh. Segundo anel: não aspirado/aspirado. O mapa não deve sugerir que uma letra portuguesa corresponde a cada som; deve mostrar gesto, sopro e palavra.

### Prompt de recuperação

Sem olhar pinyin, tente produzir “chamar”, “ir”, “obrigado(a)”, “China”, “comer” e “ser”. Depois revele os caracteres para verificar a escolha.

### Prompt de transferência

Grave duas rodadas com as seis palavras em ordem alterada. Na segunda, use três delas em frases novas: “Vou para a China”, “Por favor, repita”, “Eu sei”. Compare o áudio com uma fonte de pronúncia confiável ou peça avaliação especializada.

### Critério de domínio

Reconhece o grupo correto em **oito de dez** itens auditivos; produz seis palavras sem aplicar a ortografia portuguesa; mantém a aspiração contrastiva em q/ch; e não considera leitura silenciosa evidência de pronúncia dominada.

---

## Protocolo de uso oral do bloco

O bloco não deve ser estudado como uma lista de regras. Para cada célula, use o ciclo abaixo:

1. **Tente antes de consultar.** Leia somente a intenção ou ouça um estímulo legítimo. Produza a forma que escolheria.
2. **Compare a decisão.** Abra o mapa completo depois da tentativa. Localize o ramo fixo, o slot e o alerta vermelho.
3. **Lacune o contraste.** Cubra a palavra decisiva, mantendo visível a intenção, o tempo, o objeto ou o ponto de referência.
4. **Recombine.** Troque pelo menos três slots sem repetir a ordem dos exemplos.
5. **Transfira.** Use o prompt novo com o mapa fechado ou reduzido ao mínimo.
6. **Registre o erro.** Marque separadamente compreensão, recuperação, pronúncia funcional e transferência.

### Decisão de retirada do suporte

| Resultado | Próxima ação |
|---|---|
| acertou por reconhecimento visual | repetir no mapa lacunado; ainda não é domínio |
| escolheu a palavra errada, mas pronunciou bem | revisar o contraste sem acrescentar vocabulário |
| escolheu corretamente, mas o som falhou | voltar ao áudio e ao feedback; não compensar com mais explicação escrita |
| acertou exemplo, mas falhou no prompt novo | retornar aos slots e criar três variações menores |
| acertou intenção, forma, som funcional e transferência | retirar pinyin/tradução e manter somente prompt mínimo |

### Alertas de escopo

- **Caracteres simplificados, pinyin tonal e tradução natural** são apoios de organização. Eles não devem aparecer antes da primeira tentativa quando o objetivo for recuperação.
- **Pinyin registra tons lexicais**, mas a fala conectada pode realizar mudanças tonais, especialmente com **不**, **一** e terceiros tons. A regra de **不** antes de quarto tom e as mudanças de **一** são fenômenos de pronúncia que devem ser ouvidos, não apenas lidos.[8]
- **Naturalidade depende de contexto, região e registro.** As células escolhem um padrão de alta utilidade para iniciante; elas não pretendem esgotar exceções nem substituir exposição auditiva.
- **Pronúncia não é validada pelo PDF.** O critério “pronúncia funcional” exige áudio, gravação comparável, ferramenta validada ou feedback humano. O material organiza a decisão e o treino; não promete corrigir o aparelho fonador por leitura.
- **Não reproduza material proprietário.** Use o áudio principal licenciado pelo estudante e crie prompts originais. O bloco não fornece transcrições, falas ou respostas de nenhum curso externo.

## Referências

[1]: https://resources.allsetlearning.com/chinese/grammar/Main_Page "Chinese Grammar Wiki — Main Page and level organization"
[2]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22bu%22_and_%22mei%22 "Chinese Grammar Wiki — Comparing 不 and 没"
[3]: https://human.libretexts.org/Bookshelves/Languages/Chinese/CHN101_Elementary_Mandarin_I_Textbook/05%3A_Ordering_Food_and_Drink/5.07%3A_Lesson_4_Grammar_-_Expressing_would_like_to_with__(xiang) "CHN101 Elementary Mandarin I — Expressing would like to with 想"
[4]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22hui,%22_%22neng,%22_%22keyi%22 "Chinese Grammar Wiki — Comparing 会, 能 and 可以"
[5]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22haishi%22_and_%22huozhe%22 "Chinese Grammar Wiki — Comparing 还是 and 或者"
[6]: https://resources.allsetlearning.com/chinese/grammar/Directional_verbs_%22lai%22_and_%22qu%22 "Chinese Grammar Wiki — Directional verbs 来 and 去"
[7]: https://elon.io/grammar/chinese-mandarin/verbs/zhidao-renshi-know "Elon.io — 知道 vs 认识: Know a Fact vs Be Acquainted"
[8]: https://resources.allsetlearning.com/chinese/pronunciation/Tone_change_rules "Chinese Pronunciation Wiki — Tone change rules"
[9]: https://resources.allsetlearning.com/chinese/pronunciation/The_%22j%22_%22q%22_and_%22x%22_sounds "Chinese Pronunciation Wiki — The j, q and x sounds"
[10]: https://resources.allsetlearning.com/chinese/grammar/Measure_words_with_%22this%22_and_%22that%22 "Chinese Grammar Wiki — Measure words with 这 and 那"
[11]: https://resources.allsetlearning.com/chinese/grammar/Uses_of_%22le%22 "Chinese Grammar Wiki — Uses of 了"
[12]: https://resources.allsetlearning.com/chinese/grammar/Expressing_experience_with_%22guo%22 "Chinese Grammar Wiki — Expressing experiences with 过"
[13]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22zai%22_and_%22you%22 "Chinese Grammar Wiki — Comparing 再 and 又"
[14]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22youdian%22_and_%22yidian%22 "Chinese Grammar Wiki — Comparing 有点 and 一点"
[15]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22er%22_and_%22liang%22 "Chinese Grammar Wiki — Comparing 二 and 两"
[17]: https://resources.allsetlearning.com/chinese/grammar/Using_%22ye%22_and_%22dou%22_together "Chinese Grammar Wiki — Using 也 and 都 together"
[18]: https://resources.allsetlearning.com/chinese/grammar/Questions_with_%22ne%22 "Chinese Grammar Wiki — Questions with 呢"
