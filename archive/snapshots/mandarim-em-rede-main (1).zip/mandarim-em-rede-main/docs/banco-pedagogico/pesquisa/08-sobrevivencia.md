# 08 — Sobrevivência social

## Reparo, cortesia, manutenção e encerramento

**Público:** adulto brasileiro iniciante a intermediário inicial, com prioridade para fala e recombinação.  
**Unidade editorial:** célula de transferência. Cada célula treina uma ação social observável, oferece um padrão produtivo, limita a variação e termina em produção oral sem suporte completo.

> Este bloco prepara o aluno para **continuar uma interação quando algo dá errado, reduzir o custo social de um pedido, manter o canal aberto e sair de uma conversa sem ruptura**. Ele não é uma lista de frases para reconhecer. É uma rede de decisões orais.

## Escopo e decisão de seleção

O bloco foi filtrado por quatro perguntas: **o aluno precisa dizer isso para manter a interação? A expressão é reutilizável? A diferença de registro muda a escolha? A célula pode ser testada sem reproduzir uma conversa pronta?** Foram mantidas expressões de alta utilidade e ação oral clara. Foram deixadas de fora fórmulas raras, excessivamente cerimoniosas, listas de sinônimos sem decisão pragmática e material que só produz reconhecimento visual.

Os exemplos abaixo são **enunciados isolados e autorais**. Não reproduzem diálogos, transcrições ou áudios proprietários. O material deve ser usado depois da sessão principal de áudio: primeiro o aluno tenta responder; só depois consulta caracteres, pinyin, tradução e contraste.

### Convenções de leitura

- **[F]** = componente fixo; **[V]** = componente substituível; **[O]** = extensão opcional; **[A]** = alerta auditivo, tonal ou de pronúncia; **[X]** = contraste crítico; **[R]** = prompt ou critério de domínio.
- O pinyin usa marcas de tom. A tradução é **natural em português brasileiro**, não uma tradução palavra por palavra.
- A ordem sugerida de suporte é: **mapa completo → mapa lacunado → prompt mínimo → situação oral sem mapa**.
- O estudante não precisa ler caracteres para iniciar a fala. Os caracteres entram como apoio de organização e reconhecimento posterior.

## Mapa geral do bloco

| Família | Ação dominante | Células | Resultado oral prioritário |
|---|---|---|---|
| **Reparo** | recuperar o fio quando a compreensão falha | R1–R5 | identificar o tipo de falha, pedir ajuste, localizar a palavra ou confirmar o sentido |
| **Cortesia** | reduzir imposição e administrar face | C1–C4 | abrir contato, pedir favor, agradecer, desculpar-se e responder adequadamente |
| **Manutenção** | sinalizar escuta e sustentar o turno | M1–M4 | devolver pergunta, confirmar recebimento, convidar continuação e ganhar tempo |
| **Encerramento** | fechar a interação com clareza e vínculo | E1–E4 | anunciar saída, combinar próximo contato, fechar canal e escolher despedida adequada |

---

# 1. Reparo

## R1 — Nomear a falha: não ouvi claramente ou não entendi

**Intenção.** Informar o interlocutor sobre a natureza da falha sem fingir compreensão. O objetivo é separar **som não captado** de **sentido não construído**.

**Padrão ou função.**

```text
[F] 我没听清楚。       Wǒ méi tīng qīngchu.       Não ouvi direito.
[F] 我没听懂。         Wǒ méi tīng dǒng.          Não entendi o que ouvi.
[F] 我不明白。         Wǒ bù míngbai.             Não entendo / não compreendo.
```

**Exemplos.**

1. **我没听清楚。**  
   **Wǒ méi tīng qīngchu.**  
   Não ouvi claramente.
2. **我没听懂。**  
   **Wǒ méi tīng dǒng.**  
   Não consegui entender.
3. **我不明白这个意思。**  
   **Wǒ bù míngbai zhège yìsi.**  
   Não entendo o que isso quer dizer.

**Slots substituíveis.**

- **[V — objeto da dificuldade]**: `这个词` *zhège cí* — esta palavra; `最后一句` *zuìhòu yí jù* — a última frase; `这个意思` *zhège yìsi* — este sentido.
- **[V — fonte da falha]**: `没听清楚` — não ouvi claramente; `没听懂` — não entendi o que ouvi; `不明白` — não compreendo o sentido.

**Extensões.**

- **我没听清楚，你能再说一遍吗？**  
  **Wǒ méi tīng qīngchu, nǐ néng zài shuō yí biàn ma?**  
  Não ouvi direito; você pode repetir?
- **我听懂了。**  
  **Wǒ tīng dǒng le.**  
  Agora eu entendi.
- **我不太明白。**  
  **Wǒ bú tài míngbai.**  
  Não entendo muito bem. Aqui, `不太` suaviza a afirmação.

**Observação pedagógica.** O aluno brasileiro tende a usar uma única tradução de “não entendi” para problemas diferentes. A decisão funcional deve vir antes da frase: **o som não chegou?** use `没听清楚`; **o som chegou, mas o sentido não?** use `没听懂` ou `不明白`. A negação de evento ou resultado usa `没`, não `不`: compare `没听懂` com `不明白`, que descreve estado ou compreensão insuficiente.

**Potencial de mapa.** **Mapa de contraste**: no centro, “localizar a falha”; ramo azul `听`/ouvir; ramo verde `懂`/entender; ramo vermelho `[X] 没` para evento não alcançado versus `不` para estado ou avaliação; ramo dourado, “agora posso pedir o reparo adequado”.

**Prompt de recuperação.** O interlocutor fala uma frase rápida e o aluno não captou os sons. Produza uma frase curta que nomeie a falha. Depois, imagine que ouviu as palavras, mas não entendeu o sentido, e troque apenas o núcleo.

**Prompt de transferência.** Em uma chamada com ruído, diga que não ouviu claramente. Em uma aula, diga que ouviu a frase, mas não compreendeu uma ideia. Faça as duas respostas sem consultar o mapa completo.

**Critério de domínio.** Em quatro de cinco tentativas, o aluno escolhe `没听清楚`, `没听懂` ou `不明白` de acordo com a causa da falha, inicia a frase sem traduzir palavra por palavra e mantém `méi` em `没` e `bù` em `不`.

**Alerta de pronúncia e registro.** `清楚 qīngchu` normalmente tem a segunda sílaba neutra; não dê o mesmo peso a `chu`. `不明白 bù míngbai` é neutro e útil em diversos contextos; `什么？` ou `哈？` podem ser naturais entre íntimos, mas são abruptos para o repertório-base de sobrevivência.

---

## R2 — Pedir repetição sem abandonar a conversa

**Intenção.** Solicitar que a pessoa repita a mensagem inteira de modo claro e socialmente aceitável.

**Padrão ou função.**

```text
[O] 不好意思， + [V] 你/您能再说一遍吗？
     Bù hǎoyìsi, + nǐ/nín néng zài shuō yí biàn ma?
     Desculpe, você poderia repetir?

[F] 请再说一遍。
    Qǐng zài shuō yí biàn.
    Por favor, repita.
```

**Exemplos.**

1. **不好意思，你能再说一遍吗？**  
   **Bù hǎoyìsi, nǐ néng zài shuō yí biàn ma?**  
   Desculpe, você pode repetir?
2. **请再说一遍。**  
   **Qǐng zài shuō yí biàn.**  
   Por favor, repita.
3. **不好意思，您能再说一遍吗？**  
   **Bù hǎoyìsi, nín néng zài shuō yí biàn ma?**  
   Desculpe, o senhor/a senhora poderia repetir?

**Slots substituíveis.**

- **[V1 — interlocutor]**: `你 nǐ` — você, relação comum; `您 nín` — forma respeitosa, útil com pessoa mais velha, cliente, professor ou contexto profissional.
- **[V2 — tipo de reparo]**: `再说一遍` *zài shuō yí biàn* — repetir a fala; `再讲一遍` *zài jiǎng yí biàn* — explicar/dizer novamente, conforme o contexto.
- **[O — marcador de leve constrangimento]**: `不好意思` antes do pedido.

**Extensões.**

- **你能再说一遍吗？**  
  **Nǐ néng zài shuō yí biàn ma?**  
  Você pode repetir?
- **请你再说一遍，好吗？**  
  **Qǐng nǐ zài shuō yí biàn, hǎo ma?**  
  Você poderia repetir, por favor?
- **不好意思，我没听清楚。**  
  **Bù hǎoyìsi, wǒ méi tīng qīngchu.**  
  Desculpe, não ouvi direito.

**Observação pedagógica.** O núcleo `再说一遍` deve ficar automático antes de o aluno aprender muitas alternativas. `请` vem antes do verbo e funciona bem em pedidos polidos e situações de serviço; uma pergunta com `能不能` ou `能...吗` oferece ao interlocutor uma saída e costuma ser mais flexível em conversa. [1] [4]

**Potencial de mapa.** **Mapa de padrão**: centro “repetição”; `[F] 再 + V + 一遍`; `[V] 说/讲`; `[O] 不好意思`; `[X]` repetição inteira versus palavra específica de R4; margem tonal em `yí biàn`.

**Prompt de recuperação.** Você não entendeu nada do enunciado anterior. Produza primeiro a versão curta com `请`; em seguida, produza a versão mais acolchoada com `不好意思` e `能...吗`.

**Prompt de transferência.** Peça repetição a um amigo e depois a uma pessoa que você trata com respeito. Não mude a intenção; mude apenas o grau de cortesia e o pronome.

**Critério de domínio.** O aluno pede repetição espontaneamente em menos de três segundos em quatro de cinco tentativas, produz a forma `zài shuō yí biàn` sem ler e escolhe `你` ou `您` de modo coerente com o cenário.

**Alerta de pronúncia e registro.** `一遍 yí biàn`: `一` muda para segundo tom antes de `遍`, que é quarto tom. `请 qǐng` não deve ser pronunciado como “tching” português. `什么？shénme?` é um reparo aberto muito informal; não é o padrão seguro para falar com desconhecidos, superiores ou em atendimento. [6]

---

## R3 — Pedir alteração de velocidade ou volume

**Intenção.** Especificar que a mensagem precisa ser repetida em uma condição auditiva diferente: mais devagar ou mais alto.

**Padrão ou função.**

```text
[F] 请 + 说 + [V] 慢/大声 + [O] 一点。
    Qǐng shuō màn/dàshēng yìdiǎn.
    Por favor, fale mais devagar/mais alto.

[F] 能不能 + 说慢一点 + 再说一遍？
    Néng bu néng shuō màn yìdiǎn zài shuō yí biàn?
    Você poderia falar mais devagar e repetir?
```

**Exemplos.**

1. **请说慢一点。**  
   **Qǐng shuō màn yìdiǎn.**  
   Por favor, fale mais devagar.
2. **请说大声一点。**  
   **Qǐng shuō dàshēng yìdiǎn.**  
   Por favor, fale um pouco mais alto.
3. **能不能说慢一点，再说一遍？**  
   **Néng bu néng shuō màn yìdiǎn, zài shuō yí biàn?**  
   Você pode falar mais devagar e repetir?

**Slots substituíveis.**

- **[V1 — ajuste de entrega]**: `慢 màn` — devagar; `大声 dàshēng` — em voz mais alta; `清楚 qīngchu` — claramente, em extensões mais avançadas.
- **[V2 — intensidade]**: `一点 yìdiǎn` — um pouco; `再慢一点 zài màn yìdiǎn` — ainda mais devagar.
- **[V3 — interlocutor]**: `你` ou `您`, conforme a relação.

**Extensões.**

- **不好意思，我还在学习中文，可以说慢一点吗？**  
  **Bù hǎoyìsi, wǒ hái zài xuéxí Zhōngwén, kěyǐ shuō màn yìdiǎn ma?**  
  Desculpe, ainda estou aprendendo chinês; pode falar um pouco mais devagar?
- **可以说大声一点吗？**  
  **Kěyǐ shuō dàshēng yìdiǎn ma?**  
  Pode falar um pouco mais alto?
- **请慢一点。**  
  **Qǐng màn yìdiǎn.**  
  Mais devagar, por favor. Esta forma depende fortemente do tom de voz e do contexto; a forma com `说` é mais transparente para o iniciante.

**Observação pedagógica.** Ensine o aluno a diagnosticar antes de pedir: **velocidade**, **volume** ou **sentido**. Repetir a mesma solicitação genérica não resolve todo problema. `一点` reduz a imposição e torna o pedido menos brusco. O aluno deve praticar a sequência “nomear a dificuldade → pedir ajuste → tentar ouvir de novo”, não apenas recitar `慢一点`.

**Potencial de mapa.** **Mapa de contraste** com três ramos: `[X]` rápido → `慢`; `[X]` baixo → `大声`; `[X]` sentido desconhecido → R4. Um anel externo mostra a combinação `ajuste + repetição`, e a saída é `我明白了`.

**Prompt de recuperação.** Escolha sem ver a resposta: a pessoa falou rápido; a pessoa falou baixo; você não sabe o significado de uma palavra. Produza o pedido correspondente em cada caso.

**Prompt de transferência.** Em uma videochamada, peça que alguém repita mais devagar. Em um ambiente barulhento, peça volume maior. Troque o interlocutor de `你` para `您` na segunda situação.

**Critério de domínio.** O aluno distingue velocidade de volume em cinco situações, produz pelo menos três pedidos completos sem recorrer ao português e combina ajuste com repetição em duas tentativas.

**Alerta de pronúncia e registro.** `慢 màn` e `大声 dàshēng` não são intercambiáveis. `能不能 néng bu néng` é uma pergunta A-não-A; `不` tende a ficar neutro nesse molde, não deve receber o mesmo destaque de `能`. Fontes didáticas de reparo também registram a utilidade de combinar repetição e velocidade, mas a pronúncia precisa ser conferida no áudio legítimo do curso do aluno. [6]

---

## R4 — Isolar a palavra ou trecho problemático

**Intenção.** Pedir esclarecimento de um item específico quando a mensagem geral foi compreendida, evitando fazer a outra pessoa repetir tudo.

**Padrão ou função.**

```text
[V] + 是什么意思？
[V] shì shénme yìsi?
O que significa [V]?

[F] 最后那个词 + 是什么意思？
    Zuìhòu nàge cí shì shénme yìsi?
    O que significa a última palavra?
```

**Exemplos.**

1. **这个词是什么意思？**  
   **Zhège cí shì shénme yìsi?**  
   O que significa esta palavra?
2. **最后那个词是什么意思？**  
   **Zuìhòu nàge cí shì shénme yìsi?**  
   O que significava a última palavra?
3. **我不认识这个词。**  
   **Wǒ bù rènshi zhège cí.**  
   Não conheço esta palavra.

**Slots substituíveis.**

- **[V1 — unidade]**: `这个词 zhège cí` — esta palavra; `这个名字 zhège míngzi` — este nome; `最后一句 zuìhòu yí jù` — a última frase.
- **[V2 — localização]**: `最后` — último; `第一个` — primeiro; `中间那个` — aquele do meio.
- **[V3 — referência]**: o próprio item ouvido, quando o aluno conseguir repeti-lo; caso contrário, `那个` — aquele.

**Extensões.**

- **“X”是什么意思？**  
  **“X” shì shénme yìsi?**  
  O que significa “X”? O slot pode ser preenchido por uma palavra que o aluno conseguiu recuperar.
- **这个词怎么说？**  
  **Zhège cí zěnme shuō?**  
  Como se diz esta palavra? Use quando a dúvida é de formulação, não necessariamente de significado.
- **你能解释一下吗？**  
  **Nǐ néng jiěshì yíxià ma?**  
  Você pode explicar um pouco?

**Observação pedagógica.** O salto pedagógico é passar de reparo amplo para reparo localizado. Depois de uma repetição, o aluno não deve pedir a mesma repetição indefinidamente: deve apontar a unidade que bloqueia a compreensão. Isso reduz o trabalho do interlocutor e demonstra controle da conversa.

**Potencial de mapa.** **Mapa de reparo restrito**: centro “palavra/trecho”; `[V] item ouvido`; `[F] 是什么意思`; `[X]` significado versus pronúncia (`怎么说`); ramo de escalada “repetir tudo → localizar item → confirmar compreensão”.

**Prompt de recuperação.** Você entendeu a ideia geral, mas perdeu a última palavra. Gere uma pergunta com `最后那个词`. Depois substitua por “esta expressão”.

**Prompt de transferência.** Em uma aula, pergunte o significado de um termo desconhecido. Em uma conversa informal, pergunte como se diz uma palavra em mandarim. Use o padrão adequado sem voltar à frase inteira.

**Critério de domínio.** O aluno identifica quando a dúvida é localizada, produz duas perguntas com slots diferentes e não usa `请再说一遍` como resposta automática para toda dificuldade.

**Alerta de registro.** `什么意思？shì shénme yìsi?` é útil e direto, mas uma entonação ríspida pode soar como cobrança. `不好意思` ou `请问` pode abrir a pergunta em contexto mais formal.

---

## R5 — Confirmar o sentido antes de seguir

**Intenção.** Testar uma hipótese de compreensão e dar ao interlocutor uma chance clara de corrigir a interpretação.

**Padrão ou função.**

```text
[F] 你的意思是 + [V] + 吗？
    Nǐ de yìsi shì + [V] + ma?
    Você quer dizer que [V]?

[F] 你是说 + [V] + 吗？
    Nǐ shì shuō + [V] + ma?
    Você está dizendo que [V]?
```

**Exemplos.**

1. **你的意思是明天见吗？**  
   **Nǐ de yìsi shì míngtiān jiàn ma?**  
   Você quer dizer que nos encontramos amanhã?
2. **你是说这个吗？**  
   **Nǐ shì shuō zhège ma?**  
   Você está falando deste aqui?
3. **所以，你现在不方便，对吗？**  
   **Suǒyǐ, nǐ xiànzài bù fāngbiàn, duì ma?**  
   Então, agora não é conveniente para você, certo?

**Slots substituíveis.**

- **[V1 — hipótese]**: `明天见 míngtiān jiàn` — ver-nos amanhã; `现在不方便 xiànzài bù fāngbiàn` — não estar disponível agora; `这个 zhège` — isto.
- **[V2 — confirmação final]**: `吗 ma` — pergunta sim/não; `对吗 duì ma` — certo?
- **[O — consequência]**: `所以 suǒyǐ` — então/portanto, quando o aluno resume uma consequência.

**Extensões.**

- **你是说现在走吗？**  
  **Nǐ shì shuō xiànzài zǒu ma?**  
  Você quer dizer que vamos sair agora?
- **你的意思是这个，对吗？**  
  **Nǐ de yìsi shì zhège, duì ma?**  
  Você quer dizer isto, certo?
- **我明白了。**  
  **Wǒ míngbai le.**  
  Entendi.

**Observação pedagógica.** Confirmar não é repetir mecanicamente. O aluno precisa formular uma hipótese curta e aceitar a possibilidade de correção. A célula é especialmente valiosa no início do intermediário porque desloca o aluno de “não entendi” para “acho que entendi X; confirme”.

**Potencial de mapa.** **Mapa de confirmação**: `[N] hipótese`; `[F] 你的意思是/你是说`; `[V] conteúdo resumido`; `[O] 所以`; `[R]` resposta mental “sim, corrigir ou pedir novo reparo”. Conecta R1–R4 à manutenção M2.

**Prompt de recuperação.** O interlocutor dá uma informação sobre um horário. Sem ver a resposta, confirme sua hipótese usando `你的意思是...吗`.

**Prompt de transferência.** Confirme duas situações novas: uma sobre horário e outra sobre posse de um objeto. Em uma delas, produza uma hipótese deliberadamente diferente e corrija-a depois.

**Critério de domínio.** O aluno produz três confirmações com conteúdo novo, usa `吗` ou `对吗` no lugar apropriado e consegue alterar a hipótese após um “não” imaginado, sem abandonar a interação.

**Alerta de contraste.** `吗` transforma uma afirmação em pergunta de sim/não; `呢` não é substituto automático de `吗`. A distinção entre essas partículas é funcional, não apenas ortográfica. [2]

---

# 2. Cortesia

## C1 — Abrir o contato com “desculpe/excuse-me” ou “posso perguntar?”

**Intenção.** Conseguir a atenção de alguém ou iniciar uma pergunta sem tratar uma pequena interrupção como uma falta grave.

**Padrão ou função.**

```text
[O] 不好意思， + pergunta/pedido.
    Bù hǎoyìsi, + pergunta/pedido.
    Desculpe / com licença, + pergunta/pedido.

[F] 请问， + pergunta.
    Qǐngwèn, + pergunta.
    Com licença, posso perguntar...?

[F] 打扰一下。
    Dǎrǎo yíxià.
    Desculpe interromper por um instante.
```

**Exemplos.**

1. **不好意思，请问洗手间在哪儿？**  
   **Bù hǎoyìsi, qǐngwèn xǐshǒujiān zài nǎr?**  
   Com licença, onde fica o banheiro?
2. **请问，这里可以坐吗？**  
   **Qǐngwèn, zhèlǐ kěyǐ zuò ma?**  
   Com licença, posso sentar aqui?
3. **打扰一下。**  
   **Dǎrǎo yíxià.**  
   Desculpe interromper um instante.

**Slots substituíveis.**

- **[V1 — abertura]**: `不好意思` — desculpe/com licença, leve e cotidiano; `请问` — introduz pergunta; `打扰一下` — marca uma interrupção.
- **[V2 — ação]**: `问一下 wèn yíxià` — perguntar rapidinho; `看一下 kàn yíxià` — dar uma olhada; `坐 zuò` — sentar.
- **[V3 — pessoa]**: `你 nǐ` ou `您 nín`, quando houver pedido explícito a alguém.

**Extensões.**

- **不好意思，可以问你一个问题吗？**  
  **Bù hǎoyìsi, kěyǐ wèn nǐ yí ge wèntí ma?**  
  Desculpe, posso fazer uma pergunta?
- **请问，地铁站怎么走？**  
  **Qǐngwèn, dìtiězhàn zěnme zǒu?**  
  Com licença, como se chega à estação de metrô?
- **打扰您一下。**  
  **Dǎrǎo nín yíxià.**  
  Desculpe incomodá-lo(a) por um instante.

**Observação pedagógica.** `不好意思` faz dupla função: pedido leve de desculpa e abertura para chamar alguém. `请问` não significa simplesmente um “por favor” colocado em qualquer lugar; é uma fórmula para introduzir pergunta. `打扰一下` enquadra a ação como interrupção. O aluno deve escolher a abertura pela ação, não pelo desejo abstrato de parecer educado.

**Potencial de mapa.** **Mapa de função social** com três portas: chamar/pequena fricção → `不好意思`; perguntar informação → `请问`; interromper alguém ocupado → `打扰一下`. O centro é “abrir o canal”; o conteúdo da pergunta fica em ramo variável.

**Prompt de recuperação.** Você precisa perguntar a localização de um banheiro a um desconhecido. Produza a abertura e a pergunta. Depois, imagine que a pessoa está ocupada e troque apenas a abertura.

**Prompt de transferência.** Em um café, pergunte se pode ocupar uma cadeira. Em um ambiente profissional, interrompa alguém para fazer uma pergunta curta. Não use `对不起` como fórmula automática de atenção.

**Critério de domínio.** O aluno seleciona a abertura adequada em quatro de cinco cenários, produz a pergunta sem inserir `请` no fim e distingue atenção leve, pergunta e interrupção.

**Alerta de registro.** `对不起 duìbuqǐ` é uma desculpa real e pode ser pesada para simplesmente chamar alguém ou passar. Para pequena fricção ou atenção, `不好意思` é geralmente mais natural; para pedido de informação, `请问` é uma fórmula segura. [3] [4]

---

## C2 — Fazer um favor sem transformar o pedido em ordem

**Intenção.** Pedir uma ação que custa tempo ou esforço ao interlocutor, reconhecendo a imposição e oferecendo margem para recusa.

**Padrão ou função.**

```text
[F] 麻烦你/您 + ação + [O] 一下。
    Máfan nǐ/nín + ação + yíxià.
    Você poderia me fazer o favor de...?

[F] 你能不能 + ação？
    Nǐ néng bu néng + ação?
    Você poderia...?

[F] 你可以 + ação + 吗？
    Nǐ kěyǐ + ação + ma?
    Você pode...?
```

**Exemplos.**

1. **麻烦你帮我看一下这个。**  
   **Máfan nǐ bāng wǒ kàn yíxià zhège.**  
   Você poderia dar uma olhada nisto para mim?
2. **你能不能帮我一个忙？**  
   **Nǐ néng bu néng bāng wǒ yí ge máng?**  
   Você poderia me fazer um favor?
3. **可以等我一下吗？**  
   **Kěyǐ děng wǒ yíxià ma?**  
   Você pode esperar um instante?

**Slots substituíveis.**

- **[V1 — abertura]**: `麻烦你/您` — reconhece o trabalho pedido; `能不能` — pergunta de possibilidade; `可以...吗` — pergunta de permissão ou conveniência; `请` — pedido polido, mais associado a serviço, instrução ou situação semi-formal.
- **[V2 — ação]**: `帮我看一下` — olhar para mim; `等我一下` — esperar; `再说一遍` — repetir; `带一杯咖啡` — trazer um café.
- **[O — redutor]**: `一下 yíxià` — rapidinho/um instante; `好吗 hǎo ma` — tudo bem?

**Extensões.**

- **麻烦您帮我看一下这个，可以吗？**  
  **Máfan nín bāng wǒ kàn yíxià zhège, kěyǐ ma?**  
  O senhor/a senhora poderia dar uma olhada nisto, por favor?
- **请帮我一下。**  
  **Qǐng bāng wǒ yíxià.**  
  Por favor, me ajude um instante. Útil em serviço ou registro mais polido.
- **麻烦你了。**  
  **Máfan nǐ le.**  
  Obrigado por se dar ao trabalho / desculpe o incômodo. Muitas vezes aparece depois que a pessoa ajuda.

**Observação pedagógica.** O ponto não é empilhar marcadores de educação. É calibrar **proximidade** e **custo do favor**. Um pedido pequeno a amigo pode usar `帮我...一下`; um favor real a colega ou desconhecido favorece `麻烦你/您`; uma pergunta com `能不能` ou `可以...吗` dá uma saída clara ao interlocutor. `请` vem antes da ação e não é um sufixo equivalente ao “por favor” brasileiro. [1] [4]

**Potencial de mapa.** **Mapa de escala de imposição**: pequeno e íntimo → `[F] V + 一下`; polido/serviço → `请 + V`; favor com custo → `麻烦你/您 + V`; pedido com saída → `能不能/可以...吗`. O ramo vermelho marca “ordem direta” quando o favor exige esforço.

**Prompt de recuperação.** Gere três pedidos para a mesma ação: a um amigo íntimo, a um colega e a uma pessoa desconhecida. Mude somente a abertura e o grau de suavização.

**Prompt de transferência.** Peça para alguém esperar, olhar um documento e repetir uma informação. Faça cada pedido em um contexto diferente e não use a mesma fórmula nas três situações.

**Critério de domínio.** O aluno produz quatro pedidos com ações novas, coloca `请` antes do verbo, usa `一下` depois da ação quando apropriado e não transforma um favor significativo em imperativo nu.

**Alerta de registro.** `请` pode soar distante entre amigos próximos; `麻烦你` explicita que o pedido dá trabalho. `劳驾` e `借光` são opções regionais, sobretudo do norte, para estranhos e passagem; não são prioridade do repertório inicial. [4]

---

## C3 — Agradecer e responder ao agradecimento

**Intenção.** Fechar o ciclo de ajuda sem misturar a resposta a um agradecimento com a resposta a um pedido de desculpa.

**Padrão ou função.**

```text
[F] 谢谢（你/您）。
    Xièxie (nǐ/nín).
    Obrigado(a).

[F] 麻烦你了。
    Máfan nǐ le.
    Obrigado por se dar ao trabalho.

[F] 不客气 / 不用谢。
    Bú kèqi / bú yòng xiè.
    Não há de quê / não precisa agradecer.
```

**Exemplos.**

1. **谢谢你。**  
   **Xièxie nǐ.**  
   Obrigado(a).
2. **麻烦你了。**  
   **Máfan nǐ le.**  
   Obrigado por se dar ao trabalho.
3. **不客气。**  
   **Bú kèqi.**  
   Não há de quê.
4. **不用谢。**  
   **Bú yòng xiè.**  
   Não precisa agradecer.

**Slots substituíveis.**

- **[V1 — destinatário]**: `你 nǐ`, `您 nín`, ou ausência do pronome em `谢谢`.
- **[V2 — resposta]**: `不客气` — não há de quê; `不用谢` — não precisa agradecer; `应该的 yīnggāi de` — era o certo a fazer, extensão inicial-intermediária.
- **[O — peso do favor]**: `太谢谢了 tài xièxie le` — muito obrigado; use sem transformar toda interação cotidiana em fórmula solene.

**Extensões.**

- **谢谢你的帮助。**  
  **Xièxie nǐ de bāngzhù.**  
  Obrigado(a) pela sua ajuda.
- **不客气，请坐。**  
  **Bú kèqi, qǐng zuò.**  
  Não há de quê; sente-se. O segundo enunciado abre uma ação de acolhimento.
- **应该的。**  
  **Yīnggāi de.**  
  Não fiz mais que a obrigação / era o certo. Registro mais relacional; introduzir depois do par básico.

**Observação pedagógica.** O par deve ser recuperado como ação, não como tradução isolada: **agradecimento → resposta ao agradecimento**. O erro de transferência mais importante para brasileiros é usar `没关系` (“não tem problema”) como resposta a `谢谢`; no mandarim, `没关系` pertence principalmente ao par de desculpa. [3]

**Potencial de mapa.** **Mapa de pares adjacentes**: `[N] ajuda recebida`; `[F] 谢谢`; `[V] 不客气/不用谢`; ramo vermelho `[X]` agradecimento ≠ desculpa; conexão com C4.

**Prompt de recuperação.** Alguém lhe entrega um objeto. Agradeça. Depois imagine que a pessoa agradece sua ajuda e produza a resposta adequada, sem usar `没关系`.

**Prompt de transferência.** Faça três rodadas com favores de tamanhos diferentes: pequeno, significativo e repetido. Alterne `谢谢`, `谢谢你` e `麻烦你了` e responda sem consultar.

**Critério de domínio.** O aluno reconhece se deve agradecer ou responder ao agradecimento, produz `bú kèqi` com tom funcional e não confunde `不客气` com `没关系` em cinco situações.

**Alerta de pronúncia.** Em `不客气 bú kèqi`, `不` aparece como `bú` diante de `客 kè`, que é quarto tom. Em `谢谢 xièxie`, a segunda sílaba costuma ser neutra; não dê a ela o mesmo peso da primeira.

---

## C4 — Desculpar-se e responder a uma desculpa na medida certa

**Intenção.** Reparar uma pequena fricção ou assumir uma falha real, escolhendo uma forma proporcional ao dano e sabendo responder quando outra pessoa se desculpa.

**Padrão ou função.**

```text
[leve]   不好意思， + situação.
         Bù hǎoyìsi, + situação.
         Desculpe / foi mal, + situação.

[real]   对不起， + situação.
         Duìbuqǐ, + situação.
         Desculpe, eu errei / sinto muito.

[resposta] 没关系 / 没事儿 / 不要紧。
           Méi guānxi / méi shìr / bú yàojǐn.
           Tudo bem / não foi nada / não é grave.
```

**Exemplos.**

1. **不好意思，我来晚了。**  
   **Bù hǎoyìsi, wǒ lái wǎn le.**  
   Desculpe, me atrasei.
2. **对不起，这是我的错。**  
   **Duìbuqǐ, zhè shì wǒ de cuò.**  
   Desculpe, a culpa foi minha.
3. **没关系。**  
   **Méi guānxi.**  
   Tudo bem.
4. **没事儿。**  
   **Méi shìr.**  
   Não foi nada.

**Slots substituíveis.**

- **[V1 — peso]**: `不好意思` — atrito leve, atraso pequeno, chamar atenção; `对不起` — falha real ou dano; `抱歉 bàoqiàn` — formal, serviço, escrita ou comunicação profissional.
- **[V2 — situação]**: `我来晚了` — cheguei atrasado; `我弄错了 wǒ nòng cuò le` — eu me enganei; `我忘了 wǒ wàng le` — esqueci.
- **[V3 — resposta]**: `没关系` — tudo bem; `没事儿` — não foi nada, informal; `不要紧` — não é grave.

**Extensões.**

- **抱歉，让您久等了。**  
  **Bàoqiàn, ràng nín jiǔ děng le.**  
  Peço desculpas por tê-lo(a) feito esperar tanto. Registro formal ou de atendimento.
- **对不起，我弄错了。**  
  **Duìbuqǐ, wǒ nòng cuò le.**  
  Desculpe, eu me enganei.
- **没关系，别放在心上。**  
  **Méi guānxi, bié fàng zài xīn shàng.**  
  Tudo bem, não fique pensando nisso. Extensão para intermediário inicial.

**Observação pedagógica.** A escolha é lexicalmente graduada: `不好意思` é leve; `对不起` assume uma falta mais séria; `抱歉` é mais formal e pode soar distante entre amigos. Não é necessário dramatizar uma pequena demora, mas também não se deve minimizar um dano real. A resposta depende do ato anterior: **desculpa → 没关系/没事儿; agradecimento → 不客气/不用谢**. [3]

**Potencial de mapa.** **Mapa de contraste e escala**: `[N] reparar fricção`; baixo → `不好意思`; real → `对不起`; formal → `抱歉`; retorno → `没关系/没事儿/不要紧`. Uma margem registra “não usar `对不起` apenas para chamar atenção”.

**Prompt de recuperação.** Escolha a expressão para três situações: atraso de dois minutos, erro que causou prejuízo e aviso de atendimento formal. Depois produza a resposta de quem ouviu cada desculpa.

**Prompt de transferência.** Em um encontro, você chega tarde. Em uma tarefa, entrega informação errada. Em um serviço, faz alguém esperar. Produza desculpa proporcional e resposta correspondente.

**Critério de domínio.** O aluno escolhe a intensidade adequada em cinco cenários, produz pelo menos duas desculpas e duas respostas sem misturar os pares e usa `méi guānxi` como resposta a desculpa, não a agradecimento.

**Alerta de registro e pronúncia.** `对不起 duìbuqǐ` não é equivalente universal a “com licença”. `不好意思 bù hǎoyìsi` contém `yì` de quarto tom e `si` geralmente neutro. `没事儿 méi shìr` traz o `儿化` comum em certas variedades; o aluno pode começar com `没事 méi shì` se ainda não trabalha o `r` retroflexo.

---

# 3. Manutenção

## M1 — Devolver a pergunta e manter reciprocidade

**Intenção.** Mostrar que a conversa é recíproca, responder minimamente e devolver a vez sem iniciar um novo interrogatório.

**Padrão ou função.**

```text
[resposta curta] + 你呢？
                  Nǐ ne?
                  E você?

[pergunta] 你最近怎么样？
           Nǐ zuìjìn zěnmeyàng?
           Como você tem passado ultimamente?
```

**Exemplos.**

1. **我叫安娜，你呢？**  
   **Wǒ jiào Ānnà, nǐ ne?**  
   Eu me chamo Ana. E você?
2. **我很好，你呢？**  
   **Wǒ hěn hǎo, nǐ ne?**  
   Estou bem. E você?
3. **你最近怎么样？**  
   **Nǐ zuìjìn zěnmeyàng?**  
   Como você tem passado ultimamente?

**Slots substituíveis.**

- **[V1 — conteúdo devolvido]**: `你呢` — e você?; `你的工作呢 nǐ de gōngzuò ne` — e o seu trabalho?; `中文呢 Zhōngwén ne` — e o chinês?
- **[V2 — pergunta de acompanhamento]**: `最近怎么样` — como tem passado; `最近忙不忙 zuìjìn máng bu máng` — anda ocupado?
- **[O — resposta mínima]**: `我也很好 wǒ yě hěn hǎo` — eu também estou bem; `还不错 hái búcuò` — nada mal.

**Extensões.**

- **我也很好，你呢？** — **Wǒ yě hěn hǎo, nǐ ne?** — Eu também estou bem. E você?
- **最近忙不忙？** — **Zuìjìn máng bu máng?** — Você anda ocupado ultimamente?
- **还不错。** — **Hái búcuò.** — Nada mal.

**Observação pedagógica.** `呢 ne` é um marcador neutro que, neste uso, devolve a pergunta ou pergunta “e quanto a X?”. Ele não funciona como a pergunta sim/não de `吗 ma`. Pratique a unidade como movimento de turno: **responder um pouco → devolver a vez**. [2]

**Potencial de mapa.** **Mapa de manutenção**: `[N] reciprocidade`; `[F] resposta curta`; `[O] 你呢`; ramos variáveis para pessoa, assunto e estado; `[X] 呢` para “e você?” versus `吗` para sim/não.

**Prompt de recuperação.** Responda “estou bem” e devolva a pergunta. Depois responda “sou brasileiro” e pergunte sobre a outra pessoa.

**Prompt de transferência.** Em uma conversa nova, devolva uma pergunta sobre nome, origem e trabalho. Use três conteúdos diferentes.

**Critério de domínio.** O aluno responde e devolve a vez em quatro de cinco oportunidades, usa `呢` sem acrescentar `吗` e produz três combinações novas sem depender da tradução.

**Alerta de pronúncia.** `呢 ne` é neutro e curto; não o transforme em uma sílaba plena com tom lexical.

---

## M2 — Sinalizar que recebeu a informação e convidar a continuação

**Intenção.** Evitar silêncio ou aparência de não compreensão. O aluno sinaliza que acompanhou e abre espaço para a pessoa continuar.

**Padrão ou função.**

```text
[F] 嗯，我明白了。 + [O] 你继续说。
    Èn, wǒ míngbai le. + nǐ jìxù shuō.
    Entendi. Pode continuar.

[F] 好的， + [O] 然后呢？
    Hǎo de, + ránhòu ne?
    Certo. E depois?
```

**Exemplos.**

- **嗯，我明白了。** — **Èn, wǒ míngbai le.** — Entendi.
- **好的，你继续说。** — **Hǎo de, nǐ jìxù shuō.** — Certo, pode continuar.
- **然后呢？** — **Ránhòu ne?** — E depois?

**Slots substituíveis.** `[V1]` `嗯 èn`, `好的 hǎo de`, `对 duì`; `[V2]` `你继续说 nǐ jìxù shuō`, `然后呢 ránhòu ne`, `还有呢 hái yǒu ne`; `[O]` `我明白了` ou `我知道了`.

**Extensões.**

- **好的，你继续。** — **Hǎo de, nǐ jìxù.** — Certo, pode continuar.
- **还有呢？** — **Hái yǒu ne?** — Tem mais?
- **哦，我知道了。** — **Ó, wǒ zhīdào le.** — Ah, agora entendi.

**Observação pedagógica.** Trabalhe duas operações diferentes: **receber** (`我明白了`) e **convidar continuação** (`你继续说`/`然后呢`). `嗯` não prova compreensão; se não entendeu, o aluno deve reparar com R1–R4.

**Potencial de mapa.** **Mapa de fluxo de turno**: informação recebida → `[F] 嗯/好的` → compreendi? `我明白了`; quero mais? `然后呢`; não compreendi? R1.

**Prompt de recuperação.** Após uma explicação curta, sinalize recebimento e peça que a pessoa continue. Em uma segunda rodada, imagine que não entendeu e escolha R1.

**Prompt de transferência.** Imagine uma pessoa contando um acontecimento em duas partes. Depois da primeira parte, sinalize compreensão e convide a segunda.

**Critério de domínio.** O aluno diferencia “entendi, continue” de “não entendi, repita” em cinco situações e não finge compreensão para evitar reparo.

**Alerta de contraste.** `我明白了` destaca compreensão; `我知道了` destaca recebimento da informação. Priorize a forma praticada no áudio e não trate as duas como sinônimos perfeitos.

---

## M3 — Ganhar tempo para formular uma resposta

**Intenção.** Manter o turno quando o aluno entendeu a pergunta, mas ainda precisa pensar.

**Padrão ou função.**

```text
[F] 等一下，让我想一下。
    Děng yíxià, ràng wǒ xiǎng yíxià.
    Só um instante, deixa eu pensar.

[F] 让我想想。
    Ràng wǒ xiǎngxiang.
    Deixa eu pensar.
```

**Exemplos.**

- **等一下，让我想一下。** — **Děng yíxià, ràng wǒ xiǎng yíxià.** — Só um instante, deixa eu pensar.
- **让我想想。** — **Ràng wǒ xiǎngxiang.** — Deixa eu pensar.
- **等一下，我想想怎么说。** — **Děng yíxià, wǒ xiǎngxiang zěnme shuō.** — Só um instante, vou pensar em como dizer.

**Slots substituíveis.** `[V1]` `这个问题 zhège wèntí` — esta pergunta; `怎么说 zěnme shuō` — como dizer; `什么时候 shénme shíhou` — quando. `[V2]` `等一下`, `让我想想`, `我想一下`.

**Extensões.**

- **让我想一下。** — **Ràng wǒ xiǎng yíxià.** — Deixa eu pensar um pouco.
- **我还不知道怎么说。** — **Wǒ hái bù zhīdào zěnme shuō.** — Ainda não sei como dizer.
- **我马上回答。** — **Wǒ mǎshàng huídá.** — Já respondo.

**Observação pedagógica.** Ganhar tempo não é mascarar uma falha de compreensão. O aluno deve usar a expressão, respirar e produzir uma resposta curta. A meta é iniciar o turno em até três segundos.

**Potencial de mapa.** **Mapa de gestão do turno**: pergunta recebida → `[F] 等一下/让我想想` → `[V] tópico` → resposta; se não entendeu, conexão para R1.

**Prompt de recuperação.** Alguém pergunta qual horário é conveniente. Você entende, mas precisa decidir. Ganhe tempo e depois responda com um horário.

**Prompt de transferência.** Responda a perguntas novas sobre comida, horário e preferência. Use M3 apenas quando precisar pensar.

**Critério de domínio.** O aluno mantém o turno, produz resposta pertinente depois do marcador e distingue “preciso pensar” de “não entendi” em quatro de cinco tentativas.

**Alerta de pronúncia.** `一下 yíxià` tem ritmo leve; `让 ràng` é quarto tom e `想 xiǎng` é terceiro tom.

---

## M4 — Mostrar interesse e pedir continuação específica

**Intenção.** Sustentar um tópico social sem trocar abruptamente de assunto.

**Padrão ou função.**

```text
[F] 真的吗？       Zhēn de ma?       É mesmo?
[F] 然后呢？       Ránhòu ne?        E depois?
[F] 你觉得呢？     Nǐ juéde ne?      E você, o que acha?
```

**Exemplos.**

- **真的吗？** — **Zhēn de ma?** — É mesmo?
- **然后呢？** — **Ránhòu ne?** — E depois?
- **你觉得呢？** — **Nǐ juéde ne?** — E você, o que acha?

**Slots substituíveis.** `[V1]` `然后呢` para sequência; `你觉得呢` para opinião; `还有呢` para mais informação. `[V2]` `这个地方 zhège dìfang` — este lugar; `这部电影 zhè bù diànyǐng` — este filme; `这个问题 zhège wèntí` — esta questão. `[O]` `是吗 shì ma` — é mesmo?, mais dependente da entonação.

**Extensões.**

- **这个地方怎么样？** — **Zhège dìfang zěnmeyàng?** — Como é esse lugar?
- **你觉得这部电影怎么样？** — **Nǐ juéde zhège diànyǐng zěnmeyàng?** — O que você acha desse filme?
- **还有别的吗？** — **Hái yǒu bié de ma?** — Tem outra opção?

**Observação pedagógica.** `真的吗` pode sugerir surpresa, dúvida ou ceticismo. Ensine o aluno a escolher a função: sequência, opinião ou surpresa.

**Potencial de mapa.** **Mapa de continuação temática**: `[N] manter assunto`; ramo temporal `然后呢`; ramo avaliativo `你觉得呢`; ramo de surpresa `真的吗`; saída para R5 quando há dúvida factual.

**Prompt de recuperação.** Uma pessoa conta algo inesperado; outra descreve um lugar; uma terceira narra o que aconteceu depois. Escolha a reação adequada.

**Prompt de transferência.** Faça perguntas de continuação sobre uma viagem, uma comida e um horário, mantendo o tópico por duas trocas.

**Critério de domínio.** O aluno sustenta um tópico por três turnos, usa duas perguntas de continuação e não interpreta `真的吗` como confirmação neutra em todos os casos.

**Alerta de pronúncia.** Em `真的吗 zhēn de ma`, `de` e `ma` são neutros; a entonação muda a atitude.

---

# 4. Encerramento

## E1 — Anunciar que vai sair sem desaparecer

**Intenção.** Sinalizar a saída de uma conversa ou grupo, dando uma transição clara.

**Padrão ou função.**

```text
[F] 我先走了。       Wǒ xiān zǒu le.       Eu vou indo.
[F] 我得走了。       Wǒ děi zǒu le.        Preciso ir.
[O] 打扰了，我先走了。 Dǎrǎo le, wǒ xiān zǒu le. Desculpe interromper; vou indo.
```

**Exemplos.**

- **我先走了。** — **Wǒ xiān zǒu le.** — Eu vou indo.
- **不好意思，我得走了。** — **Bù hǎoyìsi, wǒ děi zǒu le.** — Desculpe, preciso ir.
- **你们继续聊。** — **Nǐmen jìxù liáo.** — Continuem conversando.

**Slots substituíveis.** `[V1]` `我先走了` — vou sair primeiro; `我得走了` — preciso ir; `我先忙了 wǒ xiān máng le` — vou cuidar de outras coisas. `[V2]` `有事 yǒu shì` — tenho compromisso; `有点累 yǒudiǎn lèi` — estou cansado; `明天要早起 míngtiān yào zǎoqǐ` — preciso acordar cedo. `[O]` `下次聊` ou `回头聊`.

**Extensões.**

- **我有事，先走了。** — **Wǒ yǒu shì, xiān zǒu le.** — Tenho um compromisso, vou indo.
- **不好意思，我得先走了。** — **Bù hǎoyìsi, wǒ děi xiān zǒu le.** — Desculpe, preciso sair primeiro.

**Observação pedagógica.** Ensine o aluno a anunciar a ação antes de sair. `了` marca a mudança de situação: agora a pessoa vai sair. Não é preciso fornecer um motivo detalhado.

**Potencial de mapa.** **Mapa de saída**: `[N] deixar a interação`; `[F] 我先走了/我得走了`; `[V] motivo`; `[O] vocês continuam`; ligação com E2.

**Prompt de recuperação.** Em um grupo, produza a forma curta. Depois acrescente um motivo simples e indique que os outros podem continuar.

**Prompt de transferência.** Saia de uma conversa presencial, de uma videochamada e de um encontro informal, escolhendo uma fórmula diferente para cada situação.

**Critério de domínio.** O aluno anuncia a saída antes de encerrar, produz duas formas e combina saída com motivo em três situações.

**Alerta de registro.** `失陪 shīpéi` é formal e não é prioridade para fala cotidiana. `我先走了` é natural em grupo.

---

## E2 — Fechar com uma próxima conversa possível

**Intenção.** Encerrar sem transformar a despedida em ruptura definitiva.

**Padrão ou função.**

```text
[F] 下次聊。       Xià cì liáo.       A gente conversa na próxima.
[F] 有空再聊。     Yǒu kòng zài liáo.  Quando der, a gente conversa de novo.
[F] 再联系。       Zài liánxì.         A gente se fala.
```

**Exemplos.**

- **下次聊。** — **Xià cì liáo.** — A gente conversa na próxima.
- **有空再聊。** — **Yǒu kòng zài liáo.** — Quando der, a gente conversa de novo.
- **再联系。** — **Zài liánxì.** — A gente se fala.

**Slots substituíveis.** `[V1]` `下次`, `回头`, `有空`; `[V2]` `聊`, `联系`, `见`; `[O]` `明天见` ou `下周见` quando o próximo encontro é definido.

**Extensões.**

- **回头聊。** — **Huítóu liáo.** — A gente se fala mais tarde.
- **下次见。** — **Xià cì jiàn.** — Até a próxima.
- **有空再联系。** — **Yǒu kòng zài liánxì.** — Quando der, a gente se fala.

**Observação pedagógica.** Distingua próxima **conversa** (`聊`), próximo **encontro** (`见`) e contato futuro sem data (`联系`). A tradução brasileira “até mais” pode apagar essa escolha.

**Potencial de mapa.** **Mapa de vínculo futuro**: `[N] manter canal`; ramo conversa `聊`; contato `联系`; encontro `见`; tempo `下次/回头/有空`.

**Prompt de recuperação.** Você não sabe quando verá a pessoa, mas quer deixar o contato aberto. Escolha entre `下次聊`, `有空再聊` e `再联系`.

**Prompt de transferência.** Encerre três interações: colega que verá amanhã, conhecido sem data e amigo com quem quer conversar novamente.

**Critério de domínio.** O aluno escolhe entre conversa, contato e encontro em quatro de cinco situações e produz duas despedidas com conteúdo temporal.

**Alerta de uso.** `回头见 huítóu jiàn` ou `一会儿见 yíhuìr jiàn` sugerem reencontro próximo, não qualquer futuro. [5]

---

## E3 — Escolher despedida de acordo com o próximo contato

**Intenção.** Fechar com uma fórmula curta que corresponda ao que se espera depois.

**Padrão ou função.**

```text
[F] 明天见。          Míngtiān jiàn.  Até amanhã.
[F] 下次见。           Xià cì jiàn.   Até a próxima.
[F] 晚安。             Wǎn'ān.        Boa noite.
[F] 再见 / 再见了。    Zàijiàn / zàijiàn le. Tchau / até mais.
```

**Exemplos.**

- **明天见。** — **Míngtiān jiàn.** — Até amanhã.
- **下次见。** — **Xià cì jiàn.** — Até a próxima.
- **晚安。** — **Wǎn'ān.** — Boa noite.
- **再见了。** — **Zàijiàn le.** — Tchau / até mais.

**Slots substituíveis.** `[V1]` `明天`, `下周`, `下次`; `[V2]` `见`, `聊`, `联系`; `[V3]` `晚安` quando a pessoa vai dormir; `再见` para despedida geral.

**Extensões.**

- **下周见。** — **Xià zhōu jiàn.** — Até a semana que vem.
- **明天上午见。** — **Míngtiān shàngwǔ jiàn.** — Até amanhã de manhã.
- **晚安，明天见。** — **Wǎn'ān, míngtiān jiàn.** — Boa noite, até amanhã.

**Observação pedagógica.** `再见` é funcional, mas pode soar mais marcada em textos ou entre pessoas muito próximas. Quando há próximo contato claro, `明天见` ou `下次见` fornece mais informação. `晚安` é despedida ligada ao sono, não simples cumprimento noturno. [5]

**Potencial de mapa.** **Mapa de decisão final**: reencontro definido → `明天/下周 + 见`; próxima ocasião → `下次见`; sono → `晚安`; sem informação → `再见/再见了`.

**Prompt de recuperação.** Escolha a despedida para reencontro amanhã, reencontro indefinido, conversa antes de dormir e saída geral.

**Prompt de transferência.** Simule quatro encerramentos de dez segundos, alternando tempo, relação e canal.

**Critério de domínio.** O aluno escolhe a despedida pelo contexto e produz quatro formas com pinyin tonal sem usar `晚安` ou `明天见` fora de contexto.

**Alerta de pronúncia.** `晚安 wǎn'ān` tem apóstrofo para marcar o início de `ān`; `再见 zàijiàn` tem dois quartos tons.

---

## E4 — Fechar telefone ou mensagem sem parecer que a conversa caiu

**Intenção.** Tornar explícito que o canal está sendo encerrado.

**Padrão ou função.**

```text
[F] 那先这样。       Nà xiān zhèyàng.  Então, por enquanto é isso.
[F] 我先忙了。        Wǒ xiān máng le.  Vou voltar às minhas coisas.
[F — telefone] 我挂了啊。 Wǒ guà le a.   Vou desligar, tá?
```

**Exemplos.**

- **那先这样，回头聊。** — **Nà xiān zhèyàng, huítóu liáo.** — Por enquanto é isso; a gente se fala mais tarde.
- **我先忙了。** — **Wǒ xiān máng le.** — Vou voltar ao que estava fazendo.
- **我挂了啊。** — **Wǒ guà le a.** — Vou desligar, tá?

**Slots substituíveis.** `[V1]` `先这样`, `先忙了`, `先到这里`; `[V2]` `挂了` para telefone, `下次聊` para conversa, `再联系` para contato; `[O]` `啊 a` no fechamento telefônico.

**Extensões.**

- **那先这样，我们下次再聊。** — **Nà xiān zhèyàng, wǒmen xià cì zài liáo.** — Vamos parar por aqui; conversamos na próxima.
- **我先忙了，有空再联系。** — **Wǒ xiān máng le, yǒu kòng zài liánxì.** — Vou voltar às minhas coisas; quando der, a gente se fala.
- **好的，那我挂了啊。** — **Hǎo de, nà wǒ guà le a.** — Certo, então vou desligar, tá?

**Observação pedagógica.** Texto e telefone precisam de marcador explícito porque o interlocutor não vê o gesto de sair. `挂了啊` é específico de chamada. `那先这样` é uma forma natural de fechar assunto, não uma tradução palavra por palavra de “tchau”.

**Potencial de mapa.** **Mapa de canal**: presencial → E1/E3; mensagem → `那先这样` + E2; telefone → `我挂了啊` + E2/E3. O ramo vermelho marca `挂了` como específico do telefone.

**Prompt de recuperação.** Escolha uma forma para encerrar mensagem, chamada e conversa presencial. Acrescente despedida futura apenas quando fizer sentido.

**Prompt de transferência.** Grave três áudios de até dez segundos: finalizar uma chamada, uma mensagem e uma conversa em grupo.

**Critério de domínio.** O aluno fecha três canais, usa `挂了啊` apenas no telefone e acrescenta `回头聊`/`下次聊` quando apropriado.

**Alerta de naturalidade.** `慢走 màn zǒu` é normalmente dito por quem fica para quem está saindo, especialmente em lojas e restaurantes; quem vai embora não deve usar a expressão para si mesmo. [5]

---

# 5. Rede de recombinação do bloco

As células devem ser combinadas por **função**, não como diálogos fixos:

```text
falha de compreensão → R1 → R2/R3 → R4, se necessário → R5
→ M2: sinalizar compreensão → C3: agradecer → E1/E2/E3/E4
```

## Matriz de decisões rápidas

| Situação | Escolha prioritária | Evitar |
|---|---|---|
| Não captou os sons | **我没听清楚** | fingir que entendeu |
| Ouviu, mas não construiu o sentido | **我没听懂 / 我不明白** | repetir apenas “o quê?” em registro formal |
| Precisa da frase inteira | **请再说一遍 / 能再说一遍吗** | pedir uma palavra sem saber qual |
| Velocidade é o problema | **请说慢一点** | usar `大声` |
| Volume é o problema | **请说大声一点** | pedir lentidão |
| Só uma palavra bloqueia | **这个词是什么意思？** | pedir repetição total indefinidamente |
| Quer chamar alguém | **不好意思 / 请问** | usar `对不起` para qualquer atenção |
| Favor custa esforço | **麻烦你/您...** | imperativo nu a desconhecido |
| Recebeu agradecimento | **不客气 / 不用谢** | `没关系` |
| Recebeu desculpa | **没关系 / 没事儿** | `不客气` |
| Precisa devolver a vez | **你呢？** | fazer pergunta longa |
| Entendeu e quer continuação | **你继续说 / 然后呢** | silêncio |
| Precisa pensar | **让我想想 / 等一下** | mascarar incompreensão |
| Vai sair | **我先走了 / 我得走了** | desaparecer |
| Vai fechar chamada | **我挂了啊** | usar `挂了` fora do telefone |
| Quer deixar canal aberto | **下次聊 / 再联系** | prometer data inexistente |

## Protocolo de prática e retirada do suporte

1. **Orientação pós-áudio — 2 minutos.** Identificar a função e consultar o padrão completo somente depois da tentativa auditiva.
2. **Recuperação — 3 a 5 minutos.** Mostrar intenção e lacunas, por exemplo `[pedido de repetição] + [ajuste]`; produzir antes da solução.
3. **Recombinação — 4 a 6 minutos.** Trocar pelo menos três slots; uma variação deve alterar interlocutor ou canal.
4. **Transferência — 3 a 5 minutos.** Receber contexto novo sem frase-modelo completa; decidir a ação social.
5. **Reteste — 2 minutos.** Mapa fechado; registrar compreensão, recuperação, pronúncia funcional e transferência.

### Progressão visual por célula

| Estado | Apoio visível | Tarefa |
|---|---|---|
| **Completo** | intenção, padrão, pinyin, tradução e contraste | identificar a função |
| **Lacunado** | intenção e slots | completar oralmente `[不好意思] + [repetição]` |
| **Reduzido** | situação, canal e relação | pedir repetição a um professor |
| **Independente** | estímulo oral ou situação nova | reagir em até três segundos sem mapa |

## Critério global de domínio

O bloco está dominado quando o aluno consegue, em situações não vistas, iniciar reparo sem fingir compreensão; escolher entre repetição, ajuste, esclarecimento e confirmação; calibrar `不好意思`, `请问`, `麻烦你/您`, `对不起` e `抱歉`; separar **谢谢 → 不客气** de **desculpa → 没关系**; manter três turnos; anunciar a saída; escolher encerramento coerente; produzir três recombinações por família; e manter pronúncia funcional.

| Dimensão | 0 | 1 | 2 |
|---|---|---|---|
| **Compreensão** | não identifica a função | identifica com pistas | identifica sem pista |
| **Recuperação** | não inicia ou copia | inicia com hesitação | inicia espontaneamente |
| **Pronúncia funcional** | impede compreensão | compreensível com esforço | compreensível no contexto |
| **Transferência** | repete exemplo | troca um slot | escolhe e recombina em contexto novo |

**Passagem recomendada:** pelo menos **6/8**, sem zero em transferência e sem depender do texto completo. Uma página não corrige pronúncia sozinha: falhas tonais exigem áudio, gravação ou feedback humano qualificado.

## Notas de escopo e segurança metodológica

Uma forma frequente com decisão clara vale mais que uma lista de sinônimos. `您`, `抱歉`, `应该的`, `劳驾` e `失陪` entram apenas como camadas de registro. Traduções brasileiras preservam a ação: “não há de quê” pode corresponder a `不客气`; “tudo bem”, a `没关系`; “com licença”, a `不好意思` ou `请问`, conforme a função.

Os exemplos são enunciados isolados e autorais. O relatório não reproduz diálogos, transcrições ou áudios proprietários. O áudio continua sendo a fonte primária; o mapa entra depois da tentativa e termina dispensável.

### Contexto editorial do projeto

A seleção, a unidade de célula, a progressão de suporte, a regra de antecipação e o critério de domínio foram alinhados aos documentos internos **Mandarim em Rede — Auditoria de estresse e reconstrução definitiva**, **Frame textual**, **Plano de Ação de 90 Dias** e **Mandarim em Rede 01 — Fundamentos de Transferência Oral**. Esses documentos definem o áudio como motor primário, o mapa como camada pós-recuperação e a transferência como prova de aprendizagem.

## Referências

[1]: https://resources.allsetlearning.com/chinese/grammar/Polite_requests_with_%22qing%22 "Chinese Grammar Wiki — Polite requests with 请"

[2]: https://www.chineseboost.com/grammar/ma-ne/ "Chinese Boost — 吗 and 呢: the two Chinese question particles"

[3]: https://elon.io/grammar/chinese-mandarin/pragmatics/apologizing-degrees "Elon.io — Apologizing: 对不起, 不好意思, 抱歉, 打扰"

[4]: https://elon.io/grammar/chinese-mandarin/pragmatics/requests-qing-mafan "Elon.io — Making Requests: 请, 麻烦你, 劳驾"

[5]: https://goeastmandarin.com/how-to-say-goodbye-in-chinese/ "GoEast Mandarin — How to say goodbye in Chinese"

[6]: https://www.varsitytutors.com/practice/subjects/conversational-mandarin/lessons/asking-for-repetition "Varsity Tutors — Asking for Repetition in Conversational Mandarin"
