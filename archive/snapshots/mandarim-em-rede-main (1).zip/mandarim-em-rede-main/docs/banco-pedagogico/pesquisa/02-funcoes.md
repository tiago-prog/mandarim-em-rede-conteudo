# Funções comunicativas — pedir, negar, confirmar, localizar, preferir, convidar e reparar

> **Bloco para fala e recombinação.** Este documento organiza células de transferência para estudantes brasileiros de mandarim do iniciante ao intermediário inicial. O foco é agir oralmente: recuperar uma intenção, montar um padrão, trocar poucos componentes e usar a estrutura em uma situação nova.

## Escopo editorial e uso

O bloco foi desenhado como camada **pós-áudio**. O estudante realiza primeiro sua prática auditiva sem abrir o mapa, tenta responder, consulta a organização visual somente depois e retorna à produção com suporte reduzido. Os exemplos abaixo são frases isoladas, criadas para este relatório; não são diálogos, transcrições, roteiros ou adaptações de material proprietário.

A seleção privilegia funções de alta utilidade interacional e padrões produtivos. A referência oficial do HSK descreve a avaliação por tarefas, tópicos, vocabulário, gramática e caracteres, com objetivos comunicativos explícitos; por isso, a unidade aqui não é uma lista de palavras, mas uma ação que o aluno precisa conseguir realizar. [9] A arquitetura também segue a referência gramatical funcional de Ross e Ma, que organiza o mandarim por estruturas e funções, incluindo estratégias de comunicação, negação, localização, preferências, convites, pedidos e recusas. [1]

### Convenções de leitura

- **Caracteres:** simplificados.
- **Pinyin:** com tons lexicais ou, quando a forma consagrada de fala exige, com a marca de mudança tonal relevante para a produção.
- **Tradução:** natural em português brasileiro, não palavra por palavra.
- **[FIXO]:** componente que permanece no núcleo.
- **[SLOT]:** componente substituível.
- **[OPCIONAL]:** extensão que só entra depois de o núcleo estar estável.
- **Mapa:** deve passar de completo para lacunado, reduzido e dispensável.
- **Domínio:** exige compreensão auditiva, recuperação oral, pronúncia funcional e transferência; reconhecimento dos caracteres não é aprovação.

### Visão de progressão

| Função | Ação oral central | Padrão-base prioritário | Contraste principal para brasileiros |
|---|---|---|---|
| Pedir | obter informação, item ou ação | 请问……？ / 你能……吗？ | **请** como marcador de pedido; **能/可以** não são simplesmente “poder” em todos os contextos |
| Negar | recusar, negar ou dizer que algo não ocorreu | 不 / 没(有) / 不要 | **不** não é intercambiável com **没** |
| Confirmar | verificar se uma informação está correta | ……吗？ / ……对吗？ / A-not-A | respostas por eco são mais claras que um “sim/não” isolado |
| Localizar | perguntar e informar onde alguém ou algo está | X 在哪儿？ / X 在 + lugar | **在** localiza; **是** identifica |
| Preferir | escolher uma opção e declarar preferência | A 还是 B？ / 更喜欢 A | **还是** em pergunta de escolha; **或者** em afirmação/alternativa |
| Convidar | propor atividade compartilhada | 要不要一起……？ / ……吧 | convite não é ordem; **吧** suaviza proposta |
| Reparar | manter o entendimento quando surge problema | 我没听懂，请…… / 你的意思是……吗？ | **没听懂** comunica falha ocorrida; repetição exige ritmo e entoação naturais |

---

## 1. Pedir

### Intenção

**Solicitar informação, ajuda, item ou ação de maneira suficientemente clara e adequada ao contexto.** O aluno não deve aprender “pedir” como uma tradução fixa de “por favor”. Ele precisa escolher se está pedindo informação, pedindo que alguém faça algo ou pedindo que lhe deem algo.

### Padrão ou função

O núcleo recomendado para iniciantes tem dois caminhos que podem ser recombinados sem misturar suas funções:

1. **Perguntar informação com abertura polida**  
   `[FIXO] 请问 + [pergunta]？`  
   *Qǐngwèn + [pergunta]?*  
   “Com licença, [pergunta]?”

2. **Pedir uma ação ao interlocutor**  
   `[S] + 能/可以 + [ação] + 吗？`  
   *[S] + néng/kěyǐ + [ação] + ma?*  
   “Você pode [ação]?”

Para pedir um item em contexto de atendimento ou serviço, use:

`请给我 + [quantidade/classificador/item]。`  
*Qǐng gěi wǒ + [item].*  
“Por favor, me dê/traga [item].”

A forma **请 + verbo** é uma solicitação curta e polida. Ela é produtiva, mas **请** pode soar mais formal do que o brasileiro espera; em relações próximas, o mandarim muitas vezes usa uma pergunta com **能/可以** ou uma formulação direta contextualizada. [2] [3]

### Exemplos

1. **请问，洗手间在哪儿？**  
   *Qǐngwèn, xǐshǒujiān zài nǎr?*  
   Com licença, onde fica o banheiro?

2. **你能再说一遍吗？**  
   *Nǐ néng zài shuō yí biàn ma?*  
   Você pode repetir?

3. **可以帮我吗？**  
   *Kěyǐ bāng wǒ ma?*  
   Você pode me ajudar?

4. **请给我一杯水。**  
   *Qǐng gěi wǒ yì bēi shuǐ.*  
   Por favor, me dê um copo de água.

5. **请说慢一点。**  
   *Qǐng shuō màn yìdiǎn.*  
   Fale um pouco mais devagar, por favor.

### Slots substituíveis

| Slot | Exemplos de substituição | Tradução funcional |
|---|---|---|
| `[pergunta]` | 洗手间在哪儿？ / 你叫什么名字？ / 现在几点？ | onde fica o banheiro? / qual é seu nome? / que horas são? |
| `[ação]` | 再说一遍 / 写下来 / 等一下 / 帮我 | repetir / escrever / esperar um pouco / me ajudar |
| `[item]` | 水 / 茶 / 这个 / 那本书 | água / chá / isto / aquele livro |
| `[quantidade/classificador]` | 一杯 *yì bēi* / 一个 *yí ge* / 一张 *yì zhāng* | um copo / um item / uma folha ou bilhete |
| `[S]` | 你 / 你们 | você / vocês |

### Extensões

- **请问……？** abre uma busca de informação, sobretudo com desconhecidos, atendentes e pessoas na rua.
- **你可以……吗？** e **你能……吗？** transformam o pedido em pergunta. Como regra operacional, **能** enfatiza possibilidade ou capacidade na situação; **可以** pode enfatizar permissão ou possibilidade. A diferença não precisa ser ensinada como teoria antes da prática, mas deve ser percebida em contraste: *你能帮我吗？* “Você consegue/pode me ajudar?”; *这里可以坐吗？* “Pode sentar aqui?”
- **麻烦你 + ação** (*Máfan nǐ + ação*) significa “desculpe incomodar; você poderia…?”. É uma extensão útil para o iniciante avançado, mas não deve substituir o núcleo.
- **请不要 + ação** é um pedido negativo: “por favor, não…”. Não o confundir com uma recusa do próprio falante.

### Observação pedagógica

Treine primeiro **intenção → padrão**, e não “português → tradução de cada palavra”. Mostre uma situação curta, como um banheiro desconhecido ou uma fala rápida, e peça uma produção imediata. Em seguida, troque apenas o slot da pergunta. O aluno deve fazer pelo menos três pedidos com o mesmo esqueleto: pedir informação, pedir repetição e pedir ajuda.

Evite ensinar uma escala artificial de polidez baseada apenas em acrescentar **请**. A escolha depende de relação, situação e ação. A própria referência de gramática funcional observa que **请** é uma forma polida, mas pode ser mais formal do que o uso cotidiano entre pessoas próximas. [2]

**Alertas:**

- **请 qǐng** tem inicial aspirada e não deve ser lido como “tching” do português.
- **请问 qǐngwèn** é uma expressão convencional equivalente a “com licença, posso perguntar…?”. Não interpretar literalmente como “por favor, perguntar”.
- Em **一杯 yì bēi**, **一** aparece normalmente como quarto tom antes de **杯**, que tem primeiro tom. A regra geral é que **一** muda de acordo com o tom seguinte; não avaliar o aluno por leitura mecânica do pinyin.
- **给 gěi** é “dar/para” no pedido; não o confundir com **几 jǐ**, “quantos”.

### Potencial de mapa

**Família:** mapa de função + mapa de padrão + contraste de registro.

**Centro:** “quero obter informação, item ou ação”.

**Primeiro anel:**

- perguntar informação: **请问 + pergunta**;
- pedir ação: **能/可以 + ação + 吗**;
- pedir item: **请给我 + item**.

**Segundo anel:** slots de pergunta, ação, item e quantidade. **Vermelho:** escolha entre pedido de informação e pedido de ação; diferença de registro entre **请** e pergunta modal. **Laranja:** **qǐng**, **qǐngwèn**, **néng**, **kěyǐ**. **Dourado:** três pedidos novos sem consultar frases completas.

### Prompt de recuperação

Sem mostrar a resposta, apresente uma situação em português e um único gatilho visual:

> Você está em um lugar desconhecido. Pergunte onde fica o banheiro.

Depois:

> A pessoa falou rápido. Peça para repetir.

Por fim:

> Você quer um copo de água. Faça o pedido.

A resposta só aparece depois da tentativa. O aluno deve reconstruir **请问……**, **你能……吗** ou **请给我……** conforme a intenção.

### Prompt de transferência

Você está em uma estação, cafeteria ou sala de aula que não conhece. Produza três pedidos que não usem os exemplos anteriores: peça uma informação, peça uma ação e peça um item. Troque pelo menos dois slots e mantenha a abertura adequada ao interlocutor.

### Critério de domínio

Considere a célula funcionalmente dominada quando o aluno:

- identifica se precisa pedir informação, ação ou item;
- produz três pedidos novos sem traduzir palavra por palavra;
- alterna **请问**, **能/可以……吗** e **请给我……** de modo compreensível;
- mantém a ordem do padrão e a pronúncia funcional de **qǐng** e **qǐngwèn**;
- consegue fazer um pedido após um prompt novo, sem consultar o mapa completo.

---

## 2. Negar

### Intenção

**Recusar algo, negar uma identificação ou informar que uma ação não ocorreu.** Para o brasileiro, o risco central é tratar “não” como uma única palavra que serve para tudo. O bloco deve treinar uma decisão oral: estou negando intenção/hábito/estado, estou dizendo que algo não aconteceu, ou estou recusando uma oferta/pedido?

### Padrão ou função

Use três ramos contrastivos, com exemplos curtos:

1. **Não querer, não fazer ou não ser, no presente/futuro ou como hábito**  
   `[S] + 不 + [verbo/adjetivo]`  
   *[S] + bù + [verbo/adjetivo].*

2. **Ação que não ocorreu ou ainda não foi realizada**  
   `[S] + 没(有) + [verbo]`  
   *[S] + méi(yǒu) + [verbo].*

3. **Recusa direta / proibição contextual**  
   `不要 + [item/ação]`  
   *Bú yào + [item/ação].*  
   “Não quero [item]” ou “Não faça [ação]”, conforme o contexto.

A distinção operacional entre **不** e **没** é sustentada por descrições de gramática de nível inicial: **不** normalmente nega intenção, presente, futuro e hábitos; **没(有)** nega ocorrência passada, realização ou existência/posse. [4] Não transformar isso em uma regra absoluta para todos os níveis; na fala real, aspecto, contexto e verbo também importam.

### Exemplos

1. **我不想喝咖啡。**  
   *Wǒ bù xiǎng hē kāfēi.*  
   Não quero beber café.

2. **我不是老师。**  
   *Wǒ bú shì lǎoshī.*  
   Eu não sou professor(a).

3. **我不在家。**  
   *Wǒ bú zài jiā.*  
   Não estou em casa.

4. **我没听懂。**  
   *Wǒ méi tīng dǒng.*  
   Não entendi.

5. **我昨天没喝咖啡。**  
   *Wǒ zuótiān méi hē kāfēi.*  
   Ontem não bebi café.

6. **我没有时间。**  
   *Wǒ méiyǒu shíjiān.*  
   Não tenho tempo.

7. **不要，谢谢。**  
   *Bú yào, xièxie.*  
   Não quero, obrigado(a).

8. **不对，这不是我的。**  
   *Bú duì, zhè bú shì wǒ de.*  
   Não, isso não está certo; não é meu.

### Slots substituíveis

| Slot | Exemplos | Função |
|---|---|---|
| `[verbo/adjetivo]` | 想喝茶 / 喜欢咖啡 / 是学生 / 在家 | não querer beber chá / não gostar de café / não ser estudante / não estar em casa |
| `[verbo de evento]` | 听懂 / 吃饭 / 去学校 / 看电影 | não ter entendido / não ter comido / não ter ido / não ter visto |
| `[item]` | 咖啡 / 这个 / 那个 | recusar café / isto / aquilo |
| `[ação]` | 走 / 说话 / 抽烟 | não vá / não fale / não fume |
| `[identificação/posse]` | 不是我的 / 不是他的 | não é meu / não é dele |

### Extensões

- **不是……** nega identificação, classificação ou posse. É uma forma central para correção: **不是我的** “não é meu”.
- **没有……** também expressa “não ter” e “não haver”: **我没有钱。** *Wǒ méiyǒu qián.* “Não tenho dinheiro.” Não formar *不有* para esse sentido. [4]
- **不太 + adjetivo/verbo psicológico** suaviza a negativa: **我不太喜欢咖啡。** *Wǒ bú tài xǐhuan kāfēi.* “Não gosto muito de café.”
- **没关系。** *Méi guānxi.* “Tudo bem; não tem problema.” É uma resposta de reparo/atitude, não uma simples negação temporal.
- **别 + verbo** (*bié + verbo*) é uma extensão de proibição coloquial: **别走。** *Bié zǒu.* “Não vá; não vá embora.” Começar por **不要** é mais transparente para o iniciante.

### Observação pedagógica

Não ensine uma tabela abstrata de equivalentes de “não” sem ação. Use cartões de situação: “você não quer café”, “você não entendeu o que aconteceu”, “o celular não é seu”, “ontem você não foi”. O aluno precisa escolher o negador antes de falar.

O contraste mais produtivo é em pares mínimos funcionais:

- **我不喝咖啡。** *Wǒ bù hē kāfēi.* — Eu não bebo café / não vou beber café.
- **我没喝咖啡。** *Wǒ méi hē kāfēi.* — Eu não bebi café.

A tradução brasileira precisa incluir o tempo ou a intenção quando isso for necessário, mas não deve induzir a ideia de que **不 = não** e **没 = não** em qualquer contexto.

**Alertas:**

- **不 bù** muda normalmente para **bú** antes de uma sílaba de quarto tom: **bú yào**, **bú shì**, **bú duì**. O pinyin didático pode preservar a forma lexical **bù**, mas a produção oral deve seguir a forma conectada.
- **没 méi** não é **每 měi** (“cada/todo”).
- **不要 bú yào** pode significar “não quero” quando o sujeito está implícito ou “não faça” quando dirigido a outra pessoa. Contexto e entoação resolvem a diferença.
- Para **是** e **在**, use **不** no núcleo inicial: **不是**, **不在**. Evite ensinar *没是* ou *没在* como padrão.

### Potencial de mapa

**Família:** mapa de contraste, com mapa de função como entrada.

**Centro:** “rejeitar, negar ou corrigir”.

**Primeiro anel:**

- intenção/hábito/estado → **不**;
- evento não ocorrido → **没(有)**;
- recusa/proibição → **不要**;
- identidade/posse → **不是**.

**Segundo anel:** tempo, aspecto, item e ação. **Vermelho:** **不 × 没**, **不 × 不要**, **不是 × 不在**. **Laranja:** mudança de tom de **不** e contraste **méi/měi**. **Dourado:** decisão rápida em quatro situações novas.

### Prompt de recuperação

Dê somente o contexto em português, sem mostrar o negador:

> Você não quer café. Diga isso.

> Você não entendeu o que a pessoa falou. Diga isso.

> Ontem você não bebeu café. Diga isso.

> A bolsa não é sua. Corrija a informação.

O aluno deve escolher entre **不**, **没**, **不要** e **不是** antes de consultar qualquer forma escrita.

### Prompt de transferência

Uma pessoa oferece três bebidas, pergunta sobre uma ação de ontem e aponta para um objeto que não é seu. Responda oralmente às três situações sem repetir os exemplos do mapa. Em uma segunda rodada, troque bebida, ação e proprietário.

### Critério de domínio

Considere a célula dominada quando o aluno:

- escolhe **不** ou **没(有)** pela situação, e não pela tradução isolada de “não”;
- recusa um item com **不要** sem soar como se estivesse negando um evento passado;
- corrige identidade/posse com **不是**;
- produz quatro negativas novas com latência curta;
- realiza **bú yào**, **bú shì** e **méi** com pronúncia funcional;
- transfere o contraste para uma situação não praticada.

---

## 3. Confirmar

### Intenção

**Verificar se uma informação, identificação, posse, intenção ou plano está correto e responder de maneira não ambígua.** Confirmar não é somente dizer “sim”. O aluno precisa formular uma checagem e, quando responde, repetir o núcleo relevante.

### Padrão ou função

Use três formatos graduados:

1. **Pergunta com 吗**  
   `[afirmação] + 吗？`  
   *[afirmação] ma?*  
   “É verdade que…?”

2. **Checagem de confirmação**  
   `[afirmação]，对吗？`  
   *[afirmação], duì ma?*  
   “Está certo?” / “É isso mesmo?”

3. **Pergunta A-not-A**  
   `[verbo/adjetivo] + 不 + [verbo/adjetivo]？`  
   *[V] bu [V]?*  
   “Você [V] ou não?”

Em respostas, prefira o **eco do verbo ou predicado**:

- **对，是我的。** *Duì, shì wǒ de.* — Isso, é meu.
- **不是，不是我的。** *Bú shì, bú shì wǒ de.* — Não, não é meu.
- **要。/不要。** *Yào. / Bú yào.* — Quero. / Não quero.

A forma A-not-A é uma maneira importante de perguntas sim-não, e o mandarim costuma favorecer respostas por eco, isto é, repetindo o predicado afirmativa ou negativamente. [6]

### Exemplos

1. **这是你的手机吗？**  
   *Zhè shì nǐ de shǒujī ma?*  
   Este celular é seu?

2. **对，是我的。**  
   *Duì, shì wǒ de.*  
   Sim, é meu.

3. **不对，不是我的。**  
   *Bú duì, bú shì wǒ de.*  
   Não, não é meu.

4. **你明天有时间，对吗？**  
   *Nǐ míngtiān yǒu shíjiān, duì ma?*  
   Você tem tempo amanhã, certo?

5. **你是不是巴西人？**  
   *Nǐ shì bú shì Bāxī rén?*  
   Você é brasileiro(a)?

6. **你要不要茶？**  
   *Nǐ yào bú yào chá?*  
   Você quer chá ou não? / Quer chá?

7. **是的，我明天有时间。**  
   *Shì de, wǒ míngtiān yǒu shíjiān.*  
   Sim, amanhã eu tenho tempo.

8. **不是，我今天没有时间。**  
   *Bú shì, wǒ jīntiān méiyǒu shíjiān.*  
   Não, hoje eu não tenho tempo.

### Slots substituíveis

| Slot | Exemplos | O que se confirma |
|---|---|---|
| `[afirmação]` | 这是你的书 / 他在家 / 明天九点见 | posse / localização / plano |
| `[V]` | 是 / 要 / 喜欢 / 有 | ser / querer / gostar / ter |
| `[pessoa]` | 我 / 你 / 他 / 他们 | participante |
| `[item/opção]` | 茶 / 咖啡 / 这个 / 那个 | objeto ou alternativa |
| `[tempo]` | 今天 / 明天 / 上午九点 | momento do evento |

### Extensões

- **对吗？** procura confirmação do enunciado inteiro. É especialmente útil para checar entendimento de um plano: **我们明天见，对吗？** *Wǒmen míngtiān jiàn, duì ma?* “A gente se encontra amanhã, certo?”
- **是不是……？** é uma pergunta de confirmação direta, mas não deve receber **吗** no final: evite *是不是吗*. Escolha um formato.
- **真的吗？** *Zhēn de ma?* significa “É mesmo?” e introduz surpresa ou dúvida; não é o padrão neutro para toda confirmação.
- **可以吗？** *Kěyǐ ma?* confirma aceitabilidade de uma proposta: “Pode ser?”. É uma função próxima de confirmação, mas não equivale a confirmar um fato.

### Observação pedagógica

Ensine confirmação em ciclos de **afirmação → checagem → resposta por eco**. O aluno recebe uma informação parcial e precisa verificar um componente: pessoa, objeto, local, tempo ou intenção. A resposta deve incluir o predicado, porque o “sim” isolado do português cria transferência inadequada.

Há um alerta importante para brasileiros: perguntas negativas podem gerar respostas difíceis de interpretar. Em vez de treinar cedo frases como “Você não vai?”, use uma formulação afirmativa ou A-not-A. Quando a pergunta for negativa, peça uma resposta completa: **不，我去。** *Bù, wǒ qù.* “Não; eu vou.” ou **对，我不去。** *Duì, wǒ bú qù.* “Isso; eu não vou.” O ponto pedagógico é responder à proposição inteira, não traduzir mecanicamente “sim” e “não”. A discussão pública de perguntas negativas em mandarim documenta justamente essa diferença entre confirmar a suposição do interlocutor e confirmar o fato em si. [6]

**Alertas:**

- **对 duì** significa “correto; isso mesmo”, não é um “sim” universal.
- **是的 shì de** confirma uma proposição. **不是 bú shì** a nega; diante de quarto tom, **不** realiza-se como **bú**.
- Em **是不是 shì bú shì**, o primeiro **是** e o segundo **是** formam a estrutura A-not-A; não inserir **吗**.
- **还是 háishi** aparece em perguntas de escolha, não como substituto geral de “ou” em qualquer frase.

### Potencial de mapa

**Família:** mapa de função + mapa de contraste.

**Centro:** “verificar e alinhar informação”.

**Primeiro anel:**

- afirmação + **吗**;
- afirmação + **对吗**;
- A-not-A;
- resposta por eco.

**Segundo anel:** posse, localização, tempo, vontade e identidade. **Vermelho:** **对 × 是的 × 不对 × 不是**; pergunta negativa; **吗 × A-not-A**. **Laranja:** **duì**, **shì**, **bú**. **Dourado:** confirmar um dado novo e corrigi-lo quando estiver errado.

### Prompt de recuperação

Mostre uma informação incompleta e peça a operação:

> Aponte para um celular e pergunte se ele é da outra pessoa.

> Diga que amanhã há encontro e peça confirmação.

> Pergunte se a pessoa quer chá ou não.

Depois, altere apenas o proprietário, o dia ou a bebida. A resposta deve ser dada por eco, não por “sim/não” em português mentalmente traduzido.

### Prompt de transferência

Você recebeu três informações em um ambiente novo: uma localização, um horário e a posse de um objeto. Confirme cada uma com um formato diferente (**吗**, **对吗**, A-not-A) e responda às próprias checagens como exercício de recuperação. Não copie os exemplos.

### Critério de domínio

Considere a célula dominada quando o aluno:

- formula confirmação com **吗**, **对吗** e A-not-A;
- responde repetindo o predicado relevante;
- diferencia confirmação de fato, confirmação de aceitabilidade (**可以吗**) e escolha entre alternativas;
- evita *是不是吗*;
- mantém pronúncia funcional de **duì**, **shì**, **bú**;
- consegue esclarecer uma pergunta negativa por meio de uma frase completa;
- transfere a função para pessoa, objeto, local e horário novos.

---

## 4. Localizar

### Intenção

**Perguntar onde uma pessoa ou coisa está, informar a própria localização e localizar um objeto dentro, sobre ou ao lado de outro.** A função deve ser treinada com referentes reais ou imaginados no espaço, não com listas de preposições.

### Padrão ou função

1. **Perguntar localização**  
   `[pessoa/objeto] + 在哪儿/哪里？`  
   *[pessoa/objeto] zài nǎr/nǎlǐ?*  
   “Onde está/fica [pessoa/objeto]?”

2. **Responder localização**  
   `[pessoa/objeto] + 在 + [lugar]。`  
   *[pessoa/objeto] zài + [lugar].*

3. **Localização interna ou relacional**  
   `[objeto] + 在 + [lugar] + 里/上/旁边。`  
   *[objeto] zài [lugar] lǐ/shàng/pángbiān.*

4. **Localização de uma ação**  
   `[S] + 在 + [lugar] + [verbo] + [objeto]。`  
   *[S] zài [lugar] [verbo] [objeto].*

A estrutura de localização com **在** antes do verbo é uma diferença de ordem importante: em mandarim, o local da ação vem depois do sujeito e antes do verbo. [5]

### Exemplos

1. **洗手间在哪儿？**  
   *Xǐshǒujiān zài nǎr?*  
   Onde fica o banheiro?

2. **手机在哪里？**  
   *Shǒujī zài nǎlǐ?*  
   Onde está o celular?

3. **我在这里。**  
   *Wǒ zài zhèlǐ.*  
   Estou aqui.

4. **他在那儿。**  
   *Tā zài nàr.*  
   Ele está ali.

5. **手机在包里。**  
   *Shǒujī zài bāo lǐ.*  
   O celular está dentro da bolsa.

6. **书在桌子上。**  
   *Shū zài zhuōzi shàng.*  
   O livro está sobre a mesa.

7. **我在咖啡店学习。**  
   *Wǒ zài kāfēidiàn xuéxí.*  
   Estudo na cafeteria.

### Slots substituíveis

| Slot | Exemplos | Tradução funcional |
|---|---|---|
| `[pessoa/objeto]` | 我 / 你 / 他 / 手机 / 书 / 洗手间 | eu / você / ele / celular / livro / banheiro |
| `[lugar]` | 家 / 学校 / 咖啡店 / 包 / 桌子 | casa / escola / cafeteria / bolsa / mesa |
| `[relação]` | 里 *lǐ* / 上 *shàng* / 旁边 *pángbiān* | dentro / sobre / ao lado |
| `[deítico]` | 这里 / 那里 / 这儿 / 那儿 | aqui / ali / aqui / ali |
| `[verbo]` | 学习 / 工作 / 吃饭 / 等人 | estudar / trabalhar / comer / esperar alguém |

### Extensões

- **哪儿** e **哪里** significam “onde”. Escolha uma forma para automatizar primeiro; depois alterne as duas. **哪儿 nǎr** é frequente em fala e traz o **儿** retroflexo; **哪里 nǎlǐ** é transparente para o iniciante.
- **这儿/那儿** e **这里/那里** são pares locais. Não confundir **那 nà** (“aquele/ali”) com **哪 nǎ** (“qual/onde” em compostos interrogativos).
- **有没有 + objeto + 在 + lugar？** é uma extensão para existência/ausência: **这里有没有洗手间？** *Zhèlǐ yǒu méiyǒu xǐshǒujiān?* “Tem banheiro aqui?”
- Para direção, acrescente uma célula posterior; não sobrecarregue este padrão com **左边**, **右边**, **一直走** e trajetos inteiros antes de o aluno localizar pessoas e objetos.

### Observação pedagógica

A melhor prática é espacial. Peça ao aluno que olhe para três objetos reais ou os imagine, pergunte a localização e responda usando três lugares diferentes. Só depois introduza a localização de ação: **我在家学习**. O mapa deve marcar a posição de **在** antes do lugar e, na extensão, antes do verbo; não deve apresentar uma regra longa em português.

A distinção **在 × 是** é uma decisão de produção:

- **手机在包里。** — O celular está na bolsa.
- **这是我的手机。** — Este é o meu celular.

O primeiro localiza; o segundo identifica. A referência gramatical também separa **在** como verbo de localização e as construções em que **在 + lugar** precede um verbo de ação. [1] [5]

**Alertas:**

- **在 zài** é quarto tom. **再 zài** (“de novo”) tem a mesma pronúncia; o contexto e os caracteres distinguem as funções.
- **哪儿 nǎr** não é o “r” gutural do português brasileiro. Faça a aproximação sem exagerar o som.
- **这里 zhèlǐ** e **那里 nàlǐ** têm redução de força na fala conectada; não exija que cada sílaba receba a mesma intensidade.
- Não transportar a ordem brasileira “eu estudo na cafeteria” como posição final obrigatória. No mandarim, **我在咖啡店学习** coloca o local antes de **学习**.

### Potencial de mapa

**Família:** mapa de padrão espacial + mapa de contraste.

**Centro:** “encontrar ou posicionar pessoa/objeto”.

**Primeiro anel:** X **在哪儿/哪里**; X **在 + lugar**; X **在 + lugar + 里/上**; S **在 + lugar + verbo**.

**Segundo anel:** objetos, pessoas, deíticos, recipientes e lugares. **Vermelho:** **在 × 是**, **哪 × 那**, posição do local antes do verbo. **Laranja:** **zài**, **nǎr**, **zhèlǐ**, **nàr**. **Dourado:** localização com objetos reais e prompt auditivo.

### Prompt de recuperação

Sem caracteres, dê um referente e peça a operação:

> Pergunte onde está o seu celular.

> Diga que o celular está dentro da bolsa.

> Diga que você está na cafeteria estudando.

> Use “aqui” em uma resposta e “ali” em outra.

### Prompt de transferência

Em um espaço novo, escolha mentalmente quatro objetos e três lugares. Faça quatro perguntas e quatro respostas, incluindo uma localização interna, uma sobre superfície e uma localização de ação. Não use **是** para localizar.

### Critério de domínio

Considere a célula dominada quando o aluno:

- pergunta com **哪儿** ou **哪里** e responde com **在**;
- usa **里**, **上** ou **旁边** quando a relação espacial exigir;
- mantém o local antes do verbo em uma frase de ação;
- diferencia **在** de **是** e **哪** de **那**;
- produz ao menos quatro localizações novas sem apoio escrito;
- reconhece a função ao ouvir, mesmo quando o referente e o local são trocados.

---

## 5. Preferir

### Intenção

**Escolher uma opção entre duas ou mais e declarar preferência sem depender de tradução literal.** O aluno deve conseguir perguntar a preferência de outra pessoa, responder com uma opção e intensificar ou suavizar a preferência.

### Padrão ou função

1. **Perguntar escolha entre duas opções**  
   `[S] + 喜欢 + A + 还是 + B？`  
   *[S] xǐhuan A háishi B?*  
   “Você prefere/gosta mais de A ou B?”

2. **Declarar preferência**  
   `[S] + 更喜欢 + A。`  
   *[S] gèng xǐhuan A.*  
   “Eu prefiro A.”

3. **Declarar preferência moderada ou contrastiva**  
   `[S] + 比较喜欢 + A。`  
   *[S] bǐjiào xǐhuan A.*  
   “Eu gosto mais de A / tendo a preferir A.”

4. **Expressar escolha situacional**  
   `[S] + 想 + V + A，不想 + V + B。`  
   *[S] xiǎng V A, bù xiǎng V B.*  
   “Quero fazer A, não quero fazer B.”

### Exemplos

1. **你喜欢茶还是咖啡？**  
   *Nǐ xǐhuan chá háishi kāfēi?*  
   Você prefere chá ou café?

2. **我更喜欢茶。**  
   *Wǒ gèng xǐhuan chá.*  
   Eu prefiro chá.

3. **我比较喜欢在家学习。**  
   *Wǒ bǐjiào xǐhuan zài jiā xuéxí.*  
   Eu prefiro estudar em casa.

4. **你喜欢坐地铁还是坐公共汽车？**  
   *Nǐ xǐhuan zuò dìtiě háishi zuò gōnggòng qìchē?*  
   Você prefere andar de metrô ou de ônibus?

5. **我不太喜欢咖啡。**  
   *Wǒ bú tài xǐhuan kāfēi.*  
   Não gosto muito de café.

6. **我想喝茶，不想喝咖啡。**  
   *Wǒ xiǎng hē chá, bù xiǎng hē kāfēi.*  
   Quero beber chá, não café.

### Slots substituíveis

| Slot | Exemplos | Campo de recombinação |
|---|---|---|
| `[S]` | 我 / 你 / 他 / 我们 | quem prefere |
| `A/B` | 茶/咖啡; 中文/英语; 在家/在学校 | opções |
| `[V]` | 喝 / 吃 / 学习 / 看 | ação |
| `[grau]` | 更 / 比较 / 最 | prefiro / gosto mais ou menos / gosto mais de todos |
| `[atitude]` | 不太喜欢 / 很喜欢 | baixa ou alta preferência |

### Extensões

- **最喜欢** (*zuì xǐhuan*) significa “gostar mais de todos; preferir acima das demais opções”: **我最喜欢茶。** *Wǒ zuì xǐhuan chá.* “O que eu mais gosto é chá.”
- **还是** é o marcador recomendado em pergunta de escolha: **茶还是咖啡？**. Em uma afirmação que apresenta alternativas, **或者 huòzhě** é mais apropriado: **你可以喝茶或者咖啡。** “Você pode beber chá ou café.” Não ensinar **还是** e **或者** como equivalentes em todos os ambientes.
- **比较喜欢** permite resposta menos categórica; **更喜欢** explicita comparação, mesmo quando a segunda opção fica implícita.
- **想** expressa vontade atual, não preferência estável. Compare: **我喜欢茶** “gosto/prefiro chá” versus **我想喝茶** “quero beber chá agora”.

### Observação pedagógica

A unidade precisa separar **preferência** de **desejo imediato**. Use objetos e atividades que permitam troca controlada. Primeiro, pergunte A ou B; depois, faça o aluno responder com **更喜欢**; por fim, troque o domínio: bebidas → idiomas → lugar de estudo. Isso produz recombinação sem exigir vocabulário amplo.

Não trate a tradução “preferir” como prova de que todo uso de **喜欢** implica comparação. Em mandarim, **喜欢** pode significar simplesmente “gostar”. O componente **更** torna a preferência comparativa mais explícita.

**Alertas:**

- **喜欢 xǐhuan:** a segunda sílaba costuma ser neutra ou menos proeminente. Não dê a mesma força a **huan**.
- **还是 háishi:** normalmente o tom está marcado em **hái**; a sílaba **shi** é fraca na expressão. Não transformá-la em **shì** forte sem necessidade.
- **更 gèng** é quarto tom. **不太** realiza-se frequentemente como **bú tài** na fala conectada.
- **或者 huòzhě** não é a primeira escolha em uma pergunta direta de alternativas.

### Potencial de mapa

**Família:** mapa de função + mapa de contraste lexical.

**Centro:** “escolher e declarar preferência”.

**Primeiro anel:** pergunta A **还是** B; resposta **更喜欢**; preferência moderada **比较喜欢**; desejo situacional **想**.

**Segundo anel:** opções, ações, grau e intensidade. **Vermelho:** **还是 × 或者**, **喜欢 × 想**, **更喜欢 × 最喜欢**. **Laranja:** **xǐhuan**, **háishi**, **gèng**, **bú tài**. **Dourado:** trocar domínio sem trocar o esqueleto.

### Prompt de recuperação

Dê somente duas opções e peça a operação:

> Pergunte: chá ou café?

> Responda: você prefere chá.

> Diga que prefere estudar em casa.

> Diga que não gosta muito de café.

Faça a segunda rodada com dois idiomas ou dois meios de transporte.

### Prompt de transferência

Você precisa escolher uma atividade e uma bebida para um encontro. Pergunte a preferência de outra pessoa, responda à pergunta e depois reformule a sua preferência usando **更喜欢** ou **比较喜欢**. Não repita chá/café na segunda rodada.

### Critério de domínio

Considere a célula dominada quando o aluno:

- pergunta uma escolha com **还是**;
- responde com **更喜欢** ou **比较喜欢** sem depender de uma tradução palavra por palavra;
- separa preferência estável (**喜欢**) de vontade do momento (**想**);
- usa pelo menos três pares de opções novos;
- mantém a pronúncia funcional de **xǐhuan**, **háishi** e **gèng**;
- consegue suavizar ou intensificar a preferência em contexto novo.

---

## 6. Convidar

### Intenção

**Propor que outra pessoa participe de uma atividade compartilhada, em um tempo ou lugar indicado, deixando espaço para aceitar, recusar ou negociar.** O objetivo não é decorar um convite completo, mas combinar participante, atividade, tempo e resposta.

### Padrão ou função

1. **Convite direto e conversacional**  
   `你要不要 + [一起] + [ação]？`  
   *Nǐ yào bú yào [yìqǐ] [ação]?*  
   “Você quer [fazer algo]?” / “Vamos [fazer algo]?”

2. **Proposta com 吧**  
   `[tempo] + 我们 + [一起] + [ação] + 吧。`  
   *[tempo] wǒmen [yìqǐ] [ação] ba.*  
   “Vamos [ação] [tempo].”

3. **Checagem da proposta**  
   `[proposta]，好吗？/可以吗？`  
   *[proposta], hǎo ma/kěyǐ ma?*  
   “Pode ser?” / “Tudo bem?”

A pesquisa de análise conversacional sobre convites em mandarim identifica, entre os formatos principais, perguntas A-not-A, imperativos e declarações; para o nível inicial, a pergunta **要不要** e a proposta com **吧** dão acesso produtivo a esses recursos sem exigir uma descrição avançada da sequência social. [7]

### Exemplos

1. **你要不要一起吃饭？**  
   *Nǐ yào bú yào yìqǐ chīfàn?*  
   Você quer comer junto?

2. **我们明天一起喝咖啡吧。**  
   *Wǒmen míngtiān yìqǐ hē kāfēi ba.*  
   Vamos tomar café juntos amanhã.

3. **周末一起看电影，好吗？**  
   *Zhōumò yìqǐ kàn diànyǐng, hǎo ma?*  
   Vamos ver um filme no fim de semana, pode ser?

4. **你要不要跟我一起去学校？**  
   *Nǐ yào bú yào gēn wǒ yìqǐ qù xuéxiào?*  
   Você quer ir comigo para a escola?

5. **好啊，可以。**  
   *Hǎo a, kěyǐ.*  
   Claro, pode ser.

6. **不好意思，我今天没时间。**  
   *Bù hǎoyìsi, wǒ jīntiān méi shíjiān.*  
   Desculpe, hoje não tenho tempo.

7. **改天可以吗？**  
   *Gǎitiān kěyǐ ma?*  
   Pode ser outro dia?

### Slots substituíveis

| Slot | Exemplos | Função |
|---|---|---|
| `[tempo]` | 今天 / 明天 / 周末 / 晚上 | hoje / amanhã / fim de semana / à noite |
| `[ação]` | 吃饭 / 喝茶 / 看电影 / 学习中文 | comer / tomar chá / ver filme / estudar chinês |
| `[一起]` | 一起 / 跟我一起 | juntos / comigo |
| `[destino]` | 去学校 / 去咖啡店 / 去公园 | ir à escola / cafeteria / parque |
| `[resposta]` | 好啊 / 可以 / 没问题 / 不好意思，我没时间 | aceitação / negociação / recusa |

### Extensões

- **我们……吧** transforma uma atividade em proposta coletiva. **吧** suaviza e abre espaço para alinhamento; não é simplesmente “por favor”.
- **一起** torna a participação compartilhada explícita. Sem **一起**, a frase ainda pode ser convite, mas a leitura fica mais dependente do contexto.
- **跟我一起 + verbo** especifica o acompanhante: “comigo”.
- **我请你喝咖啡。** *Wǒ qǐng nǐ hē kāfēi.* significa “Eu te pago um café / eu te convido para um café”. **请** aqui tem o sentido de oferecer ou pagar, não o de marcador genérico de polidez.
- Para recusar sem fechar a relação, use uma razão simples e alternativa: **今天不行，明天可以吗？** *Jīntiān bù xíng, míngtiān kěyǐ ma?* “Hoje não dá; amanhã pode ser?”

### Observação pedagógica

Convite é uma ação social, não uma frase isolada. O aluno deve praticar o ciclo **propor → aceitar/recusar → ajustar** sem receber um diálogo pronto. Mantenha a recusa curta e funcional; não introduza cedo justificativas longas, fórmulas ritualizadas ou nuances de face que não serão usadas.

A progressão recomendada é:

1. **你要不要……？** com duas atividades conhecidas;
2. **我们……吧。** com tempo substituível;
3. **好吗/可以吗？** para checar o acordo;
4. recusar e oferecer outro momento.

O estudo sobre aprendizes de chinês também mostra que a organização das aceitações de convites depende de proficiência e de recursos interacionais disponíveis; por isso, o material deve testar não apenas a produção do convite, mas também a resposta e o ajuste. [7]

**Alertas:**

- **要 yào** é quarto tom; antes dele, **不** realiza-se como **bú**: **要不要 yào bú yào**.
- **一起 yìqǐ** deve ser treinado como unidade rítmica, não como duas sílabas igualmente fortes.
- **吧 ba** é partícula neutra, sem acento lexical forte. Evite pronunciá-la como uma palavra plena.
- **请 qǐng** em **我请你……** não é o mesmo uso de **请 + verbo** em um pedido polido.
- Um convite com **你要不要……？** pode ser direto e natural entre conhecidos; com desconhecidos ou situação formal, contexto e tratamento importam mais do que acrescentar partículas automaticamente.

### Potencial de mapa

**Família:** mapa de função social + mapa de sequência.

**Centro:** “propor atividade compartilhada”.

**Primeiro anel:** **要不要……？**; **我们……吧**; **好吗/可以吗**; resposta de aceitação, recusa ou negociação.

**Segundo anel:** tempo, atividade, destino, acompanhante e alternativa. **Vermelho:** convite × pedido; **要不要** × desejo individual; **吧** × ordem. **Laranja:** **yào bú yào**, **yìqǐ**, partícula **ba**. **Dourado:** convite em contexto novo com resposta adequada.

### Prompt de recuperação

Dê um cartão de intenção:

> Convide alguém para comer junto amanhã.

> Proponha tomar chá no fim de semana.

> Recuse o convite porque hoje você não tem tempo e proponha outro dia.

O aluno deve escolher entre pergunta **要不要** e proposta **我们……吧** sem ver a solução.

### Prompt de transferência

Você encontrou uma pessoa conhecida antes de uma atividade. Faça um convite com tempo e ação novos, responda aceitando ou recusando e, se recusar, proponha uma alternativa. Faça uma segunda rodada alterando o lugar e o dia.

### Critério de domínio

Considere a célula dominada quando o aluno:

- produz convite com **要不要** e com **我们……吧**;
- inclui atividade e pelo menos um slot de tempo, lugar ou acompanhante;
- responde aceitando, recusando ou negociando;
- diferencia convite de pedido e de simples declaração de desejo;
- mantém **yào bú yào**, **yìqǐ** e **ba** em ritmo funcional;
- consegue ajustar a proposta em situação não ensaiada.

---

## 7. Reparar

### Intenção

**Restabelecer o entendimento quando há problema para ouvir, compreender, formular ou interpretar.** Reparar é uma habilidade de continuidade: o aluno não abandona a interação nem finge que entendeu. Ele sinaliza o problema, especifica o que precisa e retoma a conversa.

### Padrão ou função

1. **Sinalizar falha de compreensão**  
   `我没听懂。` / `我不明白。`  
   *Wǒ méi tīng dǒng. / Wǒ bù míngbai.*  
   “Não entendi.” / “Não compreendo.”

2. **Pedir repetição**  
   `请再说一遍。` ou `你能再说一遍吗？`  
   *Qǐng zài shuō yí biàn. / Nǐ néng zài shuō yí biàn ma?*  
   “Por favor, repita.” / “Você pode repetir?”

3. **Pedir redução de velocidade**  
   `请说慢一点。`  
   *Qǐng shuō màn yìdiǎn.*  
   “Fale um pouco mais devagar.”

4. **Checar interpretação**  
   `你的意思是 + [interpretação] + 吗？`  
   *Nǐ de yìsi shì + [interpretação] + ma?*  
   “Você quer dizer que [interpretação]?”

5. **Corrigir a própria fala**  
   `不，我是说 + [reformulação]。`  
   *Bù, wǒ shì shuō + [reformulação].*  
   “Não; quero dizer [reformulação].”

### Exemplos

1. **我没听懂。**  
   *Wǒ méi tīng dǒng.*  
   Não entendi.

2. **请再说一遍。**  
   *Qǐng zài shuō yí biàn.*  
   Por favor, repita.

3. **你能再说一遍吗？**  
   *Nǐ néng zài shuō yí biàn ma?*  
   Você pode repetir?

4. **请说慢一点。**  
   *Qǐng shuō màn yìdiǎn.*  
   Fale um pouco mais devagar.

5. **你的意思是明天见吗？**  
   *Nǐ de yìsi shì míngtiān jiàn ma?*  
   Você quer dizer que nos encontramos amanhã?

6. **是这个意思吗？**  
   *Shì zhège yìsi ma?*  
   É isso que você quer dizer?

7. **不，我是说下午。**  
   *Bù, wǒ shì shuō xiàwǔ.*  
   Não; quero dizer à tarde.

8. **现在我明白了。**  
   *Xiànzài wǒ míngbai le.*  
   Agora entendi.

### Slots substituíveis

| Slot | Exemplos | Função |
|---|---|---|
| `[pedido]` | 再说一遍 / 说慢一点 / 写下来 | repetir / falar devagar / escrever |
| `[interpretação]` | 明天见 / 在这里 / 你要茶 | encontro amanhã / estar aqui / querer chá |
| `[reformulação]` | 下午 / 咖啡 / 在家 | à tarde / café / em casa |
| `[fonte do problema]` | 没听懂 / 不明白 / 不知道 | não ouvi-entendi / não compreendo / não sei |

### Extensões

- **我没听清。** *Wǒ méi tīng qīng.* — “Não ouvi com clareza.” Use quando o problema é o sinal acústico ou a velocidade, sem afirmar necessariamente que o significado era desconhecido.
- **什么意思？** *Shénme yìsi?* — “O que significa?” É uma pergunta curta e direta; pode soar abrupta fora de contexto. Para um pedido mais claro, use **这是什么意思？** *Zhè shì shénme yìsi?* “O que isso significa?”
- **你是说……？** *Nǐ shì shuō…?* — “Você quer dizer…?” é uma versão mais curta de checagem de interpretação.
- Uma repetição parcial com entoação interrogativa, como repetir somente uma palavra ou expressão desconhecida, é um recurso natural de reparo em conversa. Pesquisas sobre fala espontânea em mandarim mostram que essa repetição pode pedir esclarecimento e também sinalizar surpresa; por depender de entoação e contexto, deve ser extensão, não o primeiro modelo do iniciante. [8]

### Observação pedagógica

Reparo deve ser treinado como sequência de ações, mas sem reproduzir diálogos. Use estímulos independentes: uma frase rápida, uma informação incompleta, uma palavra desconhecida e uma frase que o próprio aluno formulou errado. O aluno escolhe a ferramenta mínima:

- não ouviu/entendeu → **我没听懂** ou **我没听清**;
- precisa de repetição → **请再说一遍**;
- precisa de velocidade menor → **请说慢一点**;
- precisa checar a interpretação → **你的意思是……吗？**;
- falou algo errado → **不，我是说……**.

O reparo deve ser curto e orientado ao problema. Não exija que o iniciante explique em português por que não entendeu. A forma **我没听懂** sinaliza falha de compreensão do conteúdo; **我没听清** focaliza a percepção acústica. A diferença é útil quando o aluno precisa pedir repetição ou velocidade menor, mas não deve virar uma aula abstrata sobre aspecto antes da tentativa oral.

Reparar também inclui reconhecer que agora a mensagem foi compreendida: **现在我明白了** encerra o ciclo. O mapa deve mostrar o fluxo mínimo:

```text
problema → sinalizar → especificar pedido → confirmar entendimento
```

**Alertas:**

- **没 méi** em **我没听懂** e **我没听清** é segundo tom. Não confundir com **每 měi**.
- **再 zài** (“de novo”) e **在 zài** (“em; estar localizado”) têm a mesma pronúncia; o contexto decide a função.
- **一遍 yí biàn** realiza **一** como segundo tom antes de **遍 biàn**, de quarto tom. O pinyin com tons lexicais pode não registrar todas as mudanças; a fala conectada precisa ser ouvida e imitada. [10]
- **明白 míngbai** costuma ter a segunda sílaba fraca/neutra. Não atribuir a **bai** o mesmo peso de **míng**.
- Repetição parcial com entoação interrogativa, como **明天？** *Míngtiān?*, pode soar como surpresa ou questionamento, além de simples falta de audição. Para o iniciante, começar com **请再说一遍** evita ambiguidade; só depois explorar a repetição parcial como recurso conversacional. [8]

### Potencial de mapa

**Família:** mapa de reparo + mapa de sequência interacional.

**Centro:** “manter a interação quando a compreensão falha”.

**Primeiro anel:** declarar falha; pedir repetição; pedir fala mais lenta; checar interpretação; reformular a própria fala; confirmar que entendeu.

**Segundo anel:** fonte do problema, ação pedida e interpretação. **Vermelho:** **没听懂 × 没听清**, pedir repetição × pedir explicação, reparo × fingir compreensão. **Laranja:** **méi**, **tīng**, **dǒng**, **zài**, **biàn**, ritmo de **yí biàn**. **Dourado:** uma sequência de reparo que termina com retomada da tarefa.

### Prompt de recuperação

Dê um estímulo oral rápido ou uma informação incompleta e peça somente a ação necessária:

> Você não entendeu. Sinalize o problema.

> Você ouviu, mas a pessoa falou rápido demais. Peça para repetir.

> Você entendeu parte da mensagem e quer conferir: “você quer dizer amanhã?”.

> Você se corrigiu. Diga “não; quero dizer à tarde”.

Não exiba o pinyin antes da tentativa. Em uma segunda rodada, altere o conteúdo interpretado, mas preserve a função do reparo.

### Prompt de transferência

Em uma situação nova, alguém informa um horário, um local ou uma bebida, mas você não compreende tudo. Produza uma sequência de até quatro movimentos: sinalize o problema, peça repetição ou velocidade menor, confirme sua interpretação e encerre com **现在我明白了**. Repita com outro conteúdo sem consultar o mapa completo.

### Critério de domínio

Considere a célula dominada quando o aluno:

- escolhe entre **我没听懂**, **我没听清**, pedido de repetição e checagem de interpretação;
- produz o reparo sem abandonar a intenção comunicativa original;
- consegue pedir repetição e velocidade menor com ordem e pronúncia funcionais;
- reformula a própria fala com **我是说……**;
- reconhece e encerra o reparo com **现在我明白了**;
- transfere a sequência para conteúdo novo, sem reproduzir uma conversa memorizada.

---

## Integração do bloco em mapas e revisão

As sete funções formam uma rede de operações, não uma sequência de diálogos. O mapa de consolidação deve ligar **pedir → confirmar → localizar → preferir → convidar**, enquanto **negar** e **reparar** funcionam como operações transversais que podem aparecer em qualquer ponto.

| Estado do suporte | O que aparece | Exigência oral |
|---|---|---|
| Orientação | intenção, padrão completo, tradução natural, slots e um alerta | reconhecer a operação e ouvir o núcleo |
| Recuperação | intenção, lacunas e slots nomeados | reconstruir antes de consultar a solução |
| Recombininação | situação, poucos gatilhos e contraste | trocar pelo menos três componentes controlados |
| Transferência | contexto novo e sem frase-modelo | escolher a função adequada e agir |
| Independência | apenas situação ou estímulo auditivo | produzir, reparar e continuar sem mapa |

### Protocolo curto de revisão

1. **Mesmo dia:** uma tentativa por função com mapa completo apenas depois da produção.
2. **Dia seguinte:** lacunas em três funções; retirar a tradução.
3. **Três a sete dias depois:** prompts em português, sem caracteres ou pinyin; avaliar latência e recombinação.
4. **Revisão cumulativa:** situação nova que exija ao menos quatro operações, incluindo uma negação ou reparo.

O objetivo não é elevar a quantidade de frases reconhecidas. É reduzir a dependência da ordem original, aumentar o número de variações funcionais e manter a capacidade de continuar quando houver incerteza. A literatura sobre reparo trata essa operação como mecanismo para restabelecer entendimento e manter o avanço da interação; por isso, reparar deve ser avaliado como desempenho comunicativo, não como uma lista de fórmulas. [8]

### Critério de domínio do bloco

O bloco está funcionalmente dominado quando o aluno consegue, sem o mapa completo:

- fazer um pedido adequado ao contexto;
- negar intenção, posse ou ocorrência usando o negador apropriado;
- confirmar informação por eco ou checagem clara;
- localizar pessoa, objeto ou ação;
- perguntar e declarar preferência;
- convidar, aceitar, recusar ou negociar;
- reparar uma falha e retomar a tarefa;
- produzir pelo menos três recombinações por função;
- manter pronúncia funcional nos pontos destacados;
- transferir as operações para uma situação não vista.

Esse critério não afirma fluência geral nem correção fonética automática. O material organiza recuperação e transferência; a validação de percepção tonal e pronúncia requer áudio legítimo, gravação comparável, ferramenta validada ou feedback humano qualificado. O áudio continua sendo o motor primário, e o mapa deve ficar menor à medida que o aluno melhora.

## Referências

[1]: https://resources.allsetlearning.com/chinese/grammar/Reference:Modern_Mandarin_Chinese_Grammar:_A_Practical_Guide "Modern Mandarin Chinese Grammar: A Practical Guide — referência funcional"
[2]: https://resources.allsetlearning.com/chinese/grammar/Polite_requests_with_%22qing%22 "Chinese Grammar Wiki — Polite requests with qing"
[3]: https://resources.allsetlearning.com/chinese/grammar/Requesting "Chinese Grammar Wiki — Requesting"
[4]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22bu%22_and_%22mei%22 "Chinese Grammar Wiki — Comparing bu and mei"
[5]: https://resources.allsetlearning.com/chinese/grammar/Indicating_location_with_%22zai%22_before_verbs "Chinese Grammar Wiki — Indicating location with zai before verbs"
[6]: https://languagelog.ldc.upenn.edu/nll/?p=30943 "Language Log — Yes-no questions in mathematics and in Chinese"
[7]: https://doi.org/10.1016/j.pragma.2017.06.013 "Guodong Yu and Yaxin Wu — Inviting in Mandarin: Anticipating the likelihood of the success of an invitation"
[8]: https://www.paradigmpress.org/JLCS/article/download/1958/1811 "Jian Guan — Composite Social Actions: Question-Intoned Repeat-Formatted Repair Initiation in Mandarin Conversation"
[9]: https://www.chinesetest.cn/hsk "Chinese Tests Service Website — About HSK and New HSK syllabus"
[10]: https://resources.allsetlearning.com/chinese/pronunciation/Tone_change_rules "Chinese Grammar Wiki — Tone change rules"
