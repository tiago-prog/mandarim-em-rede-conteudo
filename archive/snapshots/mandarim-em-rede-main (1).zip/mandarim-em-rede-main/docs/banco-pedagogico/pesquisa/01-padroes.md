# Bloco — Padrões produtivos

## Escopo editorial

Este bloco reúne **templates de alta frequência para fala**, selecionados para adultos brasileiros do iniciante ao intermediário inicial. O foco não é apresentar regras isoladas, mas transformar cada estrutura em uma **célula de transferência oral**: uma intenção, um molde recombinável, poucos slots, exemplos naturais, uma decisão de pronúncia ou contraste quando necessária e uma tarefa que obrigue o aluno a produzir algo novo.

Os exemplos deste relatório são autorais e independentes. Eles não reproduzem diálogos, transcrições, roteiros ou áudios proprietários. A seleção parte de padrões descritos em referências públicas de gramática chinesa e é filtrada pelo desenho do projeto: o áudio ou outra fonte auditiva vem primeiro; o mapa entra depois da tentativa; o suporte diminui até desaparecer. A ordem básica SVO, a posição de palavras interrogativas, a colocação de tempo e lugar e as construções de existência e posse são descritas em referências públicas de gramática de mandarim.[1] [2] [3] [4]

### Convenções de leitura

- **[Fixo]**: elemento que permanece no molde.
- **[Slot]**: elemento substituível que o aluno deve trocar oralmente.
- **[Opcional]**: extensão que só entra depois de o núcleo estar estável.
- **Pinyin**: usa marcas de tom. Sílabas de tom neutro aparecem sem marca, como `de`, `le`, `ma`, `ne` e `guo`.
- **Sandhi**: em alguns exemplos, o pinyin registra a realização oral comum, como **bú shì**, **yí ge** e **yì bēi**. A grafia dos caracteres continua sendo 不 e 一. As mudanças de tom de 不, 一 e de dois terceiros tons devem ser aprendidas com escuta, não apenas por leitura.[16]
- **Tradução**: é brasileira e funcional. Não deve ser usada para reconstruir a ordem palavra por palavra.
- **Mapa**: cada célula pode ser visualizada em quatro estados: **orientação completa → recuperação lacunada → transferência mínima → independência sem mapa**.

### Matriz de progressão

| Faixa | Células | Resultado oral esperado |
|---|---|---|
| Núcleo iniciante | P01–P11 | perguntar, identificar, localizar, pedir, expressar desejo, capacidade e negação |
| Iniciante produtivo | P12–P18 | ordenar ações, falar de processo, experiência, resultado e direção |
| Ponte A2 | P19–P23 | comparar, escolher, justificar e condicionar ações |
| Intermediário inicial | P24–P30 | organizar resultado, grau, recorrência, sequência rápida, concessão e foco informacional |

---

## P01 — Pergunta com palavra interrogativa no lugar do slot

**Nível:** iniciante. **Operação:** descobrir uma informação sem alterar a ordem da frase.

**Intenção.** Perguntar o que, quem, onde, quando ou como, mantendo a palavra interrogativa na posição em que estaria a informação desconhecida.

**Padrão ou função.**

```text
[Sujeito] + [verbo] + [palavra interrogativa]?
[Sujeito] + [tempo] + [verbo] + [onde/como]?
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你想吃什么？ | Nǐ xiǎng chī shénme? | O que você quer comer? |
| 谁在外面？ | Shéi zài wàimiàn? | Quem está lá fora? |
| 你什么时候来？ | Nǐ shénme shíhou lái? | Quando você vem? |
| 你怎么去公司？ | Nǐ zěnme qù gōngsī? | Como você vai para o trabalho? |

**Slots substituíveis.** `[Sujeito]`: 我, 你, 他, 我们; `[verbo/ação]`: 吃, 喝, 买, 去, 学; `[interrogativo]`: 什么 shénme, 谁 shéi, 哪儿 nǎr/哪里 nǎlǐ, 什么时候 shénme shíhou, 怎么 zěnme; `[objeto/lugar]`: 茶, 中文, 公司, 家.

**Extensões.** Acrescentar tempo e lugar: `明天你想去哪儿？Míngtiān nǐ xiǎng qù nǎr?` — Para onde você quer ir amanhã? Acrescentar medida ou classificação: `你要哪一杯？Nǐ yào nǎ yì bēi?` — Qual xícara/copo você quer? Em fala, **谁** é normalmente realizado como **shéi**; pratique essa forma antes de alternar com variantes regionais.

**Observação pedagógica.** O brasileiro tende a mover “o quê”, “onde” e “como” para o início por influência do português. Treine com substituição: primeiro produza uma afirmação, depois troque apenas o slot desconhecido pelo interrogativo. Não ensine a pergunta como uma frase indivisível.

**Potencial de mapa.** Centro: **descobrir informação**. Primeiro anel: ordem S–tempo–lugar–V–O. Segundo anel: cinco interrogativos como slots. Contraste: não deslocar o interrogativo para a frente. Recuperação: apagar o interrogativo e o verbo. Transferência: perguntar sobre três objetos reais.

**Prompt de recuperação.** “Você quer beber o quê?” Produza a pergunta em mandarim antes de olhar qualquer resposta.

**Prompt de transferência.** Em um ambiente novo, pergunte onde está uma pessoa, quando ela chega e como vai até lá, usando três combinações diferentes.

**Critério de domínio.** Produzir cinco perguntas novas em até três segundos após cada intenção, sem traduzir a frase inteira e sem deslocar o interrogativo para a posição inicial; usar pelo menos três interrogativos em duas situações não ensaiadas.

---

## P02 — Pergunta neutra com 吗 e resposta pelo predicado

**Nível:** iniciante. **Operação:** verificar ou confirmar uma informação.

**Intenção.** Transformar uma afirmação em pergunta de sim/não e responder repetindo o verbo ou predicado relevante, em vez de depender de um “sim” ou “não” fixo. A partícula 吗 é colocada no final de uma afirmação.[5]

**Padrão ou função.**

```text
[Afirmação] + 吗？
Resposta afirmativa: [verbo/predicado].
Resposta negativa: 不/没 + [verbo/predicado].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你喜欢咖啡吗？ | Nǐ xǐhuan kāfēi ma? | Você gosta de café? |
| 你会说中文吗？ | Nǐ huì shuō Zhōngwén ma? | Você fala chinês? |
| 你明天来吗？ | Nǐ míngtiān lái ma? | Você vem amanhã? |
| 喜欢。/ 不喜欢。 | Xǐhuan. / Bù xǐhuan. | Gosto. / Não gosto. |

**Slots substituíveis.** `[sujeito]`: 你, 他, 你们; `[predicado]`: 是学生, 喜欢茶, 会游泳, 明天来, 在家; `[resposta]`: repita o verbo, use `不` para hábito/intenção ou `没` para algo que não ocorreu.

**Extensões.** Use `对 duì` ou `嗯 ǹg` em confirmação informal, mas ensine primeiro a resposta pelo verbo: `会。Huì.` — Sei/sim, falo. Para confirmar uma frase negativa, repita o verbo de modo explícito, pois **对** pode confirmar a negação e confundir o iniciante.

**Observação pedagógica.** Não apresente “sim = 是” e “não = 不是” como regra geral. Em mandarim, a resposta clara normalmente retoma o verbo da pergunta: `喜欢` ou `不喜欢`, `来` ou `不来`, `有` ou `没有`. Não acrescente 吗 a perguntas que já contêm 什么, 谁, 哪儿 ou um padrão A-not-A.

**Potencial de mapa.** Centro: **confirmar**. Primeiro anel: afirmação → 吗. Segundo anel: resposta positiva/negativa pelo mesmo predicado. Contraste: verbo da pergunta versus 是/不是. Transferência: confirmar preferências e planos de outra pessoa.

**Prompt de recuperação.** “Você fala inglês?” Produza a pergunta e duas respostas curtas, uma afirmativa e uma negativa.

**Prompt de transferência.** Observe três fatos sobre a situação ao redor e transforme cada fato em uma pergunta de confirmação; responda usando o predicado, não apenas “sim/não”.

**Critério de domínio.** Formar seis perguntas com 吗 e responder cada uma com o verbo adequado, sem inserir 吗 em pergunta interrogativa de outro tipo; acertar a polaridade em pelo menos cinco respostas.

---

## P03 — Pergunta afirmativa-negativa A-not-A

**Nível:** iniciante. **Operação:** pedir uma decisão ou confirmação binária de modo direto.

**Intenção.** Perguntar “faz ou não faz?”, “tem ou não tem?” ou “pode ou não pode?” oferecendo as duas alternativas na própria pergunta. É um formato frequente na fala.[6]

**Padrão ou função.**

```text
[V] + 不 + [V] + [objeto]?
有 + 没有 + [objeto]?
[modal] + 不 + [modal] + [verbo]?
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你是不是学生？ | Nǐ shì bu shì xuéshēng? | Você é estudante? |
| 你有没有时间？ | Nǐ yǒu méi yǒu shíjiān? | Você tem tempo? |
| 你能不能再说一遍？ | Nǐ néng bu néng zài shuō yí biàn? | Você pode repetir? |
| 你要不要喝茶？ | Nǐ yào bu yào hē chá? | Você quer tomar chá? |

**Slots substituíveis.** `[verbo]`: 是, 来, 去, 喜欢, 想, 要; `[modal]`: 能, 可以; `[objeto/ação]`: 茶, 中文, 这个, 再说一遍. Para verbos de dois caracteres, é natural inserir 不 depois do primeiro caractere: `喜不喜欢 xǐ bu xǐhuan?` — gosta ou não gosta?

**Extensões.** Use `有没有` com posse e experiência: `你有没有去过北京？Nǐ yǒu méiyǒu qù guo Běijīng?` — Você já foi a Pequim? Use `好不好 hǎo bu hǎo?` como pedido de confirmação ou proposta: “pode ser?”.

**Observação pedagógica.** Não coloque 吗 no final: `你能不能来吗？` é uma combinação inadequada para este objetivo. Em `有`, a negação é **没有**, não **不有**. Marque o elemento repetido como fixo e troque apenas o slot, para o aluno não decorar quatro frases isoladas.

**Potencial de mapa.** Centro: **forçar uma escolha binária**. Primeiro anel: V–不–V ou 有–没有. Segundo anel: verbos, modais e objetos. Contraste: A-not-A ≠ pergunta com 吗. Transferência: obter uma decisão real sobre horário, bebida ou repetição.

**Prompt de recuperação.** “Você tem tempo ou não?” Produza `有没有` antes de consultar.

**Prompt de transferência.** Faça três perguntas A-not-A para organizar uma tarefa: se a pessoa pode ir, se quer café e se já viu determinado lugar.

**Critério de domínio.** Produzir quatro formatos A-not-A, incluindo `有没有` e um modal, sem acrescentar 吗; responder cada um com a forma positiva ou negativa correspondente.

---

## P04 — 是 para identificação e 在 para localização

**Nível:** iniciante. **Operação:** identificar o que algo é ou dizer onde algo/alguém está.

**Intenção.** Separar duas funções que o português frequentemente cobre com “ser/estar”: **是 shì** identifica ou classifica; **在 zài** localiza. Em uma frase simples de localização, 在 é o verbo necessário, sem inserir 是.[7]

**Padrão ou função.**

```text
[coisa/pessoa] + 是 + [identidade/classificação].
[coisa/pessoa] + 在 + [lugar].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 这是我的手机。 | Zhè shì wǒ de shǒujī. | Este é o meu celular. |
| 他是老师。 | Tā shì lǎoshī. | Ele é professor. |
| 手机在包里。 | Shǒujī zài bāo lǐ. | O celular está na bolsa. |
| 我不在家。 | Wǒ bú zài jiā. | Eu não estou em casa. |

**Slots substituíveis.** `[identidade]`: 学生, 老师, 我的朋友; `[lugar]`: 家, 公司, 包里, 这里, 那里; `[sujeito]`: 我, 你, 他, 书, 洗手间.

**Extensões.** Pergunte `这是什么？Zhè shì shénme?` — O que é isto? e `手机在哪里？Shǒujī zài nǎlǐ?` — Onde está o celular? Acrescente tempo a localização: `你现在在哪儿？Nǐ xiànzài zài nǎr?` — Onde você está agora?

**Observação pedagógica.** O erro-alvo é traduzir “está” por 是: `我是在家` não é o molde básico para “estou em casa”. Em contraste, `我在家学习` usa 在 como locativo antes da ação: “estudo em casa”. Não sobrecarregue o iniciante com exceções; trabalhe primeiro identificação versus localização.

**Potencial de mapa.** Centro: **identificar ou localizar**. Primeiro anel: 是 / 在. Segundo anel: identidade e lugar. Contraste vermelho: `是 ≠ 在`. Transferência: alternar entre apontar um objeto e dizer onde ele está.

**Prompt de recuperação.** “O livro está na mesa” e “o livro é meu”: produza as duas frases sem consultar.

**Prompt de transferência.** Escolha três objetos próximos e, para cada um, diga o que é ou onde está; alterne deliberadamente as duas funções.

**Critério de domínio.** Produzir seis frases, três com 是 e três com 在, sem trocar os verbos e sem inserir um segundo verbo em `sujeito + 在 + lugar`.

---

## P05 — 有 para posse e existência; 没有 para negação

**Nível:** iniciante. **Operação:** dizer que tem, não tem ou que existe algo em determinado lugar.

**Intenção.** Expressar posse e existência. O padrão existencial coloca o lugar antes de 有, como em “neste lugar há...”.[1] [8]

**Padrão ou função.**

```text
[Sujeito] + 有 + [objeto/quantidade].
[ lugar ] + 有 + [objeto/quantidade].
[ sujeito/lugar ] + 没有 + [objeto].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我有一个问题。 | Wǒ yǒu yí ge wèntí. | Tenho uma pergunta. |
| 这里有咖啡。 | Zhèlǐ yǒu kāfēi. | Tem café aqui. |
| 桌子上有一本书。 | Zhuōzi shàng yǒu yì běn shū. | Há um livro sobre a mesa. |
| 我没有时间。 | Wǒ méiyǒu shíjiān. | Não tenho tempo. |

**Slots substituíveis.** `[sujeito]`: 我, 你, 公司; `[lugar]`: 这里, 房间里, 包里, 学校; `[objeto]`: 水, 钱, 手机, 人; `[quantidade]`: 一个, 两本, 很多.

**Extensões.** Pergunte `这里有没有洗手间？Zhèlǐ yǒu méiyǒu xǐshǒujiān?` — Tem banheiro aqui? Conecte posse e localização: `我的手机里有你的号码。Wǒ de shǒujī lǐ yǒu nǐ de hàomǎ.` — Tenho seu número no meu celular.

**Observação pedagógica.** Não ensine `不有`. Para negar posse ou existência, use **没有**. Diferencie `房间里有人` — há alguém no quarto — de `人在房间里` — a pessoa está no quarto; a primeira apresenta algo novo, a segunda localiza algo já identificado.

**Potencial de mapa.** Centro: **ter/encontrar algo**. Primeiro anel: posse versus existência. Segundo anel: pessoa/lugar, objeto, quantidade. Contraste: 有/没有 versus 在. Transferência: inventário oral de um ambiente real.

**Prompt de recuperação.** “Tem água na bolsa?” Produza a pergunta usando `有没有`.

**Prompt de transferência.** Olhe ao redor e produza três frases de existência com lugares diferentes; depois negue uma delas com `没有`.

**Critério de domínio.** Produzir duas frases de posse, duas de existência e duas negativas, mantendo `有` no lugar correto e sem usar `是` para “há”.

---

## P06 — Ordem S–tempo–lugar–verbo–objeto

**Nível:** iniciante. **Operação:** acrescentar quando e onde a ação acontece.

**Intenção.** Produzir frases curtas com informação de tempo e lugar sem copiar a ordem do português. Em um molde básico, tempo costuma vir depois do sujeito ou antes dele, e o lugar vem antes do verbo de ação.[2]

**Padrão ou função.**

```text
[Sujeito] + [tempo] + [在 + lugar] + [verbo] + [objeto].
[tempo] + [sujeito] + [在 + lugar] + [verbo] + [objeto].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我今天在家学习。 | Wǒ jīntiān zài jiā xuéxí. | Hoje estudo em casa. |
| 明天上午我在公司工作。 | Míngtiān shàngwǔ wǒ zài gōngsī gōngzuò. | Amanhã de manhã trabalho na empresa. |
| 她晚上在家吃饭。 | Tā wǎnshang zài jiā chīfàn. | Ela janta em casa à noite. |
| 我们星期六在北京看电影。 | Wǒmen xīngqīliù zài Běijīng kàn diànyǐng. | No sábado vemos um filme em Pequim. |

**Slots substituíveis.** `[tempo]`: 今天, 明天, 现在, 晚上, 星期六; `[lugar]`: 家, 公司, 北京, 学校; `[ação]`: 学习, 工作, 吃饭, 看电影.

**Extensões.** Adicione instrumento antes do verbo: `我今天在家用手机学习。Wǒ jīntiān zài jiā yòng shǒujī xuéxí.` — Hoje estudo em casa usando o celular. Use pergunta no slot: `你什么时候在家学习？Nǐ shénme shíhou zài jiā xuéxí?` — Quando você estuda em casa?

**Observação pedagógica.** Não trate a ordem como uma fórmula rígida para toda frase. Ela é um **molde de fala inicial**. A célula deve contrastar `我在家学习` — estudo em casa — com `我在家` — estou em casa. O primeiro 在 introduz o lugar da ação; o segundo é o verbo de localização.

**Potencial de mapa.** Centro: **situar uma ação**. Primeiro anel: sujeito → tempo → lugar → ação. Segundo anel: slots de tempo, lugar e verbo. Contraste: lugar antes do verbo. Transferência: narrar a rotina de um dia.

**Prompt de recuperação.** “Amanhã à tarde, eu estudo no café.” Produza a frase com a ordem mandarim.

**Prompt de transferência.** Descreva três ações reais de hoje em horários e lugares diferentes; não reutilize o mesmo verbo duas vezes.

**Critério de domínio.** Produzir cinco frases S–tempo–lugar–V–O e uma pergunta, sem colocar o lugar depois do verbo quando ele modifica a ação.

---

## P07 — 的 para posse e relação entre nomes

**Nível:** iniciante. **Operação:** especificar de quem é algo ou qual nome modifica outro.

**Intenção.** Construir sintagmas como “meu celular”, “o inverno de Pequim” e “a professora da empresa”. A relação vem antes do nome principal, ligada por 的 quando necessário.[1]

**Padrão ou função.**

```text
[possuidor/descritor] + 的 + [nome principal].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 这是我的书。 | Zhè shì wǒ de shū. | Este é o meu livro. |
| 我朋友的手机。 | Wǒ péngyou de shǒujī. | O celular do meu amigo. |
| 北京的冬天很冷。 | Běijīng de dōngtiān hěn lěng. | O inverno de Pequim é frio. |
| 这是公司的地址。 | Zhè shì gōngsī de dìzhǐ. | Este é o endereço da empresa. |

**Slots substituíveis.** `[possuidor]`: 我, 你, 他, 我朋友, 公司; `[nome]`: 书, 手机, 地址, 冬天, 老师. Para relações muito próximas, algumas expressões podem omitir 的, mas isso não é o foco inicial.

**Extensões.** Combine demonstrativo, número e medida: `这三个学生的书 Zhè sān ge xuéshēng de shū` — os livros destes três estudantes. Use o sintagma dentro de pergunta: `这是谁的包？Zhè shì shéi de bāo?` — De quem é esta bolsa?

**Observação pedagógica.** O padrão não é o possessivo português invertido: não produza “livro meu” como regra. Faça o aluno escolher primeiro o dono, depois o objeto. A função de 的 aqui é relacional; não se deve transformar cada ocorrência em uma tradução fixa “de”.

**Potencial de mapa.** Centro: **relacionar dois nomes**. Primeiro anel: possuidor/descritor → 的 → nome. Segundo anel: pessoas, instituições e objetos. Contraste: ordem antes do nome. Transferência: identificar objetos reais e seus donos.

**Prompt de recuperação.** “O celular da minha amiga” — monte o sintagma oralmente, sem olhar.

**Prompt de transferência.** Produza quatro relações novas a partir do ambiente: dono + objeto, lugar + estação, empresa + endereço e pessoa + bolsa.

**Critério de domínio.** Produzir cinco sintagmas e inseri-los em frases completas, mantendo o modificador antes do nome e usando pelo menos três possuidores diferentes.

---

## P08 — 想, 要 e 想要 para vontade, intenção e item desejado

**Nível:** iniciante. **Operação:** dizer o que quer fazer ou obter.

**Intenção.** Expressar intenção ou desejo com `想 + ação`, desejo de um item com `要 + item` e uma formulação explícita de “querer algo” com `想要 + item`.

**Padrão ou função.**

```text
我想 + [verbo/ação].
我要 + [objeto/decisão].
我想要 + [quantidade/objeto].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我想喝茶。 | Wǒ xiǎng hē chá. | Quero tomar chá. |
| 我要这个。 | Wǒ yào zhège. | Quero este aqui. |
| 我想要一杯咖啡。 | Wǒ xiǎng yào yì bēi kāfēi. | Quero um café. |
| 我不想出去。 | Wǒ bù xiǎng chūqù. | Não quero sair. |

**Slots substituíveis.** `[ação]`: 喝茶, 吃饭, 学中文, 回家; `[objeto]`: 这个, 水, 一杯咖啡, 菜单; `[negação]`: 不想 para vontade negada, 不要 para recusa ou item não desejado.

**Extensões.** Pergunte `你想吃什么？Nǐ xiǎng chī shénme?` — O que você quer comer? Faça uma proposta com `我们想...` ou suavize com `我想...` em contexto de pedido. `想要` pode ser substituído por `要` em pedidos diretos, mas o registro e a força pragmática mudam.

**Observação pedagógica.** Não iguale automaticamente 想 a “pensar”. Neste bloco, 想 introduz vontade ou intenção. A oposição útil para fala é **想 + ação** versus **要 + item/decisão**. Não ensine a distinção como absoluta: há sobreposição, e o contexto decide.

**Potencial de mapa.** Centro: **expressar vontade**. Primeiro anel: 想 + ação / 要 + objeto. Segundo anel: bebida, comida, movimento, estudo. Contraste: 不想 ≠ 不要. Transferência: fazer pedidos e declarar planos.

**Prompt de recuperação.** “Quero estudar chinês, mas não quero sair.” Produza as duas partes antes de consultar.

**Prompt de transferência.** Em um café ou loja imaginária, produza cinco escolhas: duas ações desejadas, dois itens desejados e uma recusa.

**Critério de domínio.** Produzir seis frases novas, distinguindo `不想` e `不要`, e responder a uma pergunta com `想什么` ou `要什么` sem traduzir palavra por palavra.

---

## P09 — Pedido com 请给我 e 给 + destinatário

**Nível:** iniciante. **Operação:** pedir um item ou uma ação de outra pessoa.

**Intenção.** Fazer um pedido oral curto, claro e socialmente utilizável, com `请` para cortesia e `给` para marcar o destinatário ou o item solicitado.

**Padrão ou função.**

```text
请给我 + [objeto/quantidade].
[Pessoa] + 给 + [destinatário] + [verbo] + [objeto].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 请给我一杯水。 | Qǐng gěi wǒ yì bēi shuǐ. | Por favor, me dê um copo de água. |
| 可以给我菜单吗？ | Kěyǐ gěi wǒ càidān ma? | Você pode me trazer o cardápio? |
| 给我看一下。 | Gěi wǒ kàn yíxià. | Deixa eu dar uma olhada. |
| 请给他打电话。 | Qǐng gěi tā dǎ diànhuà. | Por favor, ligue para ele. |

**Slots substituíveis.** `[destinatário]`: 我, 你, 他, 老师; `[objeto]`: 水, 茶, 菜单, 书; `[ação]`: 看一下, 打电话, 发消息; `[quantidade]`: 一杯, 一张, 两个.

**Extensões.** Acrescente `可以吗？kěyǐ ma?` para pedir permissão ou confirmar: `请给我一杯茶，可以吗？Qǐng gěi wǒ yì bēi chá, kěyǐ ma?` — Pode me dar um chá? Em registro mais direto, `给我这个` é funcional, mas `请` ajuda o iniciante a perceber a relação social.

**Observação pedagógica.** O padrão `给我 + objeto` não é uma tradução automática de todo “para mim”. Aqui, 给 pode funcionar como “dar a alguém” ou introduzir a pessoa beneficiária de uma ação. O teste deve usar pedidos reais, não frases sem ação como listas de vocabulário.

**Potencial de mapa.** Centro: **obter algo/fazer alguém agir**. Primeiro anel: 请 + 给 + destinatário. Segundo anel: objeto, medida, ação. Contraste: destinatário antes do objeto. Transferência: pedir três coisas em ambientes diferentes.

**Prompt de recuperação.** “Por favor, me dê uma xícara de chá.” Produza a frase sem consultar.

**Prompt de transferência.** Faça três pedidos: um item, uma ação em favor de outra pessoa e uma solicitação de permissão.

**Critério de domínio.** Produzir cinco pedidos compreensíveis, com pelo menos duas medidas e dois destinatários; usar `请` ou uma formulação equivalente sem hesitação prolongada.

---

## P10 — 会, 能 e 可以 para habilidade, condição e permissão

**Nível:** iniciante avançado. **Operação:** dizer se alguém sabe fazer, consegue fazer agora ou tem autorização.

**Intenção.** Escolher o modal conforme a situação: **会** tende a marcar habilidade aprendida; **能** capacidade ou condição concreta; **可以** permissão ou possibilidade autorizada. Há sobreposição, portanto o contraste é uma orientação de decisão, não uma tradução rígida.[9]

**Padrão ou função.**

```text
会 + [verbo]       = saber fazer/habilidade.
能 + [verbo]        = conseguir/ser possível na condição.
可以 + [verbo]      = poder/ter permissão.
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我会说一点中文。 | Wǒ huì shuō yìdiǎn Zhōngwén. | Sei falar um pouco de chinês. |
| 我今天不能来。 | Wǒ jīntiān bù néng lái. | Hoje não consigo ir. |
| 我可以坐这里吗？ | Wǒ kěyǐ zuò zhèlǐ ma? | Posso sentar aqui? |
| 你会不会游泳？ | Nǐ huì bu huì yóuyǒng? | Você sabe nadar? |

**Slots substituíveis.** `[verbo]`: 说中文, 游泳, 开车, 来, 参加, 坐这里; `[condição]`: 今天, 现在, 因为下雨; `[permissão]`: 坐这里, 进去, 拍照.

**Extensões.** Contraste em sequência: `我会开车，但是今天不能开。Wǒ huì kāichē, dànshì jīntiān bù néng kāi.` — Sei dirigir, mas hoje não posso/consigo dirigir. Para pedir autorização, `可以...吗？` é um molde seguro e frequente.

**Observação pedagógica.** Evite ensinar os três como três equivalentes de “poder”. Dê um cenário decisório: habilidade, condição e permissão. **不可以** recusa autorização; **不能** pode indicar impossibilidade ou proibição conforme o contexto.

**Potencial de mapa.** Centro: **avaliar possibilidade**. Primeiro anel: habilidade / condição / permissão. Segundo anel: ações. Contraste: 会–能–可以. Transferência: explicar por que consegue uma ação em um contexto, mas não em outro.

**Prompt de recuperação.** “Sei dirigir, mas hoje não posso dirigir.” Produza a oposição com dois modais.

**Prompt de transferência.** Responda a três cenários: uma habilidade aprendida, uma impossibilidade temporária e um pedido de permissão.

**Critério de domínio.** Escolher o modal adequado em seis cenários orais, produzir afirmação e negação e formular uma pergunta de permissão sem confundir `会` com `可以`.

---

## P11 — 不 e 没(有) para negação

**Nível:** iniciante. **Operação:** negar hábito, intenção, estado, posse ou ocorrência.

**Intenção.** Escolher entre **不** para negação não ligada a uma ocorrência concluída — hábito, preferência, futuro, decisão — e **没/没有** para algo que não ocorreu ou para ausência/posse negativa. A escolha é funcional e dependente do predicado.[1]

**Padrão ou função.**

```text
不 + [verbo/adjetivo/modal] = não faço/não quero/não sou.
没 + [verbo] = não fiz/não aconteceu.
没有 + [objeto] = não tenho/não há.
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我不喝咖啡。 | Wǒ bù hē kāfēi. | Não tomo café. |
| 我没喝咖啡。 | Wǒ méi hē kāfēi. | Não tomei café. |
| 我没有时间。 | Wǒ méiyǒu shíjiān. | Não tenho tempo. |
| 我还没吃饭。 | Wǒ hái méi chīfàn. | Ainda não comi. |

**Slots substituíveis.** `[verbo/estado]`: 喝咖啡, 想出去, 是学生, 会游泳; `[ocorrência]`: 吃饭, 去北京, 看电影; `[objeto ausente]`: 钱, 时间, 手机.

**Extensões.** Use `还没 hái méi` para “ainda não”: `我还没准备好。Wǒ hái méi zhǔnbèi hǎo.` — Ainda não estou pronto. Combine `不` com futuro/intenção: `明天我不去。Míngtiān wǒ bú qù.` — Amanhã não vou.

**Observação pedagógica.** Ensine por contraste temporal e aspectual, não por equivalência “não = 不”. A mudança de tom de 不 antes de uma sílaba de quarto tom aparece em `bú shì`, `bú yào`, `bú qù`; não peça ao aluno para memorizar listas sem escuta.[16]

**Potencial de mapa.** Centro: **negar corretamente**. Primeiro anel: hábito/intenção/estado versus ocorrência/posse. Segundo anel: 不, 没, 没有, 还没. Contraste: `我不吃` ≠ `我没吃`. Transferência: corrigir interpretações erradas.

**Prompt de recuperação.** “Eu não bebo café” e “eu não bebi café”: produza as duas frases.

**Prompt de transferência.** Diga três coisas que você não faz habitualmente, duas que ainda não fez hoje e uma coisa que não tem.

**Critério de domínio.** Classificar e produzir oito negações, acertando a oposição habitual/ocorrida/posse em pelo menos sete; realizar o sandhi de 不 funcionalmente em três expressões.

---

## P12 — 先……再…… para ordenar duas ações

**Nível:** iniciante produtivo. **Operação:** dizer o que vem primeiro e o que vem depois.

**Intenção.** Organizar uma sequência prática sem construir uma explicação longa.

**Padrão ou função.**

```text
先 + [ação 1]，再 + [ação 2]。
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我先吃饭，再工作。 | Wǒ xiān chīfàn, zài gōngzuò. | Primeiro como, depois trabalho. |
| 先听，再回答。 | Xiān tīng, zài huídá. | Primeiro escute, depois responda. |
| 你先休息一下，再走吧。 | Nǐ xiān xiūxi yíxià, zài zǒu ba. | Descansa um pouco e depois vai. |
| 我们先买票，再进去。 | Wǒmen xiān mǎi piào, zài jìnqù. | Primeiro compramos os ingressos, depois entramos. |

**Slots substituíveis.** `[ação 1]`: 吃饭, 买票, 洗手, 听; `[ação 2]`: 工作, 进去, 回答, 出门. `一下 yíxià` funciona como extensão breve para uma ação rápida ou suavizada.

**Extensões.** Encadeie três ações somente depois de dominar duas: `先吃饭，再学习，最后休息。Xiān chīfàn, zài xuéxí, zuìhòu xiūxi.` — Primeiro comer, depois estudar e por fim descansar. Acrescente `吧` para sugestão; a partícula suaviza a proposta em fala.[17]

**Observação pedagógica.** O valor está na ordenação oral, não na explicação gramatical. Use cartões ou prompts embaralhados: o aluno precisa reconstruir a sequência. Não apresente `先` e `再` como vocabulário sem duas ações concretas.

**Potencial de mapa.** Centro: **organizar sequência**. Primeiro anel: primeiro → depois. Segundo anel: ações substituíveis. Margem: `吧` como sugestão. Consolidação: conectar pedido, deslocamento e refeição.

**Prompt de recuperação.** “Primeiro compre a passagem, depois entre.” Produza a instrução.

**Prompt de transferência.** Explique oralmente sua rotina para preparar uma bebida usando duas ou três ações novas.

**Critério de domínio.** Produzir quatro sequências com verbos diferentes, mantendo a ordem e sem inserir o segundo verbo antes de 再; usar uma sequência para orientar outra pessoa.

---

## P13 — 在/正在 + verbo para ação em andamento

**Nível:** iniciante produtivo. **Operação:** dizer o que está acontecendo agora.

**Intenção.** Destacar uma ação em progresso. `在 + verbo` é frequente e conversacional; `正在 + verbo` torna o andamento mais explícito. `呢` pode sinalizar estado em curso ou manter o tom interacional.

**Padrão ou função.**

```text
[Sujeito] + 在/正在 + [verbo] + [objeto] (+ 呢)。
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我在看书。 | Wǒ zài kàn shū. | Estou lendo. |
| 他正在开会呢。 | Tā zhèngzài kāihuì ne. | Ele está em reunião. |
| 你在做什么呢？ | Nǐ zài zuò shénme ne? | O que você está fazendo? |
| 我们在吃饭。 | Wǒmen zài chīfàn. | Estamos comendo. |

**Slots substituíveis.** `[sujeito]`: 我, 你, 他, 他们; `[verbo]`: 看书, 开会, 吃饭, 学中文, 等朋友; `[objeto]`: 书, 中文, 饭, 人.

**Extensões.** Pergunte `你现在在做什么？Nǐ xiànzài zài zuò shénme?` — O que você está fazendo agora? Combine com lugar: `我正在家里学习。Wǒ zhèngzài jiā lǐ xuéxí.` — Estou estudando em casa.

**Observação pedagógica.** Há duas funções de 在 que precisam ser separadas: `我在北京` — estou em Pequim — e `我在看书` — estou lendo. Não trate `正在` como “tempo verbal obrigatório”. Para o iniciante, ensine uma pergunta concreta e uma resposta observável.

**Potencial de mapa.** Centro: **descrever ação atual**. Primeiro anel: sujeito + 在/正在 + verbo. Segundo anel: ações e objetos. Contraste: 在 locativo versus 在 progressivo. Transferência: relatar o que pessoas reais estão fazendo.

**Prompt de recuperação.** “Estou estudando chinês agora.” Produza a frase com 在 ou 正在.

**Prompt de transferência.** Imagine uma chamada de vídeo e descreva quatro ações que estão acontecendo, incluindo uma pergunta a outra pessoa.

**Critério de domínio.** Produzir cinco descrições em andamento e uma pergunta com `在做什么`, sem usar 在 como tradução automática de “estar” em frases de localização simples.

---

## P14 — 了 para ação concluída e mudança de situação

**Nível:** iniciante avançado. **Operação:** informar que um evento se completou ou que a situação mudou.

**Intenção.** Falar de uma ação concluída com `V + 了` ou anunciar uma mudança de estado com partícula final `了`. Mandarim não organiza o passado por conjugação; tempo e aspecto trabalham juntos.[1] [11]

**Padrão ou função.**

```text
[Sujeito] + [verbo] + 了 + [objeto].
[Nova situação] + 了。
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我买了票。 | Wǒ mǎi le piào. | Comprei a passagem. |
| 他回家了。 | Tā huí jiā le. | Ele voltou para casa. |
| 下雨了。 | Xiàyǔ le. | Começou a chover. |
| 电影开始了。 | Diànyǐng kāishǐ le. | O filme começou. |

**Slots substituíveis.** `[verbo]`: 买, 吃, 看, 回, 开始; `[objeto]`: 票, 饭, 电影; `[nova situação]`: 下雨, 天冷, 电影开始, 我二十岁.

**Extensões.** Use `已经 yǐjīng` para reforçar “já”: `我已经吃了。Wǒ yǐjīng chī le.` — Já comi. Pergunte `你吃饭了吗？Nǐ chīfàn le ma?` — Você já comeu? Diferencie `我吃了` — comi/já comi — de `我吃饭了` — passei a comer ou vou comer, dependendo do contexto e da prosódia.

**Observação pedagógica.** Não traduza 了 automaticamente como “passado”. Uma ação pode ser passada sem 了, e 了 também marca mudança de situação. Ensine com contexto antes/depois: algo ainda não ocorreu, ocorre e então a situação mudou.

**Potencial de mapa.** Centro: **atualizar o estado da situação**. Primeiro anel: ação concluída / nova situação. Segundo anel: verbos e eventos. Contraste: 了 não é conjugação de passado. Transferência: relatar o que mudou durante um dia.

**Prompt de recuperação.** “Já comprei a passagem” e “começou a chover”: produza duas frases com funções diferentes de 了.

**Prompt de transferência.** Conte três atualizações de uma situação imaginária: o que terminou, o que começou e o que mudou.

**Critério de domínio.** Produzir quatro frases com 了 e explicar oralmente, por contexto, se cada uma indica conclusão ou mudança; não usar 了 como marcador mecânico de todo passado.

---

## P15 — 过 para experiência anterior

**Nível:** A2. **Operação:** dizer se já teve uma experiência, sem fixar o momento.

**Intenção.** Perguntar ou afirmar que alguém já fez algo alguma vez. `过` marca experiência anterior; a negação usa `没`, não `不`.[12]

**Padrão ou função.**

```text
[Sujeito] + [verbo] + 过 + [objeto].
[Sujeito] + 没 + [verbo] + 过 + [objeto].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你去过上海吗？ | Nǐ qù guo Shànghǎi ma? | Você já foi a Xangai? |
| 我吃过中国菜。 | Wǒ chī guo Zhōngguó cài. | Já comi comida chinesa. |
| 我没坐过飞机。 | Wǒ méi zuò guo fēijī. | Nunca viajei de avião. |
| 你有没有学过中文？ | Nǐ yǒu méiyǒu xué guo Zhōngwén? | Você já estudou chinês? |

**Slots substituíveis.** `[verbo]`: 去, 吃, 看, 学, 坐; `[objeto/lugar]`: 北京, 日本菜, 这部电影, 中文, 飞机; `[negação]`: 没, 从来没 — nunca.

**Extensões.** Acrescente `一次 yí cì` ou `两次 liǎng cì` para o número de experiências: `我去过两次。Wǒ qù guo liǎng cì.` — Já fui duas vezes. Se o tempo específico for central, troque a pergunta por uma frase com tempo e não force 过.

**Observação pedagógica.** O contraste principal é **experiência em algum momento** versus **evento concluído em contexto definido**: `我去过北京` — já fui a Pequim — e `我去年去了北京` — fui a Pequim no ano passado. Não faça o aluno associar 过 simplesmente a “já” em toda frase.

**Potencial de mapa.** Centro: **checar repertório de experiências**. Primeiro anel: V–过–O. Segundo anel: locais, alimentos, estudos e viagens. Contraste: 过 versus 了. Transferência: entrevista oral de experiências.

**Prompt de recuperação.** “Você já comeu comida japonesa?” Produza a pergunta e duas respostas.

**Prompt de transferência.** Faça uma mini-enquete oral com quatro experiências suas e pergunte a outra pessoa sobre duas delas.

**Critério de domínio.** Produzir cinco frases com 过, duas negativas com 没 e uma pergunta `有没有…过`; manter o sentido de experiência sem acrescentar um tempo específico incompatível.

---

## P16 — Complemento resultativo: V + 懂/完/好/清楚

**Nível:** A2. **Operação:** dizer qual resultado uma ação alcançou.

**Intenção.** Tornar explícito se ouvir levou a entender, se uma tarefa terminou, se algo ficou pronto ou se uma percepção ficou clara. Complementos resultativos aparecem imediatamente depois do verbo.[10]

**Padrão ou função.**

```text
[Sujeito] + [verbo] + [resultado] + 了/吗。
[Sujeito] + 没 + [verbo] + [resultado].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我听懂了。 | Wǒ tīng dǒng le. | Entendi o que ouvi. |
| 你看懂了吗？ | Nǐ kàn dǒng le ma? | Você entendeu o que leu/viu? |
| 我做完了。 | Wǒ zuò wán le. | Terminei. |
| 我没听清楚。 | Wǒ méi tīng qīngchu. | Não ouvi com clareza. |

**Slots substituíveis.** `[verbo]`: 听, 看, 做, 写, 吃; `[resultado]`: 懂, 完, 好, 清楚, 饱; `[objeto]`: 这句话, 作业, 饭, 名字.

**Extensões.** Pergunte `你准备好了吗？Nǐ zhǔnbèi hǎo le ma?` — Você está pronto? Use a negação com 没: `我还没做好。Wǒ hái méi zuò hǎo.` — Ainda não deixei pronto. Em reparo comunicativo, `没听清楚` é mais específico que `没听懂`: não ouvir claramente não é necessariamente não compreender.

**Observação pedagógica.** Não trate 懂, 完 e 好 como simples advérbios traduzíveis. O aluno precisa escolher o **resultado** que a ação atingiu. A construção é particularmente produtiva para manutenção da conversa, mas só entra depois que o verbo-base estiver disponível.

**Potencial de mapa.** Centro: **avaliar resultado**. Primeiro anel: verbo → resultado. Segundo anel: entender, terminar, preparar, ouvir claramente. Contraste: ação sem resultado versus ação concluída com resultado. Transferência: relatar tarefas e reparar compreensão.

**Prompt de recuperação.** “Não ouvi claramente; pode repetir?” Produza a primeira parte com complemento resultativo.

**Prompt de transferência.** Descreva três tarefas: uma que terminou, uma que ainda não terminou e uma que você entendeu claramente.

**Critério de domínio.** Produzir seis combinações verbo–resultado, incluindo uma negativa com 没, e escolher corretamente entre 懂, 完, 好 e 清楚 em quatro cenários.

---

## P17 — Complemento potencial: V + 得/不 + resultado

**Nível:** A2–B1. **Operação:** dizer se uma ação é possível de alcançar em determinada condição.

**Intenção.** Expressar capacidade potencial: “consigo ouvir”, “não consigo terminar”, “dá para ver”. O complemento potencial insere 得 ou 不 entre verbo e complemento.[13]

**Padrão ou função.**

```text
[Sujeito] + [verbo] + 得 + [resultado]?
[Sujeito] + [verbo] + 不 + [resultado].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你听得懂吗？ | Nǐ tīng de dǒng ma? | Você consegue entender ouvindo? |
| 我看不清楚。 | Wǒ kàn bu qīngchu. | Não consigo enxergar com clareza. |
| 这本书我看得完。 | Zhè běn shū wǒ kàn de wán. | Consigo terminar este livro. |
| 这个包放不进去。 | Zhège bāo fàng bu jìnqù. | Não dá para colocar isso dentro da bolsa. |

**Slots substituíveis.** `[verbo]`: 听, 看, 做, 吃, 放, 找; `[resultado/direção]`: 懂, 清楚, 完, 饱, 进去, 到; `[condição]`: 太快, 太暗, 太多, 太小.

**Extensões.** Acrescente a condição antes: `声音太小，我听不见。Shēngyīn tài xiǎo, wǒ tīng bu jiàn.` — O som está baixo demais, não consigo ouvir. Em pergunta, `做得完吗？` avalia possibilidade; `做完了吗？` pergunta se o resultado já ocorreu.

**Observação pedagógica.** Contraste visualmente três células: `听懂` = entendi; `听得懂` = consigo entender; `听不懂` = não consigo entender. Não misture complemento potencial com modal 会 no primeiro contato: os dois podem traduzir “conseguir”, mas o potencial focaliza o resultado sob uma condição.

**Potencial de mapa.** Centro: **avaliar possibilidade de resultado**. Primeiro anel: V–得–resultado / V–不–resultado. Segundo anel: percepção, conclusão, direção. Contraste: resultativo versus potencial. Transferência: resolver limitações reais.

**Prompt de recuperação.** “A fala está rápida demais; não consigo entender.” Produza a frase sem olhar.

**Prompt de transferência.** Crie quatro cenários com condições diferentes e diga o que você consegue ou não consegue fazer.

**Critério de domínio.** Produzir três potenciais afirmativos e três negativos, sem confundir 得 com 的 e distinguindo `V懂` de `V得懂` em explicação oral curta.

---

## P18 — Complemento direcional: V + 来/去 e compostos direcionais

**Nível:** A2. **Operação:** indicar movimento em direção ao ponto de referência.

**Intenção.** Dizer se alguém vem em direção ao falante/ponto de referência ou vai para longe dele, além de combinar verbos com `进`, `出`, `上`, `下`, `回` e `过`.

**Padrão ou função.**

```text
[verbo de movimento] + 来/去.
[verbo] + 进/出/上/下/回/过 + 来/去.
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你过来。 | Nǐ guòlái. | Venha aqui. |
| 他回去了。 | Tā huíqù le. | Ele voltou para lá. |
| 请进来。 | Qǐng jìnlái. | Entre, por favor. |
| 把书拿过来。 | Bǎ shū ná guòlái. | Traga o livro para cá. |

**Slots substituíveis.** `[verbo]`: 过, 回, 进, 出, 拿, 带, 走; `[direção]`: 来, 去; `[referência]`: aqui, sala, andar, casa. O referente não precisa ser explicitado se estiver claro no espaço compartilhado.

**Extensões.** Combine com lugar: `他走进教室去了。Tā zǒu jìn jiàoshì qù le.` — Ele entrou na sala. Em instruções, use `请进来` e `拿出去` para pedidos concretos.

**Observação pedagógica.** A escolha de 来/去 depende do ponto de referência, não apenas de “vir/ir” em português. Mostre fisicamente o movimento ou use um mapa simples. A forma oral pode reduzir sílabas, mas o aluno deve manter o contraste direcional e não transformar todo complemento em preposição.

**Potencial de mapa.** Centro: **mover em relação a um ponto**. Primeiro anel: verbo + direção. Segundo anel: entrar, sair, voltar, trazer. Contraste: 来 em direção ao centro versus 去 para longe. Transferência: dar e seguir instruções.

**Prompt de recuperação.** “Traga o celular para cá.” Produza a ordem completa.

**Prompt de transferência.** Imagine uma pessoa em outro cômodo e dê quatro instruções, alternando movimentos para cá e para lá.

**Critério de domínio.** Produzir seis instruções direcionais, incluindo dois compostos, com 来/去 coerentes com o ponto de referência; executar oralmente a instrução dada por outra pessoa.

---

## P19 — 把 para colocar um objeto conhecido em foco

**Nível:** B1. **Operação:** destacar o que aconteceu com um objeto específico.

**Intenção.** Colocar um objeto conhecido antes do verbo quando a frase descreve uma manipulação, mudança de estado, localização ou resultado desse objeto. O molde central é sujeito + 把 + objeto + frase verbal.[14]

**Padrão ou função.**

```text
[Sujeito] + 把 + [objeto definido] + [verbo] + [resultado/localização/quantidade].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我把书放在桌子上了。 | Wǒ bǎ shū fàng zài zhuōzi shàng le. | Coloquei o livro sobre a mesa. |
| 请把门关上。 | Qǐng bǎ mén guān shàng. | Feche a porta, por favor. |
| 他把作业做完了。 | Tā bǎ zuòyè zuò wán le. | Ele terminou a lição. |
| 你把手机拿过来。 | Nǐ bǎ shǒujī ná guòlái. | Traga o celular para cá. |

**Slots substituíveis.** `[sujeito]`: 我, 你, 他, 我们; `[objeto conhecido]`: 书, 门, 作业, 手机, 房间; `[resultado/local]`: 放在桌子上, 关上, 做完, 拿过来, 洗干净.

**Extensões.** Negue antes de 把: `别把手机放这里。Bié bǎ shǒujī fàng zhèlǐ.` — Não coloque o celular aqui. Formule pergunta: `你把钥匙放哪儿了？Nǐ bǎ yàoshi fàng nǎr le?` — Onde você colocou a chave?

**Observação pedagógica.** 把 não é simplesmente “objeto antes do verbo”. O objeto tende a ser definido/conhecido e a frase precisa dizer o que foi feito com ele. Não force 把 com verbos psicológicos como 喜欢 ou 想. Como a estrutura é B1, introduza-a por tarefas de arrumação, localização e conclusão, não por explicação abstrata.

**Potencial de mapa.** Centro: **resolver o destino de um objeto**. Primeiro anel: sujeito → 把 → objeto conhecido → ação/resultado. Segundo anel: pôr, fechar, terminar, limpar, trazer. Contraste: SVO comum versus disposição do objeto. Transferência: instruções de organização.

**Prompt de recuperação.** “Coloque o livro na mesa.” Produza o pedido com 把.

**Prompt de transferência.** Descreva como você reorganiza três objetos em uma sala, usando um resultado ou lugar diferente para cada um.

**Critério de domínio.** Produzir quatro frases com 把, todas com objeto definido e resultado/localização explícitos; rejeitar conscientemente um exemplo em que o verbo não descreve efeito sobre o objeto.

---

## P20 — 比 para comparação direta

**Nível:** A2. **Operação:** dizer que A tem mais de uma qualidade que B.

**Intenção.** Comparar pessoas, lugares, objetos ou experiências com um molde curto e altamente recombinável. A estrutura básica é `N1 + 比 + N2 + adjetivo`.[15]

**Padrão ou função.**

```text
[N1] + 比 + [N2] + [adjetivo].
[N1] + 比 + [N2] + 更 + [adjetivo].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 中文比英语难。 | Zhōngwén bǐ Yīngyǔ nán. | Chinês é mais difícil que inglês. |
| 今天比昨天冷。 | Jīntiān bǐ zuótiān lěng. | Hoje está mais frio que ontem. |
| 地铁比公交车方便。 | Dìtiě bǐ gōngjiāochē fāngbiàn. | O metrô é mais prático que o ônibus. |
| 这个方法比那个更简单。 | Zhège fāngfǎ bǐ nàge gèng jiǎndān. | Este método é ainda mais simples que aquele. |

**Slots substituíveis.** `[N1/N2]`: 中文, 英语, 今天, 昨天, 地铁, 公交车; `[adjetivo]`: 难, 冷, 贵, 快, 方便, 简单.

**Extensões.** Para igualdade, use outro molde: `我跟你一样高。Wǒ gēn nǐ yíyàng gāo.` — Tenho a mesma altura que você. Para intensidade, `比……多了` significa “bem mais”: `这个快多了。Zhège kuài duō le.` — Este é muito mais rápido.

**Observação pedagógica.** Não coloque `很` antes do adjetivo no comparativo básico e não combine `比` com `一样`. O adjetivo é positivo: “A é mais alto que B”, não “A é não baixo que B”. Para brasileiros, o alvo é a posição de `比` entre os dois termos.

**Potencial de mapa.** Centro: **comparar dois polos**. Primeiro anel: N1–比–N2–qualidade. Segundo anel: adjetivo, 更, 多了. Contraste: 比 versus 跟……一样. Transferência: escolhas de transporte, estudo e preço.

**Prompt de recuperação.** “O metrô é mais rápido que o ônibus.” Produza a comparação.

**Prompt de transferência.** Compare três pares reais do seu dia, sem repetir o mesmo adjetivo; depois diga um caso de igualdade.

**Critério de domínio.** Produzir cinco comparações, incluindo uma com 更 e uma com 多了, sem usar 很 no lugar indevido e mantendo a ordem N1–比–N2–adjetivo.

---

## P21 — 还是 em pergunta de escolha; 或者 em alternativa declarada

**Nível:** A2. **Operação:** oferecer ou escolher entre opções.

**Intenção.** Perguntar “A ou B?” com `还是` e apresentar alternativas em uma afirmação com `或者`. O contraste é pragmático: pergunta de escolha versus alternativa já aberta.[18]

**Padrão ou função.**

```text
[pergunta] + A 还是 B？
[afirmação] + A 或者 B 都可以。
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你喝茶还是咖啡？ | Nǐ hē chá háishi kāfēi? | Você toma chá ou café? |
| 我们坐地铁还是坐公交车？ | Wǒmen zuò dìtiě háishi zuò gōngjiāochē? | Vamos de metrô ou ônibus? |
| 明天或者后天都可以。 | Míngtiān huòzhě hòutiān dōu kěyǐ. | Amanhã ou depois de amanhã, para mim tanto faz. |
| 你想吃米饭还是面条？ | Nǐ xiǎng chī mǐfàn háishi miàntiáo? | Você quer arroz ou macarrão? |

**Slots substituíveis.** `[ação]`: 喝, 吃, 坐, 去, 买; `[opção A/B]`: 茶/咖啡, 地铁/公交车, 明天/后天, 米饭/面条.

**Extensões.** Responda repetindo apenas a opção: `咖啡。Kāfēi.` — Café. Use `还是` também para uma decisão conjunta: `我们现在走还是等？Wǒmen xiànzài zǒu háishi děng?` — Vamos agora ou esperamos?

**Observação pedagógica.** Não traduza `还是` e `或者` pelo mesmo “ou” em todos os contextos. O aluno deve primeiro identificar se está perguntando para alguém escolher. Não use `吗` depois de uma pergunta com 还是.

**Potencial de mapa.** Centro: **organizar escolha**. Primeiro anel: ação + opção A 还是 opção B. Segundo anel: resposta, alternativa declarada com 或者. Contraste: pergunta versus declaração. Transferência: decisões de comida, horário e transporte.

**Prompt de recuperação.** “Você quer chá ou café?” Produza a pergunta e responda com uma opção.

**Prompt de transferência.** Faça três perguntas de escolha e uma frase em que qualquer uma das duas opções serve.

**Critério de domínio.** Formar quatro perguntas com 还是 e duas afirmações com 或者, sem usar 吗 após 还是 e respondendo com uma escolha coerente.

---

## P22 — 因为……所以…… para causa e consequência

**Nível:** A2. **Operação:** justificar uma decisão ou explicar um resultado.

**Intenção.** Ligar uma causa a uma consequência. Em fala, `所以` pode aparecer mesmo quando `因为` fica implícito, mas o par completo é útil para tornar a relação visível ao iniciante.

**Padrão ou função.**

```text
因为 + [causa]，所以 + [consequência].
[consequência]，因为 + [causa].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 因为下雨，所以我不去。 | Yīnwèi xiàyǔ, suǒyǐ wǒ bú qù. | Como está chovendo, não vou. |
| 因为我很忙，所以今天不能来。 | Yīnwèi wǒ hěn máng, suǒyǐ jīntiān bù néng lái. | Como estou ocupado, não consigo ir hoje. |
| 我没吃饭，因为没有时间。 | Wǒ méi chīfàn, yīnwèi méiyǒu shíjiān. | Não comi porque não tive tempo. |
| 他迟到了，所以我们先走了。 | Tā chídào le, suǒyǐ wǒmen xiān zǒu le. | Ele se atrasou, então fomos embora primeiro. |

**Slots substituíveis.** `[causa]`: 下雨, 很忙, 没有时间, 不舒服; `[consequência]`: 不去, 不能来, 没吃饭, 先走.

**Extensões.** Responda a `你为什么不来？Nǐ wèishénme bù lái?` apenas com `因为...`; acrescente `所以` quando quiser explicitar o efeito. Para fala rápida, não obrigue o par em toda resposta.

**Observação pedagógica.** O objetivo é ação justificável, não decorar “porque = 因为”. Peça ao aluno que primeiro produza a consequência e depois acrescente a causa. Não confunda 因为 com `为了 wèile`, que introduz finalidade.

**Potencial de mapa.** Centro: **explicar decisão**. Primeiro anel: causa → consequência. Segundo anel: tempo, clima, condição pessoal. Contraste: 因为 causa versus 为了 finalidade. Transferência: justificar recusa, atraso e escolha.

**Prompt de recuperação.** “Não vou porque estou cansado.” Produza a frase inteira.

**Prompt de transferência.** Dê três justificativas reais para decisões do dia, variando o conector e a consequência.

**Critério de domínio.** Produzir quatro relações causa–consequência, responder uma pergunta com 为什么 e distinguir oralmente causa de finalidade em um exemplo.

---

## P23 — 如果……就…… para condição

**Nível:** A2–B1. **Operação:** dizer o que fará caso uma condição aconteça.

**Intenção.** Planejar, aconselhar ou prever uma consequência condicional. O molde `如果……就……` é produtivo e aparece em listas de padrões B1.[19]

**Padrão ou função.**

```text
如果 + [condição]，就 + [resultado/decisão].
如果 + [condição] 的话，(就) + [resultado].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 如果明天下雨，我们就不去。 | Rúguǒ míngtiān xiàyǔ, wǒmen jiù bú qù. | Se chover amanhã, não vamos. |
| 如果你有时间，就给我打电话。 | Rúguǒ nǐ yǒu shíjiān, jiù gěi wǒ dǎ diànhuà. | Se você tiver tempo, me liga. |
| 如果太快的话，我就听不懂。 | Rúguǒ tài kuài dehuà, wǒ jiù tīng bù dǒng. | Se for rápido demais, não entendo. |
| 如果可以，我们今天见。 | Rúguǒ kěyǐ, wǒmen jīntiān jiàn. | Se der, a gente se vê hoje. |

**Slots substituíveis.** `[condição]`: 下雨, 有时间, 太快, 可以, 你愿意; `[resultado]`: 不去, 打电话, 听不懂, 今天见, 先休息.

**Extensões.** Em fala, a condição pode vir depois: `我们不去，如果明天下雨。Wǒmen bú qù, rúguǒ míngtiān xiàyǔ.` — Não vamos se chover amanhã. Acrescente `的话 dehuà` para marcar a condição de maneira explícita, mas não exija sempre.

**Observação pedagógica.** Ensine a célula como decisão dependente de uma condição. Não force tradução palavra a palavra de `就`: em muitos contextos ele sinaliza consequência, prontidão ou encadeamento. Diferencie condição de causa: se a relação for factual e não hipotética, 因为……所以…… pode ser mais apropriado.

**Potencial de mapa.** Centro: **planejar sob condição**. Primeiro anel: se → então. Segundo anel: clima, disponibilidade, compreensão, permissão. Contraste: 如果/就 versus 因为/所以. Transferência: negociar planos contingentes.

**Prompt de recuperação.** “Se tiver tempo, me liga.” Produza a frase sem consultar.

**Prompt de transferência.** Faça três planos condicionais para um passeio, uma sessão de estudo e uma situação de reparo auditivo.

**Critério de domínio.** Produzir quatro frases condicionais com consequências diferentes, inserir `的话` em uma delas e responder a um cenário sem repetir o exemplo-base.

---

## P24 — 虽然……但是…… para concessão e contraste

**Nível:** intermediário inicial. **Operação:** reconhecer um fato e apresentar uma limitação ou contraste.

**Intenção.** Dizer “embora A, B” sem apagar a validade de A. O par `虽然……但是……` expressa concessão e reação adversativa.[20]

**Padrão ou função.**

```text
虽然 + [fato/qualidade]，但是/可是 + [contraste].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 虽然很累，但是我还要学习。 | Suīrán hěn lèi, dànshì wǒ hái yào xuéxí. | Embora esteja cansado, ainda preciso estudar. |
| 虽然下雨，但是我们还是去了。 | Suīrán xiàyǔ, dànshì wǒmen háishi qù le. | Embora tenha chovido, fomos mesmo assim. |
| 虽然中文很难，可是很有意思。 | Suīrán Zhōngwén hěn nán, kěshì hěn yǒu yìsi. | Embora o chinês seja difícil, é interessante. |

**Slots substituíveis.** `[fato]`: 很累, 下雨, 中文很难, 没有时间; `[contraste]`: 还要学习, 还是去了, 很有意思, 想继续.

**Extensões.** Em fala, a primeira parte pode aparecer sem 虽然 quando o contraste já está claro: `很累，但是我还要学习。Hěn lèi, dànshì wǒ hái yào xuéxí.` — Estou cansado, mas ainda preciso estudar. `但是` e `可是` funcionam como alternativas comuns; não transforme a diferença em uma regra rígida de nível.

**Observação pedagógica.** O padrão exige duas proposições completas. Não o use para unir meros adjetivos sem intenção. O brasileiro pode interpretar `虽然` como “mas” e omitir a primeira metade; pratique o encadeamento em duas batidas de fala.

**Potencial de mapa.** Centro: **conceder e contrastar**. Primeiro anel: fato reconhecido → reação. Segundo anel: esforço, clima, dificuldade, preferência. Contraste: 但是 não apaga a primeira proposição. Transferência: explicar escolhas apesar de obstáculos.

**Prompt de recuperação.** “Embora esteja cansado, ainda vou estudar.” Produza as duas partes.

**Prompt de transferência.** Apresente três contrastes sobre estudo, clima e comida, sem repetir o mesmo verbo principal.

**Critério de domínio.** Produzir três frases de concessão com duas proposições completas e usar `但是` ou `可是` sem trocar a lógica por uma simples coordenação.

---

## P25 — 是……的 para destacar detalhe de evento conhecido

**Nível:** intermediário inicial. **Operação:** perguntar ou responder como, quando, onde ou com que finalidade um evento ocorreu.

**Intenção.** Focalizar um detalhe de uma ação já estabelecida no discurso, especialmente modo, tempo, lugar ou propósito. O padrão não é necessário para toda frase no passado.

**Padrão ou função.**

```text
[Sujeito] + 是 + [detalhe focalizado] + [verbo/evento] + 的。
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你是怎么来的？ | Nǐ shì zěnme lái de? | Como você veio? |
| 我是坐地铁来的。 | Wǒ shì zuò dìtiě lái de. | Vim de metrô. |
| 你是在哪儿学中文的？ | Nǐ shì zài nǎr xué Zhōngwén de? | Onde você estudou chinês? |
| 我是来工作的。 | Wǒ shì lái gōngzuò de. | Vim a trabalho. |

**Slots substituíveis.** `[detalhe]`: 怎么, 在哪儿, 什么时候, 坐地铁, 为了工作; `[evento]`: 来, 学中文, 认识他, 买票.

**Extensões.** Pergunte pelo tempo ou local: `你是什么时候来的？Nǐ shì shénme shíhou lái de?` — Quando você veio? Não focalize conclusão ou experiência com este molde sem contexto discursivo claro.

**Observação pedagógica.** A construção pressupõe um evento identificável. Não ensine `是……的` como “passado enfático” universal. Para brasileiro, a decisão é: estou perguntando **qual detalhe** de uma ação já conhecida, ou apenas narrando uma ação? Se for a segunda, use o padrão comum com tempo/aspecto.

**Potencial de mapa.** Centro: **focalizar detalhe**. Primeiro anel: 是 + detalhe + evento + 的. Segundo anel: modo, lugar, tempo, finalidade. Contraste: narrativa simples versus foco. Transferência: reconstruir detalhes de uma experiência.

**Prompt de recuperação.** “Como você veio?” Produza a pergunta e uma resposta com meio de transporte.

**Prompt de transferência.** Conte como, onde e por que você realizou três ações, usando o foco apenas quando o evento já estiver estabelecido.

**Critério de domínio.** Produzir uma pergunta e três respostas focadas em detalhes diferentes, sem usar o molde para todo evento concluído.

---

## P26 — Verbo + 得 + avaliação de desempenho

**Nível:** B1. **Operação:** avaliar como alguém realiza uma ação.

**Intenção.** Descrever o grau ou a qualidade de uma ação já compreensível, usando `V + 得 + complemento`.

**Padrão ou função.**

```text
[Sujeito] + [verbo] + 得 + [avaliação/grau].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你说得很清楚。 | Nǐ shuō de hěn qīngchu. | Você fala com muita clareza. |
| 她唱得很好。 | Tā chàng de hěn hǎo. | Ela canta muito bem. |
| 你中文说得不错。 | Nǐ Zhōngwén shuō de búcuò. | Você fala chinês bem. |
| 他跑得太快了。 | Tā pǎo de tài kuài le. | Ele correu rápido demais. |

**Slots substituíveis.** `[verbo]`: 说, 唱, 写, 做, 跑; `[avaliação]`: 很清楚, 很好, 不错, 太快, 不够慢.

**Extensões.** Use pergunta: `你觉得我说得怎么样？Nǐ juéde wǒ shuō de zěnmeyàng?` — O que você acha de como eu falo? Compare com complemento potencial: `你说得清楚` avalia desempenho; `你说得清楚吗？` pode perguntar se é possível falar claramente conforme o contexto.

**Observação pedagógica.** O 得 desta célula não é 的 possessivo nem 得 potencial. O aluno deve ter uma ação observável antes da avaliação. Não corrija pronúncia apenas pela leitura: o padrão organiza o comentário, mas avaliação fonética exige áudio ou interlocutor.

**Potencial de mapa.** Centro: **avaliar execução**. Primeiro anel: verbo → 得 → qualidade. Segundo anel: clareza, velocidade, qualidade. Contraste: 的, 得 resultativo/potencial, 得 de grau. Transferência: dar feedback respeitoso.

**Prompt de recuperação.** “Você fala muito rápido.” Produza uma avaliação com 得.

**Prompt de transferência.** Avalie três ações de uma pessoa ou personagem, variando o verbo e o grau; inclua uma avaliação positiva e uma limitação.

**Critério de domínio.** Produzir quatro avaliações com ações diferentes, mantendo 得 após o verbo e distinguindo pelo menos duas funções de 得 em exemplos contrastivos.

---

## P27 — 越来越 + adjetivo para mudança gradual

**Nível:** B1. **Operação:** dizer que algo está ficando cada vez mais de determinada maneira.

**Intenção.** Descrever tendência gradual, muito útil para comentar aprendizagem, clima, dificuldade e rotina.

**Padrão ou função.**

```text
[Sujeito] + 越来越 + [adjetivo] (+ 了).
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我的中文越来越好了。 | Wǒ de Zhōngwén yuèláiyuè hǎo le. | Meu chinês está cada vez melhor. |
| 天气越来越冷了。 | Tiānqì yuèláiyuè lěng le. | O tempo está ficando cada vez mais frio. |
| 这个问题越来越难。 | Zhège wèntí yuèláiyuè nán. | Este problema está cada vez mais difícil. |
| 我们越来越熟了。 | Wǒmen yuèláiyuè shú le. | Estamos ficando cada vez mais próximos. |

**Slots substituíveis.** `[sujeito]`: 我的中文, 天气, 这个问题, 我们; `[adjetivo]`: 好, 冷, 难, 熟, 忙, 快.

**Extensões.** Use `了` no final para marcar a mudança percebida, não um passado simples. Compare `越来越好` — cada vez melhor — com `很好` — muito bom; a primeira é uma trajetória, a segunda é uma avaliação de estado.

**Observação pedagógica.** O padrão é uma operação temporal de tendência, não um intensificador livre. Dê um antes/depois implícito ou explícito. Evite apresentar vocabulário abstrato sem uma escala que o aluno possa imaginar.

**Potencial de mapa.** Centro: **descrever tendência**. Primeiro anel: sujeito → cada vez mais → qualidade. Segundo anel: aprendizagem, temperatura, dificuldade, frequência. Contraste: muito agora versus mudança gradual. Transferência: avaliar progresso próprio.

**Prompt de recuperação.** “Meu chinês está cada vez melhor.” Produza a frase.

**Prompt de transferência.** Descreva três tendências na sua rotina, no estudo e no clima, sem repetir o mesmo adjetivo.

**Critério de domínio.** Produzir quatro frases de tendência com sujeitos distintos e usar 了 apenas quando houver mudança percebida, não como terminação obrigatória.

---

## P28 — 一……就…… para sequência imediata

**Nível:** B1. **Operação:** dizer que uma ação acontece logo após outra.

**Intenção.** Relatar ou planejar uma sequência rápida e previsível: assim que A ocorre, B acontece.

**Padrão ou função.**

```text
[Sujeito] + 一 + [evento 1]，就 + [evento 2].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 我一到家就洗澡。 | Wǒ yí dào jiā jiù xǐzǎo. | Assim que chego em casa, tomo banho. |
| 他一听到消息就给我打电话。 | Tā yì tīngdào xiāoxi jiù gěi wǒ dǎ diànhuà. | Assim que soube da notícia, me ligou. |
| 你一有时间就告诉我。 | Nǐ yì yǒu shíjiān jiù gàosu wǒ. | Assim que tiver tempo, me avise. |

**Slots substituíveis.** `[evento 1]`: 到家, 听到消息, 有时间, 下班; `[evento 2]`: 洗澡, 打电话, 告诉我, 回家.

**Extensões.** O sujeito pode mudar entre as duas partes quando o contexto exigir; mantenha a relação temporal. Use com `就` sem traduzir como uma palavra isolada obrigatória.

**Observação pedagógica.** Não confundir `一` numeral com `一……就……` discursivo. O primeiro pode sofrer sandhi, como `yí dào` e `yì tīng`; a grafia dos caracteres permanece 一.[16] O foco oral é velocidade de transição, não explicação metalinguística.

**Potencial de mapa.** Centro: **encadear imediatamente**. Primeiro anel: A → logo B. Segundo anel: chegar, ouvir, ter tempo, terminar. Contraste: sequência comum com 先/再 versus sequência imediata. Transferência: descrever hábitos e respostas automáticas.

**Prompt de recuperação.** “Assim que chego em casa, estudo.” Produza a frase.

**Prompt de transferência.** Crie três sequências automáticas da sua rotina e uma instrução para outra pessoa.

**Critério de domínio.** Produzir quatro pares de eventos com relação imediata, incluindo uma condição futura, e realizar o sandhi de 一 funcionalmente em pelo menos dois pares.

---

## P29 — 让/请 + pessoa + verbo para pedir ou permitir que alguém faça

**Nível:** B1. **Operação:** fazer um pedido, dar instrução ou permitir uma ação de outra pessoa.

**Intenção.** Colocar uma pessoa entre o verbo causativo/interacional e a ação: “deixe-me…”, “peça a ele que…”, “permita que…”. `请` pode suavizar um pedido; `让` apresenta autorização, indução ou ordem conforme o contexto.[18]

**Padrão ou função.**

```text
[Sujeito] + 让/请 + [pessoa] + [ação].
请 + [pessoa] + [ação].
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 请让我试试。 | Qǐng ràng wǒ shìshi. | Deixe-me tentar. |
| 老师让我们读一遍。 | Lǎoshī ràng wǒmen dú yí biàn. | O professor pediu que lêssemos uma vez. |
| 请你再说一遍。 | Qǐng nǐ zài shuō yí biàn. | Por favor, repita. |
| 让我来吧。 | Ràng wǒ lái ba. | Deixa que eu faço. |

**Slots substituíveis.** `[pessoa]`: 我, 你, 他, 我们; `[ação]`: 试试, 读一遍, 再说一遍, 来, 看一下; `[sujeito]`: 老师, 朋友, 公司.

**Extensões.** Use `别让……` para impedir: `别让他等。Bié ràng tā děng.` — Não faça ele esperar. Combine com `吧` em oferta: `让我来吧。Ràng wǒ lái ba.` — Deixa que eu faço.

**Observação pedagógica.** A célula é socialmente sensível: `让` pode soar diretivo; `请` suaviza, mas não é um “por favor” que substitui toda polidez. Não use o padrão como tradução mecânica de cada “deixe”. O aluno deve identificar quem age e qual ação é solicitada.

**Potencial de mapa.** Centro: **orquestrar a ação de outra pessoa**. Primeiro anel: causador/pedido → pessoa → verbo. Segundo anel: repetir, tentar, ler, vir, olhar. Contraste: pedido direto `请给我` versus ação atribuída a alguém. Transferência: instruções de estudo e reparo.

**Prompt de recuperação.** “Por favor, deixe-me tentar.” Produza a frase.

**Prompt de transferência.** Faça três pedidos socialmente adequados para que pessoas diferentes realizem ações diferentes.

**Critério de domínio.** Produzir quatro frases com pessoas e ações diferentes, distinguir pedido direto de causação e usar `吧` em uma oferta sem alterar o núcleo.

---

## P30 — 应该 para conselho e expectativa razoável

**Nível:** B1. **Operação:** aconselhar ou dizer o que é esperado que aconteça.

**Intenção.** Recomendar uma ação sem usar uma ordem nua, ou indicar uma previsão baseada em expectativa.

**Padrão ou função.**

```text
[Sujeito] + 应该 + [verbo/ação].
[Sujeito] + 应该 + [verbo] + 了 / 吧.
```

**Exemplos orais.**

| Mandarim | Pinyin | Tradução natural |
|---|---|---|
| 你应该多休息。 | Nǐ yīnggāi duō xiūxi. | Você deveria descansar mais. |
| 我们应该先吃饭。 | Wǒmen yīnggāi xiān chīfàn. | A gente deveria comer primeiro. |
| 他应该到了。 | Tā yīnggāi dào le. | Ele provavelmente já chegou. |
| 你应该可以听懂。 | Nǐ yīnggāi kěyǐ tīng dǒng. | Você provavelmente consegue entender. |

**Slots substituíveis.** `[sujeito]`: 你, 我们, 他; `[ação]`: 多休息, 先吃饭, 回家, 再试一次; `[extensão]`: 吧, 了, 可以, 不要.

**Extensões.** Suavize recomendação com `吧`: `你应该早点睡吧。Nǐ yīnggāi zǎodiǎn shuì ba.` — Você devia dormir mais cedo. Contraste com `必须 bìxū` — obrigação forte — e `最好 zuìhǎo` — recomendação mais enfática; não introduza todos na mesma prática inicial.

**Observação pedagógica.** O sentido depende de prosódia e contexto: conselho e expectativa não são idênticos. Para brasileiros, não traduza 应该 como um passado; 应该 é modal e permanece antes da ação. O critério oral deve avaliar se o aluno produz conselho acionável.

**Potencial de mapa.** Centro: **orientar decisão**. Primeiro anel: sujeito → deveria → ação. Segundo anel: descanso, sequência, horário, compreensão. Contraste: 应该 versus 必须/可以. Transferência: aconselhar um colega.

**Prompt de recuperação.** “Você deveria descansar mais.” Produza o conselho.

**Prompt de transferência.** Dê quatro conselhos para uma pessoa que estuda mandarim, trabalha e precisa resolver um problema de comunicação.

**Critério de domínio.** Produzir quatro conselhos acionáveis e uma expectativa, mantendo 应该 antes do verbo e distinguindo recomendação de obrigação em uma situação nova.

---

## Como transformar cada padrão em mapa e prática

O template editorial de cada célula deve preservar a seguinte sequência:

1. **Tentativa sem resposta.** O aluno recebe apenas a intenção em português brasileiro, uma situação, uma imagem mental ou um gatilho auditivo.
2. **Reconstrução do núcleo.** O mapa revela a ordem fixa e deixa os slots em branco. Não exiba a frase completa antes da primeira tentativa.
3. **Recombinação controlada.** O aluno troca pelo menos três slots, mantendo a função comunicativa. A variação deve ser limitada o suficiente para preservar fluência e ampla o suficiente para provar que houve produção.
4. **Contraste diagnóstico.** O material mostra uma única confusão de alto risco, como `是/在`, `不/没`, `想/要`, `了/过`, `听懂/听得懂` ou `还是/或者`.
5. **Transferência.** O prompt altera contexto, pessoa, tempo, lugar, objeto ou relação social. Repetir o exemplo de orientação não conta como transferência.
6. **Retirada do suporte.** O pinyin, a tradução e o mapa completo desaparecem em momentos diferentes. Caracteres simplificados entram como apoio visual e não como pré-requisito para iniciar fala.

### Critério transversal de domínio

Uma célula só deve ser marcada como dominada quando o aluno consegue **compreender a intenção ao ouvir**, **recuperar o padrão sem a resposta**, **produzir pelo menos três recombinações**, **manter pronúncia funcional nos pontos trabalhados** e **transferir o padrão para uma situação nova**. Reconhecimento visual, repetição imediata e tradução correta não bastam. Um resultado tonal incerto deve retornar ao áudio ou a feedback humano/tecnológico validado; mais leitura não substitui escuta e produção.

### Alertas gerais para brasileiros

- **Pinyin não é ortografia portuguesa.** `q`, `x`, `zh`, `ch`, `sh`, `r`, `j` e `c` devem ser aprendidos por escuta e imitação.
- **Não memorize tons apenas como números.** A realização conectada importa; destaque especialmente `bú shì`, `bú yào`, `yí ge`, `yì bēi`, `yí biàn` e sequências de terceiros tons.
- **Tradução funcional não é tradução palavra por palavra.** `我有时间` é naturalmente “tenho tempo”; `这里有水` é “tem água aqui”.
- **Registro é parte da ação.** `请`, `可以吗`, `吧`, `呢` e uma ordem direta não são intercambiáveis em todos os contextos.
- **Não use exemplos genéricos sem decisão oral.** Cada item deve responder: quem fala, para qual finalidade, com qual escolha linguística e qual slot será trocado.
- **Não transformar este bloco em transcrição.** Os padrões são unidades independentes de função e recombinação. O áudio do percurso do aluno deve continuar sendo a fonte principal de escuta e antecipação.

## Referências

[1]: https://resources.allsetlearning.com/chinese/grammar/Beginner_Guide_to_Chinese_Grammar "Beginner Guide to Chinese Grammar — AllSet Learning Chinese Grammar Wiki"
[2]: https://resources.allsetlearning.com/chinese/grammar/Chinese_word_order "Chinese word order — AllSet Learning Chinese Grammar Wiki"
[3]: https://resources.allsetlearning.com/chinese/grammar/Sentence_Patterns "Sentence Patterns — AllSet Learning Chinese Grammar Wiki"
[4]: https://resources.allsetlearning.com/chinese/grammar/Placement_of_question_words "Placement of question words — AllSet Learning Chinese Grammar Wiki"
[5]: https://resources.allsetlearning.com/chinese/grammar/Yes-no_questions_with_%22ma%22 "Yes-no questions with 吗 — AllSet Learning Chinese Grammar Wiki"
[6]: https://resources.allsetlearning.com/chinese/grammar/Affirmative-negative_question "Affirmative-negative question — AllSet Learning Chinese Grammar Wiki"
[7]: https://resources.allsetlearning.com/chinese/grammar/Expressing_existence_in_a_place_with_%22zai%22 "Expressing existence in a place with 在 — AllSet Learning Chinese Grammar Wiki"
[8]: https://human.libretexts.org/Bookshelves/Languages/Chinese/CHN101_Elementary_Mandarin_I_Textbook/04%3A_Family/4.08%3A_Lesson_3_Grammar_-_Expressing_existence_with__(you) "Expressing existence with 有 — Kapi'olani Community College via LibreTexts"
[9]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22hui,%22_%22neng,%22_%22keyi%22 "Comparing 会, 能, 可以 — AllSet Learning Chinese Grammar Wiki"
[10]: https://resources.allsetlearning.com/chinese/grammar/Result_complements "Result complements — AllSet Learning Chinese Grammar Wiki"
[11]: https://resources.allsetlearning.com/chinese/grammar/Uses_of_%22le%22 "Uses of 了 — AllSet Learning Chinese Grammar Wiki"
[12]: https://resources.allsetlearning.com/chinese/grammar/Expressing_experiences_with_%22guo%22 "Expressing experiences with 过 — AllSet Learning Chinese Grammar Wiki"
[13]: https://resources.allsetlearning.com/chinese/grammar/Potential_complements "Potential complement — AllSet Learning Chinese Grammar Wiki"
[14]: https://resources.allsetlearning.com/chinese/grammar/Using_%22ba%22_sentences "Using 把 sentences — AllSet Learning Chinese Grammar Wiki"
[15]: https://resources.allsetlearning.com/chinese/grammar/Basic_comparisons_with_%22bi%22 "Basic comparisons with 比 — AllSet Learning Chinese Grammar Wiki"
[16]: https://resources.allsetlearning.com/chinese/pronunciation/Tone_change_rules "Tone change rules — AllSet Learning Chinese Pronunciation Wiki"
[17]: https://resources.allsetlearning.com/chinese/grammar/Suggestions_with_%22ba%22 "Suggestions with 吧 — AllSet Learning Chinese Grammar Wiki"
[18]: https://resources.allsetlearning.com/chinese/grammar/B1_grammar_points "B1 grammar points — AllSet Learning Chinese Grammar Wiki"
[19]: https://resources.allsetlearning.com/chinese/grammar/B1_grammar_points "B1 grammar points: causative and conditional patterns — AllSet Learning Chinese Grammar Wiki"
[20]: https://resources.allsetlearning.com/chinese/grammar/Expressing_%22although..._but...%22_with_%22suiran...danshi%22 "Expressing 虽然……但是…… — AllSet Learning Chinese Grammar Wiki"

> **Nota de revisão.** As referências sustentam a existência e o uso geral dos padrões. A seleção, os exemplos autorais, os prompts, a gradação de suporte e os critérios de domínio são decisões pedagógicas do projeto Mandarim em Rede e devem passar por revisão linguística independente antes de publicação comercial.
