# 06 — Variações e expansões

## Escopo do bloco

Este bloco reúne **células de variação oral** para um aluno brasileiro do iniciante ao intermediário inicial. A unidade não é uma frase para memorizar, mas uma operação que o aluno consegue reconstruir, alterar e transferir. O percurso recomendado é:

```text
SUBSTITUIR um slot → ESTENDER a moldura → COMBINAR duas funções → TRANSFERIR sem mapa
```

As frases abaixo são exemplos autorais de uso geral. Não reproduzem diálogos, transcrições ou áudios proprietários. O áudio que o aluno já pratica continua sendo a fonte primária de escuta e pronúncia; este bloco entra **depois da tentativa de recuperação**, para organizar relações e provocar produção nova.

A seleção segue a unidade de transferência definida no projeto: uma intenção oral, um padrão produtivo, um conjunto pequeno de slots, uma expansão graduada, um alerta contrastivo e uma tarefa de transferência. A resposta completa deve aparecer somente depois da primeira tentativa do aluno. A progressão pode ser marcada assim:

- **Substituição:** o aluno mantém a moldura e troca um componente.
- **Extensão:** o aluno acrescenta tempo, lugar, quantidade, aspecto ou complemento sem perder o núcleo.
- **Combinação:** o aluno conecta duas ações ou intenções em uma situação nova.

A recuperação é prioritária em relação à releitura. Em um estudo clássico, praticar a recuperação produziu ganhos maiores do que o estudo elaborativo com mapas conceituais, inclusive quando o teste final exigia compreensão e inferência [14]. Portanto, o mapa abaixo de cada célula é um **suporte removível**, não o produto final.

## Como aplicar a progressão

| Estado | O que o aluno recebe | Ação oral exigida | Quando retirar suporte |
|---|---|---|---|
| Apoio | intenção, padrão completo, pinyin tonal e tradução natural | identificar a função e ouvir o núcleo | após uma produção correta com o padrão visível |
| Recuperação | intenção e lacunas nos slots | produzir antes de consultar a resposta | quando consegue trocar três slots sem copiar uma frase |
| Recombinação | intenção, dois ou três slots e uma restrição | montar variações em tempo limitado | quando a ordem se mantém sem tradução palavra por palavra |
| Transferência | somente situação, propósito e poucos gatilhos | agir oralmente em contexto não visto | quando produz duas rodadas diferentes sem o mapa |
| Independência | prompt mínimo ou estímulo auditivo | responder e reparar a própria fala | manter revisão espaçada, não aumentar a página |

### Política de naturalidade e carga

Cada célula trabalha uma ação dominante. As extensões entram uma de cada vez. O aluno não precisa aprender todo o vocabulário da tabela; deve selecionar de três a cinco itens que já consiga ouvir ou dizer. Traduções são naturais em português brasileiro e não devem ser usadas para reconstruir a ordem palavra por palavra. Pinyin com marcas tonais registra a forma lexical; na fala conectada, há mudanças regulares, como **不 bù → bú** antes de uma sílaba de quarto tom e mudanças de terceiro tom em certos grupos [12]. O áudio ou um interlocutor competente continua necessário para avaliar a pronúncia.

---

## 1. Desejar uma ação: `想 + verbo`

**Progressão:** substituição nuclear → negação → pergunta de decisão.

### Intenção

Dizer o que se quer fazer ou perguntar o que a outra pessoa quer fazer. É uma célula de alta produtividade porque o slot principal pode receber bebida, comida, deslocamento, estudo ou descanso.

### Padrão ou função

```text
[F] 我想 + [V] ação。
[F] 我不想 + [V] ação。
[F] 你想不想 + [V] ação？
```

`想` expressa desejo ou intenção. A pergunta positiva com `吗` pergunta se a pessoa quer; a forma `想不想` oferece uma decisão direta.

### Exemplos

1. **我想喝水。**  
   *Wǒ xiǎng hē shuǐ.*  
   Quero beber água.

2. **我不想喝咖啡。**  
   *Wǒ bù xiǎng hē kāfēi.*  
   Não quero tomar café.

3. **你想吃饭吗？**  
   *Nǐ xiǎng chīfàn ma?*  
   Você quer comer?

4. **你想不想喝茶？**  
   *Nǐ xiǎng bu xiǎng hē chá?*  
   Você quer tomar chá?

### Slots substituíveis

| Slot | Opções controladas | Função oral |
|---|---|---|
| `[V] ação` | 喝水 *hē shuǐ*; 吃饭 *chīfàn*; 看电影 *kàn diànyǐng*; 回家 *huí jiā*; 休息 *xiūxi* | o que a pessoa pretende fazer |
| `[O] pessoa` | 我 *wǒ*; 你 *nǐ*; 我们 *wǒmen* | quem deseja |
| `[O] pergunta` | 吗 *ma*; 不/不 *bu* na forma A-not-A | formato da decisão |

### Extensões

1. Acrescente lugar: **我想在家看电影。** *Wǒ xiǎng zài jiā kàn diànyǐng.* — Quero ver um filme em casa.
2. Acrescente tempo: **我今天想早点回家。** *Wǒ jīntiān xiǎng zǎodiǎn huí jiā.* — Hoje quero voltar para casa mais cedo.
3. Combine duas ações em sequência: **我想先吃饭，再休息。** *Wǒ xiǎng xiān chīfàn, zài xiūxi.* — Quero comer primeiro e depois descansar.

### Observação pedagógica

O contraste operacional é **想** versus **要**. `想` apresenta desejo ou plano; `要` pode indicar necessidade, decisão mais imediata ou pedido, dependendo do contexto. Não peça ao iniciante que traduza ambos sempre como “querer”. Primeiro estabilize a ação no slot; só depois introduza a diferença por situação. O `不` de **我不想** permanece geralmente com quarto tom lexical, pois a sílaba seguinte `想` é terceiro tom; não force a mudança de tom sem escuta.

### Potencial de mapa

```text
[N] expressar desejo
 ├── [F] 我想 / 我不想 / 你想不想
 ├── [V] ação: beber, comer, ver, voltar, descansar
 ├── [O] tempo + lugar
 ├── [A] xiǎng, hē, shuǐ, chá
 └── [X] 想 = desejo/plano ≠ 要 = necessidade/decisão/pedido
```

### Prompt de recuperação

Você está com um amigo. Diga, sem olhar, que quer beber água; depois diga que não quer café; por fim pergunte se ele quer comer. A primeira tentativa deve usar apenas a intenção em português e três palavras-gatilho: **querer — água — comer**.

### Prompt de transferência

Você acabou de sair do trabalho. Diga o que quer fazer agora, onde quer fazer e o que não quer fazer hoje. Em seguida, pergunte a outra pessoa se ela quer fazer uma atividade diferente.

### Critério de domínio

Produz **quatro variações** com pelo menos três verbos diferentes, faz uma negação e uma pergunta A-not-A sem consultar a forma completa, mantém a ordem `想 + ação` e não traduz `想` como um auxiliar português antes de começar a frase.

---

## 2. Capacidade e possibilidade: `会 / 能`

**Progressão:** substituição de habilidade → pergunta → restrição situacional.

### Intenção

Dizer que sabe fazer algo por habilidade e dizer que consegue ou não consegue fazer algo em uma situação concreta. Esta célula transforma “eu sei uma língua” em uma rede de ações observáveis.

### Padrão ou função

```text
[F] 我会 + [V] habilidade。
[F] 我能 + [V] ação possível nesta situação。
[F] 你会不会 + [V] habilidade？
```

`会` tende a marcar habilidade aprendida; `能` tende a marcar possibilidade, condição ou capacidade no momento. `可以` pode ser acrescentado depois para permissão ou aceitabilidade, mas não deve ser apresentado como sinônimo automático dos dois.

### Exemplos

1. **我会说一点中文。**  
   *Wǒ huì shuō yìdiǎn Zhōngwén.*  
   Sei falar um pouco de chinês.

2. **你会不会做饭？**  
   *Nǐ huì bu huì zuòfàn?*  
   Você sabe cozinhar?

3. **我今天不能去。**  
   *Wǒ jīntiān bù néng qù.*  
   Hoje não posso ir.

4. **你能再说一遍吗？**  
   *Nǐ néng zài shuō yí biàn ma?*  
   Você pode repetir?

### Slots substituíveis

| Slot | Opções controladas | Função oral |
|---|---|---|
| `[V] habilidade` | 说中文 *shuō Zhōngwén*; 做饭 *zuòfàn*; 开车 *kāichē*; 游泳 *yóuyǒng* | saber executar |
| `[V] situação` | 去 *qù*; 来 *lái*; 等 *děng*; 帮忙 *bāngmáng*; 再说一遍 *zài shuō yí biàn* | conseguir nesta condição |
| `[O] restrição` | 今天 *jīntiān*; 现在 *xiànzài*; 太晚了 *tài wǎn le*; 没时间 *méi shíjiān* | motivo para possibilidade ou impossibilidade |

### Extensões

1. Negue habilidade: **我不会开车。** *Wǒ bú huì kāichē.* — Não sei dirigir.
2. Acrescente condição: **我今天能帮你。** *Wǒ jīntiān néng bāng nǐ.* — Hoje consigo ajudar você.
3. Combine com reparo: **我听不懂，你能说慢一点吗？** *Wǒ tīng bu dǒng, nǐ néng shuō màn yìdiǎn ma?* — Não consigo entender; você pode falar um pouco mais devagar?

### Observação pedagógica

Não avalie `会` e `能` por tradução isolada. Pergunte primeiro: a pessoa tem a habilidade? Use `会`. A pergunta é sobre conseguir nas condições atuais? Use `能`. Em **不会**, `不` costuma realizar-se como **bú** antes de **会 huì**, que é quarto tom. Em **不能**, o `不` não sofre a mesma mudança porque `能 néng` é segundo tom. A distinção tonal é um alerta, não um requisito para o aluno receber explicação longa.

### Potencial de mapa

```text
[N] declarar capacidade
 ├── [F] 会 / 能
 ├── [V] falar, cozinhar, dirigir, nadar, ajudar
 ├── [O] hoje, agora, tarde, sem tempo
 ├── [A] huì ≠ néng; bú huì
 └── [X] habilidade ≠ possibilidade situada ≠ permissão
```

### Prompt de recuperação

Sem olhar, produza: “eu sei falar um pouco de chinês”; “eu não sei dirigir”; “hoje não posso ir”; “você pode repetir?”. Troque apenas uma ação na segunda rodada.

### Prompt de transferência

Você está em uma estação e alguém pede ajuda. Diga uma coisa que você sabe fazer, uma coisa que não sabe fazer e uma coisa que hoje consegue fazer. Termine pedindo que a pessoa repita uma informação.

### Critério de domínio

Produz três frases com `会` e três com `能`, usa uma negação apropriada para cada função, responde a um prompt de habilidade sem hesitação longa e não usa `会` automaticamente para toda ocorrência de “poder”.

---

## 3. Quantificar e especificar: número + classificador + substantivo

**Progressão:** substituição do item → troca de quantidade → demonstrativo e pergunta de escolha.

### Intenção

Pedir, identificar ou escolher uma quantidade concreta. Os classificadores não são decoração: quando se conta um substantivo, o mandarim normalmente exige a estrutura `número + classificador + substantivo` [3].

### Padrão ou função

```text
[F] [número] + [classificador] + [N] substantivo
[F] 这/那 + [classificador] + [N]
[F] 请给我 + [quantidade] + [N]
```

### Exemplos

1. **我要一杯水。**  
   *Wǒ yào yì bēi shuǐ.*  
   Quero um copo de água.

2. **请给我两本书。**  
   *Qǐng gěi wǒ liǎng běn shū.*  
   Por favor, me dê dois livros.

3. **这三个问题很重要。**  
   *Zhè sān gè wèntí hěn zhòngyào.*  
   Estas três perguntas são importantes.

4. **你要哪个？**  
   *Nǐ yào nǎge?*  
   Qual você quer?

### Slots substituíveis

| Slot | Opções controladas | Uso |
|---|---|---|
| `[número]` | 一 *yī*; 两 *liǎng*; 三 *sān*; 几 *jǐ* | quantidade ou pergunta de quantidade |
| `[classificador]` | 个 *gè* para itens gerais; 杯 *bēi* para copos/xícaras; 本 *běn* para livros; 张 *zhāng* para folhas/ingressos | unidade do item |
| `[N]` | 水 *shuǐ*; 书 *shū*; 票 *piào*; 问题 *wèntí* | item contado |
| `[demonstrativo]` | 这 *zhè*; 那 *nà*; 哪 *nǎ* | proximidade ou escolha |

### Extensões

1. Faça um pedido: **请给我三张票。** *Qǐng gěi wǒ sān zhāng piào.* — Por favor, me dê três ingressos.
2. Acrescente posse: **这是我的两本书。** *Zhè shì wǒ de liǎng běn shū.* — Estes são os meus dois livros.
3. Combine com localização: **那两杯咖啡在桌子上。** *Nà liǎng bēi kāfēi zài zhuōzi shàng.* — Aqueles dois cafés estão sobre a mesa.

### Observação pedagógica

Evite ensinar uma lista extensa. Comece com `个`, `杯`, `本` e `张`, cada um ligado a uma ação. Antes de uma sílaba de primeiro, segundo ou terceiro tom, `一` costuma ser ouvido como **yì**; antes de quarto tom, como **yí**. Assim, **一杯** aparece como *yì bēi*, enquanto **一遍** aparece como *yí biàn*. O aluno deve ouvir a expressão inteira, não decorar uma falsa regra de “um tom por palavra”.

### Potencial de mapa

```text
[N] especificar quantidade
 ├── [F] número + classificador + substantivo
 ├── [V] 1/2/3; 个/杯/本/张; item
 ├── [O] 这/那/哪; 我的/你的
 ├── [A] yì bēi, yí biàn, liǎng běn
 └── [X] não dizer “um água” com a ordem do português
```

### Prompt de recuperação

Peça oralmente: um copo de água, dois livros, três ingressos e qual item a pessoa quer. Não mostre os classificadores; ofereça apenas os quatro substantivos como gatilhos.

### Prompt de transferência

Você está organizando uma mesa para três pessoas. Diga quantos copos, livros ou ingressos precisa, aponte para um item próximo e pergunte qual dos dois itens a pessoa quer.

### Critério de domínio

Produz quatro sintagmas quantitativos corretos, usa pelo menos três classificadores, responde a uma escolha com `哪个` e não omite automaticamente o classificador depois de um número.

---

## 4. Destinatário e ação dirigida: `给 + pessoa`

**Progressão:** destinatário simples → ação para alguém → pedido ao interlocutor.

### Intenção

Dizer para quem uma ação é dirigida ou pedir que alguém entregue algo. A célula organiza uma relação muito útil na fala: **quem recebe, quem age e o que é transferido**.

### Padrão ou função

```text
[F] 我/你 + 给 + [V] pessoa + [ação/objeto]
[F] 请给 + [V] pessoa + [O] objeto
```

`给` pode funcionar como verbo “dar” ou como marcador do destinatário “para/ao”. O mapa deve registrar a função no contexto, não uma tradução única.

### Exemplos

1. **我给你发消息。**  
   *Wǒ gěi nǐ fā xiāoxi.*  
   Vou te mandar uma mensagem.

2. **我给朋友打电话。**  
   *Wǒ gěi péngyou dǎ diànhuà.*  
   Vou telefonar para um amigo.

3. **请给我一张纸。**  
   *Qǐng gěi wǒ yì zhāng zhǐ.*  
   Por favor, me dê uma folha.

4. **我给你介绍一个朋友。**  
   *Wǒ gěi nǐ jièshào yí ge péngyou.*  
   Vou apresentar um amigo a você.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[pessoa]` | 我 *wǒ*; 你 *nǐ*; 他 *tā*; 朋友 *péngyou*; 老师 *lǎoshī* | destinatário ou alvo |
| `[ação]` | 发消息 *fā xiāoxi*; 打电话 *dǎ diànhuà*; 介绍 *jièshào*; 买 *mǎi* | ação direcionada |
| `[objeto]` | 一张纸 *yì zhāng zhǐ*; 一杯茶 *yì bēi chá*; 这个 *zhège* | coisa recebida ou transferida |

### Extensões

1. Acrescente tempo: **我明天给你打电话。** *Wǒ míngtiān gěi nǐ dǎ diànhuà.* — Amanhã vou telefonar para você.
2. Acrescente negação: **我没给他发消息。** *Wǒ méi gěi tā fā xiāoxi.* — Não mandei mensagem para ele.
3. Combine com resultado no nível seguinte: **我把书给你。** *Wǒ bǎ shū gěi nǐ.* — Eu te dou o livro. Use apenas depois de o padrão de destinatário estar estável.

### Observação pedagógica

A interferência mais comum é colocar o destinatário depois de todo o verbo, como em uma tradução literal do português. No padrão selecionado, `给 + pessoa` vem antes da ação: **给你发消息**, não uma sequência criada palavra por palavra a partir de “mandar mensagem para você”. A tradução brasileira pode alternar “para você”, “te” e “a você”, mas a posição mandarim deve permanecer audível.

### Potencial de mapa

```text
[N] dirigir uma ação a alguém
 ├── [F] 给 + pessoa
 ├── [V] enviar, telefonar, apresentar, comprar
 ├── [O] tempo; objeto pedido
 ├── [A] gěi; diànhuà; xiāoxi
 └── [X] destinatário antes da ação ≠ ordem portuguesa literal
```

### Prompt de recuperação

Diga: “vou mandar uma mensagem para você”; “vou ligar para um amigo”; “por favor, me dê uma folha”. Troque apenas o destinatário na segunda rodada.

### Prompt de transferência

Você precisa organizar uma pequena tarefa. Diga a quem vai telefonar, para quem vai enviar uma mensagem e o que vai pedir a alguém. Acrescente “amanhã” a uma das frases.

### Critério de domínio

Produz três frases com destinatários diferentes, mantém `给 + pessoa` antes do verbo, faz um pedido com `请给我` e combina uma frase com tempo sem deslocar o destinatário para o fim.

---

## 5. Moldura de tempo e lugar antes da ação

**Progressão:** SVO curto → tempo → lugar → tempo + lugar.

### Intenção

Dizer quando e onde uma ação acontece. Em uma ordem frequente, o tempo aparece depois do sujeito ou no início, e a localização de uma ação aparece antes do verbo: `sujeito + tempo + 在 + lugar + verbo + objeto` [1] [2].

### Padrão ou função

```text
[F] [S] + [tempo] + 在 + [lugar] + [V] + [O]
[F] [S] + 在 + [lugar] + [V]
```

### Exemplos

1. **我今天在家工作。**  
   *Wǒ jīntiān zài jiā gōngzuò.*  
   Hoje trabalho em casa.

2. **我们明天在学校见。**  
   *Wǒmen míngtiān zài xuéxiào jiàn.*  
   Nós nos vemos amanhã na escola.

3. **他晚上在公司吃饭。**  
   *Tā wǎnshang zài gōngsī chīfàn.*  
   À noite ele janta na empresa.

4. **你周末在哪儿学习？**  
   *Nǐ zhōumò zài nǎr xuéxí?*  
   Onde você estuda no fim de semana?

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[S]` | 我 *wǒ*; 我们 *wǒmen*; 他 *tā* | participante |
| `[tempo]` | 今天 *jīntiān*; 明天 *míngtiān*; 周末 *zhōumò*; 晚上 *wǎnshang* | quando |
| `[lugar]` | 家 *jiā*; 学校 *xuéxiào*; 公司 *gōngsī*; 北京 *Běijīng* | onde a ação ocorre |
| `[V/O]` | 工作 *gōngzuò*; 学习中文 *xuéxí Zhōngwén*; 吃饭 *chīfàn*; 见朋友 *jiàn péngyou* | ação |

### Extensões

1. Pergunte somente o lugar: **你在哪儿工作？** *Nǐ zài nǎr gōngzuò?* — Onde você trabalha?
2. Acrescente intenção: **我明天想在家学习。** *Wǒ míngtiān xiǎng zài jiā xuéxí.* — Amanhã quero estudar em casa.
3. Combine com sequência: **我们先在家吃饭，再去学校。** *Wǒmen xiān zài jiā chīfàn, zài qù xuéxiào.* — Primeiro comemos em casa, depois vamos à escola.

### Observação pedagógica

A regra é para **local da ação**, não para toda ocorrência de localização. Compare **我在家看书** (*Wǒ zài jiā kàn shū*, leio em casa) com **书在桌子上** (*Shū zài zhuōzi shàng*, o livro está sobre a mesa). No primeiro, `在 + lugar` modifica o verbo; no segundo, `在` faz parte do predicado de localização. A posição anterior ao verbo é um ponto de decisão que precisa ser praticado, não apenas explicado [1] [2].

### Potencial de mapa

```text
[N] situar uma ação
 ├── [F] sujeito + tempo + 在 + lugar + verbo
 ├── [V] hoje/amanhã/fim de semana; casa/escola/empresa
 ├── [O] objeto ou intenção 想
 ├── [A] zài, xuéxiào, wǎnshang
 └── [X] local da ação antes do verbo ≠ localização do objeto
```

### Prompt de recuperação

Sem olhar, diga onde e quando você trabalha, estuda e come. Use três combinações diferentes. Depois pergunte onde outra pessoa estuda.

### Prompt de transferência

Você está planejando amanhã. Diga uma ação em casa pela manhã, outra em um lugar público à tarde e pergunte onde um amigo vai estar à noite. Não use o mapa completo.

### Critério de domínio

Produz quatro frases com tempo e lugar, pergunta `在哪儿` sem deslocar o local para o final, distingue localização da ação e do objeto e mantém o verbo depois do lugar em pelo menos três tentativas.

---

## 6. Ação em andamento: `在/正在 + verbo`

**Progressão:** verbo simples → ação em curso → lugar + ação em curso.

### Intenção

Dizer o que está acontecendo agora e perguntar o que alguém está fazendo. A forma mais econômica é `在 + verbo`; `正在` acrescenta saliência de “estar justamente em andamento”, e `呢` pode marcar o estado conversacional [11].

### Padrão ou função

```text
[F] S + 在 + [V] (+ O)
[F] S + 正在 + [V] (+ O)
[F] S + 在 + [V] + 呢？
```

### Exemplos

1. **我在看书。**  
   *Wǒ zài kàn shū.*  
   Estou lendo.

2. **我正在等朋友。**  
   *Wǒ zhèngzài děng péngyou.*  
   Estou esperando um amigo.

3. **你在做什么呢？**  
   *Nǐ zài zuò shénme ne?*  
   O que você está fazendo agora?

4. **我们在上汉语课。**  
   *Wǒmen zài shàng Hànyǔ kè.*  
   Estamos tendo aula de chinês.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[S]` | 我 *wǒ*; 你 *nǐ*; 他 *tā*; 我们 *wǒmen* | participante |
| `[V/O]` | 看书 *kàn shū*; 等朋友 *děng péngyou*; 做饭 *zuòfàn*; 上课 *shàng kè* | ação em curso |
| `[marcador]` | 在 *zài*; 正在 *zhèngzài*; 呢 *ne* | aspecto e enquadramento conversacional |

### Extensões

1. Acrescente lugar, sem confundir as duas funções de `在`: **我在家看书。** *Wǒ zài jiā kàn shū.* — Estou lendo em casa.
2. Acrescente contraste: **我不是在看电影，我在看书。** *Wǒ bú shì zài kàn diànyǐng, wǒ zài kàn shū.* — Não estou vendo filme; estou lendo.
3. Combine com pedido de interrupção: **我正在开会，不能接电话。** *Wǒ zhèngzài kāihuì, bù néng jiē diànhuà.* — Estou em reunião e não posso atender.

### Observação pedagógica

O risco central é tratar `在` sempre como “em”. Compare **我在家看书** (local + ação) e **我在看书** (ação em andamento). A tradução brasileira pode usar “estou” nos dois casos, mas a arquitetura mandarim muda. Não exija a forma longa `正在...呢` em toda fala; ela é uma expansão, não um molde obrigatório [11].

### Potencial de mapa

```text
[N] relatar ação agora
 ├── [F] 在/正在 + verbo
 ├── [V] ler, esperar, cozinhar, ter aula
 ├── [O] lugar; 呢; contraste
 ├── [A] zài ≠ zài locativo por posição e intenção
 └── [X] 在 + lugar + V ≠ 在 + V
```

### Prompt de recuperação

Imagine três ações acontecendo agora. Diga: “estou lendo”; “estou esperando um amigo”; “o que você está fazendo?”. Na segunda rodada, acrescente um lugar a apenas uma frase.

### Prompt de transferência

Você está em uma chamada e não pode atender a uma pessoa. Diga o que está fazendo, onde está e por que não pode atender. Depois pergunte o que a outra pessoa está fazendo.

### Critério de domínio

Produz três ações em andamento, distingue `在 + lugar + V` de `在 + V`, usa `正在` em uma variação e entende que o marcador não é uma tradução fixa de “em”.

---

## 7. Conclusão e experiência: `了` versus `过`

**Progressão:** ação concluída → experiência anterior → combinação com contraste temporal.

### Intenção

Dizer que uma ação foi concluída em um quadro determinado e perguntar se alguém já teve uma experiência. `了` depois do verbo marca conclusão/aspecto, não simplesmente “passado”; `过` marca experiência anterior sem especificar uma ocasião [4] [5].

### Padrão ou função

```text
[F] S + tempo + V + 了 + quantidade/objeto
[F] S + V + 过 + experiência
[F] S + 没 + V + 过 + experiência
```

### Exemplos

1. **我今天喝了两杯咖啡。**  
   *Wǒ jīntiān hē le liǎng bēi kāfēi.*  
   Hoje tomei dois cafés.

2. **你吃过北京菜吗？**  
   *Nǐ chī guo Běijīng cài ma?*  
   Você já comeu comida de Pequim?

3. **我没去过中国。**  
   *Wǒ méi qù guo Zhōngguó.*  
   Nunca fui à China.

4. **我吃过，但是今天不想吃。**  
   *Wǒ chī guo, dànshì jīntiān bù xiǎng chī.*  
   Já comi, mas hoje não quero comer.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[tempo]` | 今天 *jīntiān*; 昨天 *zuótiān*; 上周 *shàng zhōu* | quadro da ação concluída |
| `[V]` | 喝 *hē*; 吃 *chī*; 去 *qù*; 看 *kàn*; 学 *xué* | ação ou experiência |
| `[experiência]` | 北京菜 *Běijīng cài*; 中国 *Zhōngguó*; 这部电影 *zhè bù diànyǐng*; 中文 *Zhōngwén* | o que já foi vivido |
| `[conector]` | 但是 *dànshì*; 所以 *suǒyǐ* | continuação da fala |

### Extensões

1. Especifique quantidade com `了`: **我买了三本书。** *Wǒ mǎi le sān běn shū.* — Comprei três livros.
2. Negue experiência com `没`: **我没看过这部电影。** *Wǒ méi kàn guo zhè bù diànyǐng.* — Nunca vi este filme.
3. Combine experiência e plano atual: **我去过北京，所以我想再去。** *Wǒ qù guo Běijīng, suǒyǐ wǒ xiǎng zài qù.* — Já fui a Pequim, por isso quero ir de novo.

### Observação pedagógica

A decisão oral é: estou contando **o que aconteceu em um quadro** ou verificando **se a pessoa tem essa experiência**? Use `了` no primeiro caso e `过` no segundo. A negação de experiência usa `没`, não `不`: **没去过**. Não introduza neste bloco todos os usos de `了` final de frase; isso confundiria conclusão com mudança de estado. As fontes gramaticais também alertam que aspecto não é o mesmo que tempo verbal [4].

### Potencial de mapa

```text
[N] localizar uma ação no repertório vivido
 ├── [F] V + 了 / V + 过 / 没 + V + 过
 ├── [V] comer, beber, ir, ver, estudar
 ├── [O] tempo, quantidade, 但是, 所以
 ├── [A] le neutro; guo neutro; méi
 └── [X] conclusão em quadro ≠ experiência anterior
```

### Prompt de recuperação

Diga três coisas que fez hoje usando `了`. Depois responda se já estudou chinês, se já foi à China e se já viu um filme específico usando `过` ou `没...过`.

### Prompt de transferência

Você está conhecendo alguém em uma viagem. Conte uma coisa que fez ontem, diga uma experiência que já teve e uma que nunca teve. Termine explicando qual atividade quer fazer hoje.

### Critério de domínio

Escolhe `了` ou `过` de acordo com a intenção em seis prompts, nega experiências com `没`, inclui uma quantidade após uma ação concluída e combina passado experiencial com uma decisão atual.

---

## 8. Resultado alcançado e possibilidade: `V+懂/完` e `V+得/不+complemento`

**Progressão:** resultado real → possibilidade → impossibilidade situada.

### Intenção

Dizer se a ação chegou a um resultado e se o resultado é alcançável. Essa célula é especialmente útil para reparo de compreensão e para tarefas concretas. Os complementos potenciais são comuns na fala cotidiana e colocam `得` ou `不` imediatamente depois do verbo modificado [6].

### Padrão ou função

```text
[F] S + V + resultado + 了
[F] S + V + 得 + resultado？
[F] S + V + 不 + resultado
```

### Exemplos

1. **我听懂了。**  
   *Wǒ tīng dǒng le.*  
   Entendi.

2. **你听得懂吗？**  
   *Nǐ tīng de dǒng ma?*  
   Você consegue entender?

3. **我听不懂。**  
   *Wǒ tīng bu dǒng.*  
   Não consigo entender.

4. **这本书我一个星期看得完。**  
   *Zhè běn shū wǒ yí ge xīngqī kàn de wán.*  
   Consigo terminar este livro em uma semana.

5. **这个包太小，手机放不进去。**  
   *Zhège bāo tài xiǎo, shǒujī fàng bu jìnqù.*  
   Esta bolsa é pequena demais; o celular não cabe.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[V + resultado]` | 听懂 *tīng dǒng*; 看完 *kàn wán*; 找到 *zhǎo dào*; 放进去 *fàng jìnqù* | resultado alcançado |
| `[modalidade]` | 了 *le*; 得 *de*; 不 *bu* | fato, possibilidade ou impossibilidade |
| `[condição]` | 一个星期 *yí ge xīngqī*; 太小 *tài xiǎo*; 声音太小 *shēngyīn tài xiǎo* | limite da ação |

### Extensões

1. Diferencie falha concreta: **我没听懂。** *Wǒ méi tīng dǒng.* — Não entendi. A frase relata um evento; não necessariamente uma incapacidade geral.
2. Peça ajuste: **我听不懂，请说慢一点。** *Wǒ tīng bu dǒng, qǐng shuō màn yìdiǎn.* — Não consigo entender; fale mais devagar.
3. Combine com quantidade e prazo: **这些问题我今天做得完。** *Zhèxiē wèntí wǒ jīntiān zuò de wán.* — Consigo terminar estas perguntas hoje.

### Observação pedagógica

O contraste entre **没听懂** e **听不懂** é mais útil do que uma definição abstrata: o primeiro relata que uma tentativa não resultou; o segundo apresenta uma dificuldade de possibilidade ou capacidade. Não acrescente `了` entre o verbo e o complemento potencial. Em `听不懂`, o `不` é parte da construção `V + 不 + resultado`, não a negação simples colocada antes do verbo.

### Potencial de mapa

```text
[N] avaliar resultado alcançado
 ├── [F] V+resultado; V+得+resultado; V+不+resultado
 ├── [V] entender, terminar, encontrar, colocar dentro
 ├── [O] prazo ou condição
 ├── [A] tīng dǒng; kàn wán; fàng bu jìnqù
 └── [X] 没听懂 = tentativa sem resultado ≠ 听不懂 = não conseguir
```

### Prompt de recuperação

Responda oralmente a quatro situações: você entendeu; você não entendeu a fala; você consegue terminar uma tarefa hoje; o objeto não cabe na bolsa. Use os complementos, não traduções literais.

### Prompt de transferência

Em uma aula rápida, diga que não consegue entender, peça que a pessoa fale mais devagar e depois diga que agora entendeu. Em seguida, diga se consegue terminar uma tarefa antes de sair.

### Critério de domínio

Produz `听懂了`, `没听懂`, `听得懂吗` e `听不懂` em contextos diferentes, coloca corretamente `得/不` no complemento potencial e acrescenta uma condição sem quebrar a sequência.

---

## 9. Destacar o objeto afetado: construção `把`

**Progressão:** objeto conhecido + destino → resultado → pergunta/negação.

### Intenção

Dizer o que foi feito com um objeto já conhecido ou pedir que alguém o mova, organize, feche ou conclua. A construção `把` não é uma troca estilística livre de toda frase SVO: tende a funcionar quando o objeto é definido e a ação mostra resultado, destino ou efeito [8].

### Padrão ou função

```text
[F] S + 把 + [O] objeto conhecido + [V] + resultado/destino
[F] 请/不要 + 把 + [O] + [V] + resultado/destino
```

### Exemplos

1. **请把手机放在桌子上。**  
   *Qǐng bǎ shǒujī fàng zài zhuōzi shàng.*  
   Coloque o celular sobre a mesa, por favor.

2. **我把作业做完了。**  
   *Wǒ bǎ zuòyè zuò wán le.*  
   Terminei a tarefa.

3. **你把门关上了吗？**  
   *Nǐ bǎ mén guān shàng le ma?*  
   Você fechou a porta?

4. **不要把这个给他。**  
   *Bú yào bǎ zhège gěi tā.*  
   Não dê isso a ele.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[O] objeto conhecido` | 手机 *shǒujī*; 作业 *zuòyè*; 门 *mén*; 这个 *zhège* | objeto afetado |
| `[V]` | 放 *fàng*; 做 *zuò*; 关 *guān*; 给 *gěi* | manipulação |
| `[resultado/destino]` | 在桌子上 *zài zhuōzi shàng*; 完 *wán*; 上 *shàng*; 给他 *gěi tā* | efeito, conclusão ou destinatário |

### Extensões

1. Acrescente localização específica: **把书放在包里。** *Bǎ shū fàng zài bāo lǐ.* — Coloque o livro dentro da bolsa.
2. Acrescente quantidade verbal: **把这句话读一遍。** *Bǎ zhè jù huà dú yí biàn.* — Leia esta frase uma vez.
3. Combine com capacidade em pergunta: **你能不能把门关上？** *Nǐ néng bu néng bǎ mén guān shàng?* — Você consegue fechar a porta?

### Observação pedagógica

O objeto precisa ser identificável no contexto e o verbo precisa mostrar o que acontece com ele. Evite ensinar **把** como “colocar o objeto antes do verbo” sem a parte do resultado. A forma `把 + objeto + verbo nu` costuma deixar a intenção incompleta. Como a construção tem carga maior, deve entrar depois de o aluno controlar SVO, localização e complementos.

### Potencial de mapa

```text
[N] agir sobre um objeto definido
 ├── [F] S + 把 + objeto
 ├── [V] pôr, fazer, fechar, dar
 ├── [O] destino, resultado, quantidade verbal
 ├── [A] bǎ; guān shàng; dú yí biàn
 └── [X] objeto conhecido + efeito necessário; não é SVO opcional
```

### Prompt de recuperação

Diga: coloque o celular na mesa; termine a tarefa; feche a porta; não dê isto a ele. Na primeira rodada, use apenas objeto e resultado como gatilhos.

### Prompt de transferência

Você está arrumando um quarto compartilhado. Diga a outra pessoa onde colocar dois objetos, peça que feche uma porta e pergunte se ela consegue terminar uma tarefa específica.

### Critério de domínio

Produz quatro frases com objetos definidos, inclui um destino e um resultado, forma uma pergunta com `能不能` e não usa `把` em uma frase sem objeto identificável ou sem efeito descrito.

---

## 10. Ordenar ações: `先……再……`

**Progressão:** duas ações → tempo/lugar dentro de cada etapa → decisão prática.

### Intenção

Dar instruções, narrar um plano curto ou organizar duas ações em ordem. `先` significa “primeiro”; neste padrão, `再` significa “depois”, não simplesmente “de novo” [9].

### Padrão ou função

```text
[F] 先 + [Ação 1]，再 + [Ação 2]
[F] 请/我/我们 + 先 + [Ação 1]，再 + [Ação 2]
```

### Exemplos

1. **我先吃饭，再学习。**  
   *Wǒ xiān chīfàn, zài xuéxí.*  
   Primeiro vou comer, depois estudar.

2. **请先买票，再进去。**  
   *Qǐng xiān mǎi piào, zài jìnqù.*  
   Compre o ingresso primeiro e depois entre.

3. **我们先在家吃饭，再去学校。**  
   *Wǒmen xiān zài jiā chīfàn, zài qù xuéxiào.*  
   Primeiro comemos em casa e depois vamos à escola.

4. **你先看一下，再告诉我。**  
   *Nǐ xiān kàn yíxià, zài gàosu wǒ.*  
   Olhe primeiro e depois me diga.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[Ação 1]` | 吃饭 *chīfàn*; 买票 *mǎi piào*; 看一下 *kàn yíxià*; 休息 *xiūxi* | etapa inicial |
| `[Ação 2]` | 学习 *xuéxí*; 进去 *jìnqù*; 告诉我 *gàosu wǒ*; 再说 *zài shuō* | etapa posterior |
| `[S]` | 我 *wǒ*; 你 *nǐ*; 我们 *wǒmen*; 请 *qǐng* | agente ou instrução |

### Extensões

1. **我先休息一下，再工作。** *Wǒ xiān xiūxi yíxià, zài gōngzuò.* — Primeiro vou descansar um pouco, depois trabalhar.
2. **我们先在咖啡店见，再一起去学校。** *Wǒmen xiān zài kāfēidiàn jiàn, zài yìqǐ qù xuéxiào.* — Primeiro nos encontramos no café, depois vamos juntos à escola.
3. **先吃饭，再说。** *Xiān chīfàn, zài shuō.* — Vamos comer primeiro e depois vemos.

### Observação pedagógica

Nesta moldura, `再` organiza o próximo passo; não significa automaticamente “novamente”. Ensine duas ações concretas antes de adicionar `然后` ou `接着`. A combinação só é produtiva se o aluno puder trocar cada ação separadamente.

### Potencial de mapa

```text
[N] ordenar ações
 ├── [F] 先 + Ação 1，再 + Ação 2
 ├── [V] comer, comprar, olhar, descansar
 ├── [O] tempo, lugar, 一下, 然后/接着
 ├── [A] xiān, zài, yíxià
 └── [X] 再 = depois nesta moldura ≠ sempre novamente
```

### Prompt de recuperação

Diga que primeiro vai comprar o ingresso e depois entrar. Em seguida, diga que primeiro vai comer e depois estudar. Não mostre `先` nem `再`; ofereça apenas as duas ações em português.

### Prompt de transferência

Você precisa resolver uma tarefa em uma estação. Ordene três passos: localizar o banheiro, comprar algo e encontrar um amigo. Depois reformule a ordem para uma situação em casa.

### Critério de domínio

Produz quatro sequências com duas ações, mantém a ordem temporal, incorpora um lugar ou tempo em uma das etapas e não interpreta `再` como repetição em todas as tentativas.

---

## 11. Escolha em pergunta e alternativas em afirmação: `还是 / 或者`

**Progressão:** escolha binária → troca dos itens → alternativa aberta em uma afirmação.

### Intenção

Perguntar qual de duas opções a pessoa escolhe e apresentar alternativas sem transformar a fala em uma pergunta de decisão imediata. `还是` é a escolha prototípica em perguntas; `或者` é usual em afirmações que apresentam possibilidades [7].

### Padrão ou função

```text
[F] Opção A + 还是 + Opção B？
[F] S + 可以 + Opção A + 或者 + Opção B。
```

### Exemplos

1. **你喝茶还是喝咖啡？**  
   *Nǐ hē chá háishi hē kāfēi?*  
   Você vai tomar chá ou café?

2. **我们坐地铁还是打车？**  
   *Wǒmen zuò dìtiě háishi dǎ chē?*  
   Vamos de metrô ou de táxi?

3. **周末我想在家看书或者看电影。**  
   *Zhōumò wǒ xiǎng zài jiā kànshū huòzhě kàn diànyǐng.*  
   No fim de semana quero ficar em casa lendo ou vendo filme.

4. **你可以电话或者邮件联系我。**  
   *Nǐ kěyǐ diànhuà huòzhě yóujiàn liánxì wǒ.*  
   Você pode falar comigo por telefone ou por e-mail.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[Opção A/B]` | 茶/咖啡 *chá/kāfēi*; 地铁/出租车 *dìtiě/chūzūchē*; 今天/明天 *jīntiān/míngtiān* | alternativas comparáveis |
| `[ação]` | 喝 *hē*; 坐 *zuò*; 去 *qù*; 联系 *liánxì* | ação comum às opções |
| `[marcador]` | 还是 *háishi*; 或者 *huòzhě* | pergunta versus afirmação |

### Extensões

1. **我喜欢茶，不喜欢咖啡。** *Wǒ xǐhuan chá, bù xǐhuan kāfēi.* — Gosto de chá, não de café.
2. **你今天还是明天有时间？** *Nǐ jīntiān háishi míngtiān yǒu shíjiān?* — Você tem tempo hoje ou amanhã?
3. **我们可以先坐地铁，或者直接打车。** *Wǒmen kěyǐ xiān zuò dìtiě, huòzhě zhíjiē dǎ chē.* — Podemos ir de metrô ou pegar um táxi direto.

### Observação pedagógica

A pergunta `A 还是 B？` pede uma escolha; `A 或者 B` pode deixar abertas várias possibilidades e não exige a mesma decisão naquele instante. Em pergunta indireta, `还是` também pode aparecer porque a escolha continua sendo uma questão embutida [7].

### Potencial de mapa

```text
[N] escolher ou apresentar alternativas
 ├── [F] A 还是 B？ / A 或者 B
 ├── [V] bebidas, transporte, dias, canais
 ├── [O] 喜欢, 可以, 先...再...
 ├── [A] háishi, huòzhě, kěyǐ
 └── [X] pergunta de escolha ≠ alternativa aberta em afirmação
```

### Prompt de recuperação

Pergunte: chá ou café? metrô ou táxi? hoje ou amanhã? Depois transforme uma das duplas em uma afirmação com `或者`.

### Prompt de transferência

Você está combinando um encontro. Faça duas perguntas de escolha e depois ofereça duas formas de contato em uma afirmação. Troque pelo menos uma opção na segunda rodada.

### Critério de domínio

Produz três perguntas com `还是`, converte uma escolha em uma afirmação com `或者`, mantém a ação paralela nas duas opções e demonstra que entende a diferença de decisão comunicativa.

---

## 12. Explicar motivo e consequência: `因为……所以……`

**Progressão:** razão curta → resultado → combinação com intenção, localização ou capacidade.

### Intenção

Explicar por que uma ação não ocorre, justificar uma escolha ou ligar uma condição a uma consequência. É uma expansão de intermediário inicial porque conecta duas células já conhecidas sem exigir uma narrativa longa.

### Padrão ou função

```text
[F] 因为 + [motivo]，所以 + [resultado]。
[F] 因为 + [motivo]，S + [resultado]。
```

`因为` introduz a causa. `所以` introduz a consequência. Em fala, uma das duas peças pode ser omitida quando a relação já está clara, mas o padrão completo é melhor para a primeira recuperação.

### Exemplos

1. **因为今天下雨，所以我不想出门。**  
   *Yīnwèi jīntiān xiàyǔ, suǒyǐ wǒ bù xiǎng chūmén.*  
   Como hoje está chovendo, não quero sair.

2. **因为我没时间，所以不能去。**  
   *Yīnwèi wǒ méi shíjiān, suǒyǐ bù néng qù.*  
   Como não tenho tempo, não posso ir.

3. **因为洗手间在那边，所以我们先过去。**  
   *Yīnwèi xǐshǒujiān zài nàbiān, suǒyǐ wǒmen xiān guòqù.*  
   Como o banheiro fica ali, vamos primeiro para lá.

4. **我喜欢这家店，因为东西很好吃。**  
   *Wǒ xǐhuan zhè jiā diàn, yīnwèi dōngxi hěn hǎochī.*  
   Gosto deste restaurante porque a comida é muito gostosa.

### Slots substituíveis

| Slot | Opções controladas | Função |
|---|---|---|
| `[motivo]` | 今天下雨 *jīntiān xiàyǔ*; 没时间 *méi shíjiān*; 太晚了 *tài wǎn le*; 不舒服 *bù shūfu* | causa ou condição |
| `[resultado]` | 不想出门 *bù xiǎng chūmén*; 不能去 *bù néng qù*; 先过去 *xiān guòqù*; 喜欢这家店 *xǐhuan zhè jiā diàn* | efeito, decisão ou ação |
| `[conector]` | 因为 *yīnwèi*; 所以 *suǒyǐ*; 但是 *dànshì* | relação entre ideias |

### Extensões

1. **因为下雨，所以我想在家休息。** *Yīnwèi xiàyǔ, suǒyǐ wǒ xiǎng zài jiā xiūxi.* — Como está chovendo, quero descansar em casa.
2. **因为我不会开车，所以不能去。** *Yīnwèi wǒ bú huì kāichē, suǒyǐ bù néng qù.* — Como não sei dirigir, não posso ir.
3. **因为票很贵，所以我们先看看。** *Yīnwèi piào hěn guì, suǒyǐ wǒmen xiān kànkan.* — Como o ingresso é caro, vamos dar uma olhada primeiro.

### Observação pedagógica

Não transforme `因为` e `所以` em conectores intercambiáveis. O primeiro aponta para o motivo; o segundo aponta para a consequência. A célula deve combinar apenas conteúdos já dominados; não é uma licença para introduzir muitas palavras novas.

### Potencial de mapa

```text
[N] justificar uma decisão
 ├── [F] 因为 motivo，所以 resultado
 ├── [V] chuva, tempo, preço, capacidade, conforto
 ├── [O] 想, 能, 先...再..., 但是
 ├── [A] yīnwèi, suǒyǐ, méi, bú
 └── [X] causa antes da consequência; não traduzir pela ordem portuguesa
```

### Prompt de recuperação

Complete oralmente: “Como hoje estou sem tempo, ...”; “Como está chovendo, ...”; “Como não sei dirigir, ...”. Em cada caso, produza uma consequência diferente.

### Prompt de transferência

Você precisa recusar um convite e oferecer uma alternativa. Diga o motivo, explique a consequência e proponha uma nova hora ou lugar. Faça uma segunda rodada trocando apenas o motivo.

### Critério de domínio

Produz três relações de causa e consequência, mantém `因为` no motivo e `所以` no resultado, combina uma relação com `想`, `能` ou `先……再……` e consegue variar o motivo sem repetir a frase inteira.

---

## Matriz de progressão e combinação

| Etapa | Operação dominante | Células prioritárias | Prompt mínimo |
|---|---|---|---|
| 1. Substituir | trocar um slot sem mudar a moldura | 想, 会/能, quantidade | intenção + dois gatilhos |
| 2. Estender | acrescentar informação antes ou depois do núcleo | 给, tempo/lugar, 在/正在 | ação + tempo ou lugar |
| 3. Contrastar | escolher entre formas próximas | 了/过, 没/不, 还是/或者 | situação que exige uma decisão |
| 4. Combinar | ligar duas ações ou intenções | 先……再……, 因为……所以…… | objetivo + restrição |
| 5. Transferir | agir fora da sequência de exemplos | 把, complementos, combinações cumulativas | situação nova, sem resposta visível |

### Combinações cumulativas recomendadas

1. **Desejo + lugar:** `我今天想在家学习。` — Hoje quero estudar em casa.
2. **Capacidade + reparo:** `我听不懂，你能再说一遍吗？` — Não consigo entender; você pode repetir?
3. **Quantidade + pedido + destinatário:** `请给我两杯水。` — Por favor, me dê dois copos de água.
4. **Tempo + lugar + sequência:** `我们明天先在学校见，再一起吃饭。` — Amanhã nos encontramos primeiro na escola e depois comemos juntos.
5. **Experiência + plano:** `我去过北京，所以我想再去。` — Já fui a Pequim, por isso quero ir de novo.
6. **Objeto + resultado:** `请把手机放在桌子上。` — Coloque o celular sobre a mesa, por favor.
7. **Escolha + causa:** `你喝茶还是咖啡？因为我不喝咖啡。` — Você vai tomar chá ou café? É que eu não tomo café.

## Protocolo de recuperação e transferência

Para cada célula, o aluno deve seguir quatro rodadas. Na **rodada 1**, recebe apenas intenção e dois ou três gatilhos em português. Na **rodada 2**, troca um slot, mantendo o restante. Na **rodada 3**, acrescenta uma extensão marcada. Na **rodada 4**, recebe uma situação nova e combina duas funções. A resposta completa só é consultada depois de cada tentativa.

O registro deve separar quatro dimensões: compreensão do sentido, recuperação do padrão, pronúncia funcional e transferência. Um erro de tom não deve ser “corrigido” com mais leitura; deve voltar ao áudio, ao contraste auditivo ou ao feedback humano. O material visual organiza a decisão, mas não escuta a produção.

### Critério geral de domínio do bloco

Considere o bloco funcionalmente dominado quando o aluno consegue:

- produzir pelo menos **três variações** para cada célula escolhida;
- acrescentar uma extensão sem alterar a ordem do núcleo;
- combinar duas células em pelo menos duas situações não exemplificadas;
- selecionar `不`, `没`, `了`, `过`, `会`, `能`, `还是` e `或者` por intenção, não por tradução mecânica;
- manter pronúncia funcional nos pontos trabalhados, com validação auditiva apropriada;
- repetir a transferência com menos suporte visual e sem depender da tradução brasileira.

O objetivo não é cobrir todas as estruturas do mandarim. É tornar visível uma pequena rede de operações e, em seguida, retirar o mapa. Conteúdo genérico, frases sem ação oral e explicações sem decisão observável ficam fora deste bloco.

## Referências

[1]: https://resources.allsetlearning.com/chinese/grammar/Chinese_word_order "Chinese Grammar Wiki — Chinese word order"
[2]: https://resources.allsetlearning.com/chinese/grammar/Indicating_location_with_%22zai%22_before_verbs "Chinese Grammar Wiki — Indicating location with 在 before verbs"
[3]: https://resources.allsetlearning.com/chinese/grammar/Measure_words_for_counting "Chinese Grammar Wiki — Measure words for counting"
[4]: https://resources.allsetlearning.com/chinese/grammar/Expressing_completion_with_%22le%22 "Chinese Grammar Wiki — Expressing completion with 了"
[5]: https://resources.allsetlearning.com/chinese/grammar/Expressing_experiences_with_%22guo%22 "Chinese Grammar Wiki — Expressing experiences with 过"
[6]: https://resources.allsetlearning.com/chinese/grammar/Potential_complement "Chinese Grammar Wiki — Potential complement"
[7]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22haishi%22_and_%22huozhe%22 "Chinese Grammar Wiki — Comparing 还是 and 或者"
[8]: https://resources.allsetlearning.com/chinese/grammar/Using_%22ba%22_sentences "Chinese Grammar Wiki — Using 把 sentences"
[9]: https://resources.allsetlearning.com/chinese/grammar/Sequencing_with_%22xian%22_and_%22zai%22 "Chinese Grammar Wiki — Sequencing with 先 and 再"
[10]: https://resources.allsetlearning.com/chinese/grammar/Cause_and_effect_with_%22yinwei%22_and_%22suoyi%22 "Chinese Grammar Wiki — Cause and effect with 因为 and 所以"
[11]: https://resources.allsetlearning.com/chinese/grammar/Expressing_actions_in_progress_%28full_form%29 "Chinese Grammar Wiki — Expressing actions in progress"
[12]: https://resources.allsetlearning.com/chinese/pronunciation/Tone_change_rules "Chinese Pronunciation Wiki — Tone change rules"
[13]: https://pubmed.ncbi.nlm.nih.gov/21252317/ "Karpicke and Blunt — Retrieval practice produces more learning than elaborative studying with concept mapping"
[14]: https://pubmed.ncbi.nlm.nih.gov/21252317/ "PubMed record for Karpicke and Blunt, Science 2011"
