# 09 — Partículas funcionais

## Síntese editorial

Este bloco não deve apresentar partículas como uma lista de equivalentes de palavras portuguesas. Em mandarim, partículas são palavras funcionais cujo efeito depende da frase, da situação e da atitude do falante. Elas podem marcar uma pergunta, manter uma relação com o interlocutor, propor uma ação, atualizar uma situação, indicar experiência, manter um estado ou conectar uma descrição a um nome. A categoria tradicional reúne partículas aspectuais, estruturais e modais; muitas são átonas ou de tom neutro, mas isso não significa que sejam “sem importância”. [1]

A unidade pedagógica recomendada é a **célula de transferência**: uma ação comunicativa, um padrão curto, poucos slots substituíveis, um contraste auditivo ou pragmático e uma produção oral em contexto novo. O aluno realiza primeiro a recuperação auditiva disponível em sua rota de estudo e consulta este material somente depois. A sequência permanece:

> **Ouvir → tentar responder → visualizar a função → recombinar → transferir sem o mapa.**

O conteúdo abaixo foi filtrado para um adulto brasileiro do nível iniciante ao intermediário inicial que precisa **agir oralmente**, não decorar classificações. Os exemplos são originais e independentes de diálogos, transcrições ou áudios proprietários.

## Escopo e prioridade

| Partícula ou família | Ação oral central | Prioridade | Decisão editorial |
|---|---|---:|---|
| 吗 *ma* | Transformar uma afirmação em pergunta de sim/não | A1 | Núcleo obrigatório |
| 呢 *ne* | Devolver uma pergunta, comparar um tópico ou perguntar pela localização de algo já conhecido | A1–A2 | Núcleo obrigatório |
| 吧 *ba* | Propor, suavizar um pedido ou marcar uma conclusão cautelosa | A1–A2 | Núcleo obrigatório |
| 啊 *a* e variantes de fala | Mostrar reação, concordância, surpresa ou envolvimento | A2 | Núcleo de exposição controlada |
| 了 *le* | Atualizar uma situação ou apresentar uma ação como concluída | A2 | Duas células contrastivas no mesmo mapa |
| 过 *guo* | Perguntar ou relatar experiência anterior | A2 | Núcleo de expansão |
| 着 *zhe* | Apresentar estado mantido ou ação de fundo | B1 inicial | Introdução seletiva |
| 的 *de* | Relacionar pessoa/qualidade a um nome e responder “é meu/seu” | A1–A2 | Núcleo estrutural |
| 得 *de* | Avaliar como uma ação é realizada | A2–B1 | Célula curta de expansão |
| 地 *de* | Formar advérbio escrito a partir de adjetivo | B1–B2 | Reconhecer, não priorizar como célula oral |
| 嘛 *ma*, 呗 *bei*, partículas empilhadas | Atitudes e efeitos discursivos mais finos | B1+ | Adiar para uma revisão avançada |

A separação entre prioridades evita dois erros. O primeiro é ensinar todas as ocorrências de uma mesma sílaba como se fossem uma regra única. O segundo é transformar o bloco em uma aula de metalinguagem. As seis partículas finais mais discutidas em estudos de mandarim incluem 的, 了, 呢, 吧, 吗 e 啊; elas aparecem com alta frequência na conversa, mas seus efeitos são opcionais e dependem do contexto. [10] Para o iniciante, a frequência deve ser convertida em operações observáveis, não em uma promessa de que a partícula tem uma tradução fixa.

## Regras de design para todas as células

1. **A partícula não aparece antes da tentativa.** Na etapa de recuperação, mostrar apenas a intenção em português, uma situação curta ou slots. A resposta completa fica no gabarito do editor.
2. **Pinyin com tom neutro não recebe acento.** Escrever *ma*, *ne*, *ba*, *a*, *le*, *guo*, *zhe*, *de*. O tom neutro é fraco e curto, mas a frase inteira ainda pode ter entonação de pergunta, surpresa ou insistência.
3. **A tradução é funcional.** “呢” pode resultar em “e você?”, “e X?” ou “cadê X?”, dependendo do que já está no foco; nenhuma dessas traduções é a definição universal da partícula.
4. **Um mapa, uma decisão dominante.** Não juntar em uma mesma célula “fazer pergunta com 吗”, “devolver com 呢” e “propor com 吧”. A revisão cumulativa pode contrastá-las depois.
5. **O domínio é oral e transferível.** Reconhecer a partícula na página não aprova a célula. É necessário recuperar sem olhar, trocar slots e agir em uma situação nova.
6. **Não ensinar empilhamento no início.** Partículas finais podem ocorrer juntas em ordens restritas, mas esse fenômeno é objeto de análise própria e não deve ser apresentado como licença para acrescentar partículas por intuição. [10]

---

# Células de transferência

## 1. 吗 *ma* — confirmar uma informação com pergunta de sim/não

### Intenção
Usar uma afirmação como base para confirmar se algo é verdade, se alguém fez algo, se possui uma capacidade ou se uma ação está planejada. A pergunta espera uma resposta positiva ou negativa.

### Padrão ou função

```text
[afirmação completa] + 吗？
[afirmação completa] + ma?
```

A operação é **declarar o conteúdo e anexar uma pergunta**. O conteúdo da frase não muda de ordem apenas porque virou pergunta.

### Exemplos

- 你会说中文吗？  
  *Nǐ huì shuō Zhōngwén ma?*  
  Você fala chinês?

- 你今天有空吗？  
  *Nǐ jīntiān yǒu kòng ma?*  
  Você está livre hoje?

- 这是你的手机吗？  
  *Zhè shì nǐ de shǒujī ma?*  
  Este é o seu celular?

- 他们明天来吗？  
  *Tāmen míngtiān lái ma?*  
  Eles vêm amanhã?

- 你不喝咖啡吗？  
  *Nǐ bù hē kāfēi ma?*  
  Você não toma café? / Você não vai tomar café?

A última forma exige contexto e entonação de confirmação; ela não deve ser a primeira extensão ensinada.

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Sujeito | Quem está em foco | 你 *nǐ*, 他 *tā*, 你们 *nǐmen*, 这家店 *zhè jiā diàn* |
| Tempo | Quando | 今天 *jīntiān*, 明天 *míngtiān*, 现在 *xiànzài* |
| Predicado | Ação, estado ou capacidade | 有空 *yǒu kòng*, 喜欢 *xǐhuan*, 会说中文 *huì shuō Zhōngwén* |
| Objeto ou complemento | O conteúdo confirmado | 咖啡 *kāfēi*, 这个地方 *zhège dìfang*, 你的手机 *nǐ de shǒujī* |

### Extensões controladas

1. **Responder repetindo o verbo ou predicado:**
   - 喜欢。 *Xǐhuan.* — Gosto, sim.
   - 不喜欢。 *Bù xǐhuan.* — Não gosto.
   - 有。 *Yǒu.* — Tenho / tem.
   - 没有。 *Méiyǒu.* — Não tenho / não tem.

   Essa estratégia é mais clara que procurar uma palavra universal equivalente a “sim” e “não”. A resposta normalmente retoma o núcleo verbal da pergunta. [2]

2. **Trocar uma pergunta sobre identidade por uma pergunta sobre ação:**
   - 你是巴西人吗？ *Nǐ shì Bāxī rén ma?* — Você é brasileiro(a)?
   - 你住在巴西吗？ *Nǐ zhù zài Bāxī ma?* — Você mora no Brasil?

3. **Contrastar com palavra interrogativa:** não acrescentar 吗 a uma pergunta que já contém 什么 *shénme*, 谁 *shéi*, 哪儿 *nǎr* ou 为什么 *wèishénme* em seu uso básico. *你是谁吗？* não é a forma-alvo para “Quem é você?”. [2]

### Observação pedagógica

Ensinar 吗 como “o ponto de interrogação falado” é uma boa ponte inicial, mas não deve virar uma tradução mecânica. O aluno precisa aprender a produzir a afirmação inteira antes de anexar a partícula. O alerta de contraste prioritário é **吗 versus palavra interrogativa**: a presença de uma palavra como “quem” ou “onde” já constrói outro tipo de pergunta. Outro alerta é a resposta: *对 duì* confirma uma proposição, mas repetir o verbo reduz a ambiguidade, sobretudo quando a pergunta já está na negativa. [2]

Na pronúncia, *ma* é fraco e neutro. A força interrogativa vem do contorno da frase, não de transformar *ma* em uma sílaba forte com o terceiro ou quarto tom. Não se deve ensinar que toda pergunta em mandarim precisa de uma grande subida final.

### Potencial de mapa

**Mapa de função + mapa de padrão.** Núcleo: “confirmar”. Ramo fixo: afirmação completa. Ramo variável: sujeito, tempo, predicado e objeto. Ramo vermelho: “palavra interrogativa não recebe 吗 automaticamente”. Ramo laranja: *ma* neutro. O mapa lacunado deve apagar somente 吗 e um slot por vez. O mapa mínimo deve mostrar apenas “confirmar se a pessoa tem tempo hoje” ou “confirmar se alguém fala chinês”.

### Prompt de recuperação

Mostrar apenas:

> Você quer confirmar se a pessoa fala chinês. Produza a pergunta inteira, sem ler uma frase pronta.

Gabarito do editor: 你会说中文吗？ *Nǐ huì shuō Zhōngwén ma?*

### Prompt de transferência

Sem mostrar a resposta, peça ao aluno para confirmar oralmente três informações novas: se um colega está livre amanhã; se uma pessoa gosta de chá; se uma loja abre hoje. O aluno deve escolher os verbos e objetos disponíveis no próprio repertório, não repetir os exemplos desta seção.

### Critério de domínio

A célula está dominada quando o aluno produz, em até três segundos após cada intenção, **quatro perguntas diferentes**, com pelo menos três predicados, sem colocar 吗 em pergunta com palavra interrogativa; responde a duas delas retomando o predicado na forma afirmativa e negativa; e mantém *ma* curto e não acentuado. Uma resposta reconhecida visualmente não conta.

---

## 2. 呢 *ne* — devolver o foco, comparar tópicos ou perguntar “onde está?”

### Intenção
Manter o fluxo da interação depois de responder, pedir a informação correspondente sobre outra pessoa ou coisa, comparar dois tópicos ou perguntar pela localização de algo que já está identificado no contexto.

### Padrão ou função

```text
[tópico conhecido] + 呢？
[tópico A + informação]. [tópico B] + 呢？
```

O conteúdo omitido é recuperado da situação. Por isso 呢 não é simplesmente “e” nem uma versão suave de todos os tipos de pergunta.

### Exemplos

- 我住在圣保罗。你呢？  
  *Wǒ zhù zài Shèngbǎoluó. Nǐ ne?*  
  Eu moro em São Paulo. E você?

- 这个很好，那个呢？  
  *Zhège hěn hǎo, nàge ne?*  
  Este é muito bom; e aquele?

- 你爸爸是医生，你妈妈呢？  
  *Nǐ bàba shì yīshēng, nǐ māma ne?*  
  Seu pai é médico; e sua mãe?

- 我的手机呢？  
  *Wǒ de shǒujī ne?*  
  Cadê meu celular?

- 今天晚上没空，明天晚上呢？  
  *Jīntiān wǎnshang méi kòng, míngtiān wǎnshang ne?*  
  Hoje à noite não tenho tempo; e amanhã à noite?

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Tópico | Pessoa, objeto, lugar ou tempo em foco | 你 *nǐ*, 你们 *nǐmen*, 我的妈妈 *wǒ de māma*, 明天 *míngtiān* |
| Informação recuperada | O predicado que não precisa ser repetido | mora em…, tem tempo, gosta de…, está em… |
| Par de contraste | Segundo elemento comparado | 这个/那个, 今天/明天, 北京/上海 |

### Extensões controladas

1. **Tópico isolado para localização:** 钱呢？ *Qián ne?* — E o dinheiro? / Cadê o dinheiro? Essa leitura só é natural quando o interlocutor sabe qual dinheiro está em questão.
2. **Pergunta com predicado explícito e atitude de acompanhamento:** 你在做什么呢？ *Nǐ zài zuò shénme ne?* — O que você está fazendo? Aqui a frase já contém a informação interrogativa; 呢 enquadra a pergunta como algo em andamento ou de interesse no momento.
3. **Comparar disponibilidade:** 你今天有空，明天呢？ *Nǐ jīntiān yǒu kòng, míngtiān ne?* — Hoje você tem tempo; e amanhã?

### Observação pedagógica

Começar com a operação conversacional mais estável: **responder sobre si e devolver com 你呢？**. Depois acrescentar contraste de tópicos. Só então apresentar a leitura “cadê X?”, porque ela depende de referência compartilhada. A tradução natural muda de acordo com o foco; o aluno deve aprender a perguntar “qual é o tópico que estou devolvendo?”, e não a memorizar um único equivalente.

*Ne* é normalmente neutro e curto. Não é necessário alongá-lo nem dar a ele um tom lexical forte. O contraste principal é **呢 versus 吗**: 吗 cria uma pergunta de sim/não a partir de uma proposição; 呢 frequentemente deixa uma informação implícita e reabre ou desloca o foco. Nem toda pergunta em português com “e você?” deve ser traduzida palavra por palavra; a situação decide.

### Potencial de mapa

**Mapa de foco conversacional.** Núcleo: “devolver ou comparar”. Primeiro ramo: “eu → você”. Segundo: “A → B”. Terceiro: “objeto esperado → localização”. Setas devem mostrar o que foi dito e o que fica implícito. No estado de recuperação, apagar o tópico final e pedir que o aluno o reconstrua. No estado mínimo, fornecer apenas “você respondeu onde mora; devolva a pergunta”.

### Prompt de recuperação

Mostrar apenas:

> Você acabou de dizer onde mora. Pergunte à outra pessoa onde ela mora, sem repetir o predicado.

Gabarito do editor: 我住在圣保罗。你呢？ *Wǒ zhù zài Shèngbǎoluó. Nǐ ne?*

### Prompt de transferência

Peça três ações sem resposta-modelo: devolver a pergunta depois de dizer o idioma que fala; comparar hoje e amanhã quanto à disponibilidade; perguntar pelo celular que estava sendo procurado. O aluno deve escolher tópicos coerentes e manter a elipse natural.

### Critério de domínio

O aluno domina a célula quando usa 呢 corretamente em **três operações distintas** — devolução pessoal, contraste entre tópicos e localização contextual —, produz pelo menos duas combinações novas e não troca 呢 por 吗. Em uma gravação ou interação com tutor, a pergunta deve soar curta, sem preencher artificialmente o predicado omitido.

---

## 3. 吧 *ba* — propor, suavizar ou marcar uma conclusão cautelosa

### Intenção
Convidar alguém a fazer algo junto, formular uma sugestão ou pedido menos impositivo e, em extensão posterior, apresentar uma suposição que o falante não quer afirmar como certeza absoluta.

### Padrão ou função

```text
[proposta ou pedido] + 吧。
[afirmação cautelosa] + 吧。
```

Com **我们 wǒmen** e um verbo, a estrutura normalmente funciona como “vamos…”. A partícula não é um marcador universal de cortesia; ela ajusta a atitude do enunciado.

### Exemplos

- 我们休息一下吧。  
  *Wǒmen xiūxi yíxià ba.*  
  Vamos fazer uma pausa.

- 我们走吧。  
  *Wǒmen zǒu ba.*  
  Vamos.

- 请坐吧。  
  *Qǐng zuò ba.*  
  Pode sentar / Sente-se, por favor.

- 给我一杯水吧。  
  *Gěi wǒ yì bēi shuǐ ba.*  
  Me dá um copo de água, por favor.

- 应该是吧。  
  *Yīnggāi shì ba.*  
  Acho que sim / Deve ser.

- 我们六点去吧？  
  *Wǒmen liù diǎn qù ba?*  
  Vamos às seis, então? / Pode ser às seis?

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Participantes | Quem age junto ou recebe o pedido | 我们 *wǒmen*, 你 *nǐ*, vocês, interlocutor em contexto |
| Verbo | A ação proposta | 走 *zǒu*, 休息 *xiūxi*, 看 *kàn*, 等 *děng* |
| Complemento | Lugar, objeto ou duração | 一下 *yíxià*, 在这里 *zài zhèlǐ*, 明天 *míngtiān*, 两个 *liǎng ge* |
| Grau de certeza | Conteúdo avaliado | 应该是 *yīnggāi shì*, 可能是 *kěnéng shì* |

### Extensões controladas

1. **Proposta conjunta:** 我们明天见吧。 *Wǒmen míngtiān jiàn ba.* — Vamos nos ver amanhã.
2. **Pedido mitigado:** 再说一遍吧。 *Zài shuō yí biàn ba.* — Fala mais uma vez, por favor / Vamos repetir uma vez.
3. **Concessão:** 好吧。 *Hǎo ba.* — Está bem, então. Essa forma pode aceitar algo sem entusiasmo; não ensinar como sinônimo neutro de “ótimo”.
4. **Hipótese cautelosa:** 他应该知道吧。 *Tā yīnggāi zhīdào ba.* — Ele provavelmente sabe, não é?

### Observação pedagógica

O primeiro mapa deve conter apenas **proposta conjunta**. A extensão de pedido e a de inferência têm efeitos sociais diferentes e precisam de exemplos separados. A diferença prática para 吗 é decisiva: 吗 pede confirmação binária; 吧 convida a alinhar uma ação ou reduz a força de uma afirmação. [4] [5]

O tom de *ba* é neutro. A decisão social vem da frase, do verbo e da entonação; uma ordem com 吧 ainda pode ser uma ordem. Em registro formal, não presumir que acrescentar 吧 resolve a polidez: usar também vocabulário apropriado, como 请 *qǐng*, quando necessário. A tradução “vamos” funciona bem com 我们 + verbo, mas não com todos os usos.

### Potencial de mapa

**Mapa de alinhamento entre falantes.** Núcleo: “propor sem impor”. Ramo 1: ação conjunta. Ramo 2: pedido. Ramo 3: hipótese. Ramo vermelho: “吗 pergunta; 吧 propõe ou suaviza”. O mapa completo deve mostrar a intenção antes da partícula. O mapa lacunado alterna verbo e complemento. O prompt mínimo deve mostrar somente “sugerir uma pausa” ou “dizer que provavelmente está certo”.

### Prompt de recuperação

Mostrar apenas:

> Você quer convidar a outra pessoa para fazer uma pausa. Produza uma proposta conjunta curta.

Gabarito do editor: 我们休息一下吧。 *Wǒmen xiūxi yíxià ba.*

### Prompt de transferência

Peça que o aluno faça oralmente três ações novas: propor um encontro amanhã; pedir que alguém repita; aceitar uma opção com “está bem, então”. Em uma rodada adicional, peça uma inferência cautelosa sobre a disponibilidade de alguém. Não forneça a partícula no prompt inicial.

### Critério de domínio

A célula está dominada quando o aluno produz uma proposta conjunta, um pedido mitigado e uma conclusão cautelosa, cada um com vocabulário próprio, sem usar 吗 como substituto. Também deve conseguir retirar 吧 e explicar oralmente que a frase fica mais direta ou menos enquadrada, sem afirmar que a partícula é simplesmente “por favor”.

---

## 4. 啊 *a* — mostrar reação, concordância ou envolvimento

### Intenção
Sinalizar ao interlocutor que o falante reconhece, confirma, se surpreende, aceita ou reage afetivamente ao conteúdo. A partícula acrescenta uma camada interacional; não é necessária para construir o conteúdo básico.

### Padrão ou função

```text
[afirmação, avaliação ou confirmação] + 啊。
[avaliação ou exclamação] + 啊！
```

Na fala, o som pode aparecer com variantes ortográficas como 呀 *ya* ou 哇 *wa* em contextos específicos. Para o iniciante, o alvo é reconhecer e produzir a função de envolvimento com **啊**, sem decorar uma tabela de alomorfes.

### Exemplos

- 是啊。  
  *Shì a.*  
  É mesmo / Pois é.

- 好啊。  
  *Hǎo a.*  
  Claro / Ótimo.

- 你也来了啊！  
  *Nǐ yě lái le a!*  
  Você veio também!

- 这么快啊！  
  *Zhème kuài a!*  
  Nossa, tão rápido!

- 原来是你啊。  
  *Yuánlái shì nǐ a.*  
  Ah, então era você.

- 对啊，我知道。  
  *Duì a, wǒ zhīdào.*  
  Sim, eu sei / Pois é, eu sei.

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Avaliação | Qualidade ou intensidade | 快 *kuài*, 好 *hǎo*, 便宜 *piányi*, 远 *yuǎn* |
| Confirmação | Acordo ou reconhecimento | 是 *shì*, 对 *duì*, 好 *hǎo* |
| Conteúdo novo | Informação que provoca reação | 你也来了, 他会说中文, 今天下雨 |
| Intenção prosódica | Aceitar, surpreender, reconhecer | tom caloroso, surpresa, confirmação, alívio |

### Extensões controladas

1. **Concordar:** 对啊。 *Duì a.* — Pois é / Exatamente.
2. **Aceitar:** 好啊。 *Hǎo a.* — Claro / Vamos.
3. **Reagir a uma mudança percebida:** 你长大了啊！ *Nǐ zhǎng dà le a!* — Você cresceu!
4. **Acompanhar uma descoberta:** 原来你住在这儿啊。 *Yuánlái nǐ zhù zài zhèr a.* — Ah, então você mora aqui.

### Observação pedagógica

啊 deve ser ensinado como **gesto de participação na conversa**, não como “uma palavra que significa emoção”. O aluno precisa ouvir a frase sem 啊 e depois comparar o efeito com 啊. A mesma sequência pode soar acolhedora, surpresa ou insistente conforme o contorno melódico. Por isso, um PDF com pinyin não pode alegar corrigir sozinho a prosódia.

A partícula é fraca, mas a frase pode ser expressiva. Evitar pronunciar um “á” português forte em cada ocorrência. No registro formal escrito, o uso excessivo pode parecer coloquial; na fala cotidiana, é comum. O contraste a proteger é **啊 versus 啊 como interjeição isolada**: este bloco trabalha a posição final ligada a um enunciado, não um inventário de exclamações.

### Potencial de mapa

**Mapa de atitude.** Núcleo: “reagir ao que acabou de aparecer”. Ramos: concordar, aceitar, surpreender-se, reconhecer. Cada ramo recebe a mesma base sem partícula e a base com 啊. O mapa de contraste deve registrar que a partícula não altera o fato principal, mas altera a relação com o interlocutor. No estado mínimo, só aparece uma situação: “a pessoa chegou quando você não esperava”.

### Prompt de recuperação

Mostrar apenas:

> Você concorda com entusiasmo moderado e quer soar envolvido, não seco. Diga “é mesmo / pois é”.

Gabarito do editor: 是啊。 *Shì a.*

### Prompt de transferência

Peça uma reação para quatro situações: alguém chegou cedo; a proposta é aceitável; o interlocutor revela uma informação inesperada; o falante percebe que já conhecia a pessoa. O aluno pode escolher o vocabulário, mas deve fazer a partícula apoiar a intenção, não preencher todas as frases automaticamente.

### Critério de domínio

O aluno domina a célula quando produz e diferencia oralmente pelo menos três atitudes — concordância, aceitação e surpresa —, usa 啊 em no máximo as falas em que há motivo interacional e não o acrescenta como vício em toda frase. Em avaliação, a adequação prosódica deve ser julgada por um interlocutor ou áudio de referência; a leitura do pinyin não basta.

---

## 5. 了 *le* — atualizar uma situação e apresentar uma ação como concluída

### Intenção
Usar duas operações relacionadas, mas não idênticas: **(A) informar que uma ação foi concluída no quadro relevante** e **(B) sinalizar que a situação mudou e agora vale algo diferente**. A divisão é indispensável para evitar ensinar 了 como “passado”.

### Padrões ou funções

**Célula A — ação concluída:**

```text
Sujeito + verbo + 了 (+ objeto).
```

**Célula B — mudança de situação:**

```text
[estado ou evento novo] + 了。
```

A partícula marca aspecto ou mudança de estado, não um tempo verbal único. A posição, o tipo de predicado e o contexto mudam a leitura. [6] [11]

### Exemplos

**Ação apresentada como concluída**

- 我吃了饭。  
  *Wǒ chī le fàn.*  
  Eu comi / Já fiz a refeição.

- 她买了两杯咖啡。  
  *Tā mǎi le liǎng bēi kāfēi.*  
  Ela comprou dois cafés.

- 我看了这个电影。  
  *Wǒ kàn le zhège diànyǐng.*  
  Eu assisti a esse filme.

**Mudança de situação**

- 下雨了。  
  *Xiàyǔ le.*  
  Começou a chover / Agora está chovendo.

- 我明白了。  
  *Wǒ míngbai le.*  
  Agora entendi.

- 我不喝咖啡了。  
  *Wǒ bù hē kāfēi le.*  
  Eu não tomo mais café / Parei de tomar café.

- 快迟到了。  
  *Kuài chídào le.*  
  Está quase na hora de se atrasar / Vamos nos atrasar.

### Slots substituíveis

| Parte | Célula A: conclusão | Célula B: mudança |
|---|---|---|
| Predicado | 吃 *chī*, 买 *mǎi*, 看 *kàn* | 下雨 *xiàyǔ*, 明白 *míngbai*, 累 *lèi* |
| Objeto | 饭 *fàn*, 咖啡 *kāfēi*, 电影 *diànyǐng* | Pode não haver objeto |
| Quadro temporal | 今天, 刚才, 已经 | agora, a partir de agora, finalmente |
| Negação | 没 + verbo para não ter concluído | 不/别 + predicado + 了 para “não mais / pare de” em padrões específicos |

### Extensões controladas

1. **Pergunta sobre uma ação relevante:** 你吃饭了吗？ *Nǐ chīfàn le ma?* — Você já comeu? Este padrão combina 了 com 吗; introduzi-lo somente depois de cada partícula estar estável.
2. **Mudança a partir de agora:** 我不买了。 *Wǒ bù mǎi le.* — Não vou comprar mais / Desisti da compra.
3. **Atualização imediata:** 电影开始了！ *Diànyǐng kāishǐ le!* — O filme começou!
4. **Duração até o momento:** 我在北京住了两年了。 *Wǒ zài Běijīng zhù le liǎng nián le.* — Moro em Pequim há dois anos. Adiar este formato se a distinção entre as duas ocorrências gerar sobrecarga.

### Observação pedagógica

O mapa deve ter dois ramos com perguntas diferentes:

- **O que foi feito dentro do quadro?** → verbo + 了.
- **O que mudou agora?** → situação + 了.

Não traduzir automaticamente 了 por “já”, “foi” ou “-ou”. Na negativa, **没** normalmente nega uma ação concluída ou uma experiência; **不…了** pode anunciar que algo não continuará ou não será feito a partir de agora. O contraste não é uma regra única de passado e presente. A descrição de 了 como partícula de conclusão e de mudança de estado é uma simplificação didática útil, desde que o aluno pratique os contextos e não uma equivalência fixa. [6]

Na pronúncia, *le* é fraco e neutro. O aluno brasileiro tende a ouvir uma sílaba plena e tentar acentuá-la; a atenção deve ir para o verbo, o objeto e o contorno de atualização. Não ensinar 了 com muitos tipos de complemento na mesma sessão.

### Potencial de mapa

**Mapa de contraste com dois núcleos.** Núcleo superior: “o quadro da ação”. Núcleo inferior: “a situação agora”. Cor vermelha para “não é passado automático”; cor laranja para *le* neutro; cor verde para os slots verbais. A versão de recuperação apresenta seis situações e exige que o aluno escolha qual ramo usar. A versão mínima apresenta somente “agora entendi” ou “já comprei o café”.

### Prompt de recuperação

Mostrar apenas um estímulo por vez:

1. Você informa que já fez a refeição.
2. Você percebe que começou a chover.
3. Você decidiu que não vai mais comprar o café.

Gabaritos do editor: 我吃了饭。*Wǒ chī le fàn.* / 下雨了。*Xiàyǔ le.* / 我不买了。*Wǒ bù mǎi le.*

### Prompt de transferência

Sem mostrar respostas, apresente quatro mudanças de contexto: uma pessoa terminou uma tarefa; uma loja fechou agora; o aluno finalmente entendeu uma instrução; o aluno decidiu parar de esperar. Em uma rodada separada, peça duas frases sobre ações concluídas com objetos diferentes. O avaliador deve perguntar qual dos dois ramos o aluno escolheu e por quê, em português, somente depois da produção.

### Critério de domínio

A célula está dominada quando o aluno escolhe o ramo adequado em **oito estímulos mistos**, produz pelo menos três frases de conclusão e três de mudança, usa 没 quando nega uma ação não realizada e usa 不…了 em uma mudança de decisão sem depender de tradução palavra por palavra. Não aprovar se o aluno simplesmente acrescenta 了 a todos os verbos no passado.

---

## 6. 过 *guo* — relatar experiência anterior

### Intenção
Perguntar ou dizer se alguém já teve determinada experiência pelo menos uma vez, sem precisar indicar quando ocorreu. O foco é a experiência disponível, não um evento passado específico.

### Padrão ou função

```text
Sujeito + verbo + 过 + objeto.
Sujeito + verbo + 过 + objeto + 吗？
Sujeito + 没 + verbo + 过 + objeto.
```

No uso aspectual, escrever e produzir *guo* sem acento de tom lexical. O verbo **过 guò**, “atravessar/passar”, é outra palavra.

### Exemplos

- 你去过上海吗？  
  *Nǐ qùguo Shànghǎi ma?*  
  Você já foi a Xangai?

- 你学过中文吗？  
  *Nǐ xuéguo Zhōngwén ma?*  
  Você já estudou chinês?

- 我吃过四川菜。  
  *Wǒ chīguo Sìchuān cài.*  
  Eu já comi comida de Sichuan.

- 我没看过这部电影。  
  *Wǒ méi kànguo zhè bù diànyǐng.*  
  Eu nunca assisti a esse filme / Não assisti a esse filme antes.

- 我还没试过。  
  *Wǒ hái méi shìguo.*  
  Ainda não experimentei.

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Verbo de experiência | Tipo de vivência | 去 *qù*, 吃 *chī*, 看 *kàn*, 学 *xué*, 试 *shì* |
| Objeto ou destino | O que foi vivenciado | 上海, 四川菜, 这部电影, 中文 |
| Intensificador temporal | Ausência ou novidade da experiência | 还没 *hái méi*, 从来没 *cónglái méi* |

### Extensões controladas

1. **Perguntar por uma experiência comum:** 你坐过飞机吗？ *Nǐ zuòguo fēijī ma?* — Você já andou de avião?
2. **Responder com negação de experiência:** 我没去过。 *Wǒ méi qùguo.* — Nunca fui / Não fui antes.
3. **Contrastar experiência com evento específico:**
   - 我去过北京。 *Wǒ qùguo Běijīng.* — Já fui a Pequim alguma vez.
   - 我去年去了北京。 *Wǒ qùnián qù le Běijīng.* — Fui a Pequim no ano passado.

A segunda frase informa um evento delimitado; a primeira apresenta um repertório de experiência. O contraste não precisa ser explicado por termos técnicos para ser praticado.

### Observação pedagógica

A pergunta operacional é **“isso já fez parte da experiência da pessoa?”**. Se o falante quer localizar um evento em um momento específico, usar uma expressão temporal e escolher outro padrão. A negação prototípica de 过 é **没 + verbo + 过**, não *不 + verbo + 过*. [7]

O tom do uso aspectual é neutro; não confundir com *guò* lexical. O aluno brasileiro pode traduzir *guo* como “foi” e perder a diferença entre “já tive essa experiência” e “fiz isso naquela ocasião”. Use cartões de situação, não listas de verbos isolados.

### Potencial de mapa

**Mapa de experiência.** Núcleo: “já vivi isso?”. Ramos: lugar, comida, mídia, estudo e transporte. Um ramo vermelho liga 过 a “experiência sem data” e 了 a “evento concluído em um quadro”. A recuperação deve alternar pergunta afirmativa, resposta afirmativa e resposta negativa. O prompt mínimo deve mostrar apenas “pergunte se a pessoa já estudou chinês”.

### Prompt de recuperação

Mostrar apenas:

> Pergunte se a pessoa já foi a Xangai alguma vez. Não mencione quando.

Gabarito do editor: 你去过上海吗？ *Nǐ qùguo Shànghǎi ma?*

### Prompt de transferência

Peça ao aluno para perguntar e responder sobre três experiências que façam sentido para sua vida: já provar uma comida, já assistir a um filme e já estudar um idioma. Em seguida, forneça um ano ou uma data e peça que o aluno troque para um relato de evento específico com 了, sem usar 过 automaticamente.

### Critério de domínio

O aluno domina quando produz cinco enunciados sobre experiências, nega duas experiências com 没, responde a uma pergunta de 过 sem introduzir uma data desnecessária e diferencia oralmente “já tive essa experiência” de “fiz isso em tal momento” em pelo menos três pares. *Guo* deve permanecer curto e não receber o quarto tom lexical.

---

## 7. 着 *zhe* — manter um estado ou descrever a ação de fundo

### Intenção
Apresentar uma condição que continua válida, como uma porta aberta ou uma roupa vestida, ou indicar que uma ação ocorre enquanto um estado é mantido. O foco não é simplesmente “estar fazendo” uma ação agora.

### Padrão ou função

**Estado mantido:**

```text
verbo + 着
```

**Estado de fundo + ação principal:**

```text
verbo 1 + 着 + verbo 2
```

### Exemplos

- 门开着。  
  *Mén kāizhe.*  
  A porta está aberta.

- 她穿着红衣服。  
  *Tā chuānzhe hóng yīfu.*  
  Ela está usando roupa vermelha.

- 你坐着，我马上回来。  
  *Nǐ zuòzhe, wǒ mǎshàng huílái.*  
  Fique sentado; já volto.

- 他笑着说谢谢。  
  *Tā xiàozhe shuō xièxie.*  
  Ele disse “obrigado” sorrindo.

- 请等着。  
  *Qǐng děngzhe.*  
  Espere aí / Aguarde.

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Verbo de estado | Condição mantida | 开 *kāi*, 关 *guān*, 穿 *chuān*, 戴 *dài*, 坐 *zuò* |
| Objeto | O que permanece em estado | 门 *mén*, 外套 *wàitào*, 帽子 *màozi* |
| Ação principal | O que ocorre com o estado de fundo | 说 *shuō*, 吃 *chī*, 看 *kàn* |

### Extensões controladas

1. **Porta, janela ou luz em estado:** 灯开着。 *Dēng kāizhe.* — A luz está acesa.
2. **Vestir ou portar algo:** 他戴着眼镜。 *Tā dàizhe yǎnjìng.* — Ele está usando óculos.
3. **Instrução para manter uma condição:** 你听着。 *Nǐ tīngzhe.* — Escuta / Presta atenção e continua ouvindo.
4. **Maneira de realizar uma ação:** 她站着吃饭。 *Tā zhànzhe chīfàn.* — Ela come em pé.

### Observação pedagógica

Introduzir 着 com estados perceptíveis, não com a tradução inglesa “-ing”. Em muitos contextos, **在 zài + verbo** apresenta uma ação em progresso, enquanto **verbo + 着** mantém um estado ou coloca uma ação como fundo. Assim, “a porta está aberta” e “ela está abrindo a porta” não devem ser tratados como a mesma operação. A descrição de 着 como aspecto contínuo é compatível com essa diferença, mas a escolha é lexical e contextual. [8]

*Zhe* é neutro no uso aspectual. Não confundir com *zháo* em palavras como 睡着 *shuìzháo* (“adormecer”) nem com *zhuó* em outros usos do caractere. Por ser menos produtivo para o iniciante, limitar os verbos a estados frequentes e observar a naturalidade; não criar frases artificiais com qualquer verbo de movimento.

### Potencial de mapa

**Mapa de estado versus ação.** Núcleo: “o que continua válido?”. Ramo 1: objeto em estado. Ramo 2: pessoa mantendo posição/condição. Ramo 3: estado que acompanha ação. Ramo vermelho: 在 + verbo de ação não é substituição automática de 着. A versão lacunada oferece a imagem ou situação e pede o verbo + partícula; a versão mínima oferece “a porta está aberta” ou “fale sorrindo”.

### Prompt de recuperação

Mostrar apenas:

> Descreva uma porta que permanece aberta. Não diga que alguém está abrindo a porta agora.

Gabarito do editor: 门开着。 *Mén kāizhe.*

### Prompt de transferência

Peça quatro produções: uma luz acesa, uma pessoa usando chapéu, alguém esperando enquanto você retorna e uma pessoa falando sorrindo. Em cada caso, o aluno deve escolher se o foco é estado mantido ou ação de fundo.

### Critério de domínio

A célula está dominada quando o aluno produz quatro estados mantidos naturais, uma estrutura de estado + ação e explica, por meio de um exemplo, por que **在看** não é automaticamente intercambiável com **看着**. O aluno não precisa dominar todos os usos de 着; precisa reconhecer o estado-alvo e produzi-lo funcionalmente.

---

## 8. 的 *de* — relacionar posse ou descrição a um nome

### Intenção
Identificar a quem algo pertence, atribuir uma qualidade a um substantivo ou recuperar um nome omitido quando a relação já está clara. É uma ferramenta de encaixe: “X relacionado a Y”.

### Padrão ou função

**Posse ou relação:**

```text
[possuidor] + 的 + [nome]
```

**Qualidade ou descrição antes do nome:**

```text
[descrição] + 的 + [nome]
```

**Nome omitido:**

```text
[possuidor] + 的
```

### Exemplos

- 我的手机  
  *Wǒ de shǒujī*  
  meu celular

- 这是你的包吗？  
  *Zhè shì nǐ de bāo ma?*  
  Esta é a sua bolsa?

- 那是我朋友的车。  
  *Nà shì wǒ péngyou de chē.*  
  Aquele é o carro do meu amigo.

- 我喜欢中国菜。  
  *Wǒ xǐhuan Zhōngguó cài.*  
  Eu gosto de comida chinesa.

- 红色的衣服  
  *Hóngsè de yīfu*  
  roupa vermelha

- 这个是我的。  
  *Zhège shì wǒ de.*  
  Este é meu / Esta é minha.

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Relação/possuidor | Quem ou o que se relaciona | 我 *wǒ*, 你 *nǐ*, 他 *tā*, 我朋友 *wǒ péngyou*, 公司 *gōngsī* |
| Nome | O item relacionado | 手机 *shǒujī*, 包 *bāo*, 车 *chē*, 老师 *lǎoshī* |
| Descrição | Qualidade, origem ou categoria | 红色 *hóngsè*, 中国 *Zhōngguó*, 昨天买 *zuótiān mǎi* |

### Extensões controladas

1. **Responder com posse sem repetir o nome:** 这是你的吗？ *Zhè shì nǐ de ma?* — Isto é seu? / 这是我的。*Zhè shì wǒ de.* — É meu.
2. **Relação de pessoa + nome:** 我妈妈的朋友 *wǒ māma de péngyou* — amigo da minha mãe.
3. **Descrição mais longa:** 我昨天买的书 *wǒ zuótiān mǎi de shū* — o livro que comprei ontem. Introduzir somente depois de a posse curta estar estável.
4. **Omissão em relações muito próximas:** 我的妈妈 *wǒ de māma* é possível, mas em relações familiares próximas muitas vezes se ouve 我妈妈 *wǒ māma*. Ensinar o padrão produtivo sem declarar que 的 é obrigatório em toda relação.

### Observação pedagógica

Começar por **meu/seu + objeto** e pela resposta isolada **我的**, porque são operações imediatamente úteis. Depois contrastar com 有 *yǒu*: 我的手机 significa “meu celular”; 我有手机 significa “eu tenho celular”. A partícula não é o verbo “ter”.

O *de* estrutural é geralmente neutro. Na fala, algumas relações frequentes omitem 的; isso não invalida o padrão, mas impede a regra artificial “sempre use 的”. O caractere da posse/atribuição é 的. Não misturar neste mapa 的 com 得 e 地; o pinyin coincide, mas a posição e a função são diferentes. A partícula final modal 的 deve ser adiada para não colidir com a célula de posse.

### Potencial de mapa

**Mapa de relação.** Núcleo: “de quem/que tipo é o nome?”. Ramo 1: possuidor + nome. Ramo 2: descrição + nome. Ramo 3: nome omitido. O mapa deve desenhar a direção chinesa **relacionador → 的 → nome**, em contraste com estruturas portuguesas que frequentemente colocam a relação depois. A versão mínima mostra apenas “aponte para o celular e diga que é seu”.

### Prompt de recuperação

Mostrar apenas:

> Aponte para uma bolsa e diga que ela é sua. Depois diga “esta é minha”, sem repetir bolsa.

Gabarito do editor: 这是你的包。*Zhè shì nǐ de bāo.* / 这是我的。*Zhè shì wǒ de.*

### Prompt de transferência

Peça ao aluno que produza três relações novas: o celular de um amigo, uma roupa preta e um objeto que pertence à empresa. Depois, mostre dois objetos e peça respostas curtas com **我的 / 你的 / 他的**, sem deixar o nome visível no prompt.

### Critério de domínio

O aluno domina quando constrói cinco grupos de relação com 的, responde a duas perguntas de posse com **我的/你的/他的**, omite o nome apenas quando o referente está claro e não troca 的 por 有. Também deve distinguir visual e oralmente 的 em **我的手机** de 得 em **说得很快**.

---

## 9. 得 *de* — avaliar o modo ou o grau de uma ação

### Intenção
Dizer como uma ação é realizada, ou avaliar o grau/qualidade alcançado por ela. Esta célula é valiosa para pedidos de ajuste na interação: falar mais devagar, explicar claramente, fazer bem ou fazer mal.

### Padrão ou função

```text
verbo + 得 + complemento de grau ou maneira
```

O complemento vem depois de 得 e descreve o desempenho da ação, não um nome possuído.

### Exemplos

- 你说得很清楚。  
  *Nǐ shuō de hěn qīngchu.*  
  Você explica/fala muito claramente.

- 你说得太快了。  
  *Nǐ shuō de tài kuài le.*  
  Você fala rápido demais.

- 她唱得很好。  
  *Tā chàng de hěn hǎo.*  
  Ela canta muito bem.

- 我做得不太好。  
  *Wǒ zuò de bú tài hǎo.*  
  Eu não faço muito bem / Não ficou muito bom.

- 你中文说得不错。  
  *Nǐ Zhōngwén shuō de búcuò.*  
  Você fala chinês bem.

### Slots substituíveis

| Parte | Função | Exemplos de substituição |
|---|---|---|
| Verbo | Ação avaliada | 说 *shuō*, 做 *zuò*, 唱 *chàng*, 写 *xiě*, 开 *kāi* |
| Complemento | Grau ou modo | 很清楚 *hěn qīngchu*, 太快 *tài kuài*, 很好 *hěn hǎo*, 不错 *búcuò* |
| Sujeito/objeto topicalizado | Quem ou qual habilidade | 你, 她, 我, 中文 |

### Extensões controladas

1. **Ajustar a interação:** 请你说得慢一点。 *Qǐng nǐ shuō de màn yìdiǎn.* — Fale um pouco mais devagar, por favor.
2. **Elogiar desempenho:** 你做得很好。 *Nǐ zuò de hěn hǎo.* — Você fez muito bem.
3. **Avaliar compreensão auditiva:** 他说得不清楚。 *Tā shuō de bù qīngchu.* — Ele fala de um jeito pouco claro.
4. **Comparar com 的:** 我的中文书 *wǒ de Zhōngwén shū* — meu livro de chinês; 中文说得好 *Zhōngwén shuō de hǎo* — falar chinês bem.

### Observação pedagógica

Ensinar 得 por uma necessidade de interação, não por uma definição de “complemento”. O aluno quer pedir velocidade, avaliar clareza ou elogiar um desempenho. A posição é o principal contraste: **的 vem antes de um nome; 得 vem depois do verbo e antes da avaliação**. A forma 地, que também se escreve *de*, não deve ser misturada nesta primeira célula.

O *de* de 得 é neutro e curto. Os exemplos devem usar verbos com avaliações naturais; não vale gerar combinações gramaticalmente possíveis, mas pouco usuais, apenas para preencher slots. O padrão pode ocorrer com complementos mais complexos, mas o núcleo oral inicial deve ficar em 很好, 很快, 很清楚, 不错 e 慢一点.

### Potencial de mapa

**Mapa de desempenho.** Núcleo: “como a ação saiu?”. Ramo fixo: verbo + 得. Ramo verde: avaliação substituível. Ramo vermelho: **的 + nome** versus **verbo + 得 + avaliação**. O estado de recuperação apaga 得 e o complemento em rodadas alternadas. O prompt mínimo mostra somente “peça para a pessoa falar mais devagar”.

### Prompt de recuperação

Mostrar apenas:

> A pessoa está falando rápido demais. Peça que ela fale um pouco mais devagar.

Gabarito do editor: 请你说得慢一点。*Qǐng nǐ shuō de màn yìdiǎn.*

### Prompt de transferência

Peça ao aluno para avaliar quatro desempenhos novos: alguém explicou claramente; alguém cantou muito bem; o próprio aluno não fez muito bem; outra pessoa fala chinês de modo razoável. Depois, peça um ajuste funcional usando 慢一点 ou 清楚一点.

### Critério de domínio

O aluno domina quando produz pelo menos quatro frases com verbos diferentes, faz um pedido de ajuste com 得, mantém o complemento após 得 e diferencia oralmente **我的书** de **说得很快**. Não é necessário aprovar a célula por termos técnicos; a produção precisa ser compreensível e natural para a situação.

---

# Filtro editorial: conteúdos reconhecíveis, mas não prioritários

## 地 *de*

地 aparece tipicamente entre um adjetivo e um verbo para formar uma expressão adverbial, como 慢慢地走 *mànmàn de zǒu* (“andar devagar”) ou 认真地听 *rènzhēn de tīng* (“escutar atentamente”). A distinção é legítima, mas este padrão tem menor retorno oral inicial do que 的 e 得; muitos advérbios frequentes já funcionam sem 地. [9] Portanto, incluir 地 em uma seção de reconhecimento ou contraste ortográfico, não em uma célula central de produção. Se entrar em uma revisão B1, o prompt deve ter uma ação clara e um adjetivo/adverbial natural, nunca uma lista de “três de”.

## 嘛 *ma*

嘛 pode apresentar algo como evidente ou insistente, mas sua pronúncia coincide com 吗 e sua interpretação depende muito da atitude e do contexto. Não ensinar 嘛 como “uma forma de 吗”. O aluno deve primeiro conseguir ouvir e produzir 吗 em perguntas de sim/não; uma célula posterior pode contrastar **你去吗？** (“você vai?”) com **你去嘛。** (“vai, ué / você vai, claro”) se houver áudio ou feedback contextual.

## 呗 *bei* e outras partículas finais coloquiais

呗, 咯, 咧 e combinações regionais podem ser úteis em ambientes específicos, mas têm retorno menor para o alvo nacional e iniciante do projeto. Não transformar variação coloquial em núcleo obrigatório. O material deve preparar o aluno para reconhecer que a fala real contém marcadores além dos nove focos acima, sem prometer cobertura regional completa.

## Partícula final 的 *de* e empilhamento

O 的 final, assim como combinações como 了吧, 了吗 ou 的了啊, pertence a uma camada discursiva mais avançada. Partículas finais podem ocorrer em ordens restritas e não devem ser montadas por simples soma de traduções. A pesquisa baseada em corpus mostra que agrupamentos de até três partículas podem ocorrer e que sua ordem é rígida; isso é um tema útil para reconhecimento intermediário, não para a primeira produção do aluno. [10]

## Alinhamento ao sistema Mandarim em Rede

Este bloco deve ser diagramado como uma coleção de células independentes, não como um capítulo linear de gramática. Cada célula deve caber no ciclo abaixo:

```text
intenção → padrão curto → mapa completo → recuperação lacunada → recombinação → transferência → domínio
```

O **mapa completo** pode exibir caracteres simplificados, pinyin tonal ou neutro, tradução natural e contraste. O **mapa lacunado** deve retirar a partícula, um slot ou a escolha entre duas partículas. O **prompt mínimo** deve retirar a resposta e deixar apenas uma situação oral. A partícula é o foco da célula, mas o verbo e o vocabulário precisam ser suficientemente familiares para que a tarefa não vire um teste de léxico.

Para o público brasileiro, as notas de contraste devem mudar uma decisão oral concreta:

- não colocar 吗 depois de toda palavra interrogativa;
- usar 呢 para devolver ou reabrir foco, não como simples “e” universal;
- usar 吧 para proposta ou mitigação, não como tradução fixa de “por favor”;
- ouvir 了 como conclusão ou atualização, não como passado automático;
- usar 过 para experiência sem data e 没 para negá-la;
- distinguir 着 como estado mantido de 在 como ação em progresso;
- separar 的, 得 e 地 pela posição e pela função, não só pela romanização *de*.

A exposição visual deve respeitar a regra de antecipação do projeto. O aluno não deve abrir o mapa para acompanhar o áudio principal, nem usar a tradução para produzir antes da tentativa. O material não escuta nem corrige o aluno; qualquer critério de pronúncia deve ser tratado como **pronúncia funcional observável** e validado por áudio de referência, tutor ou interlocutor, quando disponível.

## Sequência recomendada de produção

| Etapa | Conteúdo | Suporte permitido | Resultado oral esperado |
|---|---|---|---|
| 1. Primeiro contato | 吗, 呢, 吧, 的 | Mapa completo após a tentativa | Reconhecer a ação comunicativa |
| 2. Contraste inicial | 吗 × 呢; 吧 × 吗; 的 × 有 | Mapa lacunado | Escolher a partícula pelo contexto |
| 3. Atualização e experiência | 了, 过 | Dois ramos contrastivos | Relatar mudança, conclusão e experiência |
| 4. Expansão seletiva | 啊, 得, 着 | Exemplos curtos e prompts | Ajustar atitude, desempenho e estado |
| 5. Revisão cumulativa | Todas as prioridades | Situação e intenção apenas | Produzir sem o mapa e explicar a escolha depois |

Uma revisão cumulativa pode usar situações independentes, sem reproduzir diálogos de qualquer curso ou áudio. Exemplos de gatilhos: confirmar uma disponibilidade, devolver a pergunta sobre amanhã, propor uma pausa, reagir a uma chegada inesperada, informar que já comeu, perguntar se alguém já visitou uma cidade, descrever uma porta aberta, identificar de quem é um celular e pedir para alguém falar mais devagar. O avaliador deve registrar **latência**, **escolha funcional**, **recombinação** e **naturalidade suficiente**, não apenas acerto visual.

## Checklist de qualidade editorial

Antes de publicar qualquer célula, verificar:

- A intenção pode ser dita com um verbo de ação, como confirmar, devolver, propor, reagir, atualizar, relatar experiência, manter estado, relacionar ou avaliar?
- O padrão tem um núcleo fixo e no máximo cinco ou seis slots realmente úteis?
- Há pelo menos três variações controladas sem aumentar demais o vocabulário?
- A tradução brasileira é natural e não sugere equivalência palavra por palavra?
- O pinyin está com tons quando lexicais e sem acento quando a partícula é neutra?
- O contraste muda uma decisão de fala ou de compreensão?
- O aluno tenta responder antes de ver o gabarito?
- O prompt de recuperação é diferente dos exemplos de orientação?
- O prompt de transferência exige contexto novo, em vez de repetir uma frase com nomes trocados?
- O critério de domínio exige produção oral sem mapa?
- A nota de pronúncia declara o limite do PDF e não promete correção automática?
- O conteúdo evita transcrições, diálogos e áudios proprietários?

Se qualquer resposta for negativa, a célula deve ser dividida, reduzida ou retirada. O objetivo do bloco não é cobrir todas as partículas possíveis. É fazer o aluno **ouvir uma função, escolher uma forma, recombinar e agir**.

## Referências

[1]: https://resources.allsetlearning.com/chinese/grammar/Particle "Chinese Grammar Wiki: Particle"

[2]: https://resources.allsetlearning.com/chinese/grammar/Yes-no_questions_with_%22ma%22 "Chinese Grammar Wiki: Yes-no questions with ma"

[3]: https://resources.allsetlearning.com/chinese/grammar/Questions_with_%22ne%22 "Chinese Grammar Wiki: Questions with ne"

[4]: https://resources.allsetlearning.com/chinese/grammar/Suggestions_with_%22ba%22 "Chinese Grammar Wiki: Suggestions with ba"

[5]: https://resources.allsetlearning.com/chinese/grammar/Softening_speech_with_%22ba%22 "Chinese Grammar Wiki: Softening speech with ba"

[6]: https://resources.allsetlearning.com/chinese/grammar/Uses_of_%22le%22 "Chinese Grammar Wiki: Uses of le"

[7]: https://resources.allsetlearning.com/chinese/grammar/Expressing_experiences_with_%22guo%22 "Chinese Grammar Wiki: Expressing experiences with guo"

[8]: https://resources.allsetlearning.com/chinese/grammar/Aspect_particle_%22zhe%22 "Chinese Grammar Wiki: Aspect particle zhe"

[9]: https://resources.allsetlearning.com/chinese/grammar/Structural_particle_%22de%22 "Chinese Grammar Wiki: Structural particle de"

[10]: https://onlinelibrary.wiley.com/doi/10.1111/stul.12198 "Fang, H. and Hengeveld, K. Sentence-Final Particles in Mandarin"

[11]: http://comet.cls.yale.edu/mandarin/content/le/grammar/changele.htm "Yale University: Mandarin Essential Grammar — Change of State le"

> **Nota de uso das fontes.** As páginas da Chinese Grammar Wiki foram usadas para conferir padrões, níveis de prioridade e exemplos funcionais; o artigo acadêmico foi usado para a cautela sobre partículas finais e ordem de agrupamento; a página de Yale foi usada como referência complementar para a leitura de mudança de estado de 了. O relatório não reproduz diálogos, transcrições ou áudio proprietário.
