# 03 — Vocabulário funcional

## Escopo do bloco

Este bloco organiza vocabulário por **ações comunicativas observáveis**, não por ordem alfabética nem por listas de palavras. Cada entrada é uma **célula de transferência**: um núcleo curto de fala que o aluno recupera, recombina e usa em uma situação nova. A seleção cobre o iniciante e o início do intermediário, priorizando apresentação, reparo de compreensão, identificação, pedido, localização, agenda, capacidade, preferência, negação, mudança de estado, experiência, comparação, grau, planejamento e cortesia.

O desenho segue a orientação dos documentos do projeto: o áudio continua sendo a fonte primária; o mapa entra depois da tentativa; a tradução é funcional, não palavra por palavra; e o suporte deve diminuir até desaparecer. O enquadramento por tarefas, temas, vocabulário, gramática e objetivos de comunicação também é compatível com a arquitetura pública do HSK.[1]

> **Uso recomendado:** ouvir e tentar responder primeiro; consultar a célula depois; praticar as substituições; fechar o mapa; responder ao prompt de transferência. Os exemplos abaixo são autorais e não reproduzem diálogos, transcrições ou áudios proprietários.

## Legenda operacional

- **[F] Fixo:** componente cuja posição ou forma deve permanecer estável.
- **[V] Variável:** slot substituível por nome, objeto, lugar, horário ou ação.
- **[O] Extensão:** componente opcional, introduzido somente depois de o núcleo estar disponível.
- **[A] Alerta:** pronúncia, tom, registro ou ritmo que muda a compreensão ou a naturalidade.
- **[X] Contraste:** escolha que o falante precisa fazer, especialmente contra interferências do português.
- **[M] Mapa:** potencial de conexão com função, padrão, contraste, som e revisão.

## Visão de percurso

| Célula | Contexto real | Operação oral dominante | Contraste prioritário |
|---|---|---|---|
| V01 | primeiro contato | iniciar e identificar | 叫 e 名字; tom neutro |
| V02 | apresentação pessoal | informar origem e idioma | 是 e 说 |
| V03 | conversa rápida | reparar compreensão | 没 e 不; 一 e ritmo |
| V04 | objetos compartilhados | identificar e confirmar posse | 这 e 那; 是 e 在 |
| V05 | café, loja ou serviço | querer e pedir | 想, 要 e 给 |
| V06 | deslocamento ou ambiente | localizar | 在 e 是; 哪儿 e 哪里 |
| V07 | agenda e encontro | combinar horário | 有时间, 没有时间 e 可以吗 |
| V08 | aula ou conversa | declarar capacidade e pedir possibilidade | 会, 能 e 可以 |
| V09 | escolhas cotidianas | escolher e expressar preferência | 还是 e 或者 |
| V10 | hábitos e eventos | negar com precisão | 不 e 没有 |
| V11 | atualização de situação | marcar mudança de estado | 了 não é “passado” automático |
| V12 | conversa sobre experiências | dizer se já fez algo | 过 e 没有…过 |
| V13 | compras e avaliações | comparar | 比; evitar 很 após 比 |
| V14 | pedidos e avaliações | ajustar quantidade ou grau | 一点 e 有点 |
| V15 | combinar ações | ordenar um plano | 先…再… |
| V16 | manutenção da relação | suavizar, desculpar-se e confirmar | registro e função social |

---

## V01 — Abrir contato e identificar a pessoa

**Vocabulário nuclear**

- 你好 — **nǐ hǎo** — olá.
- 叫 — **jiào** — chamar-se; chamar.
- 名字 — **míngzi** — nome.
- 你呢 — **nǐ ne** — e você?
- 认识 — **rènshi** — conhecer; conhecer alguém.

**Intenção.** Iniciar uma interação e descobrir ou informar o nome sem montar a frase pela ordem do português.

**Padrão ou função.** **[F] 你叫什么名字？ Nǐ jiào shénme míngzi? — Qual é o seu nome?**; **[F] 我叫 + [V] nome. Wǒ jiào + nome. — Eu me chamo + nome.** Para devolver a pergunta, use **[F] 你呢？ Nǐ ne? — E você?**

**Exemplos.** 你好。**Nǐ hǎo.** — Olá. / 我叫 Marina。**Wǒ jiào Marina.** — Eu me chamo Marina. / 很高兴认识你。**Hěn gāoxìng rènshi nǐ.** — Prazer em conhecer você.

**Slots substituíveis.** O slot principal é um nome próprio: **我叫 + Ana/Paulo/Marina**. O sujeito também pode mudar: **他叫 + nome** — Ele se chama + nome. Não é necessário acrescentar “我的名字是” para fazer uma apresentação básica.

**Extensões.** **你好吗？ Nǐ hǎo ma? — Tudo bem?** e **我很好。Wǒ hěn hǎo. — Estou bem.** Entram como extensões de contato, não como pré-requisito do padrão de nome.

**Observação pedagógica.** O português “como você chama seu nome?” induz uma ordem inadequada. Ensine **叫** como núcleo do ato de nomear. Em **名字 míngzi**, a segunda sílaba costuma ser neutra; não dê a **zi** o mesmo peso de **míng**. Em **你好 nǐ hǎo**, o primeiro terceiro tom pode soar elevado na fala conectada; o aluno deve imitar a expressão inteira, não recitar duas sílabas isoladas.

**Potencial de mapa.** Mapa de função: **iniciar contato → identificar pessoa**. Mapa de padrão: **[pronome] + 叫 + [nome]**. Mapa de contraste: **叫** não é “chamar alguém” apenas; também introduz “chamar-se”. Mapa de revisão: conectar nome a origem e idioma em V02.

**Prompt de recuperação.** “Você acabou de conhecer alguém. Pergunte o nome e diga o seu, sem consultar a frase.”

**Prompt de transferência.** “Você entra em uma aula on-line com um participante novo. Use um nome diferente do exemplo, devolva a pergunta e acrescente ‘prazer em conhecer você’.”

**Critério de domínio.** Produzir a pergunta, duas respostas com nomes diferentes e **你呢？** em até cinco segundos após o estímulo; manter o ritmo funcional de **míngzi**; realizar a mesma operação sem pinyin visível.

---

## V02 — Informar origem e idioma

**Vocabulário nuclear**

- 哪国人 — **nǎ guó rén** — de que país; de que nacionalidade.
- 是 — **shì** — ser; identificar/classificar.
- 巴西 — **Bāxī** — Brasil.
- 中国 — **Zhōngguó** — China.
- 人 — **rén** — pessoa; componente de nacionalidade.
- 说 — **shuō** — falar; dizer.
- 中文 — **Zhōngwén** — chinês.
- 葡萄牙语 — **Pútáoyáyǔ** — português.

**Intenção.** Dizer de onde se é e qual idioma se fala, especialmente no primeiro contato.

**Padrão ou função.** **[F] 你是哪国人？ Nǐ shì nǎ guó rén? — De que país você é?**; **[F] 我是 + [V] país + 人。Wǒ shì + país + rén. — Eu sou brasileiro(a)/chinês(a).** Para idioma: **[F] 我说 + [V] idioma。Wǒ shuō + idioma. — Eu falo + idioma.**

**Exemplos.** 我是巴西人。**Wǒ shì Bāxī rén.** — Sou brasileiro(a). / 我说葡萄牙语。**Wǒ shuō Pútáoyáyǔ.** — Eu falo português. / 我会说一点中文。**Wǒ huì shuō yìdiǎn Zhōngwén.** — Sei falar um pouco de chinês.

**Slots substituíveis.** Países: **中国 Zhōngguó**, **美国 Měiguó**, **日本 Rìběn**. Idiomas: **英语 Yīngyǔ** — inglês; **西班牙语 Xībānyáyǔ** — espanhol. O slot de idioma pode receber **一点 yìdiǎn** — um pouco — quando a competência é parcial.

**Extensões.** **你会说英语吗？ Nǐ huì shuō Yīngyǔ ma? — Você fala inglês?**; **我不太会说。Wǒ bú tài huì shuō. — Não falo muito bem.** A segunda forma é uma extensão de capacidade, retomada com maior precisão em V08.

**Observação pedagógica.** Separe a função de identidade de nacionalidade (**是**) da função de idioma (**说**). “Sou português” pode significar nacionalidade, enquanto “falo português” descreve idioma; o mandarim força a decisão entre **我是…人** e **我说…语**. Em **不是 bú shì**, **不 bù** costuma mudar para segundo tom diante de uma sílaba de quarto tom; as marcas de tom registradas no pinyin seguem a forma pronunciada da expressão.[2]

**Potencial de mapa.** Mapa de função: **apresentação → origem → idioma**. Mapa de padrão: **是 + país + 人** versus **说 + idioma**. Mapa de contraste: **是 ≠ 说**. Mapa de consolidação: conectar com **会说** de V08 e com **一点** de V14.

**Prompt de recuperação.** “Diga que você é brasileiro(a) e que fala português. Depois pergunte a nacionalidade da outra pessoa.”

**Prompt de transferência.** “Em um encontro internacional, troque Brasil por Japão e português por espanhol; depois diga que fala apenas um pouco de chinês.”

**Critério de domínio.** Fazer as três operações — perguntar origem, responder nacionalidade e informar idioma — com dois países e dois idiomas; não trocar **是** por **说**; usar **一点** sem depender da tradução literal.

---

## V03 — Reparar uma falha de compreensão

**Vocabulário nuclear**

- 听懂 — **tīng dǒng** — entender ao ouvir.
- 明白 — **míngbai** — compreender; entender.
- 没 — **méi** — não ter conseguido/não ter ocorrido.
- 请 — **qǐng** — por favor.
- 再 — **zài** — novamente.
- 一遍 — **yí biàn** — uma vez completa; uma repetição.
- 慢一点 — **màn yìdiǎn** — um pouco mais devagar.

**Intenção.** Manter a conversa quando a fala foi rápida ou não ficou clara.

**Padrão ou função.** **[F] 我没听懂。Wǒ méi tīng dǒng. — Não entendi.**; **[F] 请再说一遍。Qǐng zài shuō yí biàn. — Por favor, repita.**; **[F] 请说慢一点。Qǐng shuō màn yìdiǎn. — Por favor, fale um pouco mais devagar.**

**Exemplos.** 我没听懂。**Wǒ méi tīng dǒng.** — Não entendi. / 你能再说一遍吗？**Nǐ néng zài shuō yí biàn ma?** — Você pode repetir? / 现在我明白了。**Xiànzài wǒ míngbai le.** — Agora eu entendi.

**Slots substituíveis.** Substitua a ação de reparo: **说慢一点 shuō màn yìdiǎn** — falar mais devagar; **再说一遍 zài shuō yí biàn** — repetir; **解释一下 jiěshì yíxià** — explicar um pouco, extensão inicial-intermediária. O slot de modalidade pode ser **能** — conseguir/poder em determinada situação — ou uma ordem cortês com **请**.

**Extensões.** **我听懂了。Wǒ tīng dǒng le. — Entendi.**; **请说清楚一点。Qǐng shuō qīngchu yìdiǎn. — Por favor, explique/fale um pouco mais claramente.**

**Observação pedagógica.** **没** nega um resultado ou evento não alcançado; não é uma tradução geral de “não”. Em **一遍 yí biàn**, **一 yī** muda de tom antes de uma sílaba de quarto tom; em **一点 yìdiǎn**, a realização depende da sílaba seguinte. As mudanças tonais não costumam aparecer no pinyin lexical isolado, por isso o aluno deve ouvir a expressão em bloco.[2] O objetivo desta célula é reparar a interação, não explicar por que a frase anterior não foi compreendida.

**Potencial de mapa.** Mapa de função: **falha → pedido de repetição → pedido de velocidade → confirmação de compreensão**. Mapa de contraste: **没听懂** versus **不明白**; o primeiro ancora a falha auditiva, o segundo é mais amplo. Mapa sonoro: **méi**, **zài**, **yí**, **yì**.

**Prompt de recuperação.** “Você ouviu uma frase rápida e não entendeu. Diga isso e peça repetição.”

**Prompt de transferência.** “Em uma videochamada, peça primeiro repetição; se ainda estiver difícil, peça velocidade menor; finalize dizendo que agora entendeu.”

**Critério de domínio.** Escolher espontaneamente entre **我没听懂** e **我听懂了**; formular um pedido de repetição e um de velocidade menor; manter **méi**, **yí** e **yì** funcionalmente audíveis.

---

## V04 — Identificar algo e confirmar posse

**Vocabulário nuclear**

- 这 — **zhè** — isto; este/esta.
- 那 — **nà** — aquilo; aquele/aquela.
- 什么 — **shénme** — o que; qual.
- 的 — **de** — marcador de posse/relação.
- 对 — **duì** — correto; isso mesmo.
- 我的 — **wǒ de** — meu/minha.
- 你的 — **nǐ de** — seu/sua.
- 他的 — **tā de** — dele.

**Intenção.** Descobrir o que é um objeto, indicar proximidade/distância e confirmar a quem pertence.

**Padrão ou função.** **[F] 这是什么？Zhè shì shénme? — O que é isto?**; **[F] 这是 + [V] objeto。Zhè shì + objeto. — Isto é + objeto.**; **[F] 这是 + [V] pessoa + 的 + objeto + 吗？— Este objeto é de [pessoa]?**

**Exemplos.** 这是什么？**Zhè shì shénme?** — O que é isto? / 这是我的手机。**Zhè shì wǒ de shǒujī.** — Este é o meu celular. / 那是他的包。**Nà shì tā de bāo.** — Aquela é a bolsa/mochila dele. / 对，是我的。**Duì, shì wǒ de.** — Isso, é minha.

**Slots substituíveis.** Objetos: **书 shū** — livro; **水 shuǐ** — água; **电脑 diànnǎo** — computador; **钥匙 yàoshi** — chave. Pessoas: **我 wǒ**, **你 nǐ**, **他 tā**, **她 tā**. Distância: **这** para referência próxima e **那** para referência mais distante.

**Extensões.** **不是我的。Bú shì wǒ de. — Não é meu/minha.**; **这是你的书吗？Zhè shì nǐ de shū ma? — Este livro é seu?**

**Observação pedagógica.** **这** e **那** não são apenas equivalentes de “este” e “aquele”; são escolhas de referência no espaço discursivo. **的** vem depois do possuidor: **我的手机**, não uma ordem calcada no português. Não confundir **是 shì** — identificação — com **在 zài** — localização, trabalhado em V06. O inicial de **这 zhè** não deve ser lido como o “z” do português.

**Potencial de mapa.** Mapa de função: **apontar → nomear → confirmar posse → corrigir**. Mapa de padrão: **这/那 + 是 + objeto** e **pessoa + 的 + objeto**. Mapa de contraste: **这 ≠ 那**; **是 ≠ 在**. Conecta com pedidos de V05.

**Prompt de recuperação.** “Aponte para um objeto próximo e pergunte o que é. Depois diga que é seu.”

**Prompt de transferência.** “Use um objeto distante, atribua-o a outra pessoa e corrija a resposta se alguém disser que é seu.”

**Critério de domínio.** Produzir três ciclos com objetos diferentes, alternando **这** e **那**, e confirmar/recusar posse sem traduzir a ordem de **的**.

---

## V05 — Expressar vontade e fazer um pedido

**Vocabulário nuclear**

- 想 — **xiǎng** — querer; ter vontade de.
- 要 — **yào** — querer; precisar; solicitar.
- 给 — **gěi** — dar; entregar para.
- 喝 — **hē** — beber.
- 吃 — **chī** — comer.
- 这个 — **zhège** — isto; este item.
- 谢谢 — **xièxie** — obrigado(a).

**Intenção.** Expressar o que se deseja e pedir um item ou serviço em café, loja, casa ou situação de atendimento.

**Padrão ou função.** **[F] 我想 + [V] ação。Wǒ xiǎng + ação. — Quero/gostaria de + ação.**; **[F] 我想要 + [V] objeto。Wǒ xiǎng yào + objeto. — Quero + objeto.**; **[F] 请给我 + [V] objeto。Qǐng gěi wǒ + objeto. — Por favor, me dê + objeto.**

**Exemplos.** 我想喝水。**Wǒ xiǎng hē shuǐ.** — Quero beber água. / 我想要一杯茶。**Wǒ xiǎng yào yì bēi chá.** — Quero uma xícara de chá. / 请给我这个。**Qǐng gěi wǒ zhège.** — Por favor, me dê este. / 谢谢。**Xièxie.** — Obrigado(a).

**Slots substituíveis.** Ações: **喝水 hē shuǐ** — beber água; **吃饭 chīfàn** — comer; **看这个 kàn zhège** — ver/olhar isto. Objetos: **咖啡 kāfēi**, **茶 chá**, **票 piào** — ingresso/passagem. Medida: **一杯 yì bēi** — um copo/uma xícara; **一张 yì zhāng** — uma folha/uma passagem/cartão, conforme o objeto.

**Extensões.** Negação de vontade ou pedido: **我不要咖啡。Wǒ bú yào kāfēi. — Não quero café.**; indicação: **我要这个。Wǒ yào zhège. — Quero este.**

**Observação pedagógica.** **想** apresenta vontade ou intenção; **要** pode apresentar desejo mais direto, necessidade ou pedido. Não force uma oposição absoluta: em situações reais há sobreposição, e o contexto decide o grau de diretividade. Em **不要 bú yào**, **不 bù** muda para segundo tom diante de **要 yào**, um quarto tom.[2] Ensine **请给我** como pedido utilizável, não como fórmula para toda relação social.

**Potencial de mapa.** Mapa de função: **desejar → selecionar → pedir → agradecer/recusar**. Mapa de padrão: **想 + ação** versus **想要/要 + objeto**. Mapa de contraste: **想** não é automaticamente “pensar”; aqui é vontade. Conecta objetos de V04 e grau de V14.

**Prompt de recuperação.** “Você está em um café. Diga que quer beber água e peça uma xícara de chá.”

**Prompt de transferência.** “Em uma loja, aponte para três itens; peça um, recuse outro e agradeça sem usar o exemplo do café.”

**Critério de domínio.** Produzir cinco pedidos com pelo menos três objetos e duas ações; alternar **想**, **想要** e **请给我**; negar uma escolha com **不要**; manter **bú yào**.

---

## V06 — Perguntar e informar localização

**Vocabulário nuclear**

- 在 — **zài** — estar em; localizar-se em.
- 哪儿 — **nǎr** — onde.
- 哪里 — **nǎlǐ** — onde.
- 这里 — **zhèlǐ** — aqui.
- 那里 — **nàlǐ** — ali; lá.
- 里 — **lǐ** — dentro; em.
- 洗手间 — **xǐshǒujiān** — banheiro.

**Intenção.** Encontrar uma pessoa ou objeto e informar onde está, em um ambiente físico ou digital.

**Padrão ou função.** **[F] [V] pessoa/objeto + 在哪儿？— Onde está/fica [V]?**; **[F] [V] pessoa/objeto + 在 + [V] lugar。— [V] está em [lugar].**

**Exemplos.** 洗手间在哪儿？**Xǐshǒujiān zài nǎr?** — Onde fica o banheiro? / 我在这里。**Wǒ zài zhèlǐ.** — Estou aqui. / 手机在包里。**Shǒujī zài bāo lǐ.** — O celular está na bolsa. / 他在那里。**Tā zài nàlǐ.** — Ele está ali.

**Slots substituíveis.** Pessoas: **我 wǒ**, **你 nǐ**, **他 tā**. Objetos: **手机 shǒujī**, **书 shū**, **钥匙 yàoshi**. Lugares: **家 jiā** — casa; **学校 xuéxiào** — escola; **公司 gōngsī** — empresa; **包里 bāo lǐ** — dentro da bolsa.

**Extensões.** **你在哪儿？Nǐ zài nǎr? — Onde você está?**; **我不在家。Wǒ bú zài jiā. — Não estou em casa.**; **在这儿。Zài zhèr. — Aqui.**

**Observação pedagógica.** **在** localiza; **是** identifica. A pergunta **洗手间在哪儿？** não é “o banheiro é onde?”, apesar da tradução funcional em português. **哪儿** e **哪里** cumprem a mesma função básica; escolha uma forma para estabilizar a recuperação antes de alternar. O **r** de **哪儿 nǎr** não deve ser substituído automaticamente pelo “r” gutural brasileiro.

**Potencial de mapa.** Mapa de função: **objeto/pessoa → localização → lugar específico**. Mapa de padrão: **alvo + 在 + lugar**. Mapa de contraste: **在 ≠ 是**; **这里 ≠ 那里**. Conecta com V04, V05 e V16.

**Prompt de recuperação.** “Pergunte onde está o banheiro e responda que o celular está na bolsa.”

**Prompt de transferência.** “Imagine que você está em uma estação. Pergunte por um lugar novo e informe onde você está usando ‘aqui’ e ‘ali’.”

**Critério de domínio.** Perguntar a localização de três alvos e responder com três lugares diferentes; distinguir **在** de **是** na produção e na compreensão auditiva.

---

## V07 — Organizar horário e combinar encontro

**Vocabulário nuclear**

- 什么时候 — **shénme shíhou** — quando.
- 时间 — **shíjiān** — tempo; horário.
- 现在 — **xiànzài** — agora.
- 今天 — **jīntiān** — hoje.
- 明天 — **míngtiān** — amanhã.
- 上午 — **shàngwǔ** — manhã.
- 下午 — **xiàwǔ** — tarde.
- 有时间 — **yǒu shíjiān** — ter tempo/disponibilidade.
- 可以 — **kěyǐ** — poder; ser possível; pode ser.

**Intenção.** Perguntar disponibilidade, propor um horário e confirmar ou recusar um encontro.

**Padrão ou função.** **[F] 你什么时候有时间？Nǐ shénme shíhou yǒu shíjiān? — Quando você tem tempo?**; **[F] [V] tempo + horário，可以吗？— [V] às [horas], pode ser?**; **[F] 我们 + [V] tempo + 见。Wǒmen + tempo + jiàn. — Nos vemos + tempo.**

**Exemplos.** 现在几点？**Xiànzài jǐ diǎn?** — Que horas são agora? / 我明天有时间。**Wǒ míngtiān yǒu shíjiān.** — Tenho tempo amanhã. / 明天下午三点，可以吗？**Míngtiān xiàwǔ sān diǎn, kěyǐ ma?** — Amanhã às três da tarde, pode ser? / 我们晚上见。**Wǒmen wǎnshang jiàn.** — Nos vemos à noite.

**Slots substituíveis.** Tempo: **今天 jīntiān**, **明天 míngtiān**, **下周 xià zhōu** — semana que vem. Período: **上午**, **下午**, **晚上 wǎnshang**. Horário: **九点 jiǔ diǎn**, **三点半 sān diǎn bàn**. A ação pode ser **见 jiàn** — encontrar-se/ver-se — ou **吃饭 chīfàn** — comer.

**Extensões.** **我今天没有时间。Wǒ jīntiān méiyǒu shíjiān. — Hoje não tenho tempo.**; **可以，没问题。Kěyǐ, méi wèntí. — Pode ser, sem problema.**

**Observação pedagógica.** O mandarim coloca o quadro temporal antes do evento: **明天下午三点见**. Não obrigue o iniciante a traduzir “às três da tarde” palavra por palavra. **没有时间** é a forma natural para “não ter tempo”; não use **不有**. A extensão **可以吗** pode solicitar confirmação, possibilidade ou acordo, e o tom interpessoal depende da situação.

**Potencial de mapa.** Mapa de função: **disponibilidade → proposta → confirmação/recusa**. Mapa de padrão: **tempo + período + hora + ação**. Mapa de contraste: **有时间 ≠ 没有时间**; **可以吗** como checagem de acordo. Conecta com V15 para ordenar o plano.

**Prompt de recuperação.** “Pergunte quando a pessoa tem tempo e proponha amanhã de manhã às nove.”

**Prompt de transferência.** “Você precisa remarcar um encontro: diga que hoje não tem tempo e proponha um horário diferente na semana que vem.”

**Critério de domínio.** Produzir três propostas com datas/períodos distintos, responder **可以** ou **没有时间**, e manter a ordem temporal sem copiar a estrutura do português.

---

## V08 — Declarar capacidade, possibilidade e permissão

**Vocabulário nuclear**

- 会 — **huì** — saber fazer; ter aprendido uma habilidade.
- 能 — **néng** — conseguir; ter condição em uma situação.
- 可以 — **kěyǐ** — poder; ter permissão; ser possível.
- 会说 — **huì shuō** — saber falar.
- 再 — **zài** — novamente.

**Intenção.** Dizer o que se sabe fazer, se há condição de fazer algo agora e se uma ação é permitida ou aceitável.

**Padrão ou função.** **[F] 我会 + [V] ação。Wǒ huì + ação. — Eu sei/consigo fazer + ação.**; **[F] 你能 + [V] ação + 吗？— Você consegue/pode fazer + ação?**; **[F] 可以 + [V] ação + 吗？— Pode-se/é permitido fazer + ação?**

**Exemplos.** 我会说中文。**Wǒ huì shuō Zhōngwén.** — Sei falar chinês. / 你能再说一遍吗？**Nǐ néng zài shuō yí biàn ma?** — Você pode repetir? / 现在可以吗？**Xiànzài kěyǐ ma?** — Pode ser agora? / 我不会开车。**Wǒ bú huì kāichē.** — Não sei dirigir.

**Slots substituíveis.** Ações: **说中文 shuō Zhōngwén**, **开车 kāichē** — dirigir, **做饭 zuò fàn** — cozinhar, **看汉字 kàn Hànzì** — ler/ver caracteres. O contexto seleciona **会** para habilidade, **能** para condição/capacidade na situação e **可以** para permissão ou possibilidade.

**Extensões.** **你会不会说中文？Nǐ huì bu huì shuō Zhōngwén? — Você fala chinês ou não?**; **我现在不能去。Wǒ xiànzài bù néng qù. — Agora não consigo/não posso ir.**

**Observação pedagógica.** As três formas podem ser traduzidas por “poder” em português, mas não são intercambiáveis em todos os contextos. A distinção é funcional, não uma tabela rígida: **会** aponta para conhecimento/habilidade; **能**, para capacidade ou condições; **可以**, para permissão, autorização ou possibilidade. Em **不会 bú huì**, ocorre a mudança tonal de **不** antes de **会**, que é quarto tom.[2]

**Potencial de mapa.** Mapa de contraste central: **habilidade → 会; condição → 能; permissão/possibilidade → 可以**. Mapa de padrão: modal + verbo, sem preposição equivalente a “de” antes da ação. Conecta **会说** a V02 e **能再说一遍** a V03.

**Prompt de recuperação.** “Diga que sabe falar um pouco de chinês; depois pergunte se a pessoa consegue repetir.”

**Prompt de transferência.** “Em uma sala de aula, diga o que sabe fazer, o que não consegue fazer hoje e pergunte se pode usar um objeto.”

**Critério de domínio.** Produzir uma frase com cada modal em contexto apropriado; explicar a escolha em português depois da produção; não usar **会** como equivalente universal de “poder”.

---

## V09 — Escolher entre opções e expressar preferência

**Vocabulário nuclear**

- 喜欢 — **xǐhuan** — gostar; preferir.
- 还是 — **háishi** — ou, em pergunta de escolha.
- 或者 — **huòzhě** — ou; alternativa em afirmação.
- 比较 — **bǐjiào** — relativamente; preferencialmente.
- 茶 — **chá** — chá.
- 咖啡 — **kāfēi** — café.

**Intenção.** Solicitar uma escolha e dizer uma preferência em situações de alimentação, lazer, compra ou planejamento.

**Padrão ou função.** **[F] 你喜欢 + [V] A 还是 [V] B？— Você prefere A ou B?**; **[F] 我喜欢 + [V] opção。Wǒ xǐhuan + opção. — Eu gosto/prefiro + opção.** Em afirmações com alternativas abertas: **[F] A 或者 B**.

**Exemplos.** 你喜欢茶还是咖啡？**Nǐ xǐhuan chá háishi kāfēi?** — Você prefere chá ou café? / 我喜欢茶。**Wǒ xǐhuan chá.** — Prefiro chá. / 周末我想在家看书或者看电影。**Zhōumò wǒ xiǎng zài jiā kànshū huòzhě kàn diànyǐng.** — No fim de semana quero ler ou ver um filme em casa.

**Slots substituíveis.** Bebidas: **茶**, **咖啡**, **水 shuǐ**. Ações: **看书 kànshū** — ler, **看电影 kàn diànyǐng** — ver filme, **出去吃 chūqù chī** — sair para comer. Preferência graduada: **我比较喜欢… Wǒ bǐjiào xǐhuan… — Eu prefiro um pouco/tenho mais preferência por…**

**Extensões.** **我不喜欢喝咖啡。Wǒ bù xǐhuan hē kāfēi. — Não gosto de tomar café.**; **两个都可以。Liǎng ge dōu kěyǐ. — Os dois servem/podem ser os dois.**

**Observação pedagógica.** **还是** normalmente apresenta alternativas em uma pergunta que pede escolha; **或者** aparece sobretudo em afirmações, quando as opções não precisam ser selecionadas naquele instante.[4] O erro frequente é usar **或者** em uma pergunta binária ou tratar **还是** como uma tradução fixa de “ainda”.

**Potencial de mapa.** Mapa de função: **oferecer opções → escolher → justificar suavemente**. Mapa de contraste: **还是** em pergunta versus **或者** em afirmação. Mapa de extensão: preferência simples → preferência graduada com **比较** → aceitação de ambas.

**Prompt de recuperação.** “Pergunte se a pessoa prefere chá ou café e responda que prefere chá.”

**Prompt de transferência.** “Organize seu fim de semana oferecendo duas atividades; em seguida, diga que as duas são possíveis, mas que você prefere uma delas.”

**Critério de domínio.** Formular duas perguntas com **还是**, uma afirmação com **或者**, e uma preferência negativa; não confundir pergunta de escolha com alternativa aberta.

---

## V10 — Negar hábito, intenção, evento e posse

**Vocabulário nuclear**

- 不 — **bù** — não; negação de hábito, intenção, estado ou decisão.
- 没 — **méi** — não ter ocorrido; não ter conseguido.
- 没有 — **méiyǒu** — não ter; não haver; não ter feito.
- 喝 — **hē** — beber.
- 去 — **qù** — ir.
- 有 — **yǒu** — ter; haver.

**Intenção.** Escolher a negação adequada em vez de transportar a única palavra “não” do português para todos os contextos.

**Padrão ou função.** **[F] sujeito + 不 + verbo/adjetivo** para hábito, intenção, decisão ou estado: **我不喝咖啡。Wǒ bù hē kāfēi. — Não bebo café/não vou beber café.** **[F] sujeito + 没(有) + verbo** para evento não ocorrido: **我今天没喝咖啡。Wǒ jīntiān méi hē kāfēi. — Hoje não bebi café.** Para posse: **[F] 没有 + objeto**: **我没有时间。Wǒ méiyǒu shíjiān. — Não tenho tempo.**

**Exemplos.** 我不去。**Wǒ bú qù.** — Não vou. / 我昨天没去。**Wǒ zuótiān méi qù.** — Ontem não fui. / 我没有钱。**Wǒ méiyǒu qián.** — Não tenho dinheiro. / 我不在家。**Wǒ bú zài jiā.** — Não estou em casa.

**Slots substituíveis.** Verbos: **喝**, **吃 chī**, **去**, **买 mǎi** — comprar. Marcadores de tempo ajudam a tornar a decisão observável: **今天 jīntiān**, **昨天 zuótiān**, **明天 míngtiān**. Para capacidade ou vontade, a negação entra depois do modal: **不会 bú huì**, **不能 bù néng**, **不想 bù xiǎng**.

**Extensões.** Pergunta afirmativo-negativa: **你去不去？Nǐ qù bu qù? — Você vai ou não vai?**; correção: **不是我的。Bú shì wǒ de. — Não é meu/minha.**

**Observação pedagógica.** **不** geralmente nega presente, futuro, hábito, intenção, adjetivos e decisões; **没/没有** nega ocorrência anterior, resultado não alcançado e posse com **有**. A oposição é uma orientação funcional, não uma tradução mecânica de tempo verbal.[3] Não ensine **不有** para “não ter”. Em fala conectada, **不** tende a soar **bú** antes de quarto tom, mas o pinyin lexical da palavra isolada é **bù**.[2]

**Potencial de mapa.** Mapa de contraste de alto risco: **plano/hábito → 不**; **evento não ocorrido/posse → 没(有)**. Mapa temporal: hoje/amanhã versus ontem. Conecta com V03, V07, V08 e V11.

**Prompt de recuperação.** “Diga que não bebe café, que ontem não bebeu café e que não tem tempo.”

**Prompt de transferência.** “Recuse uma atividade planejada para amanhã, relate que não fez outra ontem e diga que não tem o objeto necessário.”

**Critério de domínio.** Produzir pares mínimos com **不** e **没**, incluindo um hábito, uma decisão futura, um evento passado e posse; escolher a negação sem receber o caractere.

---

## V11 — Atualizar uma situação com 了

**Vocabulário nuclear**

- 了 — **le** — marcador de mudança de estado, atualização ou, em outros padrões, conclusão.
- 饿 — **è** — estar com fome.
- 累 — **lèi** — estar cansado.
- 明白 — **míngbai** — compreender.
- 买 — **mǎi** — comprar.
- 现在 — **xiànzài** — agora.

**Intenção.** Informar que uma situação mudou, que algo passou a ser verdadeiro ou que uma decisão foi alterada.

**Padrão ou função.** **[F] sujeito + adjetivo/verbo + 了** para nova situação: **我饿了。Wǒ è le. — Fiquei com fome/Estou com fome agora.**; **[F] sujeito + 不 + verbo + 了** para mudança de plano: **我不买了。Wǒ bù mǎi le. — Decidi não comprar mais/Não vou comprar agora.**

**Exemplos.** 我饿了。**Wǒ è le.** — Estou com fome agora. / 现在我明白了。**Xiànzài wǒ míngbai le.** — Agora entendi. / 下雨了。**Xià yǔ le.** — Começou a chover/Está chovendo agora. / 我不喝了。**Wǒ bù hē le.** — Não vou beber mais/agora mudei de ideia.

**Slots substituíveis.** Estados: **饿 è** — com fome; **累 lèi** — cansado; **忙 máng** — ocupado. Ações: **买**, **喝**, **去**, **等 děng** — esperar. O slot de sujeito pode ser pessoa, grupo ou situação meteorológica.

**Extensões.** Para ação concluída, há outro uso de **了** após o verbo: **我吃了饭。Wǒ chī le fàn. — Eu comi/fiz a refeição.** Não misture esse padrão com a mudança de estado sem contexto.

**Observação pedagógica.** **了** não é um marcador de passado automático. No padrão final, apresenta uma nova situação, uma atualização ou uma mudança de decisão; fontes didáticas distinguem esse uso do **了** aspectual após o verbo.[7] Para iniciantes, comece com pares antes/depois: antes não estava com fome → agora **饿了**; antes pretendia comprar → agora **不买了**.

**Potencial de mapa.** Mapa de função: **estado anterior → mudança → situação atual**. Mapa de contraste: **adjetivo sem 了** como descrição versus **adjetivo + 了** como atualização. Mapa de consolidação: ligar **明白了** a V03 e **不…了** a V10.

**Prompt de recuperação.** “Diga que agora está com fome e que finalmente entendeu.”

**Prompt de transferência.** “Você mudou de ideia em uma loja: diga que não vai comprar mais; depois informe que agora está cansado.”

**Critério de domínio.** Produzir duas mudanças de estado e uma mudança de plano; explicar por que **了** não significa simplesmente “ontem”; distinguir pelo menos um exemplo de mudança de estado de um exemplo de ação concluída.

---

## V12 — Falar de experiência anterior

**Vocabulário nuclear**

- 过 — **guo** — marcador de experiência anterior.
- 去过 — **qù guo** — já ter ido.
- 吃过 — **chī guo** — já ter comido.
- 看过 — **kàn guo** — já ter visto/lido.
- 没有…过 — **méiyǒu…guo** — nunca ter feito.

**Intenção.** Dizer se já se teve uma experiência, sem apresentar a experiência como acontecimento específico em uma data.

**Padrão ou função.** **[F] sujeito + verbo + 过**: **我去过中国。Wǒ qù guo Zhōngguó. — Já fui à China.**; pergunta: **[F] 你 + verbo + 过 + objeto + 吗？— Você já fez isso?**; negação: **[F] 我没(有) + verbo + 过。— Nunca fiz/não tive essa experiência.**

**Exemplos.** 你去过中国吗？**Nǐ qù guo Zhōngguó ma?** — Você já foi à China? / 我没去过中国。**Wǒ méi qù guo Zhōngguó.** — Nunca fui à China. / 我吃过北京烤鸭。**Wǒ chī guo Běijīng kǎoyā.** — Já comi pato assado de Pequim.

**Slots substituíveis.** Verbos de experiência: **去 qù** — ir; **吃 chī** — comer; **看 kàn** — ver/assistir; **用 yòng** — usar; **学 xué** — estudar/aprender. Objetos e lugares devem ser familiares o bastante para não transformar a célula em lista temática.

**Extensões.** **我去过一次。Wǒ qù guo yí cì. — Já fui uma vez.**; **你看过这个电影吗？Nǐ kàn guo zhège diànyǐng ma? — Você já viu este filme?**

**Observação pedagógica.** **过** apresenta experiência em algum momento anterior, sem focalizar o término de uma ocorrência particular. Para “ontem fui”, use o enquadramento de evento com tempo, não ensine **过** como equivalente geral de passado. A negação normalmente usa **没(有)**, retomando o contraste de V10.

**Potencial de mapa.** Mapa de função: **pergunta de experiência → resposta sim/não → frequência opcional**. Mapa de padrão: verbo + **过**. Mapa de contraste: experiência geral (**过**) versus evento situado no tempo (**昨天…**). Conecta a viagens, comida e aprendizagem sem criar listas de turismo.

**Prompt de recuperação.** “Pergunte se a pessoa já foi à China e responda que nunca foi.”

**Prompt de transferência.** “Escolha uma atividade cotidiana nova para o contexto, pergunte se alguém já a fez e responda com uma experiência sua.”

**Critério de domínio.** Formular duas perguntas de experiência, responder uma afirmativamente e outra negativamente, e manter **过** ligado ao verbo sem usar **了** como substituto automático.

---

## V13 — Comparar duas pessoas, objetos ou opções

**Vocabulário nuclear**

- 比 — **bǐ** — em comparação com; mais… do que.
- 更 — **gèng** — ainda mais; mais.
- 便宜 — **piányi** — barato.
- 贵 — **guì** — caro.
- 大 — **dà** — grande.
- 小 — **xiǎo** — pequeno.
- 冷 — **lěng** — frio.

**Intenção.** Escolher, avaliar ou explicar uma diferença entre duas opções em compra, clima, transporte ou preferência.

**Padrão ou função.** **[F] A 比 B + [V] adjetivo。A bǐ B + adjetivo. — A é mais [adjetivo] que B.** Para intensificar: **A 比 B 更 + adjetivo**. Para dizer que A não chega ao nível de B: **A 没有 B + adjetivo**.

**Exemplos.** 这个比那个便宜。**Zhège bǐ nàge piányi.** — Este é mais barato que aquele. / 北京比上海冷吗？**Běijīng bǐ Shànghǎi lěng ma?** — Pequim é mais fria que Xangai? / 我的手机没有他的贵。**Wǒ de shǒujī méiyǒu tā de guì.** — Meu celular não é tão caro quanto o dele.

**Slots substituíveis.** A: **这个 zhège**, **地铁 dìtiě** — metrô, **今天 jīntiān**. B: **那个 nàge**, **公交车 gōngjiāochē** — ônibus, **昨天 zuótiān**. Adjetivos: **快 kuài** — rápido, **方便 fāngbiàn** — conveniente, **贵**, **便宜**.

**Extensões.** **A 比 B 更方便。A bǐ B gèng fāngbiàn. — A é ainda mais conveniente que B.**; **跟…一样… gēn… yíyàng… — tão… quanto…**, quando a intenção é igualdade, não superioridade.

**Observação pedagógica.** A ordem é crucial: **A 比 B adjetivo**, e não uma cópia de “A é mais adjetivo do que B”. No padrão básico, não acrescente **很** antes do adjetivo: **他比我高**, não *他比我很高*. A referência didática classifica o padrão **比** como construção elementar e destaca a ordem e esse erro frequente.[5]

**Potencial de mapa.** Mapa de função: **duas opções → dimensão de avaliação → escolha**. Mapa de padrão: **A 比 B + adjetivo**. Mapa de contraste: superioridade (**比**), inferioridade relativa (**没有…那么…**) e igualdade (**跟…一样**).

**Prompt de recuperação.** “Diga que este item é mais barato que aquele.”

**Prompt de transferência.** “Compare duas rotas para chegar a um lugar: uma é mais rápida e a outra é mais barata. Escolha uma.”

**Critério de domínio.** Produzir três comparações com dimensões diferentes, uma pergunta comparativa e uma frase de inferioridade; manter a ordem **A 比 B + adjetivo** sem **很**.

---

## V14 — Ajustar quantidade, intensidade e expectativa

**Vocabulário nuclear**

- 一点 — **yìdiǎn** — um pouco; uma pequena quantidade.
- 有点 — **yǒudiǎn** — um pouco, frequentemente com avaliação negativa ou “um pouco demais”.
- 点 — **diǎn** — forma reduzida de “um pouco” em pedidos.
- 慢 — **màn** — devagar.
- 快 — **kuài** — rápido.
- 贵 — **guì** — caro.
- 水 — **shuǐ** — água.

**Intenção.** Pedir ajuste de velocidade/quantidade ou avaliar algo como um pouco excessivo.

**Padrão ou função.** **[F] verbo/adjetivo + 一点** para solicitar grau menor ou ajuste: **请说慢一点。Qǐng shuō màn yìdiǎn. — Fale um pouco mais devagar.** **[F] 有点 + adjetivo** para avaliação do falante: **这个有点贵。Zhège yǒudiǎn guì. — Isto está um pouco caro.** **[F] 一点 + substantivo** para pequena quantidade: **一点水 yìdiǎn shuǐ — um pouco de água.**

**Exemplos.** 请说慢一点。**Qǐng shuō màn yìdiǎn.** — Fale um pouco mais devagar. / 这个有点贵。**Zhège yǒudiǎn guì.** — Isto está um pouco caro. / 给我一点水。**Gěi wǒ yìdiǎn shuǐ.** — Me dê um pouco de água. / 快点！**Kuài diǎn!** — Mais rápido!/Anda logo!

**Slots substituíveis.** Após verbo/adjetivo: **慢一点**, **便宜一点 piányi yìdiǎn** — um pouco mais barato, **清楚一点 qīngchu yìdiǎn** — um pouco mais claro. Após **有点**: **有点累 yǒudiǎn lèi** — um pouco cansado, **有点冷 yǒudiǎn lěng** — um pouco frio. Antes de nome: **一点茶 yìdiǎn chá** — um pouco de chá.

**Extensões.** **一点也不 + adjetivo** — de jeito nenhum/nada: **一点也不辣。Yìdiǎn yě bù là. — Não é nada apimentado.** Use somente depois de estabilizar os três padrões básicos.

**Observação pedagógica.** **一点** não funciona simplesmente como “pouco” em qualquer posição. Em pedidos e comparações, aparece após o adjetivo; diante de substantivo, expressa pequena quantidade. **有点** vem antes do adjetivo e frequentemente comunica uma avaliação desfavorável ou uma intensidade acima do desejado.[6] Esse contraste é especialmente útil para brasileiros que tendem a usar uma única tradução para as duas formas.

**Potencial de mapa.** Mapa de função: **pedir ajuste → avaliar grau → quantificar**. Mapa de posição: adjetivo + **一点**; **有点** + adjetivo; **一点** + nome. Mapa sonoro: **yìdiǎn** no fluxo, com atenção ao primeiro tom lexical de **一**.

**Prompt de recuperação.** “Peça para alguém falar um pouco mais devagar e diga que o preço está um pouco caro.”

**Prompt de transferência.** “Em uma loja, peça um pouco mais barato, solicite um pouco de água e avalie a sala como um pouco fria.”

**Critério de domínio.** Produzir um pedido com **一点**, uma avaliação com **有点** e uma pequena quantidade antes de um substantivo; colocar cada forma na posição correta.

---

## V15 — Ordenar ações em um plano simples

**Vocabulário nuclear**

- 先 — **xiān** — primeiro.
- 再 — **zài** — depois; novamente, conforme o contexto.
- 然后 — **ránhòu** — depois, então.
- 吃饭 — **chīfàn** — comer/fazer uma refeição.
- 去 — **qù** — ir.
- 回家 — **huí jiā** — voltar para casa.

**Intenção.** Dizer a ordem de duas ações e tornar um plano compreensível para outra pessoa.


**Padrão ou função.** **[F] 先 + [V] ação A，再 + [V] ação B。Xiān + ação A, zài + ação B. — Primeiro faço A, depois faço B.** Para encadear mais uma etapa: **[F] 先 A，再 B，然后 C。— Primeiro A, depois B e então C.**

**Exemplos.** 我们先吃饭，再去学校。**Wǒmen xiān chīfàn, zài qù xuéxiào.** — Primeiro vamos comer, depois vamos à escola. / 我先回家，然后给你打电话。**Wǒ xiān huí jiā, ránhòu gěi nǐ dǎ diànhuà.** — Primeiro volto para casa, depois ligo para você. / 你先说，我再回答。**Nǐ xiān shuō, wǒ zài huídá.** — Você fala primeiro, depois eu respondo.

**Slots substituíveis.** Ações: **吃饭 chīfàn** — comer; **回家 huí jiā** — voltar para casa; **学习 xuéxí** — estudar; **休息 xiūxi** — descansar; **打电话 dǎ diànhuà** — telefonar. Pessoas: **我**, **你**, **我们**. O segundo slot pode receber uma ação de conversa, deslocamento ou tarefa cotidiana.

**Extensões.** **先…再…** pode receber uma pergunta: **你先去还是我先去？Nǐ xiān qù háishi wǒ xiān qù? — Você vai primeiro ou eu vou?**; **然后** pode introduzir a consequência ou próxima etapa sem exigir uma explicação gramatical extensa.

**Observação pedagógica.** **再** aqui significa “depois/novamente”, e o contexto decide a leitura. Não confunda **先…再…** com uma lista de conectores para memorizar: a operação é informar uma ordem que ajuda alguém a agir. O padrão temporal antecede a ação, o que oferece uma oportunidade concreta de reduzir a interferência da ordem portuguesa.

**Potencial de mapa.** Mapa de função: **plano → etapa 1 → etapa 2 → etapa 3**. Mapa de padrão: **先 A，再 B**. Mapa de contraste: **先** como prioridade versus **再** como etapa posterior; conectar a **什么时候** e **可以吗** de V07.

**Prompt de recuperação.** “Diga primeiro que vai comer e depois que vai voltar para casa.”

**Prompt de transferência.** “Explique seu plano antes de uma aula: uma tarefa agora, uma depois e uma terceira no final. Use três ações novas.”

**Critério de domínio.** Produzir dois planos de duas etapas e um plano de três etapas, sem traduzir a ordem do português; responder a uma pergunta sobre quem faz a primeira ação.

---

## V16 — Suavizar, desculpar-se e confirmar a continuidade

**Vocabulário nuclear**

- 不好意思 — **bù hǎoyìsi** — desculpe; com licença; foi mal.
- 对不起 — **duìbuqǐ** — desculpe, em pedido de desculpas explícito.
- 没关系 — **méi guānxi** — sem problema; tudo bem.
- 请 — **qǐng** — por favor; permita-me.
- 谢谢 — **xièxie** — obrigado(a).
- 没问题 — **méi wèntí** — sem problema.
- 对 — **duì** — certo; isso mesmo.

**Intenção.** Manter a cooperação social em pequenos reparos: chamar alguém, interromper, pedir passagem, agradecer, confirmar e responder a um pedido de desculpas.

**Padrão ou função.** **[F] 不好意思，请问 + [V] pergunta。Bù hǎoyìsi, qǐngwèn + pergunta. — Com licença, posso perguntar…?**; **[F] 对不起。Duìbuqǐ. — Desculpe.**; **[F] 没关系。Méi guānxi. — Tudo bem/sem problema.**; **[F] 对，没问题。Duì, méi wèntí. — Certo, sem problema.**

**Exemplos.** 不好意思，请问洗手间在哪儿？**Bù hǎoyìsi, qǐngwèn xǐshǒujiān zài nǎr?** — Com licença, onde fica o banheiro? / 对不起，我没听懂。**Duìbuqǐ, wǒ méi tīng dǒng.** — Desculpe, não entendi. / 没关系，请再说一遍。**Méi guānxi, qǐng zài shuō yí biàn.** — Tudo bem, repita, por favor. / 谢谢。**Xièxie.** — Obrigado(a).

**Slots substituíveis.** Após **请问**, entre uma pergunta de localização, preço, horário ou identidade: **多少钱 duōshao qián** — quanto custa; **几点 jǐ diǎn** — que horas; **是什么 shì shénme** — o que é. Após **不好意思**, pode vir uma interrupção breve ou um pedido. Após **没关系**, retome a tarefa com **请…** ou **可以…**.

**Extensões.** **麻烦你了。Máfan nǐ le. — Desculpe incomodar/Obrigado pelo trabalho.** é útil em registro cortês, mas deve entrar depois das formas básicas. **没问题** pode confirmar disponibilidade, não apenas responder a um pedido de desculpas.

**Observação pedagógica.** **不好意思** é muito produtivo para chamar atenção ou suavizar uma interrupção; **对不起** é um pedido de desculpas mais explícito. A tradução brasileira “desculpa” cobre ambos em muitos contextos, mas a escolha é guiada pela situação, pelo peso do incômodo e pelo registro. Não transforme polidez em fórmula obrigatória antes de toda frase: o aluno deve decidir se está pedindo passagem, interrompendo, reparando ou agradecendo.

**Potencial de mapa.** Mapa de função: **aproximar-se → pedir → reparar → confirmar continuidade**. Mapa de contraste: **不好意思** e **对不起**; **没关系** e **没问题**. Mapa de consolidação: conectar pedido de V05, localização de V06 e reparo de V03.

**Prompt de recuperação.** “Chame alguém com educação, pergunte onde fica o banheiro e agradeça.”

**Prompt de transferência.** “Você interrompeu uma pessoa, não entendeu a resposta e precisa retomar a conversa. Use uma forma de desculpa, uma solicitação de reparo e uma confirmação final.”

**Critério de domínio.** Escolher **不好意思** para uma interrupção e **对不起** para um pedido de desculpas explícito; responder **没关系** a uma desculpa; produzir uma sequência de quatro atos sem depender de tradução.

---

## Critérios de seleção e de uso oral

O vocabulário deste bloco foi filtrado por cinco perguntas. Primeiro, o item permite uma ação oral real, como pedir, recusar, localizar, confirmar, comparar ou reparar? Segundo, ele aceita pelo menos três substituições controladas sem exigir uma lista grande de palavras novas? Terceiro, há uma decisão de forma que um brasileiro provavelmente precisa tomar? Quarto, o item pode ser testado por um prompt sem mostrar a resposta completa? Quinto, o item ajuda a conectar células antigas e novas?

Itens que não passam por esses testes devem ficar fora do bloco, mesmo que sejam frequentes. Uma palavra isolada, uma lista temática ou uma tradução de dicionário não constitui célula de transferência. O vocabulário de objetos e lugares deve aparecer somente como slot de uma ação. O pinyin com tons e os caracteres simplificados funcionam como apoio posterior à tentativa, não como roteiro de leitura durante o áudio.

### Protocolo de progressão do suporte

| Estado | O aluno vê | O aluno faz |
|---|---|---|
| Orientação | intenção, padrão completo, caracteres, pinyin e tradução funcional | reconhece a operação depois de ouvir |
| Recuperação | intenção, padrão com lacunas e slots nomeados | tenta produzir antes de consultar |
| Recombinação | núcleo, três opções e um alerta | troca componentes e produz variações |
| Transferência | situação, intenção e poucos gatilhos | usa o padrão em contexto não visto |
| Independência | apenas prompt oral ou situação | responde sem mapa completo |

O erro de pronúncia não deve ser “corrigido” por mais texto. Se o aluno falha em tom, ritmo ou distinção fonética, deve retornar ao áudio legítimo, repetir uma unidade curta e, quando necessário, buscar feedback humano ou uma ferramenta validada. O relatório não inclui diálogos, transcrições ou áudios proprietários.

### Critério geral de domínio

Uma célula está funcionalmente dominada quando o aluno consegue compreender a intenção no áudio, recuperar o padrão sem resposta visível, produzir pelo menos três recombinações, manter pronúncia funcional nos contrastes destacados e transferir a operação para um cenário novo. Reconhecimento visual, tradução correta ou repetição do único exemplo não bastam.

## Referências

[1]: https://www.chinesetest.cn/hsk "Chinese Tests Service Website — About the New HSK"
[2]: https://resources.allsetlearning.com/chinese/pronunciation/Tone_change_rules "Chinese Pronunciation Wiki — Tone change rules"
[3]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22bu%22_and_%22mei%22 "Chinese Grammar Wiki — Comparing bu and mei"
[4]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22haishi%22_and_%22huozhe%22 "Chinese Grammar Wiki — Comparing haishi and huozhe"
[5]: https://resources.allsetlearning.com/chinese/grammar/Basic_comparisons_with_%22bi%22 "Chinese Grammar Wiki — Basic comparisons with bi"
[6]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22youdian%22_and_%22yidian%22 "Chinese Grammar Wiki — Comparing youdian and yidian"
[7]: https://resources.allsetlearning.com/chinese/grammar/Change_of_state_with_%22le%22 "Chinese Grammar Wiki — Change of state with le"
