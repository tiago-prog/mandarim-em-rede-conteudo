# Conteúdo cumulativo
## Progressão oral de 14 aulas e mapas de consolidação

> **Escopo editorial.** Este bloco organiza uma progressão própria de fala para brasileiro iniciante a intermediário inicial. Ele parte das células de transferência já definidas no projeto, amplia-as sem reproduzir diálogos, transcrições ou áudios proprietários e termina em tarefas curtas de interação. Os exemplos são originais, em caracteres simplificados, com pinyin tonal e tradução natural brasileira.

A sequência foi fixada em **14 aulas**, dentro da faixa de 12 a 16 solicitada. O número é deliberado: oito aulas retomam e expandem o núcleo já previsto no projeto; seis aulas acrescentam continuidade, aspecto, sequência, deslocamento, convite e opinião. A cada quatro ou três aulas há um mapa de consolidação. Assim, o aluno não passa de “frase reconhecida” para “frase livre” de uma vez; passa por **função → padrão → substituição → extensão → combinação → situação nova**.

A progressão adota quatro dimensões de domínio: **compreender a intenção ao ouvir, recuperar a forma oral, manter pronúncia funcional e transferir para contexto não visto**. Essa decisão é compatível com a descrição de proficiência da ACTFL, que avalia o que a pessoa consegue fazer em situações reais e espontâneas por funções/tarefas, acurácia, contexto/conteúdo e tipo de texto [1]. Também privilegia interação, reparo, cooperação orientada a objetivo e obtenção de bens/serviços, categorias destacadas no volume complementar do CEFR [2].

## 1. Regras de uso do bloco

1. **O áudio ou input principal vem antes da consulta visual.** O aluno tenta responder, registra a falha e só então consulta o mapa completo.
2. **Cada aula tem uma operação dominante.** Variações e extensões servem à ação oral; não entram como lista decorativa.
3. **Os exemplos não são para decorar como mini diálogos.** O aluno deve trocar os elementos marcados como slots e produzir pelo menos três combinações.
4. **A tradução é funcional, não palavra por palavra.** Ela ajuda a decidir o sentido em português brasileiro e deve desaparecer nos estados de recuperação e transferência.
5. **Os caracteres apoiam a organização e a leitura posterior.** Não são requisito para iniciar a produção oral.
6. **O pinyin registra tons lexicais ou a realização esperada da expressão.** Mudanças de tom na fala conectada são alertadas, não transformadas em uma nova palavra.
7. **O mapa encolhe.** Cada célula passa por `orientação completa → recuperação lacunada → transferência mínima → independência`.
8. **A revisão é espaçada e cumulativa.** Recuperar em momentos separados, variar o prompt e transferir para contexto novo é mais produtivo do que reler o mesmo exemplo; a prática de recuperação também revela lacunas que precisam de correção rápida [4].

### Notação comum das células

- **[F]** componente fixo: ordem ou expressão que sustenta a função.
- **[V]** slot variável: elemento substituível pelo aluno.
- **[O]** extensão opcional: só entra depois de o padrão-base estar estável.
- **[X]** contraste ou erro provável.
- **[A]** alerta auditivo, tonal ou de pronúncia.
- **[R]** recuperação e transferência.

---

# 2. Progressão de 14 aulas

## Aula 1 — Entrar na interação: nome, origem e idioma

### Intenção
**Iniciar uma interação e dar informação pessoal básica.** O aluno consegue cumprimentar, dizer o nome, informar nacionalidade/origem e dizer que idioma fala.

### Padrão ou função

```text
[F] 你好，我叫 + [V nome]。
Nǐ hǎo, wǒ jiào + [nome].
Olá, eu me chamo + [nome].

[F] 你是哪国人？
Nǐ shì nǎ guó rén?
De que país você é?

[F] 我是 + [V país] + 人。
Wǒ shì + [país] rén.
Eu sou + [nacionalidade].

[F] 我说 + [V idioma]。
Wǒ shuō + [idioma].
Eu falo + [idioma].
```

### Exemplos

- 你好，我叫安娜。  
  **Nǐ hǎo, wǒ jiào Ānnà.**  
  Olá, eu me chamo Ana.
- 我是巴西人，我说葡萄牙语。  
  **Wǒ shì Bāxī rén, wǒ shuō Pútáoyáyǔ.**  
  Sou brasileira e falo português.
- 我会说一点中文。  
  **Wǒ huì shuō yìdiǎn Zhōngwén.**  
  Sei falar um pouco de chinês.
- 你呢？  
  **Nǐ ne?**  
  E você?

### Slots substituíveis

`[nome]`: 安娜 Ānnà, 保罗 Bǎoluó; `[país]`: 巴西 Bāxī, 中国 Zhōngguó, 美国 Měiguó; `[idioma]`: 葡萄牙语 Pútáoyáyǔ, 中文 Zhōngwén, 英语 Yīngyǔ. Não introduzir uma lista grande: dois ou três itens bastam por rodada.

### Extensões

- 很高兴认识你。  
  **Hěn gāoxìng rènshi nǐ.**  
  Prazer em conhecer você.
- 我是巴西人，但是我住在中国。  
  **Wǒ shì Bāxī rén, dànshì wǒ zhù zài Zhōngguó.**  
  Sou brasileiro, mas moro na China.  
  *Usar somente se `住在 + lugar` já tiver sido ouvido no percurso do aluno.*

### Observação pedagógica

Ensinar **是 + nacionalidade** e **说 + idioma** como duas decisões comunicativas distintas. `我是巴西人` não deve ser substituído por uma tradução literal de “eu sou do Brasil”; `我说葡萄牙语` usa `说` para a língua falada. Em `nǐ hǎo`, os dois caracteres têm terceiro tom lexical, mas o primeiro costuma soar como segundo tom em fala conectada: o aluno deve imitar o fluxo, não aplicar uma regra isolada. `名字 míngzi` e `谢谢 xièxie` também têm sílaba final frequentemente neutra. O pinyin não deve ser lido segundo os valores ortográficos do português.

### Potencial de mapa

**Mapa de função “identificar-se”.** Centro `[N] pessoa em primeiro contato`; primeiro anel `[F] saudação + nome`; segundo anel `[V] país + idioma`; conexão lateral `[X] 是 ≠ 说`; saída `[R] devolver a pergunta com 你呢？`. O mapa deve ligar esta aula às futuras células de **preferência, localização e encontro**, não a uma lista de países.

### Prompt de recuperação

“Você acabou de conhecer alguém. Cumprimente, diga que se chama Ana, diga que é brasileira e que fala português. Depois pergunte: ‘e você?’” O aluno responde sem ver mandarim, pinyin ou tradução.

### Prompt de transferência

“Em uma chamada curta, você conhece uma pessoa chinesa chamada Li. Troque seu nome, seu país e o idioma que fala. Inclua que sabe falar um pouco de chinês.” A situação é nova porque muda interlocutor, nome e combinação de dados.

### Critério de domínio

Produzir duas apresentações com nomes e idiomas diferentes; perguntar a origem sem ordenar a frase como em português; distinguir oralmente `是 shì` de `说 shuō`; usar `你呢？` sem esperar um modelo escrito; manter pronúncia funcional de `叫 jiào`, `说 shuō` e `中文 Zhōngwén`.

---

## Aula 2 — Identificar, confirmar e reparar uma falha

### Intenção
**Descobrir o que é algo, confirmar uma informação e manter a conversa quando não entende.** A aula combina identificação e reparo porque ambas são ações observáveis em interação inicial.

### Padrão ou função

```text
[F] 这/那是什么？
Zhè/nà shì shénme?
O que é isto/aquilo?

[F] 这是/那是 + [V objeto]。
Zhè shì/nà shì + [objeto].
Isto/aquilo é + [objeto].

[F] 这是 + [V pessoa] + 的 + [V objeto] + 吗？
Zhè shì + [pessoa] de + [objeto] ma?
Isto é o(a) [objeto] de [pessoa]?

[F] 我没听懂，请再说一遍。
Wǒ méi tīng dǒng, qǐng zài shuō yí biàn.
Não entendi; por favor, repita.
```

### Exemplos

- 这是什么？  
  **Zhè shì shénme?**  
  O que é isto?
- 这是我的手机。  
  **Zhè shì wǒ de shǒujī.**  
  Este é o meu celular.
- 那是他的包。  
  **Nà shì tā de bāo.**  
  Aquela é a bolsa dele.
- 这是你的书吗？  
  **Zhè shì nǐ de shū ma?**  
  Este livro é seu?
- 对，是我的。  
  **Duì, shì wǒ de.**  
  Sim, é meu.
- 不，不是我的。  
  **Bù, bú shì wǒ de.**  
  Não, não é meu.
- 请说慢一点。  
  **Qǐng shuō màn yìdiǎn.**  
  Por favor, fale um pouco mais devagar.

### Slots substituíveis

`[referente]`: 这 zhè, 那 nà; `[pessoa]`: 我 wǒ, 你 nǐ, 他 tā; `[objeto]`: 书 shū, 手机 shǒujī, 水 shuǐ, 包 bāo. Para reparo, substituir o pedido final por `请再说一遍` ou `请说慢一点`.

### Extensões

- 你听懂了吗？  
  **Nǐ tīng dǒng le ma?**  
  Você entendeu?
- 现在我明白了。  
  **Xiànzài wǒ míngbai le.**  
  Agora eu entendi.

### Observação pedagógica

`这 zhè` e `那 nà` são contrastes espaciais; não são apenas traduções intercambiáveis de “este/aquele”. `的 de` marca relação/posse e fica entre pessoa e objeto. Em reparo, `没 méi` indica que o entendimento não ocorreu naquela tentativa; não trocar por `不 bù` automaticamente. Em `不是`, o pinyin de apoio pode registrar a realização **bú shì**, pois `不` muda antes de uma sílaba de quarto tom. O aluno precisa aprender que pedir repetição é uma competência comunicativa, não uma confissão de fracasso.

### Potencial de mapa

**Mapa de função “verificar e reparar”.** Centro `[N] informação incompleta`; ramos `[F] perguntar o que é`, `[F] confirmar posse`, `[F] negar/corrigir`, `[F] pedir repetição`; contraste `[X] 这/那 e 不/没`; conexão com Aula 1: pessoa → objeto → propriedade → compreensão.

### Prompt de recuperação

“Você aponta para um objeto próximo e pergunta o que é. Depois confirme se é o celular da outra pessoa. Imagine que a resposta veio rápida: diga que não entendeu e peça repetição.”

### Prompt de transferência

“Em uma loja, você aponta para um objeto distante, pergunta o que é, descobre que não é seu e pede que o atendente repita mais devagar.” O aluno deve encadear as funções sem receber uma sequência de frases.

### Critério de domínio

Usar `这` e `那` em três objetos; confirmar e negar posse com `的`; escolher `我没听懂` sem pista escrita quando a informação não foi entendida; pedir repetição com `能` ou com `请`; manter `bú shì` e `méi tīng dǒng` funcionalmente distintos.

---

## Aula 3 — Querer, pedir e recusar um item

### Intenção
**Expressar vontade, solicitar algo e dizer que não quer.** A função desloca o aluno da identificação para a ação transacional.

### Padrão ou função

```text
[F] 我想 + [V ação]。
Wǒ xiǎng + [ação].
Quero/gostaria de + [ação].

[F] 我想要 + [V item/quantidade]。
Wǒ xiǎng yào + [item/quantidade].
Quero + [item/quantidade].

[F] 请给我 + [V item/quantidade]。
Qǐng gěi wǒ + [item/quantidade].
Por favor, me dê + [item/quantidade].

[F] 我不要 + [V item]。
Wǒ bú yào + [item].
Não quero + [item].
```

### Exemplos

- 我想喝水。  
  **Wǒ xiǎng hē shuǐ.**  
  Quero beber água.
- 我想要一杯茶。  
  **Wǒ xiǎng yào yì bēi chá.**  
  Quero uma xícara de chá.
- 请给我一杯咖啡。  
  **Qǐng gěi wǒ yì bēi kāfēi.**  
  Por favor, me dê um café.
- 我要这个。  
  **Wǒ yào zhège.**  
  Quero este.
- 我不要咖啡。  
  **Wǒ bú yào kāfēi.**  
  Não quero café.
- 谢谢。  
  **Xièxie.**  
  Obrigado(a).

### Slots substituíveis

`[ação]`: 喝 hē, 吃 chī, 看 kàn; `[item]`: 水 shuǐ, 茶 chá, 咖啡 kāfēi, 这个 zhège; `[quantidade]`: 一杯 yì bēi, 一本 yì běn *se o classificador já tiver sido ouvido*. Não exigir a produção de muitos classificadores no mesmo bloco.

### Extensões

- 我还要一杯水。  
  **Wǒ hái yào yì bēi shuǐ.**  
  Também quero mais um copo de água.
- 我不想吃饭。  
  **Wǒ bù xiǎng chīfàn.**  
  Não estou com vontade de comer.

### Observação pedagógica

Não apresentar `想` e `要` como sinônimos perfeitos nem como regra rígida. **想 + ação** costuma enquadrar desejo/intenção; **要 + item** funciona bem para pedir ou indicar uma decisão. O contexto pode permitir sobreposição. `给我` não é “dar para eu” em ordem portuguesa; é um padrão direto de pedido. O contraste auditivo prioritário é `xiǎng` (terceiro tom) versus `yào` (quarto tom), além de `bú yào` em fala conectada.

### Potencial de mapa

**Mapa de função “resolver uma necessidade”.** Centro `[N] quero obter/fazer`; primeiro anel `[F]想 + ação`, `[F]想要 + item`, `[F]请给我 + item`; segundo anel `[V] bebida, comida, objeto, quantidade`; contraste `[X] 想 ≠ 要 em enquadramento funcional`; conexão com Aula 2: item identificado → item solicitado.

### Prompt de recuperação

“Em um café, diga que quer beber água, peça uma xícara de chá, diga que não quer café e agradeça.”

### Prompt de transferência

“Você está em uma casa de alguém. Aponte para um item que acabou de identificar, diga que o quer, recuse outro e peça mais água.” Alterar os itens em cada rodada.

### Critério de domínio

Produzir cinco pedidos com pelo menos três itens/ações; usar `请给我`; recusar com `不要` e expressar falta de vontade com `不想`; distinguir `想` e `要` pelo contexto; realizar `bú yào` sem transformar `不` em uma sílaba isolada.

---

## Aula 4 — Localizar pessoa, objeto e lugar

### Intenção
**Perguntar onde algo/alguém está e responder com uma localização curta.** A célula acrescenta espaço à rede de identificação e pedido.

### Padrão ou função

```text
[F] [V pessoa/objeto] 在哪儿/哪里？
[V pessoa/objeto] zài nǎr/nǎlǐ?
Onde está/fica [pessoa/objeto]?

[F] [V pessoa/objeto] 在 + [V lugar]。
[V pessoa/objeto] zài + [lugar].
[Pessoa/objeto] está em + [lugar].

[F] [V objeto] 在 + [V recipiente] 里。
[V objeto] zài + [recipiente] lǐ.
[Objeto] está dentro de + [recipiente].
```

### Exemplos

- 你在哪儿？  
  **Nǐ zài nǎr?**  
  Onde você está?
- 我在这里。  
  **Wǒ zài zhèlǐ.**  
  Estou aqui.
- 洗手间在哪儿？  
  **Xǐshǒujiān zài nǎr?**  
  Onde fica o banheiro?
- 手机在哪里？  
  **Shǒujī zài nǎlǐ?**  
  Onde está o celular?
- 手机在包里。  
  **Shǒujī zài bāo lǐ.**  
  O celular está na bolsa.
- 书在那儿。  
  **Shū zài nàr.**  
  O livro está ali.

### Slots substituíveis

`[pessoa/objeto]`: 我 wǒ, 你 nǐ, 他 tā, 手机 shǒujī, 书 shū; `[lugar]`: 这里 zhèlǐ, 那里 nàlǐ, 家 jiā, 学校 xuéxiào; `[recipiente]`: 包 bāo, 房间 fángjiān. Escolher `哪儿` ou `哪里` por rodada para não transformar variação regional em problema inicial.

### Extensões

- 手机在桌子上。  
  **Shǒujī zài zhuōzi shàng.**  
  O celular está em cima da mesa.
- 我在家学习中文。  
  **Wǒ zài jiā xuéxí Zhōngwén.**  
  Estudo chinês em casa.

### Observação pedagógica

A distinção central é **在 zài para localização** versus **是 shì para identificação/classificação**. `在哪儿` e `在哪里` cumprem a mesma função básica, mas o aluno deve estabilizar uma forma antes de alternar. O `r` de `哪儿 nǎr` não deve ser forçado como um “r” gutural brasileiro. Em `这里/那里`, a segunda sílaba pode reduzir na fala; a meta é reconhecer e produzir a expressão inteira, não recitar tons isolados.

### Potencial de mapa

**Mapa de função “encontrar”.** Centro `[N] localizar`; ramos `[F] pergunta com 在哪儿`, `[F] resposta com 在`, `[V] pessoa/objeto`, `[V] aqui/ali/recipiente`; contraste `[X] 在 ≠ 是`; conexão Aula 2: objeto/posse → localização; conexão Aula 3: localização → pedido.

### Prompt de recuperação

“Pergunte onde está o celular. Responda que está dentro da bolsa. Depois pergunte onde fica o banheiro e diga que você está aqui.”

### Prompt de transferência

“Use dois objetos reais à sua volta e dois lugares reais. Pergunte e responda seis vezes, alternando pessoa, objeto, aqui, ali e dentro de um lugar.”

### Critério de domínio

Produzir três perguntas de localização e três respostas novas; usar `在` sem trocá-lo por `是`; distinguir `这里` de `那里`; responder a um prompt em português sem montar a frase primeiro em português; manter `zài` e `nǎr/nǎlǐ` compreensíveis.

---

## Mapa de consolidação 1 — Entrar, verificar, pedir e localizar (Aulas 1–4)

### Intenção
**Resolver uma primeira interação curta:** apresentar-se, verificar uma informação, pedir algo e encontrar um objeto ou lugar.

### Padrão ou função

```text
[N] pessoa → identidade → objeto → necessidade → lugar/reparo
[F] saudação + identificação
[F] 这是什么？/这是…吗？
[F] 我想要…/请给我…
[F] …在哪儿？/…在…
[O] 我没听懂，请再说一遍。
```

### Exemplos de combinação

- 你好，我叫保罗。我是巴西人，我说葡萄牙语。  
  **Nǐ hǎo, wǒ jiào Bǎoluó. Wǒ shì Bāxī rén, wǒ shuō Pútáoyáyǔ.**  
  Olá, eu me chamo Paulo. Sou brasileiro e falo português.
- 这是什么？这是我的手机。  
  **Zhè shì shénme? Zhè shì wǒ de shǒujī.**  
  O que é isto? Este é o meu celular.
- 我想要一杯水。手机在哪儿？  
  **Wǒ xiǎng yào yì bēi shuǐ. Shǒujī zài nǎr?**  
  Quero um copo de água. Onde está o celular?

### Slots substituíveis

Nome, país, idioma, objeto, pessoa, pedido, quantidade e lugar. O mapa deve liberar somente dois ou três slots por rodada; a dificuldade vem da combinação das funções, não de vocabulário ilimitado.

### Extensões

Adicionar uma falha de compreensão (`我没听懂`) ou uma correção de posse (`不，不是我的`). Não acrescentar conteúdo novo durante a consolidação.

### Observação pedagógica

O mapa de consolidação não é um roteiro de diálogo. É uma **rede de decisões**. A prática baseada em tarefas funciona melhor quando a língua serve para completar uma ação significativa, e não quando o aluno apenas recita formas [3]. O professor/material deve aceitar respostas curtas e funcionais, corrigindo rapidamente os contrastes que impedem a intenção.

### Potencial de mapa

Mapa de consolidação com cinco nós: `[N] pessoa`, `[N] objeto`, `[N] necessidade`, `[N] lugar`, `[R] reparo`. Estado 1 mostra padrões; estado 2 deixa lacunas nos slots; estado 3 mostra somente a situação; estado 4 mostra apenas três gatilhos: `novo contato / precisa de algo / não encontra`.

### Prompt de recuperação

“Sem olhar, apresente-se como uma pessoa brasileira que fala português, pergunte o que é um objeto, diga que o quer e pergunte onde está outro objeto.”

### Prompt de transferência

“Situação nova: você chega a um café, conhece alguém, aponta para um objeto, faz um pedido e não encontra seu celular. Conclua em 60–90 segundos, sem reproduzir uma sequência ensaiada.”

### Critério de domínio

Executar duas rodadas de 60–90 segundos; alterar pelo menos três slots; incluir uma confirmação ou reparo; produzir sem o mapa completo; consultar apenas um gatilho mínimo na segunda rodada. O mapa 1 está consolidado quando a pessoa não depende da ordem das aulas para decidir a próxima ação.

---

## Aula 5 — Organizar tempo, disponibilidade e encontro

### Intenção
**Perguntar quando, dizer se tem tempo e propor um horário.** A função transforma localização em organização de uma ação futura.

### Padrão ou função

```text
[F] 你什么时候有时间？
Nǐ shénme shíhou yǒu shíjiān?
Quando você tem tempo?

[F] [V dia/período] + 有/没(有)时间。
[V dia/período] + yǒu/méi(yǒu) shíjiān.
[Dia/período], tenho/não tenho tempo.

[F] [V dia/período] + [V horário]，可以吗？
[V dia/período] + [horário], kěyǐ ma?
[Dia/período] às [horário], pode ser?
```

### Exemplos

- 现在几点？  
  **Xiànzài jǐ diǎn?**  
  Que horas são agora?
- 我明天有时间。  
  **Wǒ míngtiān yǒu shíjiān.**  
  Tenho tempo amanhã.
- 我今天没时间。  
  **Wǒ jīntiān méi shíjiān.**  
  Hoje não tenho tempo.
- 明天上午九点，可以吗？  
  **Míngtiān shàngwǔ jiǔ diǎn, kěyǐ ma?**  
  Amanhã às nove da manhã, pode ser?
- 可以，没问题。  
  **Kěyǐ, méi wèntí.**  
  Pode ser, sem problema.
- 我们明天见。  
  **Wǒmen míngtiān jiàn.**  
  Nos vemos amanhã.

### Slots substituíveis

`[dia/período]`: 今天 jīntiān, 明天 míngtiān, 现在 xiànzài, 周末 zhōumò; `[horário]`: 上午九点 shàngwǔ jiǔ diǎn, 下午三点 xiàwǔ sān diǎn, 晚上七点 wǎnshang qī diǎn. A princípio, usar horas inteiras; minutos entram somente se já forem familiares ao aluno.

### Extensões

- 你什么时候有时间？  
  **Nǐ shénme shíhou yǒu shíjiān?**  
  Quando você tem tempo?
- 我们下午三点见，可以吗？  
  **Wǒmen xiàwǔ sān diǎn jiàn, kěyǐ ma?**  
  Podemos nos encontrar às três da tarde?

### Observação pedagógica

`有时间` enquadra disponibilidade, enquanto `没时间` é a forma natural para “não tenho tempo” em uma situação concreta. Não exigir `没有时间` como única resposta. A ordem temporal vem antes do evento ou da proposta; não transpor automaticamente a ordem “nos vemos às nove amanhã”. O foco tonal é `míngtiān`, `shíjiān`, `kěyǐ` e `méiyǒu`; dois terceiros tons em `可以` podem sofrer ajuste em fala conectada, sem alteração da grafia lexical. Mudanças de tom são fenômenos de fala, não motivo para escrever uma “nova palavra” [5] [6].

### Potencial de mapa

Mapa de função `[N] combinar uma ação futura`; ramos `[V] dia`, `[V] período`, `[V] horário`, `[F] 有/没时间`, `[F] 可以吗？`; conexão com Aula 4: lugar → encontro no tempo.

### Prompt de recuperação

“Pergunte quando a pessoa tem tempo. Diga que amanhã você tem tempo. Proponha amanhã de manhã às nove e confirme se pode ser.”

### Prompt de transferência

“Escolha mentalmente três horários novos: um aceito, um recusado por falta de tempo e um remarcado. Produza as três propostas sem usar português durante a rodada.”

### Critério de domínio

Perguntar disponibilidade; produzir três horários não vistos no exemplo; aceitar e recusar; usar `可以吗？`; manter `今天/明天`, `上午/下午` e `有/没时间` compreensíveis; preservar a ordem temporal sem copiar a estrutura brasileira.

---

## Aula 6 — Dizer capacidade, impossibilidade e permissão

### Intenção
**Dizer o que sabe fazer, o que não consegue fazer numa situação e pedir permissão.** A célula separa três sentidos frequentemente traduzidos por “poder”.

### Padrão ou função

```text
[F] 我会 + [V ação/habilidade]。
Wǒ huì + [ação/habilidade].
Eu sei/consigo + [ação].

[F] 我不会 + [V ação/habilidade]。
Wǒ bú huì + [ação/habilidade].
Eu não sei/não consigo + [ação].

[F] 我不能 + [V ação nesta situação]。
Wǒ bù néng + [ação].
Eu não posso/não consigo + [ação] agora/nesta situação.

[F] 我可以 + [V ação] + 吗？
Wǒ kěyǐ + [ação] ma?
Posso + [ação]?
```

### Exemplos

- 我会说一点中文。  
  **Wǒ huì shuō yìdiǎn Zhōngwén.**  
  Sei falar um pouco de chinês.
- 我不会说得很快。  
  **Wǒ bú huì shuō de hěn kuài.**  
  Não consigo falar rápido.
- 我今天不能去。  
  **Wǒ jīntiān bù néng qù.**  
  Hoje não posso ir.
- 我可以坐这儿吗？  
  **Wǒ kěyǐ zuò zhèr ma?**  
  Posso sentar aqui?
- 你会不会说英语？  
  **Nǐ huì bu huì shuō Yīngyǔ?**  
  Você fala inglês?

### Slots substituíveis

`[habilidade]`: 说中文 shuō Zhōngwén, 做饭 zuòfàn, 开车 kāichē; `[ação situacional]`: 去 qù, 进来 jìnlái, 等 děng; `[ação autorizável]`: 坐这儿 zuò zhèr, 用手机 yòng shǒujī. Os slots devem ser ações já presentes ou transparentes no repertório auditivo do aluno.

### Extensões

- 你能再说一遍吗？  
  **Nǐ néng zài shuō yí biàn ma?**  
  Você pode repetir?
- 可以。/不可以。  
  **Kěyǐ. / Bù kěyǐ.**  
  Pode. / Não pode.

### Observação pedagógica

`会 huì` é capacidade aprendida ou habilidade; `能 néng` é possibilidade/capacidade numa condição; `可以 kěyǐ` é permissão ou possibilidade aceita. As fronteiras dependem do contexto, mas a pergunta do material deve obrigar uma escolha funcional. Não ensinar “um verbo = uma tradução”. O alerta tonal principal é `huì` (quarto tom) e `bú huì`; `不会` não deve ser pronunciado como `bù huì` isolado antes de outro quarto tom.

### Potencial de mapa

Mapa de contraste `[N] posso fazer?`; três ramos paralelos `[F] 会 habilidade`, `[F] 能 condição`, `[F] 可以 permissão`; conexão com Aula 5: disponibilidade → capacidade de cumprir o plano; conexão com Aula 2: `能再说一遍吗？` como reparo.

### Prompt de recuperação

“Diga que sabe falar um pouco de chinês, que não consegue falar rápido, que hoje não pode ir e pergunte se pode sentar aqui.”

### Prompt de transferência

“Em uma sala nova, escolha uma habilidade, uma impossibilidade de hoje e uma ação para a qual precisa de autorização. Produza as três frases sem repetir os exemplos.”

### Critério de domínio

Fazer uma afirmação e uma negação de habilidade; negar uma ação por situação; pedir permissão; reutilizar `能` para reparo; explicar em português, depois de produzir, por que escolheu `会`, `能` ou `可以`.

---

## Aula 7 — Expressar preferência e escolher entre alternativas

### Intenção
**Dizer do que gosta, suavizar preferência e perguntar “A ou B?”** A aula diferencia desejo momentâneo de preferência relativamente estável.

### Padrão ou função

```text
[F] 我喜欢 + [V opção/ação]。
Wǒ xǐhuan + [opção/ação].
Eu gosto de/prefiro + [opção/ação].

[F] 我不太喜欢 + [V opção]。
Wǒ bú tài xǐhuan + [opção].
Eu não gosto muito de + [opção].

[F] 你喜欢 + [V A] 还是 [V B]？
Nǐ xǐhuan A háishi B?
Você prefere A ou B?
```

### Exemplos

- 我喜欢喝茶。  
  **Wǒ xǐhuan hē chá.**  
  Gosto de beber chá.
- 我不太喜欢喝咖啡。  
  **Wǒ bú tài xǐhuan hē kāfēi.**  
  Não gosto muito de café.
- 你喜欢茶还是咖啡？  
  **Nǐ xǐhuan chá háishi kāfēi?**  
  Você prefere chá ou café?
- 我比较喜欢茶。  
  **Wǒ bǐjiào xǐhuan chá.**  
  Prefiro mais chá.
- 我喜欢茶，不喜欢咖啡。  
  **Wǒ xǐhuan chá, bù xǐhuan kāfēi.**  
  Gosto de chá, mas não de café.

### Slots substituíveis

`[A/B]`: 茶 chá, 咖啡 kāfēi, 中文 Zhōngwén, 英语 Yīngyǔ; `[ação]`: 喝 hē, 学习 xuéxí, 看 kàn. Para manter naturalidade, em pergunta de escolha usar `还是 háishi`, não `或者 huòzhě`; `或者` pode entrar depois em afirmações do tipo “chá ou café, qualquer um serve”.

### Extensões

- 我更喜欢这个。  
  **Wǒ gèng xǐhuan zhège.**  
  Prefiro este.
- 你想喝茶还是咖啡？  
  **Nǐ xiǎng hē chá háishi kāfēi?**  
  Você quer beber chá ou café?  
  *Aqui `想` pergunta vontade; não é a mesma função de `喜欢`.*

### Observação pedagógica

O contraste didático é **喜欢 = preferência/gosto** versus **想 = vontade neste momento**. `还是` ocorre na pergunta de escolha; não traduzir literalmente como “ainda é”. `喜欢 xǐhuan` costuma ter segunda sílaba neutra. `茶 chá` é segundo tom e não deve receber a mesma configuração do “chá” brasileiro.

### Potencial de mapa

Mapa de decisão `[N] escolher`; ramo `[F] gosto`, ramo `[F] preferência relativa`, ramo `[F] escolha A/还是 B`; contraste `[X] 喜欢 ≠ 想`; conexão Aula 3: quero agora → gosto em geral; conexão Aula 6: posso fazer → escolho fazer.

### Prompt de recuperação

“Diga que gosta de chá, que não gosta muito de café e pergunte se a outra pessoa prefere chá ou café.”

### Prompt de transferência

“Troque bebidas por duas atividades e duas línguas. Faça uma pergunta de escolha, responda com preferência e depois diga o que quer fazer agora.”

### Critério de domínio

Produzir uma preferência afirmativa, uma negativa suavizada e uma pergunta com `还是`; distinguir `喜欢` de `想` em dois contextos; gerar quatro combinações sem consultar o exemplo; manter `xǐhuan`, `háishi` e `chá` inteligíveis.

---

## Aula 8 — Descrever rotina e frequência

### Intenção
**Dizer quando e com que frequência faz uma ação cotidiana.** A célula amplia a frase curta para um padrão reutilizável de rotina.

### Padrão ou função

```text
[F] [V frequência/tempo] + [V sujeito] + [V ação] + [O objeto]。
[V frequência/tempo] + sujeito + ação + objeto.

[F] 你 + [V frequência] + [ação] + 吗？
Nǐ + [frequência] + [ação] ma?
Você [frequência] [ação]?
```

### Exemplos

- 我每天早上学习中文。  
  **Wǒ měitiān zǎoshang xuéxí Zhōngwén.**  
  Estudo chinês todas as manhãs.
- 我晚上不喝咖啡。  
  **Wǒ wǎnshang bù hē kāfēi.**  
  Não bebo café à noite.
- 我周末有时候看电影。  
  **Wǒ zhōumò yǒushíhou kàn diànyǐng.**  
  Às vezes vejo filmes no fim de semana.
- 你每天早上喝咖啡吗？  
  **Nǐ měitiān zǎoshang hē kāfēi ma?**  
  Você toma café todas as manhãs?

### Slots substituíveis

`[frequência/tempo]`: 每天 měitiān, 每周 měi zhōu, 早上 zǎoshang, 晚上 wǎnshang, 周末 zhōumò; `[ação]`: 学习 xuéxí, 喝 hē, 看 kàn, 工作 gōngzuò; `[objeto]`: 中文 Zhōngwén, 咖啡 kāfēi, 电影 diànyǐng. Introduzir `常常 chángcháng` e `有时候 yǒushíhou` somente depois do padrão sem advérbio estar automático.

### Extensões

- 我每天晚上都学习中文。  
  **Wǒ měitiān wǎnshang dōu xuéxí Zhōngwén.**  
  Estudo chinês todas as noites.
- 我有时候在家工作。  
  **Wǒ yǒushíhou zài jiā gōngzuò.**  
  Às vezes trabalho em casa.

### Observação pedagógica

A prioridade é posição: o marcador de tempo/frequência costuma vir antes do verbo. Não exigir que o iniciante domine todos os advérbios de uma vez. `都 dōu` só entra quando houver um conjunto ou totalidade clara; não usar como “muito”. A aula deve gerar informação pessoal verificável, não frases genéricas de livro didático. O professor pode pedir que o aluno use a própria rotina, mas o critério linguístico continua sendo a recombinação do padrão.

### Potencial de mapa

Mapa de padrão `[N] rotina`; primeiro anel `[F] tempo/frequência → sujeito → ação`; segundo anel `[V] ações e objetos`; contraste `[X] tempo antes do verbo`; conexão com Aula 5: rotina → disponibilidade; conexão com Aula 7: rotina → preferência.

### Prompt de recuperação

“Diga o que você faz todas as manhãs, o que não faz à noite e o que às vezes faz no fim de semana.”

### Prompt de transferência

“Escolha uma rotina real de trabalho/estudo e uma rotina de lazer. Diga três hábitos sem usar os exemplos de café, cinema e chinês.”

### Critério de domínio

Produzir cinco frases de rotina com três marcadores temporais diferentes; fazer e responder uma pergunta de frequência; colocar o tempo no lugar funcional; incluir uma negação sem perder a ordem; usar `有时候` ou `常常` sem transformar a resposta em leitura lenta.

---

## Mapa de consolidação 2 — Pedir, combinar, escolher e descrever rotina (Aulas 5–8)

### Intenção
**Organizar uma necessidade cotidiana no tempo:** escolher algo, verificar capacidade, combinar horário, fazer um pedido e falar da rotina que afeta o plano.

### Padrão ou função

```text
[N] necessidade + tempo + possibilidade + escolha
[F] 我想要… / 请给我…
[F] …有时间吗？/…可以吗？
[F] 会/能/可以
[F] 喜欢 A 还是 B？
[F] 每天/周末 + ação
```

### Exemplos de combinação

- 明天上午九点，可以吗？  
  **Míngtiān shàngwǔ jiǔ diǎn, kěyǐ ma?**  
  Amanhã às nove da manhã, pode ser?
- 我会说一点中文，但是我不会说得很快。  
  **Wǒ huì shuō yìdiǎn Zhōngwén, dànshì wǒ bú huì shuō de hěn kuài.**  
  Sei falar um pouco de chinês, mas não consigo falar rápido.
- 你喜欢茶还是咖啡？我比较喜欢茶。  
  **Nǐ xǐhuan chá háishi kāfēi? Wǒ bǐjiào xǐhuan chá.**  
  Você prefere chá ou café? Eu prefiro chá.

### Slots substituíveis

Dia, horário, ação, bebida, habilidade, atividade de rotina e disponibilidade. Cada rodada deve alterar pelo menos três dimensões; não repetir o mesmo pedido com apenas o item trocado.

### Extensões

Adicionar uma incompatibilidade de rotina: `我晚上没时间。` — **Wǒ wǎnshang méi shíjiān.** — “À noite não tenho tempo.” Em seguida, propor outro horário com `可以吗？`.

### Observação pedagógica

Este mapa realiza a passagem de frases isoladas para tarefa com objetivo. A recuperação espaçada deve variar o formato do prompt: intenção → mandarim; mandarim ouvido → significado; situação → combinação. Uma revisão fácil demais pode produzir familiaridade sem domínio; por isso o mapa deve pedir alteração de contexto e dar feedback após a tentativa [4].

### Potencial de mapa

Centro `[N] resolver um plano cotidiano`; cinco nós: `[A] pedido`, `[B] disponibilidade`, `[C] capacidade`, `[D] preferência`, `[E] rotina`; borda `[R] recusar/remarcar`. Estado mínimo: `plano / restrição / escolha`. Não exibir todas as frases ao mesmo tempo.

### Prompt de recuperação

“Você tem tempo amanhã, sabe falar um pouco de chinês, prefere chá e quer marcar um encontro às três. Produza as decisões em mandarim.”

### Prompt de transferência

“Situação nova: você precisa combinar um estudo de chinês, mas só pode à noite, não gosta de café e não consegue falar rápido. Faça proposta, escolha e ajuste.”

### Critério de domínio

Conduzir uma tarefa de 90 segundos com ao menos cinco funções; alterar horário, bebida e ação; usar um contraste entre `会/能/可以` e outro entre `喜欢/想`; completar sem o mapa completo na segunda rodada; marcar separadamente falha de forma e falha de decisão.

---

## Aula 9 — Dizer o que está fazendo agora

### Intenção
**Relatar uma ação em andamento e perguntar o que alguém está fazendo.** A célula introduz aspecto progressivo de forma conversacional, sem exigir terminologia gramatical pesada.

### Padrão ou função

```text
[F] 你在做什么？
Nǐ zài zuò shénme?
O que você está fazendo?

[F] 我在 + [V ação] + [O objeto]。
Wǒ zài + [ação] + [objeto].
Estou + [ação].

[O] 我正在 + [V ação]。
Wǒ zhèngzài + [ação].
Estou justamente/atualmente + [ação].
```

### Exemplos

- 你在做什么？  
  **Nǐ zài zuò shénme?**  
  O que você está fazendo?
- 我在看书。  
  **Wǒ zài kàn shū.**  
  Estou lendo.
- 我现在在家学习中文。  
  **Wǒ xiànzài zài jiā xuéxí Zhōngwén.**  
  Agora estou estudando chinês em casa.
- 我正在等朋友。  
  **Wǒ zhèngzài děng péngyou.**  
  Estou esperando um amigo.
- 你现在忙吗？  
  **Nǐ xiànzài máng ma?**  
  Você está ocupado agora?

### Slots substituíveis

`[ação]`: 看书 kàn shū, 学习中文 xuéxí Zhōngwén, 等朋友 děng péngyou, 工作 gōngzuò; `[objeto]`: 书 shū, 中文 Zhōngwén, 手机 shǒujī. `现在 xiànzài` pode entrar como marcador de tempo, mas não é obrigatório quando `在` já marca a ação em andamento.

### Extensões

- 我在家看书。  
  **Wǒ zài jiā kàn shū.**  
  Estou lendo em casa.
- 我正在学习，等一下再说。  
  **Wǒ zhèngzài xuéxí, děng yíxià zài shuō.**  
  Estou estudando; falo com você daqui a pouco.

### Observação pedagógica

O primeiro `在` de `我在看书` marca uma ação em andamento. Já o `在` de `我在家看书` marca localização; a ação é `看书`. `正在` é extensão de ênfase, não forma obrigatória em toda frase progressiva. A meta é manter o grupo `zài kàn shū` fluido, não destacar quatro itens igualmente.

### Potencial de mapa

**Mapa de função “relatar o agora”.** Centro `[N] ação em andamento`; ramos `[F] 在 + ação`, `[V] ação/objeto`, `[O] 正在`, `[X] 在 progressivo ≠ 在 localização`; conexão com Aula 8: rotina habitual → ação neste momento; conexão com Aula 4: localização → ação localizada.

### Prompt de recuperação

“Pergunte o que a pessoa está fazendo. Responda que está estudando chinês e esperando um amigo.”

### Prompt de transferência

“Imagine uma mensagem de voz enviada agora. Diga onde você está e o que está fazendo, mas use uma ação diferente de ler, estudar ou esperar.”

### Critério de domínio

Perguntar e responder sobre ação em andamento; produzir três ações novas; distinguir `我在看书` de `我在家看书`; usar `正在` somente para ênfase; manter `zài` e `zhèngzài` compreensíveis em frase completa.

---

## Aula 10 — Relatar o que aconteceu e o que ainda não aconteceu

### Intenção

**Dizer que uma ação foi realizada e informar que outra ainda não ocorreu.** A aula conecta situação presente, experiência recente e planejamento.

### Padrão ou função

```text
[F] [V tempo] + sujeito + [V ação] + 了。
[V tempo] + sujeito + [ação] + le.
[Tempo], sujeito fez/realizou a ação.

[F] 我还没 + [V ação]。
Wǒ hái méi + [ação].
Ainda não + [ação].

[F] 你 + [V ação] + 了吗？
Nǐ + [ação] + le ma?
Você já + [ação]?
```

### Exemplos

- 我昨天去了学校。  
  **Wǒ zuótiān qù le xuéxiào.**  
  Ontem fui à escola.
- 我吃饭了。  
  **Wǒ chīfàn le.**  
  Já comi.
- 我还没吃饭。  
  **Wǒ hái méi chīfàn.**  
  Ainda não comi.
- 你看电影了吗？  
  **Nǐ kàn diànyǐng le ma?**  
  Você já viu o filme?
- 我已经看了。  
  **Wǒ yǐjīng kàn le.**  
  Já vi.

### Slots substituíveis

`[tempo]`: 昨天 zuótiān, 今天 jīntiān, 刚才 gāngcái; `[ação]`: 吃饭 chīfàn, 去学校 qù xuéxiào, 看电影 kàn diànyǐng, 做作业 zuò zuòyè; `[estado]`: 了 le, 还没 hái méi, 已经 yǐjīng. Usar uma ação por vez antes de combinar duas.

### Extensões

- 我去过北京。  
  **Wǒ qùguo Běijīng.**  
  Já estive em Pequim.  
  *Extensão de experiência, não sinônimo automático de `去了`.*
- 我还没准备好。  
  **Wǒ hái méi zhǔnbèi hǎo.**  
  Ainda não estou pronto/preparado.

### Observação pedagógica

Não traduzir `了` sempre como um equivalente fixo de “passado”. Aqui ele sinaliza ação concluída ou mudança de estado dentro da situação. `还没` nega que algo tenha ocorrido até agora. `去了` situa uma ida concluída; `去过` fala de experiência.

### Potencial de mapa

**Mapa de contraste “estado da ação”.** Centro `[N] ação em relação ao agora`; ramos `[F] aconteceu`, `[F] ainda não aconteceu`, `[F] pergunta se já`; contraste `[X] 了 ≠ tradução única de passado; 了 ≠ 过`; conexão com Aula 9: ação em andamento → ação concluída.

### Prompt de recuperação

“Diga que ontem foi à escola, que já comeu e que ainda não viu o filme.”

### Prompt de transferência

“Escolha três ações reais de hoje: uma que já terminou, uma que ainda não começou e uma sobre a qual você perguntará a outra pessoa. Produza as três sem usar ‘ontem’, ‘comer’ ou ‘filme’.”

### Critério de domínio

Produzir uma afirmação com `了`, uma negativa com `还没` e uma pergunta com `了吗`; explicar a diferença entre `去了` e `去过` quando a extensão for usada; não trocar `没` por `不`; manter `zuótiān`, `yǐjīng` e `hái méi` em ritmo natural.

---

## Aula 11 — Organizar uma sequência e dar uma razão simples

### Intenção

**Dizer o que fará primeiro e depois, e justificar uma escolha ou mudança.** A aula conecta duas ações sem transformar o conteúdo em redação.

### Padrão ou função

```text
[F] 先 + [V ação A]，再 + [V ação B]。
Xiān + [ação A], zài + [ação B].
Primeiro + [ação A], depois + [ação B].

[F] 因为 + [V razão]，所以 + [V resultado]。
Yīnwèi + [razão], suǒyǐ + [resultado].
Porque + [razão], por isso + [resultado].

[O] 然后 + [V próxima ação]。
Ránhòu + [próxima ação].
Depois/em seguida + [ação].
```

### Exemplos

- 我先喝水，再学习中文。  
  **Wǒ xiān hē shuǐ, zài xuéxí Zhōngwén.**  
  Primeiro bebo água, depois estudo chinês.
- 我先去洗手间，再回来。  
  **Wǒ xiān qù xǐshǒujiān, zài huílái.**  
  Primeiro vou ao banheiro, depois volto.
- 因为今天没时间，所以明天见。  
  **Yīnwèi jīntiān méi shíjiān, suǒyǐ míngtiān jiàn.**  
  Como hoje não tenho tempo, nos vemos amanhã.
- 因为我喜欢茶，所以我想要一杯茶。  
  **Yīnwèi wǒ xǐhuan chá, suǒyǐ wǒ xiǎng yào yì bēi chá.**  
  Como gosto de chá, quero uma xícara de chá.

### Slots substituíveis

`[ação A/B]`: 喝水 hē shuǐ, 学习中文 xuéxí Zhōngwén, 去洗手间 qù xǐshǒujiān, 回来 huílái, 工作 gōngzuò; `[razão]`: 没时间 méi shíjiān, 喜欢茶 xǐhuan chá, 不明白 bù míngbai; `[resultado]`: 明天见 míngtiān jiàn, 想要茶 xiǎng yào chá, 请再说一遍 qǐng zài shuō yí biàn.

### Extensões

- 先这样，然后再说。  
  **Xiān zhèyàng, ránhòu zài shuō.**  
  Vamos fazer assim primeiro e depois vemos/falamos.
- 你为什么不去？  
  **Nǐ wèishénme bú qù?**  
  Por que você não vai?

### Observação pedagógica

`先…再…` é ferramenta de planejamento. Introduzir duas ações antes de adicionar `然后`. `再 zài` (“depois/de novo, conforme o contexto”) não deve ser confundido com `在 zài` (“estar em”) nem com `再说一遍` (“dizer novamente”); o entorno decide a função.

### Potencial de mapa

**Mapa de função “planejar e justificar”.** Centro `[N] organizar duas ações`; ramos `[F]先…再…`, `[O]然后`, `[F]因为…所以…`; contraste `[X] 再 ≠ 在`; conexões: Aula 10, Aula 5, Aula 7 e Aula 2.

### Prompt de recuperação

“Diga que primeiro vai beber água e depois estudar. Em seguida explique que hoje não tem tempo e por isso encontrará a pessoa amanhã.”

### Prompt de transferência

“Planeje uma rotina de três passos ligada a uma necessidade real. Inclua uma mudança de plano com uma razão diferente de falta de tempo.”

### Critério de domínio

Produzir duas sequências com `先…再…`; conectar razão e resultado sem traduzir; usar `然后` como extensão; distinguir `再 zài` de `在 zài`; manter `xiān`, `zài`, `yīnwèi` e `suǒyǐ` funcionais.

---

## Mapa de consolidação 3 — Agora, antes, depois e por quê (Aulas 9–11)

### Intenção

**Descrever uma situação no tempo e agir sobre ela:** dizer o que está acontecendo, o que já ocorreu, o que ainda falta e qual é a próxima ação.

### Padrão ou função

```text
[N] agora → estado da ação → sequência → razão
[F] 我在 + ação
[F] 我已经/还没 + ação
[F] 先…再…
[F] 因为…所以…
```

### Exemplos de combinação

- 我现在在家学习中文。  
  **Wǒ xiànzài zài jiā xuéxí Zhōngwén.**  
  Agora estou estudando chinês em casa.
- 我已经吃饭了，但是我还没喝水。  
  **Wǒ yǐjīng chīfàn le, dànshì wǒ hái méi hē shuǐ.**  
  Já comi, mas ainda não bebi água.
- 我先喝水，再出去。  
  **Wǒ xiān hē shuǐ, zài chūqù.**  
  Primeiro bebo água, depois saio.

### Slots substituíveis

Ação em andamento, ação concluída, ação pendente, próximo passo e razão. Controlar no máximo duas ações e uma razão por rodada; a dificuldade é temporal e discursiva, não lexical.

### Extensões

Adicionar `你现在在做什么？` ou `你吃饭了吗？`. Não introduzir nova estrutura para responder; reutilizar as três células praticadas.

### Observação pedagógica

Este é mapa de integração, não aula de aspecto. Se o aluno repete o exemplo correto, mas não troca a ação ou a razão, o critério de transferência ainda não foi atingido.

### Potencial de mapa

Centro `[N] situação temporal`; quatro nós `[A] agora`, `[B] concluído`, `[C] pendente`, `[D] próximo passo/razão`. Estado reduzido: `agora / já / ainda não / depois`. Estado independente: uma cena e três perguntas orais.

### Prompt de recuperação

“Diga o que está fazendo agora, o que já fez e o que ainda não fez. Depois diga o que fará primeiro e depois.”

### Prompt de transferência

“Situação nova: você se atrasou para um encontro. Explique o que já fez, o que ainda precisa fazer e a ordem dos próximos passos. Dê uma razão.”

### Critério de domínio

Falar por 60–90 segundos com quatro relações temporais; trocar três ações; incluir uma razão; responder a pergunta de acompanhamento; manter `在`, `了`, `还没`, `先` e `再` sem depender do pinyin.

---

## Aula 12 — Pedir e dar um caminho simples

### Intenção

**Perguntar como chegar a um lugar e dar uma orientação curta em etapas.** O aluno passa de localizar um ponto a orientar um deslocamento.

### Padrão ou função

```text
[F] 从 + [V origem] + 到 + [V destino] + 怎么走？
Cóng + [origem] + dào + [destino] + zěnme zǒu?
Como se vai de [origem] a [destino]?

[F] 先 + [V direção/ação]，然后 + [V direção/ação]。
Xiān + [ação], ránhòu + [ação].
Primeiro + [ação], depois + [ação].

[O] 走路/坐车 + 去 + [V destino]。
Zǒulù/zuò chē qù + [destino].
Ir a pé/de veículo para + [destino].
```

### Exemplos

- 洗手间怎么走？  
  **Xǐshǒujiān zěnme zǒu?**  
  Como se chega ao banheiro?
- 从这里到车站怎么走？  
  **Cóng zhèlǐ dào chēzhàn zěnme zǒu?**  
  Como se vai daqui até a estação?
- 一直走，然后往右走。  
  **Yìzhí zǒu, ránhòu wǎng yòu zǒu.**  
  Siga reto e depois vire à direita.
- 车站在银行旁边。  
  **Chēzhàn zài yínháng pángbiān.**  
  A estação fica ao lado do banco.

### Slots substituíveis

`[origem]`: 这里 zhèlǐ, 家 jiā, 学校 xuéxiào; `[destino]`: 洗手间 xǐshǒujiān, 车站 chēzhàn, 银行 yínháng; `[ação]`: 一直走 yìzhí zǒu, 往左走 wǎng zuǒ zǒu, 往右走 wǎng yòu zǒu, 坐车 zuò chē. Introduzir duas direções por rodada.

### Extensões

- 远不远？  
  **Yuǎn bu yuǎn?**  
  É longe?
- 不远，就在旁边。  
  **Bù yuǎn, jiù zài pángbiān.**  
  Não é longe, fica logo ao lado.

### Observação pedagógica

A aula distingue localização estática (`车站在银行旁边`) de instrução de movimento (`往右走`). `怎么` pergunta modo/procedimento; não é simplesmente “onde”. `一直 yìzhí` deve ser praticado como bloco, sem exigir que o aluno decore a mudança de tom em isolamento.

### Potencial de mapa

**Mapa de função “chegar”.** Centro `[N] deslocar-se`; ramos `[F] origem → destino`, `[V] meio`, `[F] sequência de direções`, `[V] referência`; contraste `[X] 在 localização ≠ 走 movimento`; conexão com Aula 4 e Mapa 3.

### Prompt de recuperação

“Pergunte como se vai daqui até a estação. Diga: primeiro siga reto, depois vire à direita.”

### Prompt de transferência

“Escolha dois lugares reais ao seu redor. Dê uma orientação em duas etapas usando um ponto de referência diferente de banco ou escola.”

### Critério de domínio

Perguntar um caminho; dar duas instruções em sequência; usar origem e destino na ordem correta; diferenciar `在` de `走`; incluir meio de transporte ou referência; manter `zěnme`, `zǒu`, `zuǒ` e `yòu` funcionais.

---

## Aula 13 — Convidar, aceitar, recusar e remarcar

### Intenção

**Convidar alguém para fazer algo junto, aceitar, recusar sem ruptura e propor outro momento.** A função prepara a interação social além do pedido transacional.

### Padrão ou função

```text
[F] 要不要一起 + [V ação]？
Yào bu yào yìqǐ + [ação]?
Você quer fazer + [ação] junto?

[F] 我们一起 + [V ação] + 吧。
Wǒmen yìqǐ + [ação] ba.
Vamos + [ação].

[F] 好啊。/可以啊。
Hǎo a. / Kěyǐ a.
Claro. / Pode ser.

[F] 我今天不太方便，改天可以吗？
Wǒ jīntiān bú tài fāngbiàn, gǎitiān kěyǐ ma?
Hoje não consigo; pode ser outro dia?
```

### Exemplos

- 要不要一起吃饭？  
  **Yào bu yào yìqǐ chīfàn?**  
  Quer comer junto?
- 我们一起学习中文吧。  
  **Wǒmen yìqǐ xuéxí Zhōngwén ba.**  
  Vamos estudar chinês juntos.
- 好啊，明天可以吗？  
  **Hǎo a, míngtiān kěyǐ ma?**  
  Claro; amanhã pode ser?
- 我今天不太方便，改天可以吗？  
  **Wǒ jīntiān bú tài fāngbiàn, gǎitiān kěyǐ ma?**  
  Hoje não consigo; pode ser outro dia?
- 不好意思，我今天没时间。  
  **Bù hǎoyìsi, wǒ jīntiān méi shíjiān.**  
  Desculpa, hoje não tenho tempo.

### Slots substituíveis

`[ação]`: 吃饭 chīfàn, 喝茶 hē chá, 学习中文 xuéxí Zhōngwén, 看电影 kàn diànyǐng, 走路 zǒulù; `[tempo]`: 今天 jīntiān, 明天 míngtiān, 周末 zhōumò. Reciclar ações conhecidas para concentrar atenção no gerenciamento social.

### Extensões

- 你什么时候有时间？  
  **Nǐ shénme shíhou yǒu shíjiān?**  
  Quando você tem tempo?
- 周末下午可以吗？  
  **Zhōumò xiàwǔ kěyǐ ma?**  
  Fim de semana à tarde pode ser?

### Observação pedagógica

`要不要` é pergunta de convite. `吧` suaviza a proposta, mas não é partícula de polidez automática. `不太方便` permite recusar sem romper a interação; `改天` mantém a possibilidade aberta sem prometer data específica. `不好意思` deve ser praticado como bloco, com sílabas não igualmente fortes.

### Potencial de mapa

**Mapa de função “abrir e manter encontro social”.** Centro `[N] convite`; ramos `[F] convidar`, `[F] aceitar`, `[F] recusar suavemente`, `[F] remarcar`; slots `[V] atividade`, `[V] tempo`; contraste `[X] 要不要 convite ≠ 要 pedido de item`; conexões Aula 5, Aula 7 e Aula 11.

### Prompt de recuperação

“Convide a pessoa para tomar chá, aceite um convite para estudar e recuse hoje propondo outro dia.”

### Prompt de transferência

“Situação nova: convide alguém para uma atividade que não seja comer, receba uma recusa por falta de tempo e proponha um horário de fim de semana.”

### Critério de domínio

Produzir convite, aceitação e recusa com remarcação; alterar atividade e tempo; manter `要不要` como convite e `要` como querer/pedir; usar `不太方便` sem traduzir palavra por palavra; sustentar sequência social de 60 segundos.

---

## Aula 14 — Dar opinião simples, justificar escolha e fechar um plano

### Intenção

**Expressar uma avaliação curta, explicar uma preferência e concluir uma decisão.** Esta aula leva o aluno ao intermediário inicial sem exigir debate abstrato.

### Padrão ou função

```text
[F] 我觉得 + [V avaliação]。
Wǒ juéde + [avaliação].
Eu acho/considero que + [avaliação].

[F] 因为 + [V razão]，所以 + [V decisão]。
Yīnwèi + [razão], suǒyǐ + [decisão].
Porque + [razão], então + [decisão].

[F] 对我来说，+ [V avaliação]。
Duì wǒ láishuō, + [avaliação].
Para mim, + [avaliação].

[O] 我们就 + [V decisão] + 吧。
Wǒmen jiù + [decisão] ba.
Então vamos simplesmente + [decisão].
```

### Exemplos

- 我觉得这个比较好。  
  **Wǒ juéde zhège bǐjiào hǎo.**  
  Acho que este é melhor.
- 对我来说，茶比较好喝。  
  **Duì wǒ láishuō, chá bǐjiào hǎohē.**  
  Para mim, chá é mais gostoso.
- 因为今天下雨，所以我不想出去。  
  **Yīnwèi jīntiān xià yǔ, suǒyǐ wǒ bù xiǎng chūqù.**  
  Como hoje está chovendo, não quero sair.
- 我们明天下午见吧。  
  **Wǒmen míngtiān xiàwǔ jiàn ba.**  
  Então nos vemos amanhã à tarde.
- 我觉得先学习，再吃饭比较好。  
  **Wǒ juéde xiān xuéxí, zài chīfàn bǐjiào hǎo.**  
  Acho melhor estudar primeiro e comer depois.

### Slots substituíveis

`[avaliação]`: 这个比较好 zhège bǐjiào hǎo, 茶比较好喝 chá bǐjiào hǎohē, 现在不方便 xiànzài bù fāngbiàn; `[razão]`: 下雨 xià yǔ, 没时间 méi shíjiān, 喜欢茶 xǐhuan chá; `[decisão]`: 明天见 míngtiān jiàn, 一起学习 yìqǐ xuéxí, 先回家 xiān huí jiā. Não transformar `比较` em regra mecânica para toda comparação.

### Extensões

- 你觉得怎么样？  
  **Nǐ juéde zěnmeyàng?**  
  O que você acha? / Como você avalia?
- 我觉得可以。  
  **Wǒ juéde kěyǐ.**  
  Acho que pode ser.

### Observação pedagógica

`觉得` introduz avaliação experiencial; não é substituto de `知道 zhīdào` (“saber”). `比较好` pode significar “melhor/mais adequado” conforme o contexto. A razão deve servir à decisão. Se o aluno apenas repete `因为…所以…` sem alterar a escolha, o padrão ainda é declarativo, não comunicativo. `好喝 hǎohē` significa sabor agradável para bebida; não é “bom beber”.

### Potencial de mapa

**Mapa de função “avaliar e decidir”.** Centro `[N] escolha justificada`; ramos `[F] opinião`, `[F] razão`, `[F] sequência`, `[F] fechamento`; slots `[V] opção`, `[V] motivo`, `[V] plano`; contraste `[X] 觉得 ≠ 知道; 想 ≠ 觉得`; conexão com convite, preferência, sequência e tempo.

### Prompt de recuperação

“Diga qual de duas bebidas você prefere, dê uma razão e conclua o que vocês farão amanhã.”

### Prompt de transferência

“Situação nova: escolha entre duas atividades, justifique a escolha com uma condição do dia e feche um plano com horário. Não use chá, café ou estudo.”

### Critério de domínio

Produzir opinião, razão e decisão encadeadas; trocar opção, motivo e horário; responder a `你觉得怎么样？`; distinguir `觉得`, `喜欢` e `想`; concluir um plano sem depender de tradução ou mapa completo.

---

## Mapa de consolidação 4 — Situação social completa (Aulas 12–14 + rede total)

### Intenção

**Resolver uma tarefa social nova com deslocamento, convite, negociação e decisão justificada.** Este é o mapa final do bloco, não um diálogo pronto.

### Padrão ou função

```text
[N] objetivo social
 ├── localizar/chegar: 从…到…怎么走？
 ├── convidar: 要不要一起…？
 ├── negociar: …可以吗？/改天可以吗？
 ├── justificar: 因为…所以…
 ├── sequenciar: 先…再…
 ├── reparar: 我没听懂，请再说一遍。
 └── fechar: 我们…吧。
```

### Exemplos de combinação

- 从这里到车站怎么走？  
  **Cóng zhèlǐ dào chēzhàn zěnme zǒu?**  
  Como se vai daqui até a estação?
- 要不要一起喝茶？  
  **Yào bu yào yìqǐ hē chá?**  
  Quer tomar chá junto?
- 因为今天下雨，所以我们明天见吧。  
  **Yīnwèi jīntiān xià yǔ, suǒyǐ wǒmen míngtiān jiàn ba.**  
  Como hoje está chovendo, vamos nos ver amanhã.
- 我没听懂，请再说一遍。  
  **Wǒ méi tīng dǒng, qǐng zài shuō yí biàn.**  
  Não entendi; por favor, repita.

### Slots substituíveis

Objetivo, origem, destino, atividade, disponibilidade, horário, motivo, ordem das ações e reparo. Cada rodada deve alterar ao menos quatro slots e uma relação entre eles. Não aumentar a tarefa com vocabulário não ligado à ação.

### Extensões

- Uma rodada exige remarcação (`我今天不太方便，改天可以吗？`).
- Outra exige reparo (`你能再说一遍吗？`) antes da decisão.
- Outra exige avaliação (`我觉得这个比较好`) antes do fechamento.

### Observação pedagógica

A tarefa final deve ser avaliada por **decisões comunicativas**, não pela reprodução de roteiro. A rubrica registra separadamente intenção compreendida, padrão recuperado, pronúncia funcional e transferência. Não alegar correção fonética automática por leitura; tons e segmentação precisam de áudio, imitação ou feedback humano.

### Potencial de mapa

Centro `[N] resolver um plano em ambiente real`; nós de lugar, tempo, convite, negociação, reparo e fechamento. O estado completo é pós-áudio; o lacunado deixa verbos; o mínimo mostra `chegar / convidar / ajustar / decidir`; o independente mostra só uma situação e um limite de tempo.

### Prompt de recuperação

“Você quer encontrar uma pessoa, precisa descobrir o caminho, fazer um convite, verificar se o horário pode ser e explicar uma escolha.” Produza sem olhar a resposta.

### Prompt de transferência

“Escolha uma situação: encontrar alguém em lugar novo; combinar atividade com pouco tempo; ou convidar alguém quando o plano original não funciona. Fale por 90–120 segundos, altere quatro elementos e faça um reparo se travar.”

### Critério de domínio

Completar duas situações diferentes de 90–120 segundos; produzir pelo menos oito unidades funcionais; combinar seis células de aulas diferentes; alterar quatro slots; usar reparo, razão e fechamento; manter compreensão e pronúncia funcional suficientes para a interação continuar; consultar no máximo o prompt mínimo na segunda rodada.

---

# 3. Mapa mestre de progressão e consolidação

| Faixa | Aulas | Operação oral dominante | Suporte esperado | Evidência de passagem |
|---|---:|---|---|---|
| Entrada | 1–2 | identificar-se, verificar e reparar | mapa completo após o áudio | produzir apresentação e pedir repetição |
| Necessidade | 3–4 | pedir, recusar e localizar | mapa lacunado | resolver necessidade com objeto/lugar |
| Organização | 5–8 | combinar tempo, capacidade, preferência e rotina | lacunas + slots limitados | conduzir plano de 90 segundos |
| Continuidade | 9–11 | relatar agora, antes/depois e razão | mapa reduzido | conectar ações e estados sem roteiro |
| Vida social | 12–14 | chegar, convidar, negociar e decidir | prompt mínimo | transferir a rede para situação não vista |

O aluno começa com uma intenção e um padrão curto. Depois troca elementos, acrescenta uma extensão, conecta funções e termina usando somente a situação como estímulo. Essa progressão combina tarefas significativas, que dão uma razão para comunicar, com discussão posterior da língua relevante [3].

## 4. Protocolo de revisão dos mapas

A revisão ocorre, preferencialmente, no mesmo dia, no dia seguinte, três a sete dias depois e em uma consolidação posterior. O intervalo não é uma fórmula rígida; o objetivo é impedir que reconhecimento imediato seja confundido com domínio.

| Passagem | O que aparece | O que o aluno faz | Se falhar |
|---|---|---|---|
| Orientação | intenção, padrão, slots, tradução, alerta | identifica a decisão depois do input | revisita o áudio legítimo e o mapa completo |
| Recuperação | intenção + lacunas | produz antes de consultar | volta ao padrão com menos slots |
| Recombinação | núcleo + opções limitadas | produz três variações | reduz vocabulário, não aumenta explicação |
| Transferência | situação nova + gatilhos | resolve sem mapa completo | registra falha de intenção, forma ou som |
| Independência | somente situação ou estímulo | responde e sustenta a ação | agenda nova recuperação espaçada |

Quando a forma ou a intenção falhar, a correção deve vir logo; erros não corrigidos podem ser reforçados. A revisão também deve mudar o formato do prompt e pedir transferência, pois testar apenas a mesma frase é insuficiente [4].

### Registro mínimo de domínio

| Célula/mapa | Compreensão | Recuperação | Pronúncia funcional | Transferência | Próxima ação |
|---|---:|---:|---:|---:|---|
| 0 | não | não | não avaliado | não | voltar à orientação |
| 1 | com apoio | hesitante | parcial | ainda não | repetir slot limitado |
| 2 | sim | sim | suficiente para ser entendido | sim em contexto novo | espaçar e reduzir suporte |

**Regra de avanço:** não aprovar uma célula por reconhecimento de caracteres, pinyin ou tradução. Considerar consolidada quando alcançar **2** em compreensão, **2** em recuperação, **1 ou 2** em pronúncia funcional e **2** em transferência em duas tentativas separadas. Pronúncia funcional não significa sotaque nativo; significa que a intenção continua recuperável pelo interlocutor. Para tons, a confirmação deve vir de áudio ou feedback, não só da inspeção do pinyin.

## 5. Filtros editoriais aplicados

Entraram apenas padrões com ação oral clara: apresentar-se, identificar, reparar, pedir, localizar, organizar tempo, expressar capacidade, escolher, descrever rotina, relatar estado temporal, sequenciar, orientar, convidar, justificar e fechar uma decisão. Foram excluídos cumprimentos isolados sem progressão, listas sem slot, explicações sem prompt, traduções palavra por palavra, cópia e qualquer reprodução de diálogo proprietário.

Também foram evitadas duas promessas inadequadas. Mapas não substituem áudio, input compreensível, prática auditiva ou feedback de pronúncia. Completar um mapa não prova fluência. Os mapas são instrumentos de recuperação, contraste, recombinação e transferência. Estudos sobre concept mapping indicam potencial maior quando o mapa é construído a partir da recuperação, mas também apontam custo cognitivo mais alto; por isso o material mantém o mapa curto e retira o suporte progressivamente [7].

## Referências

[1]: https://www.actfl.org/proficiency-guidelines-overview "ACTFL® Proficiency Guidelines Overview"

[2]: https://rm.coe.int/common-european-framework-of-reference-for-languages-learning-teaching/16809ea0d4 "Common European Framework of Reference for Languages: Companion Volume"

[3]: https://www.teachingenglish.org.uk/professional-development/teachers/teaching-knowledge-database/t-w/tbl-task-based-learning "British Council — TBL: Task-based Learning"

[4]: https://www.edresearch.edu.au/guides-resources/practice-guides/spacing-and-retrieval-practice-guide-full-publication "Australian Education Research Organisation — Spacing and retrieval practice guide"

[5]: https://www.hackingchinese.com/the-hacking-chinese-guide-to-mandarin-tones/ "Hacking Chinese — The Hacking Chinese Guide to Mandarin Tones"

[6]: https://resources.allsetlearning.com/chinese/pronunciation/Tone_change_rules "AllSet Learning Chinese Pronunciation Wiki — Tone change rules"

[7]: https://pubmed.ncbi.nlm.nih.gov/38900767/ "Lenski, Mustafa & Großschedl — Concept mapping: increased potential as a retrieval-based task"
