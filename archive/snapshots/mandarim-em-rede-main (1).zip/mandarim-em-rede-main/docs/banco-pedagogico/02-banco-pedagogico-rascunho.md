# Banco pedagógico Mandarim em Rede — rascunho consolidado

**Status editorial:** rascunho massivo, filtrado e independente para revisão linguística e teste beta.  
**Público prioritário:** adultos brasileiros no iniciante e no intermediário inicial que usam áudio estruturado.  
**Unidade de desenho:** célula de transferência oral. Cada célula parte de uma intenção, apresenta um padrão recombinável, limita os slots, explicita um contraste relevante e termina em recuperação, transferência e domínio observável.

> **Princípio de uso:** ouvir → tentar recuperar → consultar o mapa → recombinar → transferir → retirar o suporte. O áudio ou input legítimo continua sendo a fonte primária de escuta e pronúncia. Este banco não reproduz diálogos, roteiros, transcrições ou áudios proprietários e não substitui feedback humano.

## 1. Decisões editoriais de consolidação

Os dez relatórios foram fundidos por **operação oral**, não por ordem de relatório. Repetições de `不/没`, `是/在`, `想/要`, `吗/呢`, `了/过` e `会/能/可以` aparecem uma vez como células completas e voltam apenas como conexões, contrastes ou pré-requisitos. Listas passivas, sinônimos sem decisão de uso, exercícios de cópia e formas raras foram removidos ou rebaixados para reconhecimento.

A escrita usa caracteres simplificados. O pinyin traz tons lexicais e, quando isso ajuda a fala, registra a realização conectada (`bú shì`, `yí biàn`, `yì bēi`). A tradução é natural em português brasileiro e não deve ser usada para reconstruir a ordem palavra por palavra. Os exemplos são formulações autorais deste rascunho.

### 1.1 Estados de suporte

| Estado | O que aparece | Resposta exigida | Critério de retirada |
|---|---|---|---|
| Orientação | intenção, molde, caracteres, pinyin, tradução e alerta | compreender a função e ouvir o modelo | após uma produção guiada correta |
| Recuperação | intenção, molde lacunado e poucos gatilhos | produzir antes de ver a resposta | três slots trocados sem cópia |
| Recombinação | situação, dois ou três slots e uma restrição | gerar variações em tempo limitado | ordem e escolha estáveis |
| Transferência | apenas situação e propósito | agir em contexto não visto | duas rodadas sem o mapa |
| Independência | prompt mínimo ou estímulo auditivo | responder, reparar e continuar | manutenção em revisão espaçada |

### 1.2 Prioridade de entrada

| Prioridade | Conteúdo | Destino recomendado |
|---|---|---|
| **P0 — primeiras quatro aulas** | contato, nome, identidade, `吗`, interrogativos, `是/在/有`, `这/那`, posse, `没听懂`, repetição | Aulas 1–4; deve ser recuperável antes de expandir |
| **P1 — aulas 5–8** | desejo e pedido, negação, localização, tempo, `想/要`, `会/能/可以`, escolha, rotina | Aulas 5–8; combinar com P0 |
| **P2 — aulas 9–11** | progressivo, `了`, `过`, sequência, causa e consequência, resultativos | Aulas 9–11; usar vocabulário já conhecido |
| **P3 — aulas 12–14** | direção, convite, condição, comparação, opinião, `把`, complementos produtivos | Aulas 12–14; não antecipar para compensar lacunas do núcleo |

### 1.3 Limites de uso

Este banco é um **companion de transferência**, não um curso paralelo completo, um deck, uma transcrição ou um substituto do áudio. O pinyin não prova pronúncia correta; o mapa não corrige a voz; reconhecimento visual não aprova domínio. Contrastes são tendências operacionais para o nível inicial, não fronteiras absolutas de toda a língua. Registro, região, velocidade e contexto podem alterar a escolha. `您`, `吧`, `啊`, `嘛`, `呗`, `地` e empilhamentos de partículas entram apenas quando a situação exige e depois que o núcleo está estável. Toda aprovação deve incluir compreensão auditiva, recuperação oral, pronúncia funcional no ponto treinado e transferência.

---

# 2. Categoria I — Padrões produtivos

Esta categoria guarda os moldes estruturais de maior retorno. Cada padrão deve gerar pelo menos três frases novas; a explicação gramatical só entra depois da primeira tentativa oral.

## P01 — Interrogativo no lugar do slot

**Intenção.** Descobrir uma pessoa, coisa, lugar, momento ou modo sem mover o interrogativo para a frente.  
**Padrão.** `[sujeito] + [verbo] + 什么/谁/哪儿/什么时候/怎么？`

**Exemplo-base.** `你明天想吃什么？` — *Nǐ míngtiān xiǎng chī shénme?* — “O que você quer comer amanhã?”

**Substituições.** Trocar `你` por `他/我们`; `吃` por `买/看/学`; `什么` por `谁/哪儿/什么时候/怎么`; acrescentar um lugar conhecido.

**Observação pedagógica.** O português favorece deslocar “o quê” e “onde” para o início. No mandarim, o interrogativo ocupa o lugar da informação desconhecida. Não acrescentar `吗` a uma pergunta já interrogativa.

**Potencial de mapa.** Centro “descobrir informação”; ramos pessoa, objeto, lugar, tempo e modo; alerta vermelho: posição do interrogativo.

**Recuperação.** “Pergunte onde a pessoa estuda e o que compra.” Produzir antes de ver a solução.

**Transferência.** Em uma estação nova, perguntar quem está esperando, para onde vai e quando chega.

**Domínio.** Produzir seis perguntas novas com pelo menos quatro interrogativos, mantendo a ordem e respondendo cada pergunta com informação do mesmo tipo.

## P02 — Pergunta polar com 吗

**Intenção.** Verificar uma afirmação ou preferência e responder pelo predicado relevante.  
**Padrão.** `[afirmação] + 吗？`; resposta afirmativa repete o predicado; resposta negativa nega o predicado.

**Exemplo-base.** `你喜欢绿茶吗？` — *Nǐ xǐhuan lǜchá ma?* — “Você gosta de chá verde?” / `喜欢。` — *Xǐhuan.* — “Gosto.”

**Substituições.** Trocar o predicado por `会游泳`, `在公司`, `明天来`, `是学生`; responder `不喜欢`, `不会`, `不在`, `不来` conforme a pergunta.

**Observação pedagógica.** Não ensinar “sim = 是” e “não = 不是”. A resposta clara normalmente retoma o verbo ou predicado da pergunta. `吗` não entra com `什么`, `谁`, `哪儿` ou A-não-A.

**Potencial de mapa.** Centro “confirmar”; seta afirmação → `吗`; dois ramos de resposta pelo mesmo predicado.

**Recuperação.** Perguntar “você fala inglês?” e responder afirmativa e negativamente sem usar apenas “sim/não”.

**Transferência.** Confirmar três fatos do ambiente e responder com o predicado adequado.

**Domínio.** Formular seis perguntas, acertar a polaridade em cinco respostas e não usar `是` como resposta universal.

## P03 — Pergunta A-não-A

**Intenção.** Pedir uma decisão binária diretamente.  
**Padrão.** `[V] 不 [V] ...？`, `有 没有 ...？`, ou `[modal] 不 [modal] ...？`

**Exemplo-base.** `你有没有时间？` — *Nǐ yǒu méiyǒu shíjiān?* — “Você tem tempo ou não?”

**Substituições.** `要不要喝水`, `能不能再说一遍`, `是不是你的`, `好不好`; trocar apenas uma ação por rodada.

**Observação pedagógica.** Não acrescentar `吗` ao A-não-A. Para posse e existência, usar `有没有`, nunca *不有*. Em verbos de dois caracteres, `不` costuma aparecer depois do primeiro caractere.

**Potencial de mapa.** Centro “forçar escolha”; ramos V–不–V, 有–没有, modal–不–modal; contraste com `吗`.

**Recuperação.** “Você pode vir ou não?” e “já tem ingresso ou não?”.

**Transferência.** Organizar uma tarefa perguntando se a pessoa quer café, consegue ir e tem tempo.

**Domínio.** Produzir quatro formatos, incluindo `有没有` e um modal, sem `吗`, e responder com a forma correspondente.

## P04 — 是, 在 e 有

**Intenção.** Separar identidade, localização, posse e existência.  
**Padrão.** `[X] 是 [classe]`; `[X] 在 [lugar]`; `[X] 有 [objeto]`; `[lugar] 有 [coisa]`.

**Exemplo-base.** `手机在抽屉里，桌上有一本书。` — *Shǒujī zài chōuti lǐ, zhuō shàng yǒu yì běn shū.* — “O celular está na gaveta; há um livro sobre a mesa.”

**Substituições.** `手机/钥匙/书`; `抽屉里/包里/家`; `一本书/两张票/一点水`; para identidade, `我是学生/她是老师`.

**Observação pedagógica.** O português usa “ser/estar” como formas do mesmo verbo. `是` identifica, `在` localiza e `有` indica posse ou existência. A negação cruza o padrão: `不是`, `不在`, `没有`.

**Potencial de mapa.** Pergunta central “qual relação comunico?” → identidade, lugar ou presença/posse; conexão com `不/没`.

**Recuperação.** Produzir “sou estudante”, “estou em casa”, “tenho uma pergunta” e “há água aqui”.

**Transferência.** Em uma chamada, informar identidade, local e um problema; trocar casa por escritório.

**Domínio.** Produzir seis frases em duas rodadas e manter `shì`, `zài` e `yǒu` distinguíveis.

## P05 — Ordem S–tempo–lugar–verbo–objeto

**Intenção.** Situar uma ação no tempo e no espaço.  
**Padrão.** `[sujeito] + [tempo] + [在 + lugar] + [verbo] + [objeto]`.

**Exemplo-base.** `我今晚在家做饭。` — *Wǒ jīnwǎn zài jiā zuòfàn.* — “Hoje à noite vou cozinhar em casa.”

**Substituições.** Tempo `今天/明天上午/星期六`; lugar `学校/公司/咖啡店`; ação `学习/工作/吃饭/看电影`.

**Observação pedagógica.** É um molde inicial produtivo, não uma fórmula rígida para toda frase. O lugar de uma ação vem antes do verbo; `我在家` é localização, enquanto `我在家学习` situa a ação.

**Potencial de mapa.** Linha temporal → lugar → ação → objeto; alerta “não copiar a posição portuguesa do lugar”.

**Recuperação.** “Amanhã de manhã estudo no café.”

**Transferência.** Narrar três ações reais de hoje em horários e lugares diferentes.

**Domínio.** Produzir cinco frases e uma pergunta sem colocar o lugar depois do verbo quando ele modifica a ação.

## P06 — 的 para relação e posse

**Intenção.** Relacionar um possuidor ou descritor ao nome principal.  
**Padrão.** `[possuidor/descritor] + 的 + [nome]`.

**Exemplo-base.** `这是我朋友的钥匙。` — *Zhè shì wǒ péngyou de yàoshi.* — “Esta é a chave do meu amigo.”

**Substituições.** Possuidor `我/你/她/公司`; nome `手机/地址/书/老师`; descritor `北京的冬天`.

**Observação pedagógica.** A relação vem antes do nome. Algumas relações próximas podem omitir `的`, mas essa variação deve esperar; não transforme cada `的` em uma tradução fixa “de”.

**Potencial de mapa.** Dono/descritor → `的` → objeto; conexão com identificação, quantidade e pergunta `谁的`.

**Recuperação.** Dizer “o computador da minha irmã” e perguntar “de quem é este livro?”.

**Transferência.** Relacionar quatro objetos reais a pessoas, lugares ou instituições diferentes.

**Domínio.** Produzir cinco sintagmas e inseri-los em frases completas, mantendo o modificador antes do nome.

## P07 — 想, 要 e 想要

**Intenção.** Expressar vontade de fazer algo, desejar um item ou formular uma decisão/pedido.  
**Padrão.** `想 + ação`; `想要/要 + objeto`; `要 + ação` quando a decisão é direta.

**Exemplo-base.** `我想看那部电影。` — *Wǒ xiǎng kàn nà bù diànyǐng.* — “Quero assistir àquele filme.”

**Substituições.** Ação `喝茶/回家/休息`; objeto `一杯水/这个/两张票`; pessoa `我/你/我们`.

**Observação pedagógica.** `想` tende a enquadrar desejo ou intenção; `要` pode soar mais decidido, necessário ou transacional. Há sobreposição. Não ensinar uma oposição absoluta nem depender da tradução “querer”.

**Potencial de mapa.** Desejo → ação ou item → pedido/recusa; alerta `想` ≠ `要` por enquadramento, não por equivalência rígida.

**Recuperação.** “Quero descansar, quero este item e não quero café.”

**Transferência.** Ao sair do trabalho, dizer o que quer fazer, onde e o que não quer fazer.

**Domínio.** Produzir quatro variações com três ações, uma negação e um pedido contextualizado.

## P08 — Pedir com 请问, 请给我 e 能/可以

**Intenção.** Pedir informação, item ou ação com grau de polidez adequado.  
**Padrão.** `请问 + pergunta`; `请给我 + quantidade/item`; `你能/可以 + ação + 吗？`

**Exemplo-base.** `请问，出口在哪儿？` — *Qǐngwèn, chūkǒu zài nǎr?* — “Com licença, onde fica a saída?”

**Substituições.** Pergunta `洗手间在哪儿/现在几点`; ação `写下来/等一下/帮我`; item `一杯水/一张票/这个`.

**Observação pedagógica.** `请` não é um botão universal de polidez. `能` focaliza possibilidade/capacidade na situação; `可以` frequentemente focaliza permissão ou possibilidade aceita. O registro depende do interlocutor e da ação.

**Potencial de mapa.** Informação → `请问`; item → `请给我`; ação → modal + `吗`; alerta de registro e aspiração de `qǐng`.

**Recuperação.** Pedir banheiro, repetição e um copo de água em três moldes.

**Transferência.** Em uma estação ou cafeteria, fazer um pedido de cada tipo sem reutilizar o exemplo.

**Domínio.** Identificar o tipo de pedido, produzir três solicitações novas e ajustar `请问`, `能` e `可以` ao cenário.

## P09 — 会, 能 e 可以

**Intenção.** Dizer que sabe fazer, que consegue em uma condição ou que tem permissão.  
**Padrão.** `会 + habilidade`; `能 + possibilidade situada`; `可以 + permissão/possibilidade aceita`.

**Exemplo-base.** `我会做饭，但是今天不能做。` — *Wǒ huì zuòfàn, dànshì jīntiān bù néng zuò.* — “Sei cozinhar, mas hoje não consigo.”

**Substituições.** Habilidade `说中文/游泳/开车`; condição `今天/现在/太晚`; permissão `坐这里/用手机/进来`.

**Observação pedagógica.** A tradução portuguesa “poder” comprime decisões distintas. As áreas se sobrepõem; o objetivo inicial é um foco comunicativo claro, não uma fronteira absoluta.

**Potencial de mapa.** Aprendizado → `会`; condição → `能`; autorização → `可以`; ramos negativos `不会/不能/不可以`.

**Recuperação.** Produzir “sei nadar”, “hoje não consigo ir” e “posso sentar aqui?”.

**Transferência.** Explicar o que sabe fazer, o que não consegue hoje e pedir uma autorização.

**Domínio.** Escolher a forma adequada em nove de dez cenários e produzir afirmação e negação de cada ramo.

## P10 — 不, 没(有) e 不要

**Intenção.** Negar hábito, intenção, identidade, localização, evento, posse ou recusar/proibir.  
**Padrão.** `不 + verbo/adjetivo`; `没(有) + verbo/objeto`; `不要 + item/ação`.

**Exemplo-base.** `我昨天没去，今天也不去。` — *Wǒ zuótiān méi qù, jīntiān yě bú qù.* — “Ontem não fui e hoje também não vou.”

**Substituições.** Evento `喝咖啡/看电影/听懂`; estado `想去/在家/是老师`; item `这个/茶`; proibição `走/说话`.

**Observação pedagógica.** A heurística “`不` presente/futuro, `没` passado” ajuda no começo, mas é insuficiente: `不` cobre hábito, intenção e estado; `没` cobre não ocorrência, resultado, posse e experiência. `不要` pode ser recusa ou proibição conforme contexto.

**Potencial de mapa.** O que está sendo negado? disposição/estado → `不`; ocorrência/posse → `没`; recusa/proibição → `不要`.

**Recuperação.** Escolher a forma para “não quero ir”, “não fui ontem”, “não tenho tempo” e “não quero isso”.

**Transferência.** Responder por que não está no escritório, negar uma ação de hoje e relatar uma ação não feita ontem.

**Domínio.** Classificar oito situações, produzir pares contrastivos e realizar `bú` antes de quarto tom quando aplicável.

## P11 — 在/正在, 了 e 过

**Intenção.** Dizer o que está acontecendo, apresentar uma ação como concluída/mudança ou relatar experiência.  
**Padrão.** `在/正在 + verbo`; `verbo + 了` ou `[situação] + 了`; `verbo + 过`.

**Exemplo-base.** `我正在写邮件，还没写完。` — *Wǒ zhèngzài xiě yóujiàn, hái méi xiě wán.* — “Estou escrevendo um e-mail; ainda não terminei.”

**Substituições.** Ação `看书/等朋友/学习`; resultado `写完/吃完/听懂`; experiência `去过/看过/学过`.

**Observação pedagógica.** `了` não é passado automático: pode fechar um evento ou marcar mudança de situação. `过` enquadra experiência anterior, sem afirmar que o estado continua. `正在` é uma extensão enfática; `在` também pode ser localização.

**Potencial de mapa.** Linha do evento: em curso → delimitado/mudado → experiência; conexões com `没`, complementos e revisão.

**Recuperação.** Dizer “estou estudando”, “já terminei” e “já visitei esse lugar”.

**Transferência.** Relatar agora, ontem e uma experiência anterior usando três ações diferentes.

**Domínio.** Distinguir os três enquadramentos em seis prompts e negar pelo menos um caso com `没`.

## P12 — Complementos de resultado e potencial

**Intenção.** Mostrar se uma ação chegou a um resultado ou se é possível chegar a ele.  
**Padrão.** `V + 懂/完/好/清楚`; `V + 得/不 + resultado`.

**Exemplo-base.** `我听懂了，但是写不清楚。` — *Wǒ tīng dǒng le, dànshì xiě bu qīngchu.* — “Entendi ao ouvir, mas não consigo escrever claramente.”

**Substituições.** `看懂/吃完/准备好/说清楚`; potencial `听得懂/看不懂/做得好`.

**Observação pedagógica.** O complemento muda o resultado da ação; não é apenas um advérbio. Ensinar primeiro com verbos conhecidos e situações concretas de reparo, tarefa ou conclusão.

**Potencial de mapa.** Ação → resultado alcançado ou bloqueado; contraste resultativo `懂/完/好/清楚` versus potencial `得/不`.

**Recuperação.** Produzir “não entendi”, “terminei de comer” e “não consigo explicar claramente”.

**Transferência.** Dizer o que já conseguiu fazer em uma tarefa e o que ainda não consegue fazer.

**Domínio.** Gerar quatro combinações corretas e explicar oralmente se o prompt pede resultado ou possibilidade.

---

# 3. Categoria II — Funções comunicativas

Aqui o foco é a ação social. Os padrões da Categoria I são escolhidos em função de uma tarefa, não recitados como gramática.

## F01 — Pedir informação, item ou ação

**Intenção.** Obter algo necessário sem depender de uma tradução única de “por favor”.  
**Padrão.** `请问 + pergunta`; `请给我 + item`; `你能/可以 + ação + 吗？`

**Exemplo-base.** `你可以帮我找一下出口吗？` — *Nǐ kěyǐ bāng wǒ zhǎo yíxià chūkǒu ma?* — “Você pode me ajudar a encontrar a saída?”

**Substituições.** `找洗手间/写地址/等我一下`; `出口/水/票`; `你/您`.

**Observação pedagógica.** Antes de falar, classificar a necessidade: informação, objeto ou ação. `一下` suaviza uma ação curta, mas não deve ser apresentado como requisito de todo pedido.

**Potencial de mapa.** Necessidade → tipo de pedido → molde → grau de cortesia → reparo se não houver resposta.

**Recuperação.** Pedir uma direção, um objeto e uma repetição.

**Transferência.** Fazer pedidos novos em uma loja, uma estação e uma sala de aula.

**Domínio.** Produzir três pedidos novos, manter a ordem e reagir adequadamente a uma resposta negativa.

## F02 — Negar, recusar e corrigir

**Intenção.** Dizer não, recusar uma oferta ou corrigir uma identificação sem parecer que todo “não” é igual.  
**Padrão.** `不/没(有)/不要`; `不是 + posse/identidade`; `不对` para correção.

**Exemplo-base.** `不要，谢谢；我已经有水了。` — *Bú yào, xièxie; wǒ yǐjīng yǒu shuǐ le.* — “Não quero, obrigado(a); já tenho água.”

**Substituições.** Oferta `咖啡/茶/这个`; motivo `有/不想/不能`; correção `不是我的/不是这个`.

**Observação pedagógica.** Recusa social inclui alternativa ou agradecimento quando necessário. `对` pode confirmar uma frase negativa; respostas por eco são mais claras para iniciantes.

**Potencial de mapa.** Oferta → aceitar/recusar → razão curta → manutenção da relação; ramos temporais de `不` e `没`.

**Recuperação.** Recusar café, dizer que não tem tempo e corrigir “é seu” para “não é meu”.

**Transferência.** Recusar uma oferta sem encerrar a conversa e corrigir um mal-entendido sobre um objeto.

**Domínio.** Escolher o negador em oito cenários e realizar uma recusa clara sem agressividade.

## F03 — Confirmar e checar entendimento

**Intenção.** Verificar informação, posse, horário ou sentido antes de agir.  
**Padrão.** `...吗？`; `...对吗？`; `你的意思是...吗？`; resposta por eco.

**Exemplo-base.** `你的意思是我们六点见吗？` — *Nǐ de yìsi shì wǒmen liù diǎn jiàn ma?* — “Você quer dizer que nos encontramos às seis?”

**Substituições.** Conteúdo `明天来/这个是你的/现在走`; final `吗/对吗`; interlocutor `你/您`.

**Observação pedagógica.** Confirmar é formular uma hipótese curta, não repetir mecanicamente. A pessoa deve poder corrigir a interpretação.

**Potencial de mapa.** Informação ouvida → hipótese → pergunta de confirmação → aceitar/corrigir → ação.

**Recuperação.** Confirmar um horário e a posse de um item.

**Transferência.** Em uma chamada, confirmar instruções e deliberadamente corrigir a própria hipótese após um “não”.

**Domínio.** Produzir três confirmações com conteúdo novo e responder com `对`, reformulação ou correção adequada.

## F04 — Localizar e orientar

**Intenção.** Encontrar pessoa, objeto ou lugar e oferecer uma localização suficiente para a tarefa.  
**Padrão.** `[alvo] 在哪儿/哪里？`; `[alvo] 在 + lugar`; `[lugar] 有 + coisa`.

**Exemplo-base.** `你的钥匙在哪儿？` — *Nǐ de yàoshi zài nǎr?* — “Onde estão suas chaves?” / `在桌子下面。` — *Zài zhuōzi xiàmiàn.* — “Debaixo da mesa.”

**Substituições.** Alvo `手机/出口/朋友`; lugar `包里/门口/楼上/这里`; relação `上面/下面/里面`.

**Observação pedagógica.** Escolher `在` para localização e `有` para introduzir existência. A instrução deve ser curta antes de adicionar direções compostas.

**Potencial de mapa.** Alvo → ponto de referência → relação espacial → confirmação.

**Recuperação.** Perguntar onde está o banheiro e responder com dois lugares.

**Transferência.** Orientar alguém em uma sala desconhecida usando três referências físicas.

**Domínio.** Localizar três alvos, distinguir `在` e `有` e ser compreendido sem apontar.

## F05 — Expressar preferência e escolher

**Intenção.** Selecionar uma alternativa e declarar preferência sem confundir pergunta de escolha com alternativa aberta.  
**Padrão.** `A 还是 B？`; `更喜欢 A`; `A 或者 B` em afirmação.

**Exemplo-base.** `你想喝茶还是咖啡？` — *Nǐ xiǎng hē chá háishi kāfēi?* — “Você quer chá ou café?”

**Substituições.** Bebidas, horários, lugares, meios de transporte; `更喜欢/比较喜欢` apenas depois do núcleo.

**Observação pedagógica.** `还是` solicita escolha; `或者` apresenta alternativas em frase afirmativa ou hipótese. A tradução “ou” não basta para escolher.

**Potencial de mapa.** Alternativas → pergunta fechada ou declaração aberta → escolha → justificativa opcional.

**Recuperação.** Perguntar entre dois horários e responder “prefiro o segundo”.

**Transferência.** Escolher transporte, comida e horário em três contextos novos.

**Domínio.** Usar `还是` em quatro perguntas e `或者` em duas afirmações sem trocar a função.

## F06 — Convidar, aceitar, recusar e remarcar

**Intenção.** Propor atividade compartilhada e negociar sem transformar convite em ordem.  
**Padrão.** `要不要一起 + ação？`; `...吧`; `好啊/可以`; `今天不行，...怎么样？`

**Exemplo-base.** `周六要不要一起吃饭？` — *Zhōuliù yào bu yào yìqǐ chīfàn?* — “Quer jantar junto no sábado?”

**Substituições.** Ação `喝咖啡/看电影/学习`; tempo `今晚/明天/下周`; contraproposta `星期天/七点`.

**Observação pedagógica.** Um convite é uma sequência: propor, aceitar ou recusar, e, se preciso, negociar. `吧` suaviza proposta; não significa simplesmente “sim”.

**Potencial de mapa.** Convite → resposta social → contraproposta → confirmação do plano.

**Recuperação.** Fazer um convite, aceitar e recusar com alternativa.

**Transferência.** Remarcar um encontro quando o primeiro horário não serve.

**Domínio.** Completar três sequências sem abandonar a relação e sem usar `要不要` como mero pedido de item.

## F07 — Reparar a conversa

**Intenção.** Diagnosticar a falha, pedir ajuste e confirmar que a compreensão voltou.  
**Padrão.** `我没听清楚/没听懂`; `请再说一遍/说慢一点`; `现在我明白了`.

**Exemplo-base.** `我没听清楚，请说慢一点。` — *Wǒ méi tīng qīngchu, qǐng shuō màn yìdiǎn.* — “Não ouvi direito; fale um pouco mais devagar, por favor.”

**Substituições.** Falha `没听清楚/没听懂/不明白`; ajuste `再说一遍/说大声一点`; fechamento `明白了/听懂了`.

**Observação pedagógica.** Separar som não captado, sentido não construído e volume/velocidade. Reparo é competência de continuidade, não pedido de desculpa por existir.

**Potencial de mapa.** Falha → diagnóstico → pedido de ajuste → nova tentativa → confirmação.

**Recuperação.** Responder a três cartões: ruído, velocidade e palavra desconhecida.

**Transferência.** Em videochamada, alternar repetição, velocidade menor e pergunta sobre significado.

**Domínio.** Escolher o reparo em cinco situações, pedir ajuste completo e retomar a tarefa.

---

# 4. Categoria III — Vocabulário funcional por contexto

O vocabulário entra em pequenas redes de uso. Cada célula contém poucos itens que já podem ser ouvidos, substituídos e transferidos; não é uma lista para decorar isoladamente.

## V01 — Primeiro contato

**Intenção.** Cumprimentar, dizer o nome e devolver a pergunta.  
**Padrão.** `你好，我叫 + nome。你呢？`

**Exemplo-base.** `你好，我叫小林。你呢？` — *Nǐ hǎo, wǒ jiào Xiǎolín. Nǐ ne?* — “Olá, eu me chamo Xiaolin. E você?”

**Substituições.** Nomes `安娜/保罗/Marina`; extensão `很高兴认识你`.

**Observação pedagógica.** `叫` introduz o nome; não é necessário começar por `我的名字是`. Em `名字 míngzi`, a segunda sílaba costuma ser neutra.

**Potencial de mapa.** contato → nome → reciprocidade → origem/idioma.

**Recuperação.** Perguntar o nome e responder com outro nome sem pinyin.

**Transferência.** Entrar numa aula on-line e apresentar-se a um participante novo.

**Domínio.** Fazer duas apresentações e usar `你呢？` espontaneamente.

## V02 — Origem e idioma

**Intenção.** Informar nacionalidade/origem e língua falada.  
**Padrão.** `我是 + país + 人`; `我说 + idioma`; `我会说一点 + idioma`.

**Exemplo-base.** `我是巴西人，我说葡萄牙语。` — *Wǒ shì Bāxī rén, wǒ shuō Pútáoyáyǔ.* — “Sou brasileiro(a) e falo português.”

**Substituições.** País `中国/日本/美国`; idioma `中文/英语/西班牙语`.

**Observação pedagógica.** `是` identifica pessoa/nacionalidade; `说` descreve a língua falada. `一点` limita competência sem transformar a frase em desculpa.

**Potencial de mapa.** pessoa → país → idioma → nível aproximado.

**Recuperação.** Informar dois países e dois idiomas.

**Transferência.** Em um encontro internacional, trocar país e idioma e acrescentar “falo um pouco de chinês”.

**Domínio.** Perguntar origem, responder nacionalidade e informar idioma sem trocar `是` e `说`.

## V03 — Reparo auditivo

**Intenção.** Manter a interação quando a fala não foi captada.  
**Padrão.** `我没听懂/没听清楚`; `请再说一遍`; `请说慢一点`.

**Exemplo-base.** `不好意思，我没听懂。` — *Bù hǎoyìsi, wǒ méi tīng dǒng.* — “Desculpe, não entendi.”

**Substituições.** `没听清楚` para som; `不明白` para sentido; `说大声一点` para volume.

**Observação pedagógica.** O diagnóstico vem antes do vocabulário. `没` marca resultado não alcançado; `不明白` descreve compreensão insuficiente.

**Potencial de mapa.** falha → pedido de reparo → nova escuta → `明白了`.

**Recuperação.** Escolher entre três formas para três problemas auditivos.

**Transferência.** Reparar em aula, telefone e ambiente barulhento.

**Domínio.** Produzir o diagnóstico e o pedido adequado em quatro de cinco tentativas.

## V04 — Objetos, referência e posse

**Intenção.** Nomear objeto, distinguir perto/longe e confirmar dono.  
**Padrão.** `这/那是什么？`; `这是/那是 + objeto`; `谁的 + objeto？`

**Exemplo-base.** `那是谁的电脑？` — *Nà shì shéi de diànnǎo?* — “De quem é aquele computador?”

**Substituições.** `书/钥匙/手机/包`; `这/那`; `我的/你的/他的`.

**Observação pedagógica.** `这/那` organizam referência espacial e discursiva. `的` fica depois do possuidor.

**Potencial de mapa.** apontar → nomear → relacionar → confirmar/corrigir.

**Recuperação.** Identificar dois objetos próximos e um distante.

**Transferência.** Em uma loja, perguntar por um objeto distante e confirmar que não é seu.

**Domínio.** Alternar `这/那`, produzir posse e corrigir uma atribuição.

## V05 — Café, loja e serviço

**Intenção.** Dizer o que deseja, pedir quantidade, recusar e agradecer.  
**Padrão.** `我想 + ação`; `我要/我想要 + item`; `请给我 + número + classificador + item`.

**Exemplo-base.** `请给我两杯茶，谢谢。` — *Qǐng gěi wǒ liǎng bēi chá, xièxie.* — “Por favor, me dê duas xícaras de chá, obrigado(a).”

**Substituições.** `水/咖啡/票`; classificadores `杯/张/本/个`; `不要 + item`.

**Observação pedagógica.** Introduzir quatro classificadores com ação, não como inventário. `一` muda de realização conforme a sílaba seguinte; ouvir a expressão é prioritário.

**Potencial de mapa.** desejo → quantidade → pedido → recusa/agradecimento.

**Recuperação.** Pedir uma bebida, um ingresso e um objeto; recusar um item.

**Transferência.** Fazer um pedido em cafeteria e outro em loja sem repetir item.

**Domínio.** Produzir cinco pedidos com três itens e dois classificadores funcionais.

## V06 — Ambiente e localização

**Intenção.** Perguntar e responder onde pessoas e coisas estão.  
**Padrão.** `[alvo] 在哪儿？`; `[alvo] 在 + lugar/recipiente + 里`.

**Exemplo-base.** `我的手机在包里。` — *Wǒ de shǒujī zài bāo lǐ.* — “Meu celular está na bolsa.”

**Substituições.** `钥匙/书/朋友`; `家/公司/桌子上/门口`.

**Observação pedagógica.** Começar por `哪儿` ou `哪里`, escolhendo uma forma por rodada. O objetivo é relação espacial, não decorar preposições portuguesas.

**Potencial de mapa.** alvo → relação espacial → lugar de referência.

**Recuperação.** Perguntar pelo banheiro e localizar três objetos.

**Transferência.** Descrever uma sala real sem apontar.

**Domínio.** Localizar três itens e distinguir `在` de `有`.

## V07 — Agenda e encontro

**Intenção.** Perguntar disponibilidade, especificar horário e marcar encontro.  
**Padrão.** `什么时候有空？`; `几点见？`; `[hora] 可以吗/吧？`

**Exemplo-base.** `你星期天上午有空吗？` — *Nǐ xīngqītiān shàngwǔ yǒu kòng ma?* — “Você está livre domingo de manhã?”

**Substituições.** `明天/周六/下周`; `上午/下午/晚上`; `六点/六点半`.

**Observação pedagógica.** `什么时候` pede período; `几点` pede hora. `吧` suaviza uma proposta, não responde “sim”.

**Potencial de mapa.** amplo → específico → proposta → contraproposta.

**Recuperação.** Perguntar disponibilidade, pedir a hora e propor um horário.

**Transferência.** Marcar estudo, recusar o primeiro horário e negociar o segundo.

**Domínio.** Completar a sequência em três contextos e distinguir `什么时候` de `几点`.

## V08 — Capacidade, possibilidade e permissão

**Intenção.** Dizer o que sabe, consegue hoje ou pode fazer por autorização.  
**Padrão.** `会 + habilidade`; `能 + ação`; `可以 + ação + 吗`.

**Exemplo-base.** `我今天能帮你，但是不能开车。` — *Wǒ jīntiān néng bāng nǐ, dànshì bù néng kāichē.* — “Hoje consigo ajudar, mas não consigo dirigir.”

**Substituições.** `说中文/游泳/做饭`; `现在/今天/太晚`; `用你的手机/坐这里`.

**Observação pedagógica.** Capacidade aprendida, condição e autorização são decisões diferentes, mesmo quando a tradução coincide.

**Potencial de mapa.** competência → condição → permissão; conexão com pedidos e negativas.

**Recuperação.** Produzir uma frase positiva e uma negativa de cada ramo.

**Transferência.** Responder a um pedido de ajuda em estação ou trabalho.

**Domínio.** Escolher o modal em nove de dez situações e justificar a escolha em português sem traduzir frase por frase.

## V09 — Escolha cotidiana

**Intenção.** Comparar duas opções e declarar preferência.  
**Padrão.** `A 还是 B？`; `我更喜欢 A`; `A 或者 B 都可以`.

**Exemplo-base.** `坐地铁还是坐公交车？` — *Zuò dìtiě háishi zuò gōngjiāochē?* — “Vamos de metrô ou de ônibus?”

**Substituições.** `茶/咖啡`; `今天/明天`; `在家/出去`; `更喜欢/都可以`.

**Observação pedagógica.** Ensinar a perspectiva da escolha antes do vocabulário de preferência. `还是` exige decisão no enunciado interrogativo.

**Potencial de mapa.** alternativas → escolha → preferência → motivo.

**Recuperação.** Perguntar e responder sobre bebida e transporte.

**Transferência.** Escolher comida, horário e trajeto em situações novas.

**Domínio.** Usar `还是` e `或者` com funções diferentes em seis produções.

## V10 — Rotina, atualização e experiência

**Intenção.** Falar de hábito, mudança de situação e experiência anterior.  
**Padrão.** `每天 + ação`; `...了`; `...过`.

**Exemplo-base.** `我以前去过上海，现在住在这里了。` — *Wǒ yǐqián qù guo Shànghǎi, xiànzài zhù zài zhèlǐ le.* — “Já fui a Xangai; agora moro aqui.”

**Substituições.** `每天/有时候/周末`; `吃完了/下雨了`; `看过/学过/用过`.

**Observação pedagógica.** `过` apresenta experiência; `了` fecha evento ou atualiza estado. Não ensinar nenhum deles como marcador simples de passado.

**Potencial de mapa.** hábito → evento concluído/mudança → experiência; conexão com `没` e `还没`.

**Recuperação.** Relatar uma rotina, uma mudança e uma experiência.

**Transferência.** Comparar o que fazia antes, o que faz agora e o que já experimentou.

**Domínio.** Produzir seis frases e escolher `了` ou `过` por intenção.

## V11 — Planejamento e sequência

**Intenção.** Organizar duas ações e explicar uma razão simples.  
**Padrão.** `先……再……`; `因为……所以……`; `然后`.

**Exemplo-base.** `我先买票，再去找朋友。` — *Wǒ xiān mǎi piào, zài qù zhǎo péngyou.* — “Primeiro compro a passagem, depois vou procurar meu amigo.”

**Substituições.** Ações `吃饭/学习/回家`; causa `没时间/下雨/明天早起`; consequência escolhida.

**Observação pedagógica.** `再` em sequência futura não é `在` de localização. A causa pode aparecer sem `所以` em resposta curta; ensine a dupla completa quando a relação causal precisa ficar explícita.

**Potencial de mapa.** plano → ordem → razão → consequência.

**Recuperação.** Organizar uma rotina em duas ações e justificar uma escolha.

**Transferência.** Planejar uma saída, uma aula e uma tarefa doméstica.

**Domínio.** Produzir três planos novos e manter a ordem temporal.

## V12 — Cortesia e encerramento

**Intenção.** Abrir uma interrupção, agradecer, desculpar-se, manter vínculo e sair da interação.  
**Padrão.** `不好意思/请问`; `谢谢—不客气`; `对不起—没关系`; `我先走了，下次聊`.

**Exemplo-base.** `谢谢你的帮助，下次再聊。` — *Xièxie nǐ de bāngzhù, xià cì zài liáo.* — “Obrigado pela ajuda; a gente se fala na próxima.”

**Substituições.** `麻烦你`; `没事儿/没关系`; `明天见/再联系/晚安`; canal `我挂了啊`.

**Observação pedagógica.** A escolha social depende da função: agradecimento não recebe automaticamente resposta de desculpa; dano/desculpa não é igual a favor/agradecimento. `啊` e `吧` devem ser ouvidos antes de serem generalizados.

**Potencial de mapa.** interrupção → pedido → agradecimento/desculpa → resposta → encerramento.

**Recuperação.** Agradecer ajuda, responder a um pedido de desculpa e anunciar saída.

**Transferência.** Fechar uma conversa presencial, uma ligação e uma mensagem.

**Domínio.** Completar três sequências sociais sem ruptura e ajustar registro a amigo, professor e atendente.

---

# 5. Categoria IV — Contrastes para brasileiros

Os contrastes abaixo só entram quando mudam uma decisão de fala, compreensão, registro ou pronúncia. São hipóteses de diagnóstico, não erros universais de todo brasileiro.

## C01 — 是 × 在 × 有

**Intenção.** Escolher entre identidade, lugar e posse/existência.  
**Padrão.** `她是医生`; `她在医院`; `医院有医生`.

**Exemplo-base.** `她是医生，现在在医院。` — *Tā shì yīshēng, xiànzài zài yīyuàn.* — “Ela é médica e agora está no hospital.”

**Substituições.** Profissão `学生/老师`; lugar `家/公司`; posse `有时间/有问题`.

**Observação pedagógica.** O português “está” pode induzir `是`. Perguntar primeiro “identifico, localizo ou apresento algo que existe?”.

**Potencial de mapa.** três cartões semânticos, com `不是/不在/没有` nas bordas.

**Recuperação.** Dizer “sou aluno”, “estou em casa” e “tenho tempo”.

**Transferência.** Descrever uma pessoa e o ambiente ao redor.

**Domínio.** Produzir seis frases e negar localização e posse corretamente.

## C02 — 不 × 没(有)

**Intenção.** Escolher entre disposição/hábito/estado e não ocorrência/posse.  
**Padrão.** `我不喝茶`; `我昨天没喝茶`; `我没有茶`.

**Exemplo-base.** `我不喝牛奶，今天也没喝果汁。` — *Wǒ bù hē niúnǎi, jīntiān yě méi hē guǒzhī.* — “Não bebo leite e hoje também não tomei suco.”

**Substituições.** Bebidas, ações passadas, posse `时间/钱/手机`.

**Observação pedagógica.** Não reduzir a “presente versus passado”. `不` também nega vontade e estado; `没` nega acontecimento, resultado e posse.

**Potencial de mapa.** alvo da negação → intenção/hábito/estado ou evento/posse.

**Recuperação.** Quatro prompts: não quero, não fui ontem, não tenho tempo, não gosto.

**Transferência.** Explicar ausência atual, ação não feita hoje e experiência não realizada.

**Domínio.** Acertar oito de oito situações e produzir dois pares contrastivos.

## C03 — 会 × 能 × 可以

**Intenção.** Separar habilidade, condição e permissão.  
**Padrão.** `会做`; `今天能做`; `可以做吗`.

**Exemplo-base.** `我会游泳，但是这里不可以游泳。` — *Wǒ huì yóuyǒng, dànshì zhèlǐ bù kěyǐ yóuyǒng.* — “Sei nadar, mas aqui não é permitido nadar.”

**Substituições.** Habilidades e locais com regras; condição `今天/现在`.

**Observação pedagógica.** Há sobreposição real, sobretudo em pedidos. Avaliar foco compreensível, não uma única tradução correta.

**Potencial de mapa.** saber → `会`; conseguir agora → `能`; autorizado → `可以`.

**Recuperação.** Produzir três frases com “sei”, “hoje não consigo” e “posso?”.

**Transferência.** Responder a uma situação de trabalho e a uma regra de espaço público.

**Domínio.** Escolher o modal em nove de dez cenários.

## C04 — 想 × 要

**Intenção.** Regular abertura do desejo, decisão, necessidade ou pedido.  
**Padrão.** `想 + ação`; `要 + item/ação`.

**Exemplo-base.** `我想休息，但是我现在要走。` — *Wǒ xiǎng xiūxi, dànshì wǒ xiànzài yào zǒu.* — “Quero descansar, mas agora preciso ir.”

**Substituições.** Ações, itens e razões; `想要` para objeto desejado.

**Observação pedagógica.** A oposição é de foco e força, não de dicionário. Contexto, urgência e relação podem sobrepor as formas.

**Potencial de mapa.** desejo aberto → `想`; decisão/necessidade/pedido → `要`.

**Recuperação.** Dizer o que gostaria de fazer e o que precisa fazer agora.

**Transferência.** Em uma loja e em casa, mudar o mesmo verbo de intenção para pedido.

**Domínio.** Alternar as formas em quatro situações e explicar o foco de cada uma.

## C05 — 还是 × 或者

**Intenção.** Formular escolha exigida ou alternativa declarada.  
**Padrão.** `A 还是 B？`; `A 或者 B`.

**Exemplo-base.** `我们坐车还是走路？` — *Wǒmen zuò chē háishi zǒulù?* — “Vamos de carro ou a pé?”

**Substituições.** Transporte, comida, dia, atividade; afirmações com `都可以`.

**Observação pedagógica.** A posição na pergunta é a pista funcional mais útil. Não ensinar uma equivalência binária sem situação.

**Potencial de mapa.** alternativas → tipo de enunciado → partícula/conjunção adequada.

**Recuperação.** Perguntar sobre dois horários e declarar duas opções possíveis.

**Transferência.** Planejar deslocamento e refeição em duas rodadas.

**Domínio.** Quatro perguntas com `还是` e duas frases afirmativas com `或者`.

## C06 — 来 × 去

**Intenção.** Escolher direção em relação ao ponto de referência.  
**Padrão.** `来 + ponto de referência`; `去 + destino afastado`.

**Exemplo-base.** `你什么时候来我家？` — *Nǐ shénme shíhou lái wǒ jiā?* — “Quando você vem à minha casa?”

**Substituições.** Ponto `我家/这里/公司`; destino `学校/北京/那里`.

**Observação pedagógica.** A perspectiva é do ponto de referência, não apenas “vir” e “ir” em português. A mesma ação pode mudar com o ponto de vista.

**Potencial de mapa.** movimento + centro deíctico → aproximar `来` ou afastar `去`.

**Recuperação.** Dizer “venha aqui” e “vou para a escola”.

**Transferência.** Narrar deslocamentos de uma chamada, casa e trabalho.

**Domínio.** Escolher a direção em seis cenários mudando o centro de referência.

## C07 — 知道 × 认识

**Intenção.** Separar conhecimento de fato de familiaridade com pessoa/lugar.  
**Padrão.** `知道 + informação`; `认识 + pessoa/lugar`.

**Exemplo-base.** `我知道地址，但是不认识那个人。` — *Wǒ zhīdào dìzhǐ, dànshì bù rènshi nàge rén.* — “Sei o endereço, mas não conheço aquela pessoa.”

**Substituições.** Fatos `时间/答案/原因`; pessoas `老师/邻居`; lugares conhecidos.

**Observação pedagógica.** “Conhecer” em português comprime duas relações. Perguntar: sei uma informação ou tenho familiaridade/reconhecimento?

**Potencial de mapa.** proposição/fato → `知道`; entidade/pessoa/lugar → `认识`.

**Recuperação.** Dizer que sabe o horário, mas não conhece a pessoa.

**Transferência.** Responder perguntas sobre endereço, vizinho e cidade.

**Domínio.** Classificar dez objetos e produzir quatro frases alternadas.

## C08 — 听清楚 × 听懂 × 明白

**Intenção.** Diagnosticar som, compreensão auditiva ou sentido geral.  
**Padrão.** `没听清楚`; `没听懂`; `不明白`.

**Exemplo-base.** `我听清楚了，但是还不明白这个意思。` — *Wǒ tīng qīngchu le, dànshì hái bù míngbai zhège yìsi.* — “Ouvi claramente, mas ainda não entendi o sentido.”

**Substituições.** `这个词/最后一句/这个意思`; pedidos de repetição ou explicação.

**Observação pedagógica.** O aluno deve localizar a falha antes de escolher a frase. Não usar `什么？` como reparo universal em contexto formal.

**Potencial de mapa.** som → evento auditivo → sentido → reparo específico.

**Recuperação.** Três cartões com ruído, fala rápida e conceito desconhecido.

**Transferência.** Reparar uma aula e uma conversa com sentidos distintos.

**Domínio.** Escolher a forma em quatro de cinco tentativas e seguir a interação.

## C09 — 再 × 又

**Intenção.** Distinguir repetição futura/solicitada de repetição já ocorrida.  
**Padrão.** `再 + verbo`; `又 + verbo`.

**Exemplo-base.** `请再说一次；你又迟到了。` — *Qǐng zài shuō yí cì; nǐ yòu chídào le.* — “Repita, por favor; você se atrasou de novo.”

**Substituições.** `说/看/来/联系`; tempo futuro ou evento já repetido.

**Observação pedagógica.** A tradução “de novo” esconde a linha do tempo. `再` projeta a repetição; `又` relata recorrência já observada.

**Potencial de mapa.** evento atual → repetição ainda não feita ou repetição já feita.

**Recuperação.** Pedir repetição e comentar uma ocorrência repetida ontem.

**Transferência.** Alternar pedidos futuros e queixas sobre recorrência.

**Domínio.** Produzir seis frases sem confundir `再` com `在`.

## C10 — 了 × 过

**Intenção.** Marcar evento delimitado/mudança ou experiência anterior.  
**Padrão.** `V + 了`; `V + 过`; `situação + 了`.

**Exemplo-base.** `我看过这部电影，但是今天看完了。` — *Wǒ kàn guo zhè bù diànyǐng, dànshì jīntiān kàn wán le.* — “Já vi esse filme, mas hoje terminei de vê-lo.”

**Substituições.** `吃/去/学/用`; experiência e evento atual.

**Observação pedagógica.** `过` não diz que a situação permanece; `了` não é simples passado. A pergunta de diagnóstico é “qual experiência?” versus “qual evento/mudança delimitada?”.

**Potencial de mapa.** experiência → `过`; fechamento/mudança → `了`; negação com `没`.

**Recuperação.** Dizer que já visitou um lugar e que acabou uma tarefa agora.

**Transferência.** Relatar três experiências e três mudanças em situações novas.

**Domínio.** Escolher corretamente em oito prompts e negar uma experiência com `没...过`.

## C11 — 一点 × 有点

**Intenção.** Ajustar quantidade ou grau avaliado.  
**Padrão.** `V + 一点`; `有点 + adjetivo/estado`.

**Exemplo-base.** `请慢一点；今天有点冷。` — *Qǐng màn yìdiǎn; jīntiān yǒudiǎn lěng.* — “Mais devagar, por favor; hoje está um pouco frio.”

**Substituições.** `快/大声/清楚`; estados `累/贵/忙/难`.

**Observação pedagógica.** `一点` frequentemente pede ajuste ou quantidade; `有点` avalia um grau, muitas vezes com incômodo. A posição muda a função.

**Potencial de mapa.** ação/quantidade → `一点`; estado avaliativo → `有点`.

**Recuperação.** Pedir para falar mais devagar e comentar duas condições.

**Transferência.** Ajustar velocidade, volume e preço em três situações.

**Domínio.** Usar as duas formas em quatro pares contrastivos.

## C12 — 这 × 那 × 哪 + classificador

**Intenção.** Referir perto, longe ou escolher entre itens contáveis.  
**Padrão.** `这/那 + classificador + nome`; `哪 + classificador + nome?`

**Exemplo-base.** `你要哪一张票？` — *Nǐ yào nǎ yì zhāng piào?* — “Qual ingresso você quer?”

**Substituições.** `个/杯/本/张`; `票/书/问题/咖啡`; distância e escolha.

**Observação pedagógica.** O classificador é parte do padrão de contagem. Começar com quatro formas de alto retorno, não com listas extensas.

**Potencial de mapa.** referência → medida → objeto; contraste proximidade, distância e pergunta.

**Recuperação.** Escolher um livro, uma xícara e uma passagem.

**Transferência.** Selecionar itens reais em uma mesa ou loja.

**Domínio.** Produzir seis sintagmas, com número e classificador adequados.

## C13 — 也 × 都

**Intenção.** Adicionar um participante/ação ou abranger todos.  
**Padrão.** `S + 也 + predicado`; `grupo + 都 + predicado`.

**Exemplo-base.** `我也喜欢茶，我们都喝水。` — *Wǒ yě xǐhuan chá, wǒmen dōu hē shuǐ.* — “Eu também gosto de chá; todos nós bebemos água.”

**Substituições.** Sujeitos individuais e grupos; predicados de rotina, gosto e capacidade.

**Observação pedagógica.** O escopo importa: `也` acrescenta um membro ou propriedade; `都` cobre um conjunto. Não tratar ambas como “também/todos” intercambiáveis.

**Potencial de mapa.** conjunto discursivo → inclusão individual ou totalidade.

**Recuperação.** Dizer que também fará algo e que todos farão outra coisa.

**Transferência.** Comparar hábitos de três colegas.

**Domínio.** Produzir quatro frases e explicar quem está incluído em cada uma.

## C14 — 吗 × 呢 × 吧

**Intenção.** Perguntar polarmente, devolver foco ou suavizar proposta/conclusão.  
**Padrão.** `...吗？`; `[resposta]，你呢？`; `...吧`.

**Exemplo-base.** `你有空吗？我明天有空，你呢？七点见吧。` — *Nǐ yǒu kòng ma? Wǒ míngtiān yǒu kòng, nǐ ne? Qī diǎn jiàn ba.* — “Você está livre? Eu estou livre amanhã; e você? Vamos nos ver às sete, pode ser.”

**Substituições.** Tópico devolvido `你/明天/那个`; propostas de horário e atividade.

**Observação pedagógica.** `呢` precisa de tópico ativo; `吧` não é “sim” e não substitui `吗`. Uma frase com várias partículas deve esperar o domínio de cada operação isolada.

**Potencial de mapa.** confirmar → devolver → propor; registro e entoação no ramo auditivo.

**Recuperação.** Fazer uma pergunta, devolver `你呢` e propor um horário.

**Transferência.** Conduzir três microsequências sem repetir as frases-base.

**Domínio.** Escolher a partícula em oito prompts e manter a função social compreensível.

---

# 6. Categoria V — Pronúncia e tons

Esta categoria é uma camada pós-áudio. Os exemplos abaixo organizam a escuta e a produção; não substituem modelo acústico, gravação e feedback.

## T01 — Quatro tons como identidade lexical

**Intenção.** Ouvir e produzir diferenças de altura que alteram a palavra.  
**Padrão.** mesma inicial + final + tom diferente → significado diferente.

**Exemplo-base.** `妈、麻、马、骂` — *mā, má, mǎ, mà* — “mãe; cânhamo; cavalo; xingar”.

**Substituições.** Usar sílabas já conhecidas em palavras e frases curtas, não listas longas.

**Observação pedagógica.** Tom não é emoção universal nem simplesmente volume. O português usa entonação, mas não o tom lexical da mesma maneira.

**Potencial de mapa.** intenção → sílaba → direção tonal → palavra; o áudio é o ramo obrigatório.

**Recuperação.** Dizer “estou bem” e identificar a sílaba com foco tonal.
**Transferência.** Cumprimentar, dizer que está bem e apresentar um nome novo sem consultar pinyin.

**Domínio.** Identificar o contraste solicitado em oito de dez tentativas auditivas e produzir quatro frases curtas reconhecíveis.

## T02 — Terceiro tom em fala conectada

**Intenção.** Produzir o terceiro tom de modo baixo e econômico dentro da frase.  
**Padrão.** `3º tom em frase → alvo baixo e curto`; isolamento pode ter contorno mais completo.

**Exemplo-base.** `我很好。` — *Wǒ hěn hǎo.* — “Estou muito bem.”

**Substituições.** `很忙/想买水/你好`; trocar o sujeito e manter o fluxo.

**Observação pedagógica.** Não fazer uma grande queda-subida em toda sílaba marcada com `ˇ`. Em fala conectada, manter o ponto baixo e continuar.

**Potencial de mapa.** sílaba → ponto baixo → grupo prosódico → continuidade; alerta “não alongar cada terceiro tom”.

**Recuperação.** Dizer “estou bem” e “quero água” sem pausas artificiais.

**Transferência.** Escolher uma pessoa, um estado e uma ação com terceiros tons.

**Domínio.** Produzir três frases diferentes com terceiro tom funcional e ritmo contínuo.

## T03 — Sandhi 3º + 3º

**Intenção.** Reconhecer e produzir a mudança de superfície sem criar uma nova palavra.  
**Padrão.** `3º + 3º → aproximadamente 2º + 3º na fala`; a escrita lexical permanece.

**Exemplo-base.** `你好。` — *Nǐ hǎo*; fala aproximada *ní hǎo* — “Olá.”

**Substituições.** `很好 Hěn hǎo`, `你想买 Nǐ xiǎng mǎi`; começar por pares curtos.

**Observação pedagógica.** Não ensinar “todo terceiro tom vira segundo”. A mudança depende do domínio e do agrupamento prosódico. O material escrito conserva o tom lexical.

**Potencial de mapa.** par 3+3 → primeiro sobe na fala → escrita não muda → recombinação.

**Recuperação.** Cumprimentar e dizer “muito bom” ouvindo o modelo antes.

**Transferência.** Produzir três expressões novas com dois terceiros tons conhecidos.

**Domínio.** Aplicar o padrão em quatro pares sem reescrever mentalmente o vocabulário.

## T04 — Sandhi de 不 e 一

**Intenção.** Usar negação e quantidade com a realização tonal adequada.  
**Padrão.** `不` tende a [bú] antes de quarto tom; `一` muda de realização conforme o tom seguinte.

**Exemplo-base.** `不是我的。` — *Bú shì wǒ de.* — “Não é meu.” / `一杯茶。` — *Yì bēi chá.* — “Uma xícara de chá.”

**Substituições.** `不是/不要/不对`; `一杯/一张/一遍/一个`.

**Observação pedagógica.** Os caracteres continuam `不` e `一`; o pinyin de apoio pode mostrar a fala realizada. Ensinar em blocos, não como leitura mecânica de diacríticos.

**Potencial de mapa.** marcador lexical → tom da sílaba seguinte → forma de superfície → frase funcional.

**Recuperação.** Produzir `不要`, `不是`, `一遍` e `一杯` após ouvir.

**Transferência.** Fazer uma recusa, corrigir posse e pedir uma repetição.

**Domínio.** Manter inteligibilidade e realização conectada em cinco blocos, sem perder a escrita de referência.

## T05 — Tom neutro e ritmo

**Intenção.** Reduzir sílabas leves sem dar a todas o mesmo peso.  
**Padrão.** `partícula ou sílaba não focalizada → duração e força menores`.

**Exemplo-base.** `你好吗？` — *Nǐ hǎo ma?* — “Você está bem?”

**Substituições.** `名字 míngzi`, `谢谢 xièxie`, `什么 shénme`, `呢 ne`, `吗 ma`.

**Observação pedagógica.** Tom neutro depende de contexto e prosódia; não é “tom zero” com uma regra única. O erro de dar peso igual a cada sílaba pode obscurecer o foco.

**Potencial de mapa.** palavra funcional → sílaba focal → redução rítmica → frase.

**Recuperação.** Dizer `谢谢` e `你呢` imitando o fluxo, não duas sílabas isoladas.

**Transferência.** Usar uma expressão neutra em apresentação, pedido e encerramento.

**Domínio.** Manter a sílaba leve reconhecível em quatro frases e preservar o foco informacional.

## T06 — Pinyin como sistema de decodificação

**Intenção.** Usar pinyin para recuperar som e tom, sem aplicar a ortografia portuguesa.  
**Padrão.** `caractere → pinyin + tom → modelo auditivo → produção`.

**Exemplo-base.** `请问。` — *Qǐngwèn.* — “Com licença; posso perguntar?”

**Substituições.** `q/j/x`, `zh/ch/sh/r`, `ü`, finais `-n/-ng`; sempre com palavras conhecidas.

**Observação pedagógica.** Letras latinas não conservam necessariamente o valor do português. Pinyin orienta; o áudio e a imitação validam.

**Potencial de mapa.** caractere → romanização → som → função; alerta “pinyin não é transcrição portuguesa”.

**Recuperação.** Ler três blocos já ouvidos, depois fechar o pinyin e repetir.

**Transferência.** Recuperar uma frase nova a partir de caracteres, mas confirmar a pronúncia no áudio legítimo.

**Domínio.** Usar o pinyin sem criar uma pronúncia brasileira previsível em cinco palavras treinadas.

## T07 — Aspiração e iniciais

**Intenção.** Manter contrastes que diferenciam palavras, especialmente em pedidos e lugares.  
**Padrão.** pares não aspirado/aspirado: `b/p`, `d/t`, `g/k`, `z/c`, `zh/ch`, `j/q`.

**Exemplo-base.** `请坐。` — *Qǐng zuò.* — “Sente-se, por favor.”

**Substituições.** `请吃/去/看`; pares de palavras já presentes no repertório.

**Observação pedagógica.** Aspiração é fluxo de ar, não simplesmente voz mais forte. `qǐng` não é “tching” português; `zh/ch` não são automaticamente `j/tch` do português.

**Potencial de mapa.** intenção → inicial → aspiração → palavra → inteligibilidade.

**Recuperação.** Ouvir e repetir pares contrastivos, sem avaliar por ortografia.

**Transferência.** Produzir um pedido e uma localização com iniciais treinadas.

**Domínio.** Ser compreendido por interlocutor familiarizado com o modelo em oito de dez itens.

## T08 — Palatais, retroflexas, ü e finais

**Intenção.** Evitar colapsos de sons que alterem reconhecimento de palavra.  
**Padrão.** `j/q/x` com finais compatíveis; `zh/ch/sh/r`; `ü`; `-n` versus `-ng`.

**Exemplo-base.** `学习中文。` — *Xuéxí Zhōngwén.* — “Estudar chinês.”

**Substituições.** `学生/手机/知道`; `-an/-ang`, `-in/-ing`, `你/您` conforme contexto.

**Observação pedagógica.** O brasileiro pode aproximar sons a categorias do português; tratar isso como hipótese de diagnóstico. Não avaliar sotaque nativo, e sim distinção funcional no repertório.

**Potencial de mapa.** segmento → posição articulatória → final → palavra → contraste de significado.

**Recuperação.** Produzir `中文`, `学习`, `手机` e `知道` após escuta.

**Transferência.** Inserir dois contrastes em apresentação e pedido.

**Domínio.** Manter finais e iniciais suficientemente distinguíveis em cinco frases gravadas.

## T09 — Prosódia de frase

**Intenção.** Evitar usar a melodia do português para substituir tons lexicais.  
**Padrão.** `tom lexical na sílaba + agrupamento de sentido + entoação de frase`.

**Exemplo-base.** `你能再说一遍吗？` — *Nǐ néng zài shuō yí biàn ma?* — “Você pode repetir?”

**Substituições.** Pedidos de repetição, confirmação e convite; foco em `再`, `一遍`, `吗`.

**Observação pedagógica.** Entoação interrogativa não transforma o segundo tom em pergunta nem autoriza apagar tons lexicais. Frases devem ser avaliadas como unidades, não como soma de sílabas.

**Potencial de mapa.** intenção → foco → agrupamento → tons → ação social.

**Recuperação.** Fazer uma pergunta e uma afirmação com o mesmo vocabulário, mantendo a distinção tonal.

**Transferência.** Pedir, confirmar e encerrar uma interação sem falar palavra por palavra.

**Domínio.** Ser compreendido em quatro atos de fala e manter a intenção mesmo com ritmo natural.

### Política de domínio fonético

Pronúncia funcional exige escuta de modelo, imitação, gravação própria e, quando possível, feedback de professor, interlocutor ou ferramenta. O banco não promete sotaque nativo, correção automática ou domínio por leitura. Interferências do português brasileiro devem ser confirmadas em beta com gravações reais.

---

# 7. Categoria VI — Variações e expansões

A progressão é **substituir → estender → combinar → transferir**. Uma extensão entra somente quando o núcleo já pode ser recuperado sem tradução.

## X01 — Substituir a ação mantendo o molde

**Intenção.** Produzir uma família de frases, não uma frase decorada.  
**Padrão.** `我想 + [ação]`.

**Exemplo-base.** `我想喝水。` — *Wǒ xiǎng hē shuǐ.* — “Quero beber água.”

**Substituições.** `吃饭/看电影/回家/休息`.

**Observação pedagógica.** Trocar um slot por vez; três a cinco itens bastam. A variação comprova que o padrão está disponível.

**Potencial de mapa.** intenção → molde fixo → slot de ação → alerta `想/要`.

**Recuperação.** Produzir quatro ações sem ver o molde completo.

**Transferência.** Dizer o que quer fazer ao sair do trabalho e perguntar o que outra pessoa quer.

**Domínio.** Quatro variações, uma negação e uma pergunta sem consultar.

## X02 — Acrescentar tempo e lugar

**Intenção.** Expandir uma ação curta sem perder sua ordem.  
**Padrão.** `[sujeito] + [tempo] + [lugar] + [ação]`.

**Exemplo-base.** `我明天在家学习。` — *Wǒ míngtiān zài jiā xuéxí.* — “Amanhã estudo em casa.”

**Substituições.** Tempo `今天/晚上/周六`; lugar `公司/学校/咖啡店`; ação `工作/吃饭/看书`.

**Observação pedagógica.** Acrescentar uma dimensão por vez; o objetivo é situar a ação, não cobrir todos os adjuntos.

**Potencial de mapa.** núcleo → tempo → lugar → verbo → objeto; conexão com localização.

**Recuperação.** Transformar “estudo” em “amanhã estudo na biblioteca”.

**Transferência.** Narrar três ações do próprio dia em horários e lugares distintos.

**Domínio.** Produzir cinco expansões mantendo o lugar antes da ação.

## X03 — Quantidade e classificadores

**Intenção.** Pedir ou escolher item contado.  
**Padrão.** `[número] + [classificador] + [substantivo]`.

**Exemplo-base.** `我要一张票。` — *Wǒ yào yì zhāng piào.* — “Quero uma passagem/um ingresso.”

**Substituições.** `一杯水/两本书/三个问题/两张票`.

**Observação pedagógica.** Começar por `个`, `杯`, `本`, `张`, cada qual ligado a uma ação. `二` e `两` são aprofundados na categoria de contrastes.

**Potencial de mapa.** intenção → número → medida → item → pedido.

**Recuperação.** Pedir um copo, dois livros e três perguntas.

**Transferência.** Selecionar objetos reais em uma loja ou mesa.

**Domínio.** Produzir seis sintagmas e inserir quatro em frases completas.

## X04 — Complementar com resultado ou possibilidade

**Intenção.** Dizer se uma ação chegou a um resultado ou pode chegar a ele.  
**Padrão.** `V + resultado`; `V + 得/不 + resultado`.

**Exemplo-base.** `你看得懂吗？` — *Nǐ kàn de dǒng ma?* — “Você consegue entender lendo?”

**Substituições.** `听懂/写清楚/做完/准备好`; negativo `看不懂/写不清楚`.

**Observação pedagógica.** Resultado e potencial são operações diferentes; ancorar em tarefas concretas evita explicação abstrata.

**Potencial de mapa.** ação → resultado realizado ou capacidade de alcançar resultado.

**Recuperação.** Dizer “entendi”, “não terminei” e “não consigo explicar claramente”.

**Transferência.** Avaliar o próprio desempenho numa tarefa nova.

**Domínio.** Produzir quatro pares resultativo/potencial e identificar a pergunta de cada um.

## X05 — Direção com 来/去 e complementos

**Intenção.** Indicar movimento em relação ao ponto de referência.  
**Padrão.** `V + 来/去`; extensões `拿来/带去/进来/出去`.

**Exemplo-base.** `请把书拿来。` — *Qǐng bǎ shū ná lái.* — “Traga o livro, por favor.”

**Substituições.** `拿/带/走/进`; objeto `书/水/手机`; ponto de referência `这里/那里`.

**Observação pedagógica.** Ensinar direção somente com um centro espacial visível. `来/去` não são escolhidos por tradução isolada.

**Potencial de mapa.** ação → direção → centro de referência → objeto.

**Recuperação.** Dizer “traga aqui” e “leve para lá”.

**Transferência.** Dar duas instruções de movimento em uma sala e numa ligação.

**Domínio.** Escolher a direção em seis cenários e manter o ponto de referência.

## X06 — Ordenar ações

**Intenção.** Planejar uma sequência curta.  
**Padrão.** `先 + ação, 再 + ação`; opção `然后`.

**Exemplo-base.** `我先吃饭，再学习。` — *Wǒ xiān chīfàn, zài xuéxí.* — “Primeiro vou comer, depois estudar.”

**Substituições.** Ações, horários e justificativas; `然后` para o passo seguinte.

**Observação pedagógica.** `再` projeta uma ação posterior; não confundir com `在`. Não empilhar muitas etapas no início.

**Potencial de mapa.** ação 1 → ação 2 → razão ou consequência.

**Recuperação.** Organizar duas ações domésticas e duas de estudo.

**Transferência.** Planejar uma ida à estação, uma aula e uma compra.

**Domínio.** Produzir três sequências sem inverter a ordem temporal.

## X07 — Combinar causa, condição e concessão

**Intenção.** Justificar, condicionar ou contrastar uma ação.  
**Padrão.** `因为……所以……`; `如果……就……`; `虽然……但是……`.

**Exemplo-base.** `因为下雨，所以我不出去。` — *Yīnwèi xiàyǔ, suǒyǐ wǒ bù chūqù.* — “Como está chovendo, não vou sair.”

**Substituições.** Causas `没时间/太累/明天早起`; resultados e condições simples.

**Observação pedagógica.** Introduzir uma relação por vez. Em resposta curta, `因为` pode bastar; não exigir pares completos em toda fala natural.

**Potencial de mapa.** situação → relação lógica → resultado/contraste; conexão com `不/没`.

**Recuperação.** Dar uma razão para não ir e uma condição para ir.

**Transferência.** Justificar uma escolha, condicionar um plano e contrastar uma preferência.

**Domínio.** Produzir três relações novas sem misturar os conectores.

## X08 — Foco com 把 e detalhe de evento com 是……的

**Intenção.** Organizar um objeto conhecido ou destacar detalhe de evento já compartilhado.  
**Padrão.** `把 + objeto + verbo + resultado`; `是……的` para tempo, lugar ou modo de evento conhecido.

**Exemplo-base.** `请把门关好。` — *Qǐng bǎ mén guān hǎo.* — “Feche bem a porta, por favor.”

**Substituições.** `门/书/手机`; resultado `放好/写完/拿走`; detalhes `昨天/在家/坐火车`.

**Observação pedagógica.** Adiar até o verbo e o resultado estarem disponíveis. `把` não é tradução fixa de “pegar”; a construção põe o objeto conhecido em foco.

**Potencial de mapa.** objeto conhecido → ação afetando objeto → resultado; evento conhecido → detalhe destacado.

**Recuperação.** Pedir que alguém guarde um objeto e responder onde um evento ocorreu.

**Transferência.** Resolver uma tarefa com objeto real e depois destacar quando/onde foi feita.

**Domínio.** Usar `把` em três pedidos com resultado claro e `是……的` em dois eventos conhecidos.

---

# 8. Categoria VII — Perguntas e respostas

As perguntas são pares de ação e follow-up. A resposta deve ser completa o suficiente para orientar o próximo turno.

## Q01 — Confirmar preferência ou ação com 吗

**Intenção.** Perguntar e responder sobre gosto, plano ou identidade.  
**Padrão.** `[predicado] + 吗？` → repetir ou negar predicado.

**Exemplo-base.** `你明天去上课吗？` — *Nǐ míngtiān qù shàngkè ma?* — “Você vai à aula amanhã?” / `不去，我在家学习。` — *Bù qù, wǒ zài jiā xuéxí.* — “Não, vou estudar em casa.”

**Substituições.** `喜欢喝茶/是学生/在公司`; respostas com predicado correspondente.

**Observação pedagógica.** Não responder sempre `是/不是`. `吗` é pergunta polar; a resposta deve tornar a polaridade clara.

**Potencial de mapa.** pergunta → resposta pelo predicado → follow-up `你呢`.

**Recuperação.** Perguntar se a pessoa gosta de chá e devolver “e você?”.

**Transferência.** Confirmar um plano antes de uma aula.

**Domínio.** Quatro pares com respostas completas e dois follow-ups.

## Q02 — Devolver com 呢

**Intenção.** Responder e manter a mesma dimensão conversacional.  
**Padrão.** `[resposta própria]. 你/ tópico + 呢？`

**Exemplo-base.** `我住在圣保罗，你呢？` — *Wǒ zhù zài Shèng Bǎoluó, nǐ ne?* — “Moro em São Paulo; e você?”

**Substituições.** `你/他/明天/晚上/那个`; campos de moradia, disponibilidade e preferência.

**Observação pedagógica.** `呢` depende de tópico compartilhado. Não é um ponto de interrogação universal nem substitui `吗`.

**Potencial de mapa.** resposta → pessoa/tópico ativo → `呢` → continuação.

**Recuperação.** Dizer onde está e perguntar “e você?”.

**Transferência.** Devolver pergunta sobre disponibilidade, horário e preferência.

**Domínio.** Usar `呢` em quatro follow-ups sem abrir tópico sem antecedente.

## Q03 — Quem, o quê, qual e onde

**Intenção.** Obter informação específica sem inverter a oração.  
**Padrão.** `[sujeito] + [verbo] + 什么/谁/哪个/哪儿？`

**Exemplo-base.** `你要买哪个？` — *Nǐ yào mǎi nǎge?* — “Qual você quer comprar?” / `我要这个。` — *Wǒ yào zhège.* — “Quero este.”

**Substituições.** `看什么/找谁/住在哪儿/什么时候来`.

**Observação pedagógica.** A palavra interrogativa ocupa o slot desconhecido. `谁` pode ser sujeito; não inserir `你` automaticamente.

**Potencial de mapa.** informação desconhecida → posição natural → tipo de resposta.

**Recuperação.** Formular três perguntas e antecipar o tipo de resposta.

**Transferência.** Perguntar numa estação quem está com o amigo, onde está e o que quer.

**Domínio.** Seis perguntas com quatro interrogativos, sem `吗` indevido.

## Q04 — Quando e que horas

**Intenção.** Negociar momento amplo e hora precisa.  
**Padrão.** `什么时候 + predicado`; `几点 + verbo`; `[hora] 吧/可以吗`.

**Exemplo-base.** `我们几点见？` — *Wǒmen jǐ diǎn jiàn?* — “A que horas a gente se encontra?” / `六点吧。` — *Liù diǎn ba.* — “Às seis, pode ser?”

**Substituições.** Dias, períodos, horas, ações `见/吃饭/出发`.

**Observação pedagógica.** `什么时候` busca período/momento; `几点` busca hora no relógio. A sequência amplo → específico → proposta é o alvo.

**Potencial de mapa.** disponibilidade → período → hora → proposta/contraproposta.

**Recuperação.** Marcar encontro para estudar no fim de semana.

**Transferência.** Oferecer dois horários, recusar um e negociar outro.

**Domínio.** Completar três sequências distinguindo as duas perguntas.

## Q05 — Por quê e por causa de quê

**Intenção.** Pedir e oferecer justificativa curta.  
**Padrão.** `为什么 + predicado？`; `因为 + motivo`; opcional `因为……所以……`.

**Exemplo-base.** `你为什么学中文？` — *Nǐ wèishénme xué Zhōngwén?* — “Por que você estuda chinês?” / `因为我想聊天。` — *Yīnwèi wǒ xiǎng liáotiān.* — “Porque quero conversar.”

**Substituições.** Motivos `喜欢/工作需要/朋友在中国`; resultados e planos.

**Observação pedagógica.** Uma razão curta é suficiente no iniciante. O par completo `因为……所以……` entra quando a consequência precisa ficar explícita.

**Potencial de mapa.** decisão/ação → pergunta de causa → motivo → consequência.

**Recuperação.** Perguntar por que alguém não vai e responder com um motivo.

**Transferência.** Justificar duas escolhas próprias e perguntar a razão de outra pessoa.

**Domínio.** Produzir quatro pares pergunta–resposta com causas diferentes.

## Q06 — Como e instrução simples

**Intenção.** Perguntar modo, solução ou procedimento.  
**Padrão.** `怎么 + verbo？`; `请 + verbo`; resposta em sequência curta.

**Exemplo-base.** `去车站怎么走？` — *Qù chēzhàn zěnme zǒu?* — “Como se vai à estação?”

**Substituições.** `怎么去/怎么说/怎么用`; direções `先直走，再右转`.

**Observação pedagógica.** `怎么` ocupa o slot de modo; não deslocar para o início como no português. Instruções devem começar com dois passos, não um mapa completo.

**Potencial de mapa.** objetivo → modo → sequência de ações → confirmação.

**Recuperação.** Perguntar como chegar e como dizer uma palavra.

**Transferência.** Dar caminho simples a visitante e explicar como usar um objeto.

**Domínio.** Formular quatro perguntas e responder duas com sequência compreensível.

## Q07 — Perguntas com modal e A-não-A

**Intenção.** Pedir permissão, verificar capacidade e obter decisão.  
**Padrão.** `可以……吗？`; `能不能……？`; `会不会……？`

**Exemplo-base.** `你能不能明天来？` — *Nǐ néng bu néng míngtiān lái?* — “Você consegue vir amanhã ou não?”

**Substituições.** `帮我/再说一遍/用这个`; habilidade `会不会做饭`.

**Observação pedagógica.** O formato da pergunta também comunica a ação: `可以吗` pede autorização/aceitação; A-não-A força resposta binária. Não empilhar `吗` depois de A-não-A.

**Potencial de mapa.** intenção → modal → tipo de pergunta → resposta por eco.

**Recuperação.** Produzir três perguntas com permissão, capacidade e habilidade.

**Transferência.** Negociar a realização de uma tarefa com colega.

**Domínio.** Escolher o molde correto em seis prompts e responder sem ambiguidade.

## Q08 — Reparo e confirmação do sentido

**Intenção.** Passar de “não entendi” para hipótese verificável.  
**Padrão.** `你的意思是 + hipótese + 吗？`; `你是说 + hipótese + 吗？`

**Exemplo-base.** `你的意思是明天见吗？` — *Nǐ de yìsi shì míngtiān jiàn ma?* — “Você quer dizer que nos encontramos amanhã?”

**Substituições.** Hipótese sobre horário, posse, lugar ou ação; final `吗/对吗`.

**Observação pedagógica.** A confirmação deve resumir, não repetir tudo. Se a hipótese estiver errada, reformular e continuar.

**Potencial de mapa.** falha → hipótese → checagem → correção → prosseguimento.

**Recuperação.** Confirmar um horário e a posse de um objeto.

**Transferência.** Confirmar uma instrução numa chamada e corrigir a hipótese após resposta negativa.

**Domínio.** Produzir três confirmações com conteúdo novo e duas reformulações.

---

# 9. Categoria VIII — Sobrevivência social

Sobrevivência social é a capacidade de continuar, reduzir imposição, manter o turno e encerrar com clareza. Não é um inventário de fórmulas cerimoniosas.

## S01 — Nomear a falha

**Intenção.** Dizer se não ouviu, não entendeu ou não compreendeu o sentido.  
**Padrão.** `我没听清楚`; `我没听懂`; `我不明白 + conteúdo`.

**Exemplo-base.** `我没听清楚最后一句。` — *Wǒ méi tīng qīngchu zuìhòu yí jù.* — “Não ouvi claramente a última frase.”

**Substituições.** `这个词/这个意思/最后一句`; `没听懂/不明白`.

**Observação pedagógica.** O diagnóstico reduz repetição inútil e mostra controle da interação.

**Potencial de mapa.** som → compreensão auditiva → sentido → reparo.

**Recuperação.** Escolher a forma para ruído, fala rápida e conceito desconhecido.

**Transferência.** Fazer isso numa aula, videochamada e conversa informal.

**Domínio.** Escolher corretamente em quatro de cinco tentativas e seguir para um pedido.

## S02 — Pedir repetição

**Intenção.** Solicitar a fala inteira de forma clara e socialmente aceitável.  
**Padrão.** `不好意思，您/你能再说一遍吗？`; `请再说一遍`.

**Exemplo-base.** `不好意思，您能再说一遍吗？` — *Bù hǎoyìsi, nín néng zài shuō yí biàn ma?* — “Desculpe, o senhor/a senhora poderia repetir?”

**Substituições.** `你/您`; `再说一遍/再讲一遍`; abertura `不好意思` opcional.

**Observação pedagógica.** Automatizar primeiro `再说一遍`; depois regular registro e polidez. `您` é respeitoso, não obrigatório com toda pessoa desconhecida.

**Potencial de mapa.** falha → abertura → interlocutor → `能` → repetição.

**Recuperação.** Produzir versão curta e versão mais polida.

**Transferência.** Pedir repetição a amigo e professor, mudando somente o tratamento.

**Domínio.** Iniciar o reparo em menos de três segundos em quatro de cinco tentativas.

## S03 — Pedir velocidade, volume ou clareza

**Intenção.** Ajustar a entrega da mensagem.  
**Padrão.** `请说慢/大声/清楚一点`; `能不能说慢一点，再说一遍？`

**Exemplo-base.** `可以说慢一点吗？` — *Kěyǐ shuō màn yìdiǎn ma?* — “Pode falar um pouco mais devagar?”

**Substituições.** `慢/大声/清楚`; `一点/再...一点`.

**Observação pedagógica.** Diagnosticar antes: velocidade, volume ou sentido. `一点` reduz a imposição e não é uma tradução obrigatória de “um pouco” em qualquer contexto.

**Potencial de mapa.** problema auditivo → ajuste específico → nova tentativa.

**Recuperação.** Responder a três cenários com pedidos diferentes.

**Transferência.** Usar velocidade em chamada e volume em ambiente barulhento.

**Domínio.** Distinguir cinco situações e combinar ajuste com repetição em duas.

## S04 — Isolar palavra ou trecho

**Intenção.** Pedir significado ou formulação de um item sem repetir tudo.  
**Padrão.** `[item] 是什么意思？`; `这个词怎么说？`

**Exemplo-base.** `这个词是什么意思？` — *Zhège cí shì shénme yìsi?* — “O que significa esta palavra?”

**Substituições.** `最后那个词/这句话/这个名字`; `怎么说` para formulação.

**Observação pedagógica.** Diferenciar significado de pronúncia/formulação. Entonação ríspida pode soar como cobrança; abrir com `不好意思` quando necessário.

**Potencial de mapa.** dúvida ampla → item localizado → significado ou forma → retomada.

**Recuperação.** Perguntar pelo último termo e por como se diz uma palavra.

**Transferência.** Usar a distinção numa aula e num atendimento.

**Domínio.** Produzir duas perguntas com slots distintos e não pedir repetição automática.

## S05 — Confirmar hipótese

**Intenção.** Verificar sentido e permitir correção.  
**Padrão.** `你的意思是 + hipótese + 吗？`; `所以...对吗？`

**Exemplo-base.** `你是说这个吗？` — *Nǐ shì shuō zhège ma?* — “Você está falando deste aqui?”

**Substituições.** Horário, objeto, lugar ou consequência; `吗/对吗`.

**Observação pedagógica.** A hipótese deve ser curta e revisável. Confirmar é uma habilidade intermediária de continuidade.

**Potencial de mapa.** hipótese → confirmação → aceitar/corrigir → próximo passo.

**Recuperação.** Confirmar um horário ouvido e uma propriedade de objeto.

**Transferência.** Fazer uma hipótese deliberadamente errada e corrigir após um “não”.

**Domínio.** Produzir três confirmações e reformular duas vezes.

## S06 — Cortesia de contato, pedido e desculpa

**Intenção.** Abrir uma interrupção, reduzir imposição ou reconhecer um incômodo.  
**Padrão.** `不好意思/请问`; `麻烦你 + ação`; `对不起/抱歉`.

**Exemplo-base.** `不好意思，请问洗手间在哪儿？` — *Bù hǎoyìsi, qǐngwèn xǐshǒujiān zài nǎr?* — “Com licença, onde fica o banheiro?”

**Substituições.** `麻烦你帮我一下`; `对不起`; tratamento `你/您`.

**Observação pedagógica.** `不好意思` cobre interrupção ou constrangimento leve; `对不起/抱歉` pode reconhecer dano ou desculpa mais explícita. Registro depende da situação.

**Potencial de mapa.** ação social → grau de imposição → abertura adequada → pedido.

**Recuperação.** Abrir uma pergunta, pedir ajuda e desculpar-se por atraso.

**Transferência.** Usar formas diferentes com amigo, atendente e professor.

**Domínio.** Escolher a abertura em seis cenários sem empilhar fórmulas.

## S07 — Agradecer e responder

**Intenção.** Fechar um favor ou reconhecer ajuda sem confundir com desculpa.  
**Padrão.** `谢谢`; `谢谢你的帮助`; resposta `不客气/没事儿` conforme contexto.

**Exemplo-base.** `谢谢你的帮助。` — *Xièxie nǐ de bāngzhù.* — “Obrigado(a) pela sua ajuda.”

**Substituições.** `谢谢你/谢谢老师`; resposta `不客气/没关系/没事儿`.

**Observação pedagógica.** `不客气` responde agradecimento; `没关系` e `没事儿` respondem desculpa ou minimizam problema. A distinção social vale mais que decorar sinônimos.

**Potencial de mapa.** favor → agradecimento → resposta de cortesia → continuação/encerramento.

**Recuperação.** Agradecer e escolher a resposta a um pedido de desculpa.

**Transferência.** Encerrar uma ajuda presencial e uma troca de mensagens.

**Domínio.** Completar quatro pares sociais sem trocar a resposta de função.

## S08 — Manter e encerrar o canal

**Intenção.** Sustentar o turno, ganhar tempo e anunciar saída ou próximo contato.  
**Padrão.** `你呢/然后呢/你继续说`; `让我想想`; `我先走了，下次聊`; `我挂了啊`.

**Exemplo-base.** `我先走了，下次再聊。` — *Wǒ xiān zǒu le, xià cì zài liáo.* — “Vou indo; a gente conversa na próxima.”

**Substituições.** `明天见/再联系/晚安`; canal `我先忙了/我挂了啊`.

**Observação pedagógica.** Encerrar explicitamente evita parecer que a conversa caiu. `啊` e `吧` dependem de entoação e relação; ensinar primeiro fórmulas centrais.

**Potencial de mapa.** manutenção do turno → anúncio de saída → vínculo futuro → despedida.

**Recuperação.** Ganhar tempo, devolver pergunta e anunciar saída.

**Transferência.** Fechar conversa presencial, ligação e mensagem sem copiar a mesma despedida.

**Domínio.** Completar três encerramentos claros e escolher canal/registro adequado.

---

# 10. Categoria IX — Partículas funcionais

Partículas são ensinadas por operação comunicativa e posição. `地`, `嘛`, `呗` e empilhamentos ficam em reconhecimento ou revisão avançada até que o aluno domine o núcleo.

## P01 — 吗 para pergunta polar

**Intenção.** Transformar afirmação em verificação de sim/não.  
**Padrão.** `[afirmação] + 吗？`

**Exemplo-base.** `你现在有空吗？` — *Nǐ xiànzài yǒu kòng ma?* — “Você está livre agora?”

**Substituições.** Predicados de gosto, identidade, localização e plano.

**Observação pedagógica.** `吗` não entra com interrogativo ou A-não-A. A resposta retoma o predicado.

**Potencial de mapa.** afirmação → `吗` → resposta polar por eco.

**Recuperação.** Criar quatro perguntas a partir de afirmações.

**Transferência.** Confirmar disponibilidade e propriedade de objetos.

**Domínio.** Usar `吗` em cinco perguntas sem aplicação indevida.

## P02 — 呢 para devolução e tópico

**Intenção.** Retomar pessoa ou tópico ativo e manter a conversa.  
**Padrão.** `[resposta]. 你呢？`; `[tópico] 呢？`

**Exemplo-base.** `我喜欢茶，你呢？` — *Wǒ xǐhuan chá, nǐ ne?* — “Eu gosto de chá; e você?”

**Substituições.** Pessoa, dia, item ou plano já mencionado.

**Observação pedagógica.** Não usar `呢` como pergunta solta sem tópico em repertório inicial.

**Potencial de mapa.** resposta → tópico compartilhado → `呢` → continuidade.

**Recuperação.** Devolver pergunta sobre bebida, lugar e horário.

**Transferência.** Alternar pessoa e tópico em quatro situações.

**Domínio.** Quatro usos apropriados e nenhum `吗` duplicado.

## P03 — 吧 para proposta e suavização

**Intenção.** Propor, sugerir ou marcar conclusão cautelosa.  
**Padrão.** `[proposta] + 吧`; `[horário] + 吧`.

**Exemplo-base.** `我们六点见吧。` — *Wǒmen liù diǎn jiàn ba.* — “Vamos nos encontrar às seis, pode ser?”

**Substituições.** Horário, ação, sugestão de plano; `好吧` em aceitação resignada, apenas depois.

**Observação pedagógica.** `吧` suaviza; não é sinônimo de “sim” nem marcador obrigatório de todo convite.

**Potencial de mapa.** plano → proposta → espaço para aceitação/negociação.

**Recuperação.** Propor horário e atividade com `吧`.

**Transferência.** Negociar um horário e aceitar uma sugestão.

**Domínio.** Produzir quatro propostas sem transformar `吧` em pergunta polar automática.

## P04 — 啊 em reação e envolvimento

**Intenção.** Mostrar reação, envolvimento ou confirmação informal.  
**Padrão.** `enunciado + 啊` em contexto oral apropriado.

**Exemplo-base.** `原来是你啊！` — *Yuánlái shì nǐ a!* — “Ah, então era você!”

**Substituições.** Reações `好啊/对啊/这样啊`; interlocutor e contexto.

**Observação pedagógica.** A partícula depende fortemente de entoação e relação. Entra depois de `吗/呢/吧` e não deve ser usada para compensar falta de prosódia.

**Potencial de mapa.** informação → reação → partícula de envolvimento → resposta.

**Recuperação.** Produzir uma reação de surpresa e uma concordância informal.

**Transferência.** Reagir a uma descoberta numa conversa curta.

**Domínio.** Usar `啊` em três situações sem alterar o conteúdo proposicional.

## P05 — 了 em conclusão e mudança

**Intenção.** Apresentar uma ação como concluída ou uma situação como mudada.  
**Padrão.** `verbo + 了`; `situação + 了`.

**Exemplo-base.** `我吃完了。` — *Wǒ chī wán le.* — “Terminei de comer.”

**Substituições.** `到了/下雨了/天黑了`; `看完了/写好了/听懂了`.

**Observação pedagógica.** Diagnosticar “o que foi feito dentro do quadro?” versus “o que mudou agora?”. Não apresentar `了` como passado universal.

**Potencial de mapa.** evento → limite ou mudança → consequência atual.

**Recuperação.** Dizer que terminou, que entendeu e que começou a chover.

**Transferência.** Atualizar uma pessoa sobre uma tarefa e sobre o clima.

**Domínio.** Produzir quatro usos e escolher entre `了`, `过` e ausência de partícula.

## P06 — 过 em experiência

**Intenção.** Relatar se já teve uma experiência.  
**Padrão.** `verbo + 过`; negativo `没 + verbo + 过`.

**Exemplo-base.** `你去过中国吗？` — *Nǐ qù guo Zhōngguó ma?* — “Você já foi à China?”

**Substituições.** `看过/吃过/学过/用过`; lugares e objetos.

**Observação pedagógica.** `过` enquadra experiência anterior, não conclusão específica nem estado atual.

**Potencial de mapa.** experiência disponível → pergunta/afirmação → negação com `没`.

**Recuperação.** Perguntar se alguém já visitou um lugar e responder que nunca.

**Transferência.** Trocar viagem por comida, curso e ferramenta.

**Domínio.** Produzir quatro experiências e duas negativas sem usar `了` como substituto.

## P07 — 着 em estado de fundo

**Intenção.** Descrever estado mantido ou ação de fundo.  
**Padrão.** `V + 着`; introduzir com objetos e imagens concretas.

**Exemplo-base.** `门开着。` — *Mén kāizhe.* — “A porta está aberta.”

**Substituições.** `灯亮着/他站着/窗户关着`.

**Observação pedagógica.** `着` não é “estar fazendo” em geral e não substitui `在` progressivo. Priorizar estado visível antes de narrativas complexas.

**Potencial de mapa.** objeto → estado mantido → evento principal opcional.

**Recuperação.** Descrever duas portas/luzes em estados diferentes.

**Transferência.** Relatar estado de uma sala e o que alguém faz ao mesmo tempo.

**Domínio.** Produzir três estados e distinguir `着` de `在` e `了`.

## P08 — 的, 得 e 地

**Intenção.** Separar relação nominal, avaliação de verbo e modo da ação.  
**Padrão.** `descritor + 的 + nome`; `verbo + 得 + avaliação`; `地 + modo + verbo` apenas em extensão.

**Exemplo-base.** `他跑得很快。` — *Tā pǎo de hěn kuài.* — “Ele corre muito rápido.”

**Substituições.** `我的书`; `说得很清楚/做得很好`; `认真地学习` em revisão.

**Observação pedagógica.** Para o nível inicial, estabilizar `的` e `得` antes de exigir `地`. A mesma romanização `de` não implica a mesma função.

**Potencial de mapa.** nome → relação; verbo → avaliação; modo → verbo; três posições contrastivas.

**Recuperação.** Produzir “meu livro” e “fala claramente”.

**Transferência.** Descrever posse e avaliar duas ações numa tarefa.

**Domínio.** Distinguir `的` e `得` em seis itens; reconhecer `地` sem depender de produção.

### Filtro de partículas

`地`, `嘛`, `呗`, partículas finais empilhadas e usos regionais ficam em revisão avançada ou reconhecimento. Só entram em produção quando o aluno já sustenta intenção, tom, registro e contexto com as partículas centrais.

---

# 11. Categoria X — Conteúdo cumulativo

A progressão reúne as categorias numa sequência de 14 aulas. Cada aula combina conteúdo novo com pelo menos duas células antigas; os quatro mapas de consolidação exigem transferência para situação nova.

## Aulas 1–4 — Entrar, identificar, reparar e localizar

**Aula 1 — Contato, nome, origem e idioma.** `你好，我叫安娜。我是巴西人，我说葡萄牙语。` — *Nǐ hǎo, wǒ jiào Ānnà. Wǒ shì Bāxī rén, wǒ shuō Pútáoyáyǔ.* — “Olá, eu me chamo Ana. Sou brasileira e falo português.” Substituir nome, país e idioma; observar `是 × 说`; mapa pessoa → nome → origem → idioma → `你呢`; recuperar sem pinyin; transferir para interlocutor novo; domínio = duas apresentações completas e pergunta de volta.

**Aula 2 — Identificar, confirmar e reparar.** `这是什么？这是我的手机。` — *Zhè shì shénme? Zhè shì wǒ de shǒujī.* — “O que é isto? Este é o meu celular.” Substituir `这/那`, objetos e possuidores; observar `是 × 在`, `的`, `吗`, `没听懂`; transferir para loja; domínio = confirmar/recusar posse e pedir repetição.

**Aula 3 — Querer, pedir e recusar.** `我想喝水，请给我一杯茶。` — *Wǒ xiǎng hē shuǐ, qǐng gěi wǒ yì bēi chá.* — “Quero beber água; por favor, me dê uma xícara de chá.” Substituir ação, item e classificador; observar `想 × 要`, `不 × 没`, sandhi de `一`; transferir para casa/loja; domínio = cinco pedidos novos.

**Aula 4 — Localizar pessoa e objeto.** `洗手间在哪儿？手机在包里。` — *Xǐshǒujiān zài nǎr? Shǒujī zài bāo lǐ.* — “Onde fica o banheiro? O celular está na bolsa.” Substituir alvo e lugar; observar `在 × 有`; transferir para sala real; domínio = três localizações sem apontar.

**Mapa de consolidação 1.** `你好，我叫安娜。请问，洗手间在哪儿？` — *Nǐ hǎo, wǒ jiào Ānnà. Qǐngwèn, xǐshǒujiān zài nǎr?* — “Olá, eu me chamo Ana. Com licença, onde fica o banheiro?” Recuperar antes do mapa, trocar identidade e lugar e transferir para atendimento; domínio = combinar quatro funções.

## Aulas 5–8 — Pedir, combinar, escolher e descrever rotina

**Aula 5 — Tempo e encontro.** `你什么时候有空？我们六点见吧。` — *Nǐ shénme shíhou yǒu kòng? Wǒmen liù diǎn jiàn ba.* — “Quando você está livre? Vamos nos encontrar às seis, pode ser?” Substituir dia, hora e ação; observar `什么时候 × 几点`, `吧`; domínio = amplo → específico → proposta.

**Aula 6 — Capacidade e permissão.** `我会说一点中文，但是今天不能来。` — *Wǒ huì shuō yìdiǎn Zhōngwén, dànshì jīntiān bù néng lái.* — “Sei falar um pouco de chinês, mas hoje não consigo ir.” Substituir habilidade e condição; observar `会 × 能 × 可以`; transferir para trabalho; domínio = seis escolhas modais.

**Aula 7 — Preferência e alternativa.** `你想喝茶还是咖啡？` — *Nǐ xiǎng hē chá háishi kāfēi?* — “Você quer chá ou café?” Substituir opções e justificar; observar `还是 × 或者`; transferir para comida, transporte e horário; domínio = quatro perguntas e duas afirmações.

**Aula 8 — Rotina.** `我每天早上在家学习。` — *Wǒ měitiān zǎoshang zài jiā xuéxí.* — “Toda manhã estudo em casa.” Substituir frequência, tempo, lugar e ação; observar ordem S–tempo–lugar–V–O; domínio = cinco frases e uma pergunta.

**Mapa de consolidação 2.** `我星期六下午有空，我们先吃饭，再看电影。` — *Wǒ xīngqīliù xiàwǔ yǒu kòng, wǒmen xiān chīfàn, zài kàn diànyǐng.* — “Estou livre sábado à tarde; primeiro comemos, depois vemos um filme.” Observar `先……再……` e `再 × 在`; transferir para um plano real; domínio = combinar disponibilidade, sequência e preferência.

## Aulas 9–11 — Agora, antes, depois e por quê

**Aula 9 — Ação em andamento.** `我正在写邮件。` — *Wǒ zhèngzài xiě yóujiàn.* — “Estou escrevendo um e-mail.” Substituir ação e objeto; observar progressivo × localização; domínio = três ações em curso.

**Aula 10 — Concluído, ainda não e experiência.** `我看过这部电影，但是还没看完这本书。` — *Wǒ kàn guo zhè bù diànyǐng, dànshì hái méi kàn wán zhè běn shū.* — “Já vi esse filme, mas ainda não terminei este livro.” Observar `了 × 过 × 没`; transferir para relatório; domínio = oito decisões de aspecto.

**Aula 11 — Sequência e razão.** `因为明天早起，所以我想早点回家。` — *Yīnwèi míngtiān zǎoqǐ, suǒyǐ wǒ xiǎng zǎodiǎn huí jiā.* — “Como vou acordar cedo amanhã, quero voltar mais cedo.” Substituir causa e consequência; domínio = três razões e três sequências.

**Mapa de consolidação 3.** `我正在学习，因为下周有考试，所以今天不出去。` — *Wǒ zhèngzài xuéxí, yīnwèi xià zhōu yǒu kǎoshì, suǒyǐ jīntiān bù chūqù.* — “Estou estudando; como tenho prova na semana que vem, hoje não vou sair.” Integrar progressivo, causa e negação em rotina nova.

## Aulas 12–14 — Chegar, convidar, justificar e fechar

**Aula 12 — Caminho simples.** `先直走，再右转。` — *Xiān zhí zǒu, zài yòu zhuǎn.* — “Siga reto primeiro e depois vire à direita.” Substituir direções; observar `再`; transferir para orientar visitante; domínio = dois passos compreensíveis.

**Aula 13 — Convite e remarcação.** `周六要不要一起吃饭？` — *Zhōuliù yào bu yào yìqǐ chīfàn?* — “Quer jantar junto no sábado?” Substituir atividade e horário; responder `好啊`, `今天不行`, `明天怎么样`; observar convite × pedido; domínio = três sequências sociais.

**Aula 14 — Opinião, razão e plano.** `我觉得坐地铁比较方便，因为不堵车。` — *Wǒ juéde zuò dìtiě bǐjiào fāngbiàn, yīnwèi bù dǔchē.* — “Acho que ir de metrô é mais prático porque não fica preso no trânsito.” Substituir opção e motivo; observar comparação; domínio = opinião + razão + decisão.

**Mapa de consolidação 4.** `不好意思，六点不行。七点可以吗？那我们先吃饭，再去看电影。` — *Bù hǎoyìsi, liù diǎn bù xíng. Qī diǎn kěyǐ ma? Nà wǒmen xiān chīfàn, zài qù kàn diànyǐng.* — “Desculpe, seis não dá. Sete pode? Então primeiro jantamos e depois vamos ver um filme.” Recuperar sem mapa e negociar horários/ações; domínio = negociar, combinar e encerrar.

### Protocolo cumulativo de revisão

Revisar no mesmo dia, no dia seguinte, três a sete dias depois e em consolidação posterior. Cada revisão muda ao menos um slot, perspectiva ou contexto. O registro mínimo marca **compreensão da intenção**, **recuperação oral**, **pronúncia funcional** e **transferência**. Se falhar em duas dimensões, a célula volta à orientação; reconhecimento visual isolado não aprova domínio.

### Mapa mestre

`áudio → antecipação → recuperação → mapa completo → mapa lacunado → substituição → extensão → combinação → transferência → independência`.

---

# 12. Filtros editoriais e controle de qualidade

Foram retidos itens com retorno oral alto, recombinação e critério observável. Foram fundidos itens repetidos entre relatórios e rebaixados listas passivas, classificadores extensos, partículas pouco produtivas para a primeira faixa e explicações sem consequência de produção. O conteúdo não reproduz material proprietário; as frases são autorais e as fontes são públicas.

Antes da publicação, realizar revisão independente por professor/falante de mandarim, checagem de pinyin e sandhi, teste com gravações de brasileiros, teste de densidade visual e auditoria de registro. Confirmar que cada célula contém exemplo, substituições, observação pedagógica, potencial de mapa, recuperação, transferência e domínio.

> **Critério final:** compreender a intenção, recuperar o padrão, pronunciar funcionalmente no ponto treinado e transferir para uma situação não ensaiada. O mapa torna a estrutura visível; a recuperação torna a estrutura disponível; a transferência prova que ela foi aprendida.

---

# Referências

[1]: https://resources.allsetlearning.com/chinese/grammar/Basic_sentence_structure "Chinese Grammar Wiki — Basic sentence structure"
[2]: https://resources.allsetlearning.com/chinese/grammar/Particle "Chinese Grammar Wiki — Particle"
[3]: https://resources.allsetlearning.com/chinese/grammar/Yes-no_questions_with_%22ma%22 "Chinese Grammar Wiki — Yes-no questions with ma"
[4]: https://resources.allsetlearning.com/chinese/grammar/Affirmative-negative_question "Chinese Grammar Wiki — Affirmative-negative questions"
[5]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22hui,%22_%22neng,%22_%22keyi%22 "Chinese Grammar Wiki — Comparing 会, 能, 可以"
[6]: https://resources.allsetlearning.com/chinese/grammar/Comparing_%22haishi%22_and_%22huozhe%22 "Chinese Grammar Wiki — Comparing 还是 and 或者"
[7]: https://resources.allsetlearning.com/chinese/grammar/Change_of_state_with_%22le%22 "Chinese Grammar Wiki — Change of state with le"
[8]: https://resources.allsetlearning.com/chinese/grammar/Expressing_experiences_with_%22guo%22 "Chinese Grammar Wiki — Expressing experiences with guo"
[9]: https://resources.allsetlearning.com/chinese/grammar/Tone_change_rules "Chinese Pronunciation Wiki — Tone change rules"
[10]: https://resources.allsetlearning.com/chinese/pronunciation/Neutral_tone "Chinese Pronunciation Wiki — Neutral tone"
[11]: https://resources.allsetlearning.com/chinese/pronunciation/The_%22j%22_%22q%22_and_%22x%22_sounds "Chinese Pronunciation Wiki — The j, q and x sounds"
[12]: https://resources.allsetlearning.com/chinese/grammar/Directional_verbs_%22lai%22_and_%22qu%22 "Chinese Grammar Wiki — Directional verbs 来 and 去"
[13]: https://resources.allsetlearning.com/chinese/grammar/Potential_complement "Chinese Grammar Wiki — Potential complement"
[14]: https://resources.allsetlearning.com/chinese/grammar/Using_%22ba%22_sentences "Chinese Grammar Wiki — Using 把 sentences"
[15]: https://resources.allsetlearning.com/chinese/grammar/Sequencing_with_%22xian%22_and_%22zai%22 "Chinese Grammar Wiki — Sequencing with 先 and 再"
[16]: https://resources.allsetlearning.com/chinese/grammar/Structural_particle_%22de%22 "Chinese Grammar Wiki — Structural particle de"
[17]: https://resources.allsetlearning.com/chinese/grammar/Expressing_permission_with_%22keyi%22 "Chinese Grammar Wiki — Expressing permission with keyi"
[18]: https://www.actfl.org/proficiency-guidelines-overview "ACTFL Proficiency Guidelines Overview"
[19]: https://rm.coe.int/common-european-framework-of-reference-for-languages-learning-teaching/16809ea0d4 "Common European Framework of Reference for Languages: Companion Volume"
[20]: https://www.edresearch.edu.au/guides-resources/practice-guides/spacing-and-retrieval-practice-guide-full-publication "Australian Education Research Organisation — Spacing and retrieval practice guide"
[21]: https://pubmed.ncbi.nlm.nih.gov/38900767/ "Concept mapping: increased potential as a retrieval-based task"
[22]: https://www.pimsleur.com/the-pimsleur-method/ "Pimsleur — The Pimsleur Method"
[23]: https://www.chineseboost.com/grammar/ma-ne/ "Chinese Boost — 吗 and 呢"
[24]: https://elon.io/grammar/chinese-mandarin/pragmatics/apologizing-degrees "Elon.io — Apologizing in Mandarin"
[25]: https://www.varsitytutors.com/practice/subjects/conversational-mandarin/lessons/asking-for-repetition "Varsity Tutors — Asking for Repetition in Conversational Mandarin"
[26]: https://doi.org/10.1016/j.pragma.2017.06.013 "Inviting in Mandarin: Anticipating the likelihood of invitation success"
[27]: https://www.isca-archive.org/speechprosody_2020/xu20_speechprosody.pdf "Revisiting Neutral Tone in Mandarin Broadcast News Speech"
[28]: https://www.repository.cam.ac.uk/bitstreams/cd6d3251-33ee-4712-8daf-e44bb6fb8185/download "Neutral Tone in Mandarin: Representation and Interaction with Utterance-level Prosody"
[29]: https://www.teachingenglish.org.uk/professional-development/teachers/teaching-knowledge-database/t-w/tbl-task-based-learning "British Council — Task-based Learning"
[30]: https://www.chinesetest.cn/hsk "Chinese Tests Service Website — HSK and New HSK syllabus"
