# Banco pedagógico — Mandarim em Rede

Esta pasta reúne a base de conteúdo pedagógico criada para alimentar as aulas do projeto **Mandarim em Rede**.

O material foi organizado em dois níveis:

1. um documento editorial final, pronto para servir como fonte de produção;
2. relatórios especializados separados por categoria, para consulta, expansão e revisão.

O conteúdo é independente, não oficial e complementar ao estudo auditivo. Ele não reproduz diálogos, transcrições, roteiros, vozes ou áudios proprietários de terceiros.

## Estrutura da pasta

```text
banco-pedagogico/
├── README.md
├── 01-banco-pedagogico-final.md
├── 02-banco-pedagogico-rascunho.md
└── pesquisa/
    ├── 01-padroes.md
    ├── 02-funcoes.md
    ├── 03-vocabulario.md
    ├── 04-contrastes.md
    ├── 05-pronuncia.md
    ├── 06-variacoes.md
    ├── 07-qa.md
    ├── 08-sobrevivencia.md
    ├── 09-particulas.md
    └── 10-cumulativo.md
```

## Documento principal

### `01-banco-pedagogico-final.md`

É a versão editorial consolidada. Contém:

- fundamentos e limites do banco;
- definição da célula de transferência;
- estados progressivos de suporte;
- protocolo diário de uso;
- política de caracteres, pinyin e tradução;
- matriz de prioridade das primeiras dez aulas;
- banco de células e aulas;
- revisão cumulativa de 14 dias;
- critérios de domínio;
- ficha de registro e métricas;
- regras editoriais e checklist de qualidade;
- referências numeradas.

Este é o arquivo recomendado para orientar a produção das aulas e a futura diagramação.

## Documento de trabalho

### `02-banco-pedagogico-rascunho.md`

É o rascunho consolidado usado durante a revisão editorial. Deve ser preservado para rastreabilidade, mas não deve ser tratado como a fonte final quando houver divergência com o documento principal.

## Relatórios de pesquisa

| Arquivo | Conteúdo |
|---|---|
| [`01-padroes.md`](pesquisa/01-padroes.md) | Padrões de frase produtivos com slots, exemplos e tarefas orais. |
| [`02-funcoes.md`](pesquisa/02-funcoes.md) | Pedir, negar, confirmar, localizar, preferir, convidar e reparar. |
| [`03-vocabulario.md`](pesquisa/03-vocabulario.md) | Vocabulário organizado por contexto e função comunicativa. |
| [`04-contrastes.md`](pesquisa/04-contrastes.md) | Contrastes de alto risco para falantes de português brasileiro. |
| [`05-pronuncia.md`](pesquisa/05-pronuncia.md) | Tons, pinyin, escuta, articulação e interferências prováveis. |
| [`06-variacoes.md`](pesquisa/06-variacoes.md) | Substituição, extensão, combinação e transferência. |
| [`07-qa.md`](pesquisa/07-qa.md) | Perguntas, respostas, follow-ups e prompts de transferência. |
| [`08-sobrevivencia.md`](pesquisa/08-sobrevivencia.md) | Reparo, cortesia, manutenção e encerramento de interações. |
| [`09-particulas.md`](pesquisa/09-particulas.md) | Partículas explicadas por operação comunicativa. |
| [`10-cumulativo.md`](pesquisa/10-cumulativo.md) | Progressão cumulativa de 14 aulas e mapas de consolidação. |

## Ordem recomendada de uso

Para produzir uma nova aula, consulte primeiro o documento final. Em seguida, use o relatório de padrões ou funções correspondente. Consulte os relatórios de contrastes e pronúncia somente quando a célula exigir uma decisão específica. Termine verificando o relatório cumulativo para conectar a aula a conteúdos anteriores.

Cada célula produzida deve conter, quando aplicável:

- uma intenção comunicativa única;
- um padrão produtivo;
- componentes fixos e substituíveis;
- exemplos em caracteres simplificados;
- pinyin com tons ou indicação de tom neutro;
- tradução funcional em português brasileiro;
- uma observação de contraste ou pronúncia;
- um prompt de recuperação;
- um prompt de transferência;
- um critério de domínio.

## Prioridade das primeiras aulas

A sequência inicial recomendada é:

1. iniciar contato e dizer o nome;
2. identificar origem e idioma;
3. reparar falhas de compreensão;
4. identificar e confirmar posse;
5. expressar desejo e pedir itens;
6. localizar pessoas e objetos;
7. organizar horário e encontro;
8. indicar capacidade e preferência;
9. consolidar identidade, objetos e reparo;
10. consolidar uma situação cotidiana completa.

## Relação com os demais documentos do projeto

- [Análise de viabilidade](../analise-viabilidade-implementacao.md)
- [Estrutura da Aula-piloto 01](../aula-piloto-01-estrutura.md)
- [Roteiro de apresentação da Aula-piloto 01](../roteiro-apresentacao-aula-piloto-01.md)
- [PDF 01 — aulas](../mandarim-em-rede-pdf-01-aulas.md)
- [Plano de ação de 90 dias](../plano-acao-mandarim-em-rede-90-dias.md)
- [Auditoria de estresse](../mandarim-em-rede-auditoria-estresse.md)
- [Frame textual do sistema](../mandarim-em-rede-frame-textual.txt)

## Limites editoriais

O banco deve continuar sendo usado como camada de transferência oral. O áudio permanece como fonte primária de escuta e antecipação. Nenhum mapa deve entregar a resposta antes da tentativa. A leitura de pinyin não comprova nem corrige pronúncia sem áudio ou feedback adequado. O projeto não deve sugerir afiliação, endosso ou autorização da Pimsleur.

— **Manus AI**
