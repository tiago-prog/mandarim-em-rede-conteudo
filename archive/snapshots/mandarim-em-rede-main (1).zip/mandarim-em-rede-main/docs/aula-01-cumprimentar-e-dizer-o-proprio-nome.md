# Aula 1 — Cumprimentar e dizer o próprio nome

## Mandarim em Rede 01 — Fundamentos de Transferência Oral

> **Função da aula:** iniciar uma interação e identificar as pessoas envolvidas.
>
> **Sequência de uso:** ouvir → tentar responder → consultar o mapa → recombinar → transferir → produzir sem olhar.

Esta é a porta de entrada do sistema **Mandarim em Rede**. O objetivo não é decorar uma lista de frases. O objetivo é transformar uma pequena estrutura ouvida em uma resposta que o aluno consiga recuperar, modificar e usar em uma situação nova.

O áudio principal deve ser realizado sem acompanhar este material. O mapa e as explicações entram depois da primeira tentativa.

---

## 1. Objetivo de Fala

Ao final desta aula, o aluno deve conseguir realizar uma apresentação curta, sem ler a resposta, seguindo esta sequência:

1. cumprimentar uma pessoa;
2. perguntar o nome dela;
3. dizer o próprio nome;
4. devolver a pergunta com **你呢？**.

### Resultado mensurável

O aluno considera a aula concluída quando consegue realizar **duas trocas de quatro falas**, usando dois nomes diferentes e sem consultar o mapa completo:

```text
saudação → pergunta do nome → resposta → devolução da pergunta
```

A produção não precisa ser perfeita ou nativa. Ela precisa ser funcional, compreensível para a tarefa e realizada com apoio visual reduzido.

---

## 2. Mapa Mental Principal

### Tipo de mapa

**Mapa de intenção comunicativa.**

O centro do mapa não é uma palavra isolada nem uma regra gramatical. É uma ação:

> **[N] Iniciar uma interação e identificar as pessoas.**

### Núcleo do mapa

```text
[N] INICIAR UMA INTERAÇÃO
        │
        ├── cumprimentar
        ├── perguntar o nome
        ├── dizer o próprio nome
        └── devolver a pergunta
```

### Ramos principais

#### Ramo 1 — `[F]` Cumprimentar

```text
你好。
Nǐ hǎo.
Olá.
```

- **Função:** abrir a interação.
- **Componente:** estrutura fixa nesta aula.
- **Substituição:** não é necessário criar variações antes de a saudação-base estar estável.
- **Expansão posterior:** perguntar como a pessoa está será trabalhado como uma extensão, não como requisito desta aula.

#### Ramo 2 — `[F]` Perguntar o nome

```text
你叫什么名字？
Nǐ jiào shénme míngzi?
Qual é o seu nome?
```

- **Função:** identificar o nome do interlocutor.
- **Componentes principais:** `你` + `叫` + `什么` + `名字`.
- **Componente fixo nesta célula:** a sequência completa da pergunta.
- **Nota de uso:** o aluno deve recuperar a pergunta como um padrão do mandarim, e não montá-la seguindo palavra por palavra a ordem do português.

#### Ramo 3 — `[S]` Dizer o próprio nome

```text
我叫 + [nome]。
Wǒ jiào + [nome].
Eu me chamo + [nome].
```

- **Função:** informar o próprio nome.
- **Componentes fixos:** `我叫 Wǒ jiào`.
- **Componente substituível:** `[nome]`.
- **Regra de recombinação:** trocar o nome sem alterar o núcleo `我叫`.

#### Ramo 4 — `[O]` Devolver a pergunta

```text
你呢？
Nǐ ne?
E você?
```

- **Função:** devolver o foco ao interlocutor.
- **Componente:** expressão curta e estável.
- **Papel na interação:** transformar uma resposta isolada em troca conversacional.
- **Status:** extensão curta da célula principal; deve ser praticada depois de o aluno conseguir dizer o próprio nome.

#### Ramo 5 — `[A]` Foco auditivo

- `你 nǐ`: terceiro tom na forma lexical isolada.
- `好 hǎo`: terceiro tom na forma lexical.
- `叫 jiào`: quarto tom, curto e descendente.
- `什么 shénme`: a segunda sílaba de `什么` é geralmente átona ou neutra na fala corrente.
- `名字 míngzi`: a segunda sílaba de `名字` é geralmente neutra.
- `呢 ne`: partícula normalmente átona ou neutra.

#### Ramo 6 — `[X]` Contraste para o brasileiro

O português pode induzir o aluno a procurar uma correspondência literal para “Qual é o seu nome?”. Em mandarim, a pergunta deve ser recuperada como:

```text
你叫什么名字？
Nǐ jiào shénme míngzi?
```

A tarefa desta aula não é analisar a tradução palavra por palavra. É reconhecer a intenção e produzir o padrão funcional.

#### Ramo 7 — `[R]` Transferência

```text
Situação nova:
Você acaba de conhecer uma pessoa em uma sala on-line.
Cumprimente, pergunte o nome, diga o seu e devolva a pergunta.
```

O mapa está completo nesta seção para orientar o aluno depois da primeira tentativa. Na etapa de transferência, ele deve ser reduzido a uma situação e a poucos gatilhos.

### Representação resumida do mapa

```text
                         [N] INICIAR UMA INTERAÇÃO
                                      │
        ┌─────────────────────────────┼─────────────────────────────┐
        │                             │                             │
        ▼                             ▼                             ▼
 [F] CUMPRIMENTAR          [F] PERGUNTAR O NOME          [S] DIZER O NOME
        │                             │                             │
   你好 Nǐ hǎo.          你叫什么名字？               我叫 + [nome]
        │                   Nǐ jiào shénme             Wǒ jiào + [nome]
        │                      míngzi?
        └─────────────────────────────┼─────────────────────────────┘
                                      ▼
                           [O] DEVOLVER A PERGUNTA
                                      │
                                  你呢？
                                  Nǐ ne?
                                      │
                                      ▼
                           [R] PRODUZIR EM SITUAÇÃO NOVA
```

---

## 3. Padrões e Frases-Chave

### Legenda dos componentes

| Marca | Significado | Aplicação nesta aula |
|---|---|---|
| `[F]` | componente fixo | permanece estável durante a recombinação |
| `[S]` | slot substituível | recebe um valor diferente dentro do mesmo padrão |
| `[O]` | extensão opcional | amplia a interação depois que o núcleo está estável |
| `[A]` | alerta auditivo | indica o que deve ser ouvido ou produzido |
| `[R]` | recuperação ou transferência | exige produção antes da consulta |

### Padrão 1 — Cumprimentar

```text
[F] 你好。
    Nǐ hǎo.
    Olá.
```

- **Fixo:** `你好`.
- **Uso:** abrir uma interação de forma simples.
- **Produção:** dizer a expressão uma vez e aguardar a resposta do interlocutor.

### Padrão 2 — Perguntar o nome

```text
[F] 你叫什么名字？
    Nǐ jiào shénme míngzi?
    Qual é o seu nome?
```

- **Fixo nesta aula:** `你叫什么名字？`.
- **Uso:** perguntar o nome de uma pessoa.
- **Atenção:** não substituir a estrutura por uma tradução montada palavra por palavra.
- **Produção:** usar a pergunta depois da saudação.

### Padrão 3 — Dizer o próprio nome

```text
[F] 我叫 + [S] nome。
    Wǒ jiào + [S] nome.
    Eu me chamo + [nome].
```

#### Exemplos de recombinação

```text
我叫安娜。
Wǒ jiào Ānnà.
Eu me chamo Ana.
```

```text
我叫保罗。
Wǒ jiào Bǎoluó.
Eu me chamo Paulo.
```

- **Fixo:** `我叫 Wǒ jiào`.
- **Substituível:** o nome da pessoa que está falando.
- **Regra:** o aluno deve trocar o nome sem trocar o núcleo da estrutura.
- **Observação:** os nomes acima são apenas exemplos. O aluno pode usar o próprio nome ou outro nome indicado pelo exercício.

### Padrão 4 — Devolver a pergunta

```text
[O] 你呢？
    Nǐ ne?
    E você?
```

- **Extensão:** aparece depois de o aluno dizer o próprio nome.
- **Uso:** devolver a pergunta sem repetir a pergunta completa.
- **Produção:** dizer o nome e acrescentar `你呢？` para manter a troca.

### Mini-diálogo de referência

Este diálogo só deve ser consultado **depois da primeira tentativa**. Ele serve para mostrar a organização da troca, não para ser decorado como um roteiro único.

```text
A: 你好。
   Nǐ hǎo.
   Olá.

B: 你好。
   Nǐ hǎo.
   Olá.

A: 你叫什么名字？
   Nǐ jiào shénme míngzi?
   Qual é o seu nome?

B: 我叫安娜。你呢？
   Wǒ jiào Ānnà. Nǐ ne?
   Eu me chamo Ana. E você?
```

### Mapa fixo × substituível

| Parte da troca | Elemento fixo | Elemento substituível |
|---|---|---|
| Saudação | `你好` | — |
| Pergunta do nome | `你叫什么名字？` | — |
| Resposta | `我叫` | nome |
| Devolução | `你呢？` | — |

### Versão lacunada

Use esta versão para recuperação. O aluno deve falar antes de escrever ou conferir.

```text
1. Cumprimente:
   ________。

2. Pergunte o nome:
   你叫 ________ ________？

3. Diga o próprio nome:
   ________ 叫 + [nome]。

4. Devolva a pergunta:
   你 ________？
```

### Prompt mínimo de transferência

Depois da prática com o mapa lacunado, feche a página de respostas e use somente este prompt:

> Você conheceu uma pessoa nova em uma sala on-line. Cumprimente, pergunte o nome, diga que se chama **um nome diferente dos exemplos** e devolva a pergunta.

---

## 4. Vocabulário Funcional

O vocabulário desta aula deve permanecer limitado ao necessário para realizar a interação.

| Elemento | Pinyin | Função nesta aula |
|---|---|---|
| 你 | **nǐ** | você |
| 我 | **wǒ** | eu |
| 叫 | **jiào** | chamar-se; chamar |
| 什么 | **shénme** | o que; qual |
| 名字 | **míngzi** | nome |
| 呢 | **ne** | devolver o foco ou a pergunta ao interlocutor |

### O que não é necessário introduzir agora

Para evitar sobrecarga, esta aula não precisa ensinar ainda:

- uma lista de nomes chineses;
- países e nacionalidades;
- profissões;
- números;
- explicações extensas sobre partículas;
- caracteres adicionais fora das frases da aula;
- várias formas de perguntar o nome;
- uma conversa completa sobre como a pessoa está.

A expressão `你好吗？ Nǐ hǎo ma? — Tudo bem com você?` pode ser apresentada posteriormente como extensão. Ela não é necessária para dominar o núcleo desta aula.

---

## 5. Pontos Críticos de Pronúncia e Tons

### 5.1 `你好 — Nǐ hǎo`

As duas sílabas aparecem com terceiro tom na forma lexical: `nǐ hǎo`. Em fala conectada, a primeira sílaba costuma ser realizada com contorno de segundo tom, aproximando-se de `ní hǎo` na pronúncia efetiva.

O aluno deve:

- ouvir a expressão completa;
- imitar a sequência;
- evitar transformar a regra em uma fórmula mecânica;
- não pronunciar `nǐ` como se fosse simplesmente “ni” do português.

### 5.2 `叫 — jiào`

`叫 jiào` tem quarto tom, com queda curta e definida.

O aluno deve evitar:

- alongar a sílaba;
- transformá-la em uma pergunta por causa da entonação;
- produzir um som equivalente ao valor ortográfico de `j` em português.

O `j` do pinyin mandarim não deve ser lido automaticamente como o `j` de palavras portuguesas como “já” ou “jogo”. O áudio deve orientar a produção.

### 5.3 `什么 — shénme`

Em `什么 shénme`, a primeira sílaba recebe o segundo tom. A segunda sílaba é geralmente átona ou neutra na fala corrente.

O aluno deve evitar dar o mesmo peso às duas sílabas. A palavra deve ser aprendida dentro da pergunta completa, e não como uma sequência de tons isolados.

### 5.4 `名字 — míngzi`

Em `名字 míngzi`, `míng` recebe o segundo tom e `zi` costuma ser neutro.

O aluno deve evitar:

- pronunciar `zi` com a mesma força de `míng`;
- inserir uma vogal adicional depois de `z`;
- ler `zi` com o valor ortográfico de “zi” em português.

### 5.5 `你呢 — Nǐ ne`

Em `你呢？ Nǐ ne?`, `ne` normalmente é uma partícula átona. Ela não deve receber o mesmo peso de uma palavra lexical plena.

### 5.6 Regra de segurança pedagógica

O pinyin ajuda a visualizar o alvo, mas não comprova nem corrige a pronúncia sozinho. A avaliação de pronúncia funcional exige escuta, comparação com áudio, gravação própria, feedback humano ou ferramenta adequada.

> **Foco da aula:** produzir uma troca compreensível, não buscar uma pronúncia nativa por meio da leitura silenciosa.

---

## 6. Exercícios de Recombinação

Realize todos os exercícios oralmente. Primeiro tente responder. Só depois consulte uma forma de apoio.

### Exercício 1 — Núcleo fixo

Diga a estrutura de apresentação usando seu próprio nome:

```text
我叫 + seu nome。
Wǒ jiào + seu nome.
```

Repita duas vezes sem ler a frase completa.

### Exercício 2 — Troca de nome

Produza oralmente:

1. “Eu me chamo Ana.”
2. “Eu me chamo Paulo.”
3. “Eu me chamo [outro nome].”

O objetivo é manter `我叫` estável e trocar somente o nome.

### Exercício 3 — Perguntar e responder

Imagine que você encontrou três pessoas diferentes. Para cada uma:

1. cumprimente;
2. pergunte o nome;
3. responda usando um nome diferente;
4. devolva a pergunta.

Faça a sequência com:

- Ana;
- Paulo;
- um nome escolhido por você.

### Exercício 4 — Inverter os papéis

Agora imagine que outra pessoa iniciou a interação. Responda à saudação, escute a pergunta do nome e diga o seu.

Depois acrescente:

```text
你呢？
Nǐ ne?
E você?
```

O objetivo é responder sem depender da ordem visual da página.

### Exercício 5 — Dois contextos

Faça a mesma estrutura em dois contextos:

1. você conhece alguém presencialmente;
2. você entra em uma sala on-line.

A linguagem central permanece a mesma. O que muda é a situação imaginada.

### Exercício 6 — Produção com apoio reduzido

Use somente os gatilhos abaixo e produza a troca completa:

```text
cumprimentar → nome da outra pessoa → seu nome → devolver
```

Depois repita usando outro nome e sem consultar o mapa completo.

### Tabela de registro

| Tentativa | Usei nome diferente? | Consultei o mapa completo? | Precisei de pista? | Consegui devolver `你呢？`? |
|---:|---|---|---|---|
| 1 | Sim / Não | Sim / Não | Sim / Não | Sim / Não |
| 2 | Sim / Não | Sim / Não | Sim / Não | Sim / Não |
| 3 | Sim / Não | Sim / Não | Sim / Não | Sim / Não |

---

## 7. Tarefa de Produção Oral — sem olhar

### Auto-teste principal

Feche o mapa completo e deixe visível apenas esta instrução:

> Você acaba de conhecer uma pessoa em uma sala on-line. Realize uma troca curta em mandarim: cumprimente, pergunte o nome, diga o seu e devolva a pergunta. Use um nome que não apareceu nos exemplos.

### Procedimento

1. prepare-se em silêncio por até 20 segundos;
2. produza a primeira troca sem consultar o texto;
3. faça uma pausa;
4. repita a troca usando outro nome;
5. se possível, grave a segunda tentativa;
6. marque quais partes exigiram apoio;
7. compare seu desempenho com os critérios de domínio.

### Gatilhos permitidos

Se a tarefa estiver difícil, use apenas estes gatilhos, nesta ordem:

```text
saudação → pergunta do nome → [seu nome] → devolução
```

Não reabra o mapa completo antes de tentar novamente. Se ainda assim não conseguir, consulte apenas a parte que falhou e registre a célula como “em recuperação”.

### Critério da tarefa

A tarefa foi realizada quando o aluno consegue:

- iniciar a interação;
- recuperar a pergunta do nome;
- usar `我叫 + nome` com um nome diferente;
- devolver a pergunta;
- repetir a sequência com menos apoio na segunda tentativa.

---

## 8. Critério de Domínio

O aluno pode avançar quando cumprir todos os critérios essenciais abaixo.

### Compreensão

- reconhece que a aula serve para iniciar uma interação e identificar pessoas;
- entende a função de `你好`, `你叫什么名字？`, `我叫 + nome` e `你呢？` quando ouve ou vê o contexto.

### Recuperação

- tenta responder antes de consultar a solução;
- produz a pergunta do nome sem montar uma tradução palavra por palavra;
- diz o próprio nome usando `我叫`.

### Recombinação

- troca o nome sem alterar `我叫`;
- produz pelo menos três variações controladas;
- consegue realizar a troca com nomes diferentes.

### Pronúncia funcional

- produz `叫 jiào` com uma queda perceptível do quarto tom;
- evita dar peso excessivo às sílabas neutras de `什么 shénme`, `名字 míngzi` e `呢 ne`;
- realiza uma produção compreensível para a tarefa com apoio do áudio ou feedback disponível.

### Transferência

- realiza duas trocas de quatro falas;
- usa uma situação ou nome que não copia exatamente o exemplo;
- repete a tarefa com menos apoio visual.

### Ficha final de autoavaliação

Marque uma nota para cada dimensão:

| Dimensão | 0 — ainda não | 1 — com apoio | 2 — sem mapa completo |
|---|---:|---:|---:|
| Compreensão | ☐ | ☐ | ☐ |
| Recuperação | ☐ | ☐ | ☐ |
| Pronúncia funcional | ☐ | ☐ | ☐ |
| Transferência | ☐ | ☐ | ☐ |

O aluno não deve considerar a célula dominada apenas porque reconheceu a página ou acompanhou a leitura. Se a transferência estiver em 0, a célula retorna para uma versão mais controlada do prompt. Se a pronúncia estiver instável, o próximo passo é voltar ao áudio e buscar comparação ou feedback, não acrescentar mais explicação textual.

---

## 9. Conexões

Esta é a primeira porta de entrada do sistema **Mandarim em Rede**. Ela estabelece três fundamentos que reaparecerão em todas as aulas:

1. **Intenção antes da frase:** o aluno começa pela ação que deseja realizar.
2. **Padrão antes da lista:** o aluno aprende uma estrutura que pode receber substituições.
3. **Tentativa antes da consulta:** o mapa organiza depois que o aluno tenta recuperar.

### O que será expandido nas próximas aulas

#### Aula 2 — Origem e idioma

O aluno reaproveitará `我` e `你` para falar sobre país, nacionalidade e idioma. O padrão `我叫 + nome` será ampliado por novas estruturas com componentes substituíveis.

#### Aula 3 — Reparo da compreensão

O aluno aprenderá a dizer que entendeu, que não entendeu e que precisa de repetição. A interação iniciada nesta aula passará a incluir manutenção e reparo.

#### Aula 4 — Identificação e posse

O aluno usará a intenção de identificar pessoas e objetos para perguntar “o que é isto?” e confirmar relações de posse.

#### Consolidação 1

As quatro primeiras aulas serão combinadas em prompts que exigem apresentação, origem, idioma, identificação e reparo sem seguir um diálogo decorado.

### Conexão com o método

```text
Aula 1: iniciar a interação
        ↓
Aula 2: acrescentar identidade e origem
        ↓
Aula 3: manter a conversa quando houver falha
        ↓
Aula 4: identificar pessoas e objetos
        ↓
Consolidação: combinar células em situação nova
```

### Frase-âncora da aula

> **O mapa mostra como a interação se organiza. A recombinação mostra que o padrão pode mudar. A transferência mostra se o aluno consegue usá-lo fora do exemplo.**

---

## Quiz rápido de fechamento

Responda sem consultar as páginas anteriores.

### 1. Qual é a intenção central desta aula?

A. Descrever uma rotina diária.

B. Iniciar uma interação e identificar as pessoas.

C. Perguntar onde está um objeto.

D. Fazer um pedido em um restaurante.

### 2. Qual parte pode ser substituída em `我叫 + [nome]`?

A. `我`

B. `叫`

C. O nome

D. `你呢`

### 3. Qual expressão devolve a pergunta ao interlocutor?

A. `你好`

B. `你叫什么名字？`

C. `我叫`

D. `你呢？`

### 4. Em que momento o aluno deve consultar o mapa completo?

A. Antes de tentar responder.

B. Depois da primeira tentativa.

C. Durante cada frase do áudio.

D. Somente ao final do PDF.

### 5. Qual sequência representa a troca central?

A. pedido → recusa → localização → encerramento.

B. saudação → pergunta do nome → resposta → devolução da pergunta.

C. pergunta de preço → compra → agradecimento → despedida.

D. origem → horário → preferência → localização.

### Gabarito

| Questão | Resposta |
|---:|---|
| 1 | B |
| 2 | C |
| 3 | D |
| 4 | B |
| 5 | B |

O quiz verifica a compreensão da arquitetura da aula. A evidência principal de domínio continua sendo a produção oral sem o mapa completo.

---

## Encerramento

Nesta aula, você não precisa saber falar sobre todos os aspectos de uma apresentação. Você precisa dominar uma pequena operação e conseguir reutilizá-la:

```text
你好 → 你叫什么名字？ → 我叫 + [nome] → 你呢？
```

> **Ouça. Tente. Organize. Recombine. Transfira. Produza sem olhar.**

---

## Referências

[1]: ./mandarim-em-rede-pdf-01-aulas.md "Mandarim em Rede 01 — Fundamentos de Transferência Oral"

[2]: ./mandarim-em-rede-auditoria-estresse.md "Auditoria de estresse e reconstrução definitiva — Mandarim em Rede"

[3]: ./mandarim-em-rede-frame-textual.txt "Frame textual do sistema visual Mandarim em Rede"

[4]: ./aula-piloto-01-estrutura.md "Estrutura da Aula-piloto 01 — Mandarim em Rede"

[5]: ./roteiro-apresentacao-aula-piloto-01.md "Roteiro de apresentação da Aula-piloto 01 — Mandarim em Rede"

— **Manus AI**

2026-09-08
