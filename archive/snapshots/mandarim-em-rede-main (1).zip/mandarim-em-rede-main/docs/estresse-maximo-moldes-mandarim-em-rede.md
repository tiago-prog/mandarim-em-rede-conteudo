# Teste de estresse máximo — Moldes visuais do Mandarim em Rede

## Conclusão executiva

A ideia é viável, mas a referência ainda não deve ser tratada como um sistema visual pronto. Ela é uma coleção de páginas atraentes com três linguagens diferentes: ficha de escrita, apostila editorial ilustrada e apresentação conceitual. Se essas linguagens forem simplesmente copiadas, o resultado provavelmente será bonito, porém inconsistente, difícil de editar, caro de produzir e cognitivamente pesado.

A decisão mais segura é transformar a referência em um **sistema modular de produção**, não em uma sequência de imagens. O sistema deve separar fundo decorativo, componentes editoriais, conteúdo linguístico e funções de exercício. A imagem gerada por IA pode fornecer atmosfera, ornamentos e ilustrações. Ela não deve ser responsável por texto exato, pinyin, caracteres chineses, tabelas, grades, QR codes ou relações de um mapa mental.

O maior risco não é estético. É o produto parecer uma apostila convencional decorada, embora a proposta seja uma camada de transferência oral baseada em mapas. O teste de estresse, portanto, exige que cada elemento visual prove sua função: orientar, reduzir carga cognitiva, provocar recuperação ou organizar transferência.

---

## 1. O que está sendo estressado

O sistema proposto precisa funcionar sob seis condições simultâneas:

1. O criador deve conseguir preencher e adaptar os moldes sem reconstruir a página.
2. O aluno deve entender imediatamente onde olhar e o que fazer.
3. O exercício deve continuar legível em tela, impressão colorida e impressão em escala de cinza.
4. A identidade visual deve permanecer reconhecível em lições diferentes.
5. O material deve escalar para dezenas de páginas sem virar uma coleção artesanal impossível de manter.
6. A estética não pode contradizer a metodologia de produção oral, recuperação ativa e suporte progressivamente reduzido.

Uma solução que atende apenas à aparência não passa no teste. O produto precisa sobreviver ao uso real, à edição repetida, à impressão e à expansão.

---

## 2. Diagnóstico da referência

### 2.1 Pontos fortes

A referência oferece uma direção de marca clara. O azul-marinho cria estabilidade e contraste. O creme proporciona uma superfície de leitura confortável. O dourado e o vermelho coral remetem à estética chinesa sem depender de realismo fotográfico. As montanhas, a névoa e as nuvens criam continuidade entre páginas de funções diferentes.

A referência também entende a importância de hierarquia. Há títulos fortes, seções numeradas, caixas de destaque, ícones e rodapés. O aluno consegue reconhecer que se trata de um material didático premium, não de uma folha improvisada.

A combinação de página funcional e página conceitual é útil. A ficha de escrita prova que o sistema consegue ser prático. O mapa mental prova que a marca consegue organizar informação. A aula-piloto prova que existe uma camada metodológica além do vocabulário.

### 2.2 Fragilidades

A referência mistura pelo menos quatro níveis de acabamento: uma ficha simples, uma página de lição com personagem, uma capa ilustrada e uma página de mapa radial. Sem regras, isso cria uma coleção visualmente fragmentada.

Algumas páginas possuem densidade alta demais para um produto cujo diferencial é clareza estrutural. Uma página com vocabulário, frases, diálogo, pronúncia, exercícios e revisão pode parecer completa, mas força o aluno a alternar muitas operações cognitivas sem indicação clara de sequência.

O uso de ilustrações temáticas, como panda, restaurante, lanternas e ambientes, pode transformar o produto em um conjunto de cenas decorativas. Isso é aceitável para abertura de módulo, mas prejudica páginas de recuperação se a imagem competir com o prompt ou com a área de resposta.

O mapa mental radial é visualmente impactante, mas pode ser inadequado para preencher com muitos itens. Sete ramos com três subitens cada já produzem aproximadamente 21 unidades de leitura. Em uma página A4, isso se aproxima de um pôster de visão geral, não de um exercício de recuperação.

---

## 3. Teste de estresse por dimensão

### 3.1 Estresse de editabilidade

**Pergunta:** o criador consegue substituir título, caracteres, pinyin, tradução, exercício, mapa e QR code sem editar uma imagem inteira?

**Resultado:** a solução baseada apenas em imagens falha.

Uma imagem final com texto não permite editar com segurança diacríticos, caracteres chineses, tabelas, linhas, caixas ou instruções. Mesmo quando o texto parece correto, qualquer alteração exige recriação ou trabalho de composição sobre a imagem.

**Regra aprovada:** o sistema deve ter componentes independentes:

| Camada | Conteúdo | Deve ser editável? |
|---|---|---:|
| Fundo | papel, montanhas, névoa, textura | opcional |
| Identidade | moldura, nuvens, filetes, ornamentos | sim, pelo menos por posição/opacidade |
| Estrutura | caixas, tabelas, linhas, círculos, conexões | sim |
| Conteúdo | títulos, português, pinyin, caracteres | obrigatoriamente |
| Exercício | lacunas, alternativas, áreas de resposta | obrigatoriamente |
| Metadados | página, módulo, QR code, versão | obrigatoriamente |

**Decisão:** entregar moldes em uma ferramenta de layout editável. A imagem pode ser um ativo de fundo, nunca o arquivo-mestre do produto.

### 3.2 Estresse de leitura

**Pergunta:** o aluno identifica a ação da página em até cinco segundos?

**Resultado:** a página de aula cheia e o mapa mestre falham potencialmente.

O aluno precisa saber se deve ouvir, falar, completar, relacionar, escrever ou avaliar. Títulos decorativos como “Lição 1” não são suficientes. Cada página precisa de um verbo de ação visível.

**Regra aprovada:** todo molde de exercício deve conter, no topo, quatro sinais:

```text
AÇÃO PRINCIPAL | TEMPO ESTIMADO | APOIO DISPONÍVEL | RESULTADO
```

Exemplo de placeholder:

```text
FALE EM VOZ ALTA | 5 min | mapa lacunado | produza 4 variações
```

O verbo deve ter mais contraste que a decoração. O aluno não deve descobrir a tarefa lendo um parágrafo introdutório.

### 3.3 Estresse de carga cognitiva

**Pergunta:** a página reduz a complexidade ou adiciona elementos para lembrar?

**Resultado:** o layout editorial de seis seções por página falha como padrão para aulas de transferência.

Uma página que apresenta vocabulário, diálogo, pronúncia, exercício e revisão pode funcionar como referência de consulta, mas não como sequência principal de produção. Ela transforma uma aula em uma superfície de leitura.

**Regra aprovada:** cada página de prática deve privilegiar uma operação cognitiva dominante:

| Operação | Página adequada |
|---|---|
| Orientar | mapa completo e objetivo |
| Recuperar | prompt e resposta escondida |
| Recombinar | padrão fixo com elementos substituíveis |
| Contrastar | duas formas ou dois tons |
| Transferir | situação nova sem mapa completo |
| Avaliar | checklist e autoavaliação |

Uma página pode conter operações secundárias, mas uma só deve comandar a leitura.

### 3.4 Estresse de mapas mentais

**Pergunta:** o mapa é realmente um instrumento de recuperação ou apenas uma ilustração da estrutura?

**Resultado:** o mapa mestre funciona para orientação, mas não deve ser usado como exercício principal.

O mapa radial completo comunica arquitetura. Ele não é necessariamente bom para produzir uma frase. Para uso pedagógico, o sistema precisa de três níveis:

```text
MAPA COMPLETO → MAPA LACUNADO → PROMPT MÍNIMO
```

O mapa completo mostra relações. O lacunado exige reconstrução. O prompt mínimo testa transferência. Se todos os mapas mantiverem todos os rótulos e respostas, o aluno sempre reconhecerá a solução em vez de recuperá-la.

**Regra aprovada:** cada mapa deve possuir uma versão de orientação e pelo menos uma versão de recuperação. O molde deve prever as duas desde o início.

### 3.5 Estresse tonal e tipográfico

**Pergunta:** o sistema visual mantém pinyin, tons e caracteres legíveis em diferentes dispositivos e impressões?

**Resultado:** a estética não resolve sozinha a precisão linguística.

Pinyin com marcas tonais exige fonte compatível, tamanho suficiente e espaçamento adequado. Caracteres chineses precisam de fonte consistente. A cor não deve ser o único marcador de tom, porque pode desaparecer na impressão em escala de cinza ou ser inacessível para pessoas com deficiência visual.

**Regras aprovadas:**

- cada tom deve ter marca diacrítica e, se usado código cromático, também um símbolo ou rótulo;
- pinyin deve permanecer legível em tamanho de impressão confortável;
- o pinyin não deve ser colocado sobre fundos texturizados;
- caracteres, pinyin e tradução devem possuir alinhamento fixo;
- o layout deve ser testado em escala de cinza;
- nenhum tom deve ser comunicado exclusivamente por vermelho, azul, verde ou amarelo.

### 3.6 Estresse de impressão

**Pergunta:** a página ainda funciona impressa em casa, sem cor e com margens variáveis?

**Resultado:** páginas com fundo azul-marinho integral e ornamentos densos têm risco elevado.

O fundo escuro pode consumir tinta, reduzir contraste e tornar a escrita desconfortável. A borda muito próxima da margem pode ser cortada por impressoras domésticas. Aquarelas claras podem desaparecer ou ficar manchadas.

**Regra aprovada:** usar o creme como área principal de trabalho. Reservar o azul-marinho integral para capa, separadores ou páginas de abertura. Os exercícios devem ter fundo claro, borda segura e linhas suficientemente escuras para sobreviverem à cópia.

### 3.7 Estresse de consistência

**Pergunta:** o aluno reconhece que páginas diferentes pertencem ao mesmo sistema?

**Resultado:** a consistência não deve depender de repetir a mesma ilustração.

O sistema precisa de tokens visuais, isto é, regras pequenas e repetíveis:

| Token | Regra |
|---|---|
| Cor de orientação | azul-marinho |
| Cor de substituição | verde ou azul-esverdeado |
| Cor de alerta | coral/vermelho |
| Cor de transferência | dourado |
| Título | mesma família tipográfica e escala por tipo de página |
| Rodapé | mesmo formato para módulo, aula e página |
| Nuvens | apenas em bordas ou separadores |
| Montanhas | baixa opacidade e nunca atrás de texto essencial |
| Número da seção | círculo ou cápsula, sempre no mesmo lugar |
| Caixa de resposta | fundo claro com borda e altura padronizadas |

A identidade deve sobreviver mesmo quando a página não contém panda, restaurante, montanha ou ilustração temática.

### 3.8 Estresse de produção em escala

**Pergunta:** é possível produzir 50 a 100 páginas sem que cada uma se torne uma composição manual única?

**Resultado:** a abordagem “gerar uma imagem por página” falha.

A produção precisa de uma biblioteca de componentes. O sistema mínimo deve incluir:

- uma capa;
- dois cabeçalhos de lição;
- três estilos de caixa;
- duas tabelas;
- três tipos de prompt;
- uma ficha de contraste;
- três estados de mapa;
- um rodapé;
- uma revisão;
- um conjunto limitado de ornamentos.

A produção de um novo PDF deve ser principalmente preenchimento de conteúdo, não reinvenção de design.

---

## 4. Teste de estresse pedagógico

### 4.1 Risco: estética substituir o método

O produto pode ficar visualmente sofisticado e continuar sendo uma apostila de tradução. O sinal de falha é o aluno passar mais tempo admirando ou lendo do que tentando produzir.

**Mitigação:** cada página de conteúdo deve ter pelo menos uma instrução de produção oral antes da resposta. O campo de resposta deve ser visível. A resposta não deve aparecer imediatamente na mesma hierarquia visual do prompt.

### 4.2 Risco: excesso de apoio

Se o mapa completo, pinyin, caracteres e tradução aparecem juntos em todos os cartões, o aluno reconhece a resposta. Isso contradiz a recuperação ativa.

**Mitigação:** criar versões de suporte graduado. A página de exercício deve permitir cobrir, esconder ou consultar a resposta depois da tentativa.

### 4.3 Risco: confundir mapa semântico com mapa gramatical

Um mapa com muitas categorias gramaticais pode deslocar o projeto para uma apostila explicativa. O aluno passa a classificar estruturas em vez de usá-las.

**Mitigação:** o núcleo de cada mapa deve ser uma intenção comunicativa ou uma operação oral. A gramática entra somente como explicação mínima de uma escolha necessária.

### 4.4 Risco: página de lição virar conteúdo proprietário

Quando o material tenta acompanhar lições específicas do Pimsleur com vocabulário, diálogos e transcrições, a diferenciação desaparece e surgem riscos de reprodução indevida.

**Mitigação:** indexar o produto por função comunicativa, padrão e tipo de transferência. O áudio externo é uma referência de uso, não uma fonte a ser reproduzida no PDF.

### 4.5 Risco: o mapa ficar bonito, mas não gerar recombinação

Um mapa radial pode mostrar “cumprimentar”, “perguntar nome” e “responder”, mas não indicar qual parte pode mudar nem qual ordem deve ser preservada.

**Mitigação:** cada ramo de padrão deve distinguir explicitamente:

```text
FIXO | SUBSTITUÍVEL | OPCIONAL | CONTRASTE | TAREFA
```

### 4.6 Risco: o exercício ser reconhecido como tarefa escolar genérica

Lacunas de tradução e múltipla escolha são fáceis de produzir, mas não comprovam fala. O aluno pode completar sem conseguir produzir a frase em contexto.

**Mitigação:** toda página de exercício deve incluir pelo menos um prompt de português funcional ou situação, produção em voz alta e recombinação com elemento novo.

---

## 5. Teste de estresse visual por molde

### 5.1 Capa da coleção

**Função correta:** identidade e promessa.

**Falha provável:** texto demais ou imagem central competindo com o título.

**Regra:** a capa deve ter uma área segura central. O fundo deve ser discreto e a tipografia deve ser montada separadamente. A capa não precisa demonstrar toda a metodologia.

**Passa se:** o título é legível em miniatura, a marca é reconhecível sem depender dos ornamentos e o arquivo permite alterar subtítulo e edição.

### 5.2 Abertura temática de lição

**Função correta:** criar contexto e orientar o módulo.

**Falha provável:** tornar-se uma página decorativa que não informa a ação do aluno.

**Regra:** objetivos devem ser mensuráveis e o áudio deve aparecer como elemento auxiliar, não como promessa vaga. A ilustração deve ficar na faixa superior ou lateral e não invadir a área de objetivos.

**Passa se:** o aluno sabe o tema, o resultado e o próximo passo em menos de 20 segundos.

### 5.3 Página de aula/roteiro

**Função correta:** guiar uma sequência de transferência.

**Falha provável:** excesso de explicação ao facilitador, pouca área de uso pelo aluno.

**Regra:** separar instrução do facilitador e ação do aluno por cor, rótulo e posição. O roteiro deve caber em uma página ou ter continuação claramente numerada.

**Passa se:** o fluxo ouvir → tentar → consultar → recombinar → transferir é visualmente inequívoco.

### 5.4 Mapa mental mestre

**Função correta:** mostrar a arquitetura do produto ou módulo.

**Falha provável:** tentar encaixar todos os conteúdos e transformar o mapa em índice ilegível.

**Regra:** limitar a seis ou sete ramos primários e deslocar detalhes para mapas de aula. O mapa mestre deve ser um mapa de navegação, não uma página de exercícios.

**Passa se:** o aluno consegue explicar o percurso geral sem precisar ler cada subramo.

### 5.5 Página de exercícios

**Função correta:** provocar recuperação, recombinação e produção.

**Falha provável:** preencher a página com caixas vazias decorativas, deixando pouco espaço para escrever ou falar.

**Regra:** cada caixa precisa ter uma tarefa, um campo de resposta e um critério. O espaço em branco é recurso pedagógico, não sobra visual.

**Passa se:** o aluno consegue realizar a tarefa sem confundir instrução, exemplo e resposta.

### 5.6 Revisão e autoavaliação

**Função correta:** medir capacidade de uso, não apenas sensação de familiaridade.

**Falha provável:** checklist motivacional sem evidência de produção.

**Regra:** cada item de checklist deve corresponder a uma ação observável, como “produzo quatro variações sem olhar”. A tabela de vocabulário deve ser secundária ao teste oral.

**Passa se:** a autoavaliação aponta uma próxima ação de revisão.

### 5.7 Ficha de escrita

**Função correta:** apoiar caracteres e memória visual quando necessário.

**Falha provável:** puxar o projeto para caligrafia e desviar da produção oral.

**Regra:** tratar como suplemento, não como página padrão de todas as aulas. Não usar a ficha para sugerir que escrever é pré-requisito para falar.

**Passa se:** a ficha ajuda o reconhecimento sem aumentar a carga da aula oral.

---

## 6. Falhas que devem ser eliminadas antes de gerar qualquer ativo

### Falha 1 — Um prompt para “página completa”

Um prompt que peça título, pinyin, caracteres, tabelas e exercícios à IA tem alta chance de produzir texto incorreto, relações erradas e elementos não editáveis.

**Decisão:** gerar apenas fundo, ornamentação ou ilustração sem texto. Montar o conteúdo em editor.

### Falha 2 — Tratar todos os moldes como A4 vertical idêntico

A4 vertical é adequado para a maioria das páginas, mas o mapa mestre precisa de maior área respirável e a capa tem outra proporção de informação. Forçar tudo na mesma grade cria mapas comprimidos e páginas com vazios artificiais.

**Decisão:** manter A4 como saída final, mas usar grades internas diferentes por tipo de página.

### Falha 3 — Usar ornamento nos quatro cantos de todas as páginas

Repetir nuvens vermelho-douradas em todas as páginas pode tornar a coleção cansativa e reduzir a área útil.

**Decisão:** definir três níveis de decoração:

| Nível | Uso | Decoração |
|---|---|---|
| Alto | capa, abertura, separador | nuvens, montanhas, ornamentos completos |
| Médio | mapa, explicação, consolidação | moldura, nuvens lineares, montanhas suaves |
| Baixo | exercício, escrita, revisão | filetes, microornamentos e fundo quase limpo |

### Falha 4 — Usar ilustrações com personagens como identidade central

Um panda ou personagem pode ser simpático, mas aumenta dependência de consistência visual e pode deslocar a marca para o infantil. Também pode não se adequar a todos os públicos brasileiros.

**Decisão:** mascote opcional. A identidade principal deve ser tipográfica, cromática e estrutural.

### Falha 5 — Confundir “vazio” com “editável”

Uma imagem sem texto não é necessariamente um molde editável. Se as caixas e ornamentos estão achatados em uma única imagem, o criador ainda não consegue alterar o layout.

**Decisão:** o molde precisa ser um arquivo com objetos separáveis ou um sistema reproduzível com especificações de componentes.

### Falha 6 — Não testar a impressão

Uma página bonita na tela pode falhar na impressora doméstica, na escala de cinza ou em um celular pequeno.

**Decisão:** qualquer protótipo visual precisa passar por quatro testes: tela grande, celular, impressão colorida e impressão em escala de cinza.

### Falha 7 — Permitir que a cor carregue significado sozinho

O aluno pode não distinguir cores, pode imprimir em preto e branco ou pode interpretar vermelho como erro sem entender o sistema.

**Decisão:** toda codificação cromática deve vir acompanhada de posição, rótulo, ícone ou padrão de linha.

### Falha 8 — Tentar resolver a pronúncia com decoração

Um ícone de ouvido ou uma cor de tom não comprova que o aluno percebe ou produz o som.

**Decisão:** a função visual deve orientar o treino; a validação depende de áudio, repetição e produção.

### Falha 9 — Criar uma coleção de páginas sem ordem operacional

Mesmo páginas individualmente boas podem formar um PDF confuso.

**Decisão:** o produto precisa de um mapa de navegação e de uma convenção de status: orientação, recuperação, recombinação, transferência e revisão.

### Falha 10 — Usar a referência como cópia estética literal

A referência contém elementos de diferentes origens e pode ter sido produzida por ferramentas distintas. Copiar personagens, ornamentos específicos, textos ou composição pode criar problemas de originalidade, licenciamento e coerência.

**Decisão:** usar a referência como direção de atmosfera e hierarquia, não como arquivo a ser replicado. Criar novos ornamentos, nova composição e uma gramática própria.

---

## 7. Sistema mínimo aprovado após o estresse

### 7.1 Arquitetura de página

Cada tipo de página deve possuir três zonas:

```text
ZONA A — ORIENTAÇÃO
Título, função, tempo e objetivo.

ZONA B — OPERAÇÃO
Mapa, exercício, tabela ou prompt principal.

ZONA C — FECHAMENTO
Critério, revisão, próxima ação ou transferência.
```

A decoração deve ficar nas margens e nunca competir com essas zonas.

### 7.2 Biblioteca mínima de componentes

| Componente | Variações iniciais |
|---|---:|
| Moldura | 2 |
| Cabeçalho | 3 |
| Caixa de objetivo | 2 |
| Caixa de destaque | 3 |
| Tabela | 2 |
| Prompt oral | 3 |
| Mapa | completo, lacunado, mínimo |
| Bloco de contraste | 2 |
| Checklist | 1 |
| Rodapé | 2 |
| Ornamento de nuvem | 4 ativos |
| Textura de montanha | 2 ativos |

Mais variedade antes da validação aumenta custo sem melhorar necessariamente a experiência.

### 7.3 Regras de preenchimento

O molde deve indicar claramente o tipo de conteúdo esperado. Placeholders recomendados:

```text
[TÍTULO FUNCIONAL]
[OBJETIVO MENSURÁVEL]
[MAPA COMPLETO]
[MAPA LACUNADO]
[PROMPT DE INTENÇÃO]
[RESPOSTA — REVELAR APÓS TENTATIVA]
[CONTRASTE PRINCIPAL]
[TAREFA DE TRANSFERÊNCIA]
[CRITÉRIO DE DOMÍNIO]
```

O placeholder não deve aparecer na versão final vendida. Ele é uma ferramenta de produção do criador.

---

## 8. Protocolo de teste antes da produção em série

### Teste A — preenchimento

Preencher três moldes com uma aula real. Registrar quantas vezes é necessário alterar a estrutura do molde. Se o criador precisar redesenhar o layout em mais de 20% do conteúdo, o molde é rígido demais ou foi mal escolhido.

### Teste B — leitura de cinco segundos

Mostrar cada página a um usuário por cinco segundos e perguntar: “O que você deveria fazer aqui?”. A resposta deve identificar a ação principal, não apenas o tema.

### Teste C — execução sem explicação

Entregar uma página de exercício sem instrução oral do criador. O aluno deve saber quando falar, quando olhar e o que registrar.

### Teste D — redução de suporte

Usar a mesma célula em mapa completo, lacunado e prompt mínimo. Observar se o aluno consegue produzir com menos apoio.

### Teste E — impressão

Imprimir em colorido e escala de cinza. Avaliar contraste, margens, linhas, pinyin e áreas de resposta.

### Teste F — tela pequena

Abrir em um celular. Verificar se o título, a instrução e o prompt continuam reconhecíveis sem zoom excessivo.

### Teste G — revisão de uma semana

Retomar a página após sete dias. Verificar se a estrutura visual ajuda o aluno a localizar a célula sem depender da memória do layout.

### Teste H — expansão

Criar cinco aulas com o mesmo sistema. Se a coleção parecer cinco produtos diferentes, os tokens visuais ou a hierarquia estão instáveis.

---

## 9. Critérios de aprovação e reprovação

### O sistema passa se

- o criador editar textos e blocos sem recriar a página;
- o aluno identificar a ação principal rapidamente;
- o exercício exigir produção oral antes da resposta;
- o mapa reduzir apoio ao longo da aula;
- a página funcionar em cor, preto e branco e tela pequena;
- a identidade sobreviver sem ilustração temática;
- o material puder crescer com componentes reutilizáveis;
- pinyin e caracteres permanecerem editáveis e legíveis;
- cada ornamento tiver função de marca ou ambientação, não apenas preenchimento;
- a página de revisão medir ações observáveis.

### O sistema reprova se

- a imagem precisar ser recriada para qualquer alteração de conteúdo;
- a ornamentação ocupar o espaço de resposta;
- o aluno confundir exemplo com exercício;
- o mapa mostrar tudo e não exigir recuperação;
- o texto depender de cor para ser entendido;
- a página funcionar apenas no arquivo original e não na impressão;
- cada lição exigir um estilo novo;
- a página se parecer mais com propaganda do que com instrumento de estudo;
- a solução depender de conteúdo reproduzido do Pimsleur;
- a estética de capa invadir o núcleo operacional da aula.

---

## 10. Decisões finais

### Decisão 1 — Não gerar ainda as páginas completas

A geração imediata de páginas completas criaria falsa sensação de avanço. Antes, é necessário fechar a grade, os tokens visuais, a quantidade de texto e a ferramenta de edição.

### Decisão 2 — Gerar três ativos de teste

A primeira rodada deve conter somente:

1. um fundo de aula/roteiro com baixa decoração;
2. uma página de exercício com caixas e áreas editáveis;
3. um fundo de mapa mental sem rótulos, com estrutura que será refeita em vetor.

### Decisão 3 — Usar um arquivo editável como produto de produção

O criador precisa trabalhar em um arquivo com elementos separados. A imagem gerada serve como referência, textura ou fundo. O arquivo-mestre deve manter texto, estrutura e conteúdo fora da imagem.

### Decisão 4 — Consolidar o estilo em uma página de sistema

Antes dos moldes, criar uma página de especificação com paleta, fontes, espaçamentos, níveis de decoração, componentes, exemplos de mapa e estados de suporte. Isso evita que cada nova página introduza uma interpretação diferente da marca.

### Decisão 5 — Priorizar função sobre ornamentação

A estética é aprovada somente quando não prejudica leitura, edição, impressão e produção oral. A frase operacional é:

> **A decoração cria reconhecimento; a estrutura cria aprendizagem.**

---

## 11. Prompt mestre revisado após o teste de estresse

> Criar um ativo visual editorial, não uma página final com texto, para o sistema educacional premium “Mandarim em Rede”, destinado a brasileiros que estudam mandarim com apoio de áudio estruturado. O ativo deve funcionar como camada de fundo ou referência de layout editável. Formato vertical A4, composição calma, sofisticada e imprimível. Usar azul-marinho profundo como âncora, creme marfim como área principal de leitura, dourado envelhecido em filetes e detalhes, vermelho coral discreto em nuvens chinesas estilizadas e cinza-azulado muito suave em montanhas e névoa. Manter áreas centrais amplas, limpas e sem textura para inserir posteriormente títulos, pinyin com tons, caracteres simplificados, tabelas, exercícios, mapas e campos de resposta. Colocar ornamentos apenas nas margens e cantos, sem invadir o conteúdo. Não inserir texto, letras, números, caracteres chineses, pinyin, tabelas exatas, QR code, marca d’água ou conteúdo linguístico. Não criar relações de mapa mental em imagem; reservar a área para uma estrutura vetorial editável. Evitar excesso de ornamentos, contraste baixo, textura atrás de texto, personagens infantis, realismo fotográfico e composição que pareça uma página pronta não editável. Priorizar hierarquia, espaço negativo, consistência de marca e compatibilidade com impressão em escala de cinza.

## 12. Próximo experimento recomendado

A próxima etapa não é gerar o catálogo inteiro. É criar um **protótipo triplo** e avaliá-lo com os testes A–F:

- fundo de aula/roteiro;
- página de exercício;
- mapa mental estrutural.

Os três devem usar a mesma paleta, moldura, tipografia de referência e nível de decoração. Se passarem, o sistema pode ser expandido para capa, abertura temática, revisão, escrita e separadores. Se falharem, será muito mais barato corrigir três protótipos do que revisar um PDF completo.

## Veredito

A ideia é forte como direção de produto, mas frágil como processo se for implementada como geração de imagens prontas. Ela passa no teste de estresse somente sob uma condição: **o visual deve ser tratado como um sistema editorial editável, no qual a IA fornece atmosfera e ativos, enquanto a composição pedagógica permanece determinística e sob controle do criador**.
