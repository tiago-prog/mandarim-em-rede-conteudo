# Análise da página autoral-base — Mandarim em Rede

## Veredito

A página autoral enviada deve substituir o PDF de referência como principal fonte de direção do sistema. Ela já resolve o problema mais difícil: estabelece uma gramática própria que combina identidade premium, instrução metodológica e conteúdo linguístico funcional.

A decisão correta não é recriar esse visual com IA. É transformar esta página em um **template editorial controlado**, mantendo sua composição, proporções, hierarquia e atmosfera. A IA pode ser usada somente para ativos secundários, como montanhas, nuvens, texturas e ilustrações pontuais.

## Características objetivas observadas

A imagem possui 1414 × 2000 pixels e proporção aproximada de 0,707, muito próxima do formato A4 vertical. O layout usa uma área central clara, uma borda externa azul-marinho espessa, linhas internas douradas, ornamentos de nuvem nos cantos e montanhas em baixa opacidade na parte inferior e lateral.

A página é organizada em quatro grandes movimentos verticais:

1. título e identificação da aula;
2. objetivo e fluxo metodológico;
3. resultado desejado;
4. conteúdo linguístico em tabela.

Essa sequência é pedagogicamente forte porque leva o leitor de **orientação → processo → critério → material de prática**.

## O que deve ser preservado exatamente como princípio

### 1. Moldura como identidade

A moldura azul-marinho não é uma decoração periférica; ela cria uma área de produto reconhecível. A linha dourada interna suaviza o contraste e reforça a sensação de material premium.

A moldura deve ser um componente fixo, mas com duas versões:

- versão completa para capas, separadores e páginas conceituais;
- versão reduzida para páginas densas de exercício.

### 2. Título grande e centralizado

O título “Aula 1 — Entrar na interação” tem alta visibilidade e comunica imediatamente o estado do material. A hierarquia está correta: o aluno sabe primeiro **onde está** antes de receber instruções.

O template deve reservar uma área equivalente para:

```text
[AULA / MÓDULO] — [TÍTULO FUNCIONAL]
```

A expressão funcional deve ser mais importante que uma nomenclatura técnica ou um número de lição externo.

### 3. Separação forte entre instrução e conteúdo

A página distingue bem três tipos de informação:

- texto instrucional em fundo claro;
- fluxo da experiência em faixa azul-marinho;
- resultado desejado em caixa dourada.

Essa diferenciação deve se tornar uma regra do sistema:

| Função | Tratamento visual |
|---|---|
| Instrução | fundo creme, texto escuro |
| Processo | faixa azul-marinho, texto claro |
| Resultado | caixa dourada, texto escuro em destaque |
| Conteúdo linguístico | tabela com cabeçalho azul-marinho |
| Decoração | bordas e baixa opacidade |

### 4. Faixa de fluxo como elemento central

A faixa azul-marinho com a sequência “ouvir → tentar responder → consultar o mapa → reconstruir → recombinar → transferir → produzir sem olhar” é o melhor elemento metodológico da página.

Ela não é apenas um ornamento. Ela funciona como contrato de uso. Deve ser preservada, mas transformada em componente reutilizável com três tamanhos:

- faixa completa para página de roteiro;
- faixa abreviada para abertura de módulo;
- versão numerada para página de exercício.

O texto pode ser ajustado para caber, mas a lógica deve permanecer intacta.

### 5. Caixa do facilitador

A caixa intermediária explica que o facilitador deve proteger a ordem da experiência e não antecipar as respostas. Isso é importante porque impede que o material vire aula gramatical tradicional.

Entretanto, essa caixa não deve aparecer em todas as páginas para o aluno. Ela pertence ao **roteiro do facilitador** ou à abertura do módulo. Em páginas de uso individual, deve ser substituída por uma instrução mais curta:

```text
Tente responder antes de consultar o mapa.
```

### 6. Resultado desejado mensurável

A caixa dourada é muito bem resolvida. Ela não promete “aprender mandarim”; define um comportamento observável: realizar uma troca curta usando um nome e uma situação nova, sem consultar o mapa completo.

Essa deve ser uma regra de todas as aulas:

> O resultado desejado precisa descrever o que o aluno produz, em que condição e com quanto apoio.

### 7. Tabela linguística

A tabela é o elemento mais importante para transformar o conceito em conteúdo. As quatro colunas — função, mandarim, pinyin e sentido funcional — evitam que o material vire uma lista de tradução.

A escolha de “sentido funcional” é especialmente forte. Ela prioriza o uso da expressão em situação real, não uma equivalência palavra por palavra.

A tabela deve permanecer como componente editável com:

- cabeçalho azul-marinho;
- células creme;
- linhas finas e discretas;
- primeira coluna com função comunicativa;
- segunda coluna com caracteres maiores;
- terceira coluna com pinyin legível;
- quarta coluna com tradução natural.

## O que deve ser melhorado sem alterar a identidade

### 1. Controle de densidade no topo

O título, a linha dourada, o cabeçalho da seção, o parágrafo e a faixa de fluxo ocupam bastante espaço antes do conteúdo linguístico. Isso funciona em uma página de roteiro, mas não deve ser copiado para uma folha de exercícios mais densa.

Recomendação: classificar a página como **Roteiro de Aula — Tipo R1**. Criar uma versão compacta para exercícios, com título menor e fluxo reduzido.

### 2. Tratamento do texto corrido

O parágrafo do objetivo é funcional, mas uma frase longa pode ficar difícil em telas menores. O template deve impor limite de duas ou três linhas para a instrução inicial e quatro linhas para a orientação do facilitador.

Se o texto ultrapassar esse limite, ele deve ser dividido em uma caixa adicional ou movido para notas do facilitador.

### 3. Quebra de pinyin

A tabela precisa suportar pinyin longo sem quebras que prejudiquem a leitura. Em expressões como `Nǐ jiào shénme míngzi?`, a quebra de linha deve ocorrer entre palavras, nunca no meio de uma sílaba ou de uma unidade tonal.

O arquivo editável deve permitir aumento automático da altura da linha ou ajuste de largura da coluna.

### 4. Uso de textura de montanha

As montanhas estão bem posicionadas como elemento de fundo, mas devem ficar abaixo de uma opacidade segura. Elas não podem competir com células da tabela, pinyin ou texto de instrução.

A textura deve ser separada da página e poder ser desligada na versão para impressão econômica.

### 5. Área inferior vazia

O espaço vazio inferior é visualmente calmo e pode ser mantido como respiro. Porém, para algumas aulas, ele pode receber uma pequena área de “próxima ação”, “observação do facilitador” ou “registro de dificuldade”.

Não preencher esse espaço automaticamente. O vazio deve permanecer uma opção de design, não uma obrigação de ocupar toda a página.

## Novo sistema de moldes derivado da página autoral

A página autoral permite definir cinco moldes prioritários:

### R1 — Roteiro de aula

É a página enviada. Inclui título, objetivo, fluxo, orientação, resultado e tabela linguística.

### R2 — Mapa de aula

Mantém a mesma moldura e cabeçalho, mas substitui a tabela por mapa completo, mapa lacunado e legenda de cores.

### R3 — Recombinação oral

Mantém a faixa de processo e a caixa dourada, mas usa blocos de padrão fixo, elementos substituíveis, prompts e área de produção.

### R4 — Transferência e autoavaliação

Usa a mesma identidade, com situação nova, checklist de domínio, escala de apoio e espaço de registro.

### R5 — Consolidação de módulo

Usa o mapa integrador, os contrastes principais e uma tarefa oral cumulativa. Deve ser menos decorativa e mais panorâmica.

A capa e a abertura temática continuam úteis, mas são acessórios. O núcleo do produto está nesses cinco moldes operacionais.

## Paleta funcional sugerida

A página permite fixar uma paleta mais precisa:

| Uso | Cor aproximada | Função |
|---|---|---|
| Azul-marinho | `#173754` | títulos, moldura, processo, cabeçalho de tabela |
| Creme | `#F8F2E7` | fundo principal e células |
| Dourado | `#C99E4A` | linha, resultado, ornamentos e destaque |
| Coral | `#C94D3F` | nuvens e alerta visual pontual |
| Cinza-azulado | `#8A96A0` | montanhas e textura |
| Texto escuro | `#24323D` | corpo e instruções |

Esses valores são uma aproximação operacional a ser refinada no arquivo de design. A regra mais importante é preservar contraste, não perseguir uma reprodução pixel a pixel.

## Sistema de componentes editáveis

A página deve ser reconstruída como componentes separados:

```text
MASTER
├── moldura azul-marinho
├── filete dourado
├── ornamento de nuvem superior
├── ornamentos inferiores
├── textura de montanha
├── título da aula
├── cabeçalho de seção
├── parágrafo de instrução
├── faixa de fluxo
├── caixa do facilitador
├── caixa de resultado
├── título de conteúdo
├── tabela linguística
└── rodapé
```

O arquivo-mestre ideal deve permitir ocultar ou duplicar qualquer componente. Uma imagem achatada não deve ser considerada o molde principal.

## Teste de estresse específico desta página

### Teste de preenchimento

Substituir “Aula 1 — Entrar na interação” por cinco títulos com comprimentos diferentes. O título deve continuar cabendo sem reduzir drasticamente a fonte.

### Teste de tabela

Testar de quatro a oito linhas, com frases curtas e longas. Nenhuma linha deve comprimir o pinyin ou a tradução a ponto de exigir fonte pequena.

### Teste de variação de conteúdo

Usar uma aula de apresentação, uma de pedidos e uma de localização. A página deve continuar parecendo parte da mesma coleção sem depender da ilustração temática.

### Teste de impressão

Imprimir em A4 colorido e escala de cinza. Verificar se a faixa azul, a caixa dourada, a tabela e as linhas permanecem distinguíveis.

### Teste de uso

Entregar a página a um facilitador sem explicação adicional. Ele deve entender qual é o resultado desejado, em que ordem conduzir a experiência e quais estruturas são o núcleo da aula.

## Consequência para a geração de imagens

A imagem autoral é forte demais para ser substituída por uma geração genérica. O caminho correto é:

1. usar esta página como especificação de layout;
2. redesenhar os componentes em editor vetorial;
3. gerar somente ativos que ainda não existem, como novas montanhas, nuvens ou ilustrações temáticas;
4. manter todo texto e toda estrutura fora da imagem;
5. criar uma versão compacta e uma versão completa do mesmo sistema.

Não é necessário gerar um novo fundo para provar o conceito. O conceito já foi demonstrado pela própria página.

## Veredito final

A página autoral deve ser promovida de “exemplo” para **página-mãe do sistema visual**. Ela tem coerência, propósito e uma hierarquia que conversa diretamente com a metodologia do projeto.

O que falta não é inspiração visual. Falta transformar o desenho em um sistema editável, responsivo a diferentes quantidades de conteúdo e testado em produção.

A próxima ação mais estratégica é criar o template editável R1 a partir desta página e, somente depois, derivar R2, R3, R4 e R5. A geração de imagens deve ser subordinada a esse sistema, não o contrário.
