# Pacote de refinamento

O arquivo principal é `prompt-refinamento-max-mandarim-em-rede.md`. Ele deve ser lido antes de qualquer alteração nos moldes.

A referência visual autoral está em `../referencias/first-page.png`. Ela é a página-mãe do sistema e tem prioridade sobre referências genéricas.

Os documentos de apoio são o conceito consolidado, a análise da página autoral e o teste de estresse dos moldes. O objetivo é refinar sem descaracterizar, mantendo editabilidade, precisão linguística, função pedagógica e impressão adequada.
