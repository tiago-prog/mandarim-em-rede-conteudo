# Roteiro de apresentação — Aula-piloto 01

## Mandarim em Rede 01 — Fundamentos de Transferência Oral

### Aula 1 — Entrar na interação

**Tema:** cumprimentar, perguntar o nome, dizer o próprio nome e devolver a pergunta.

**Público do piloto:** adulto brasileiro iniciante ou falso iniciante que já utiliza áudio estruturado para estudar mandarim.

**Duração recomendada:** 45 a 55 minutos de condução, sem contar uma sessão externa de áudio que o participante já utilize.

**Formato:** apresentação guiada, preferencialmente com um participante por vez ou com um grupo de até quatro pessoas. O piloto deve observar o comportamento do aluno; não deve funcionar como uma palestra em que o facilitador explica tudo antes de o aluno tentar.

## 1. Objetivo do roteiro

Este roteiro serve para conduzir a primeira aula-piloto e testar se o aluno consegue passar pelo ciclo abaixo:

```text
ouvir → tentar responder → consultar o mapa → reconstruir →
recombinar → transferir → produzir sem olhar
```

A função do facilitador é **proteger a ordem da experiência**, observar as dificuldades e oferecer apenas o apoio previsto. O facilitador não deve transformar a sessão em uma aula tradicional de explicação gramatical nem antecipar as respostas que o material pretende fazer o aluno recuperar.

O resultado desejado é que o participante consiga realizar uma troca curta em mandarim usando um nome e uma situação novos, sem consultar o mapa completo.

## 2. Conteúdo linguístico da sessão

O núcleo da aula usa quatro estruturas:

| Função | Mandarim | Pinyin | Sentido funcional |
|---|---|---|---|
| Cumprimentar | 你好。 | **Nǐ hǎo.** | Olá. |
| Perguntar o nome | 你叫什么名字？ | **Nǐ jiào shénme míngzi?** | Qual é o seu nome? |
| Dizer o próprio nome | 我叫 + nome。 | **Wǒ jiào + [nome].** | Eu me chamo + nome. |
| Devolver a pergunta | 你呢？ | **Nǐ ne?** | E você? |

As expressões abaixo são extensões e não devem ser necessárias para aprovação do piloto:

| Função | Mandarim | Pinyin |
|---|---|---|
| Perguntar como a pessoa está | 你好吗？ | **Nǐ hǎo ma?** |
| Responder | 我很好。 | **Wǒ hěn hǎo.** |
| Encerrar a apresentação | 很高兴认识你。 | **Hěn gāoxìng rènshi nǐ.** |

## 3. Preparação antes da sessão

### 3.1 Materiais do facilitador

O facilitador deve ter:

- a versão do participante, sem respostas antecipadas;
- uma versão de apoio com o gabarito completo;
- a apresentação ou PDF aberto em tela compartilhada;
- um cronômetro;
- a ficha de observação deste roteiro;
- uma forma de registrar frases produzidas pelo participante;
- um gravador somente se o participante autorizar expressamente;
- acesso ao áudio que o próprio participante já utiliza, sem copiar ou redistribuir áudio de terceiros.

### 3.2 Preparação da tela

Antes de iniciar, deixar aberta somente a capa ou a página de abertura. Não deixar o mapa completo visível em uma aba, janela lateral ou miniatura. O participante não deve conseguir consultar a resposta por acidente.

Se o piloto for remoto, compartilhar a janela da apresentação e não a área de trabalho inteira. Desativar prévias de páginas seguintes quando elas revelarem respostas.

### 3.3 Aviso de uso e limites

O facilitador deve explicar que o material é um **companion visual independente e não oficial**. A sessão deve usar o áudio que o participante já possui legitimamente. Não se deve tocar, transcrever, gravar ou reproduzir material proprietário de terceiros durante o teste sem autorização adequada.

## 4. Visão geral dos tempos

| Etapa | Duração | Ação principal |
|---|---:|---|
| 0. Acolhimento e consentimento | 3 min | Explicar objetivo do teste e combinar registro. |
| 1. Orientação | 4 min | Apresentar a promessa e o protocolo. |
| 2. Áudio externo | Conforme o áudio | O participante realiza sua sessão sem o mapa. |
| 3. Primeira tentativa | 4 min | Produzir antes de ver as respostas. |
| 4. Revelação do mapa | 5 min | Mostrar a arquitetura completa após a tentativa. |
| 5. Reconstrução lacunada | 7 min | Recuperar as estruturas com apoio reduzido. |
| 6. Recombinador | 8 min | Produzir pelo menos três variações. |
| 7. Transferência | 7 min | Usar o padrão em situação nova. |
| 8. Autoavaliação | 4 min | Registrar as quatro dimensões de domínio. |
| 9. Debrief do piloto | 8 min | Coletar dificuldades e percepção de valor. |

O áudio externo pode ser realizado antes da sessão com o facilitador. Se for realizado durante o encontro, o facilitador deve permanecer em silêncio e não abrir o material visual enquanto o participante escuta e responde.

## 5. Roteiro falado completo

### Etapa 0 — Acolhimento e consentimento

**Objetivo:** criar um ambiente de teste sem transformar erros em avaliação pessoal.

**Fala do facilitador:**

> Obrigado por participar. Hoje você vai testar uma aula-piloto do projeto Mandarim em Rede. Eu não estou avaliando o seu nível de mandarim. Estou avaliando se o material consegue orientar você com clareza e ajudar na produção oral.
>
> Durante alguns momentos, eu vou evitar explicar ou corrigir imediatamente. Isso é intencional: queremos verificar o que você consegue recuperar antes de receber a resposta.
>
> Posso registrar o tempo, as páginas que você consulta, os pontos em que você hesita e as suas observações finais? Esses registros serão usados apenas para melhorar o material.

Aguardar a confirmação. Se houver gravação de voz ou imagem, solicitar autorização específica antes de iniciar.

**Se o participante pedir a resposta imediatamente:**

> Vou segurar a resposta por alguns segundos porque esta primeira tentativa faz parte do método. Se você continuar sem conseguir, registraremos a dificuldade e depois veremos a estrutura juntos.

**Registro do facilitador:**

| Item | Registro |
|---|---|
| Participante | ______________________________ |
| Data | ______________________________ |
| Usa áudio estruturado atualmente? | Sim / Não |
| Frequência aproximada | ______________________________ |
| Autorizou registro de observações? | Sim / Não |
| Autorizou gravação de voz? | Sim / Não |

### Etapa 1 — Orientação inicial

**Abrir:** página de objetivo e protocolo.

**Fala do facilitador:**

> A aula de hoje trabalha uma única função: entrar em uma interação e identificar as pessoas envolvidas.
>
> Ao final, você deverá conseguir cumprimentar alguém, perguntar o nome, dizer o seu próprio nome e devolver a pergunta.
>
> O ponto mais importante é a ordem. Primeiro você escuta e tenta responder. Depois consulta o mapa. Em seguida reconstrói o padrão, troca alguns elementos e usa a estrutura em uma situação nova.
>
> O mapa não deve ficar aberto durante o bloco principal de áudio. Ele entra como uma ponte entre lembrar uma frase e conseguir usar o padrão fora da sequência original.

Apontar para o ciclo visual:

```text
OUVIR → TENTAR RESPONDER → CONSULTAR O MAPA → RECOMBINAR → PRODUZIR SEM OLHAR
```

**Pergunta de compreensão, sem ensinar conteúdo:**

> Antes de começar, qual é a regra sobre o momento em que o mapa deve ser consultado?

Esperar a resposta. O participante deve dizer, com suas próprias palavras, que consulta o mapa depois da tentativa ou depois do áudio. Se não souber, repetir apenas:

> A regra é: primeiro tentar; depois consultar.

Não apresentar ainda nenhuma das quatro estruturas em mandarim.

### Etapa 2 — Sessão de áudio sem mapa

**Objetivo:** preservar a antecipação e o áudio como fonte primária.

Esta etapa utiliza o áudio que o participante já estuda. O facilitador não deve substituir esse áudio por uma leitura das frases do PDF.

**Fala do facilitador:**

> Agora faça a sua sessão de áudio normalmente. Não abra o mapa e não acompanhe a tela com o PDF. Responda quando o áudio pedir uma resposta e anote apenas uma dificuldade relevante, se precisar.
>
> Não tente memorizar tudo para o teste seguinte. Queremos observar o que ficou disponível para você depois da escuta.

Durante a sessão, o facilitador deve:

- permanecer em silêncio;
- não apontar para nenhuma resposta;
- não completar frases;
- não corrigir cada tentativa;
- registrar apenas comportamentos relevantes;
- interromper somente se houver um problema técnico ou se o participante solicitar pausa.

**Registro durante o áudio:**

| Observação | Nota breve |
|---|---|
| O participante tentou responder antes de ouvir a solução? | __________________ |
| Consultou alguma transcrição ou material externo? | __________________ |
| Demonstrou dificuldade tonal ou de compreensão? | __________________ |
| Pausou ou abandonou alguma resposta? | __________________ |

### Etapa 3 — Primeira tentativa sem resposta

**Abrir:** página de primeira tentativa. Não abrir o mapa completo.

**Fala do facilitador:**

> Agora feche ou deixe de lado o áudio. Sem consultar as próximas páginas, imagine que você acabou de conhecer uma pessoa.
>
> Tente produzir oralmente quatro ações: uma saudação, uma pergunta sobre o nome, uma resposta com o seu nome e uma devolução da pergunta.
>
> Você pode fazer uma tentativa mesmo que não tenha certeza. Não vou corrigir agora. Primeiro quero registrar o que você consegue recuperar.

Dar até 20 segundos para o participante se preparar. Depois solicitar:

> Quando estiver pronto, faça a tentativa em voz alta.

Não interromper durante a tentativa. Se o participante parar, esperar aproximadamente cinco segundos e perguntar apenas:

> Quer tentar continuar ou prefere registrar este ponto como uma dificuldade?

Não fornecer palavras em mandarim nesta etapa.

**Após a tentativa:**

> Obrigado. Agora marque, para cada ação, se conseguiu iniciar, se hesitou e se precisou consultar alguma coisa.

Enquanto o participante marca a ficha, registrar:

| Ação | Iniciou? | Hesitação aproximada | Consultou? | Observação |
|---|---|---:|---|---|
| Saudação | Sim / Não | ____ s | Sim / Não | __________________ |
| Pergunta do nome | Sim / Não | ____ s | Sim / Não | __________________ |
| Dizer o próprio nome | Sim / Não | ____ s | Sim / Não | __________________ |
| Devolver a pergunta | Sim / Não | ____ s | Sim / Não | __________________ |

**Transição:**

> Agora que a primeira tentativa foi registrada, vou mostrar a arquitetura que organiza essas quatro ações. A partir deste ponto, a resposta pode aparecer porque a etapa de antecipação já foi concluída.

### Etapa 4 — Revelação do mapa completo

**Abrir:** mapa completo de orientação.

**Fala do facilitador:**

> Este mapa parte de uma única intenção: iniciar uma interação e identificar pessoas.
>
> O azul-marinho indica a intenção. O azul-claro mostra uma estrutura fixa ou uma ordem que não deve ser alterada. O verde mostra a parte substituível. O laranja marca som, pinyin ou tom. O vermelho chama atenção para um contraste ou erro provável. O dourado indica a tarefa de transferência.
>
> A cor não é a única informação. Cada ramo também possui um rótulo, porque o mapa precisa continuar compreensível em impressão em escala de cinza.

Apontar para cada ramo, sem exigir repetição imediata:

> Primeiro, a saudação: **你好 — Nǐ hǎo.**
>
> Depois, a pergunta do nome: **你叫什么名字？— Nǐ jiào shénme míngzi?**
>
> Para dizer o próprio nome, usamos o padrão **我叫 + nome — Wǒ jiào + nome**.
>
> Por fim, podemos devolver a pergunta com **你呢？— Nǐ ne?**

Pedir ao participante que identifique os elementos:

> Qual parte pode ser trocada na estrutura **我叫 + nome**?

Esperar a resposta. Se necessário:

> O nome é o elemento variável. A estrutura **我叫** permanece.

#### Foco auditivo breve

**Fala do facilitador:**

> Há quatro alertas curtos. Eles não substituem o áudio e não pretendem corrigir sua pronúncia sozinhos.
>
> Em **叫 jiào**, o quarto tom é curto e descendente. Em **名字 míngzi**, a segunda sílaba costuma ser mais leve, geralmente neutra. Em **你呢？**, a partícula **呢** não recebe o mesmo peso de uma palavra tônica plena. Em **你好**, o que importa é ouvir e imitar a realização da sequência no áudio, sem tentar aplicar uma regra de forma mecânica.

Não transformar essa seção em uma aula extensa de fonética. Se o participante pedir uma explicação aprofundada, registrar a dúvida e dizer:

> Essa é uma boa questão para uma aula específica de pronúncia. Hoje vou manter apenas o alerta necessário para esta função.

#### Repetição guiada após a revelação

Agora o facilitador pode conduzir uma repetição curta. Usar uma expressão por vez:

> Ouça primeiro: **你好。**

Fazer uma pausa e dizer:

> Agora repita uma vez.

Repetir o mesmo procedimento para:

- **你叫什么名字？**
- **我叫 + seu nome.**
- **你呢？**

A repetição serve para estabelecer o som depois da recuperação inicial. Evitar fazer muitas repetições mecânicas.

### Etapa 5 — Reconstrução com o mapa lacunado

**Abrir:** mapa lacunado. Ocultar ou fechar a página completa.

**Fala do facilitador:**

> Agora vamos reduzir o apoio. A intenção continua visível, mas algumas partes desapareceram. Diga cada resposta em voz alta antes de escrever ou conferir.
>
> Se você precisar consultar, não há problema. Apenas marque que esta estrutura ainda está em recuperação.

#### Prompt 1 — Saudação

Mostrar:

```text
Cumprimentar:
________
```

**Fala:**

> Produza a saudação.

Esperar entre 5 e 10 segundos. Se o participante não iniciar:

> Pense na função: iniciar uma interação. Tente qualquer lembrança antes de consultar.

Não dizer a resposta antes da tentativa. Após a tentativa, revelar ou confirmar:

> A forma de apoio é **你好 — Nǐ hǎo.**

#### Prompt 2 — Perguntar o nome

Mostrar:

```text
Perguntar o nome:
你叫 ________ ________？
```

**Fala:**

> Complete oralmente a pergunta. Não precisa preencher primeiro no papel.

Após a tentativa:

> A estrutura completa é **你叫什么名字？— Nǐ jiào shénme míngzi?**

#### Prompt 3 — Dizer o próprio nome

Mostrar:

```text
Dizer o próprio nome:
________ 叫 + [nome]
```

**Fala:**

> Diga a frase usando o seu nome.

Após a tentativa:

> A estrutura é **我叫 + nome — Wǒ jiào + nome.** O nome é a parte variável.

#### Prompt 4 — Devolver a pergunta

Mostrar:

```text
Devolver a pergunta:
你 ________？
```

**Fala:**

> Responda com a pequena expressão que devolve a pergunta.

Após a tentativa:

> A expressão é **你呢？— Nǐ ne?**

#### Checagem da etapa

> Sem olhar o mapa completo, faça agora a sequência: saudação, pergunta do nome, seu nome e devolução da pergunta.

Registrar se o participante consegue encadear as quatro partes e se precisa voltar ao mapa completo.

### Etapa 6 — Recombinador controlado

**Abrir:** página do recombinador.

**Fala do facilitador:**

> Agora não vamos repetir uma única frase. Vamos manter o núcleo e trocar apenas o elemento que pode variar.
>
> O padrão é **我叫 + nome**. A estrutura fica estável; o nome muda.

#### Exercício 1 — Nome do participante

> Diga: “Eu me chamo” e use seu nome.

Esperar a produção. Não corrigir cada detalhe imediatamente. Se houver uma falha que impeça a compreensão, dizer:

> Vou repetir apenas o início do padrão: **我叫**. Agora complete com seu nome.

#### Exercício 2 — Nome fornecido

> Agora diga que você se chama Ana. Faça a frase inteira.

Se o facilitador estiver usando a forma transliterada prevista no material, pode oferecer o apoio somente depois da tentativa:

> No material, o nome aparece como **安娜 — Ānnà**. O objetivo aqui é praticar a posição variável do nome, não estudar a escrita do nome.

#### Exercício 3 — Segundo nome

> Agora use Paulo ou outro nome de sua escolha. Produza a frase sem olhar a estrutura completa.

#### Exercício 4 — Pergunta e resposta

> Eu vou perguntar o seu nome. Você responde usando o padrão.

Facilitador:

> 你叫什么名字？

Participante: resposta livre.

Se o participante não responder, apontar somente para o prompt de recuperação, não para a resposta completa.

#### Exercício 5 — Devolver a pergunta

> Depois de dizer seu nome, devolva a pergunta para mim usando a expressão curta da aula.

Facilitador pode responder:

> 我叫 [nome do facilitador]。你呢？

Ou, se a interação estiver invertida:

> Você diz seu nome e acrescenta a expressão de devolução.

#### Exercício 6 — Mini-diálogo de quatro falas

> Agora faça uma troca com quatro falas. Eu começo e você responde.
>
> A sequência é: saudação, pergunta do nome, resposta e devolução da pergunta.

Versão do facilitador:

1. **Facilitador:** 你好。
2. **Participante:** responde à saudação ou continua a interação.
3. **Facilitador:** 你叫什么名字？
4. **Participante:** responde com **我叫 + nome** e acrescenta **你呢？** quando apropriado.

Se for necessário simplificar, o facilitador pode dizer em português:

> Eu cumprimentei você. Agora pergunte meu nome.

Depois:

> Eu perguntei seu nome. Agora responda e devolva a pergunta.

O facilitador deve registrar se o participante consegue usar a estrutura sem receber cada frase pronta.

### Etapa 7 — Transferência em situação nova

**Abrir:** página de transferência ou prompt mínimo. Fechar o mapa completo.

**Fala do facilitador:**

> Agora vamos testar se você consegue usar a rede em uma situação que não é igual aos exemplos.
>
> Imagine que você entrou em uma sala de reunião on-line e encontrou uma pessoa que ainda não conhece. Você não tem o mapa completo aberto.
>
> Faça uma apresentação curta com quatro ações: cumprimente, pergunte o nome da pessoa, diga seu próprio nome e devolva a pergunta.
>
> Use um nome que não tenha aparecido nos exemplos anteriores. Faça a troca duas vezes, usando nomes diferentes.

Dar até 30 segundos para preparação silenciosa. Durante a produção, não interromper para corrigir.

Após a primeira tentativa:

> Agora faça novamente, mas tente reduzir a consulta ou a hesitação. O objetivo não é repetir exatamente a primeira versão; é demonstrar que a estrutura está disponível.

Se o participante concluir com facilidade, acrescentar somente uma variação controlada:

> Faça uma terceira versão em que você entra em uma conversa presencial, não em uma sala on-line.

Não acrescentar novas estruturas gramaticais. A mudança deve estar no contexto, não na complexidade linguística.

#### Critério de transferência

A tarefa é considerada executada quando o participante:

- inicia a interação sem o mapa completo;
- pergunta o nome usando a estrutura-alvo;
- responde com um elemento variável;
- usa **你呢？** ou demonstra que sabe devolver a pergunta;
- realiza a operação em uma situação ou com um nome que não copia o exemplo.

### Etapa 8 — Autoavaliação e domínio

**Abrir:** ficha de autoavaliação. Não abrir novamente o mapa completo.

**Fala do facilitador:**

> Agora você vai avaliar o seu desempenho em quatro dimensões diferentes. Não marque “dominei” apenas porque reconheceu a página. O objetivo é separar compreensão, recuperação, pronúncia funcional e transferência.

Apresentar a escala:

- **0 — ainda não consigo:** não reconheci ou não produzi;
- **1 — consigo com apoio:** produzi com hesitação, pista ou consulta;
- **2 — consigo sem mapa completo:** produzi de forma funcional e independente.

Solicitar o preenchimento:

| Dimensão | Pergunta | Nota 0–2 |
|---|---|---:|
| Compreensão | Entendi a função quando ouvi ou vi o contexto? | ____ |
| Recuperação | Tentei produzir antes de consultar a resposta? | ____ |
| Pronúncia funcional | Mantive os focos de **叫**, **名字** e **你呢**? | ____ |
| Transferência | Usei a estrutura em uma situação nova? | ____ |

Depois perguntar:

> Qual das quatro dimensões foi mais fácil?
>
> Qual foi mais difícil?
>
> Em que momento você sentiu que o mapa ajudou a produzir, e não apenas a lembrar?

Registrar as respostas sem corrigi-las.

### Etapa 9 — Debrief de usabilidade e valor

**Objetivo:** descobrir se o material funciona sem a explicação do criador e se possui valor além de ser um resumo.

**Fala do facilitador:**

> Terminamos a atividade. Agora quero avaliar o material, não o seu desempenho. Responda com franqueza: críticas específicas são mais úteis do que elogios gerais.

Fazer as perguntas abaixo, uma por vez, sem induzir a resposta:

1. Em que momento você soube o que deveria fazer?
2. A página de primeira tentativa deixou claro que a resposta não deveria ser consultada ainda?
3. O mapa completo ajudou você a enxergar uma relação ou apenas mostrou frases prontas?
4. A diferença entre estrutura fixa e elemento variável ficou clara?
5. O mapa lacunado exigiu recuperação ou permitiu apenas copiar?
6. O prompt de transferência parecia uma tarefa diferente dos exemplos?
7. Qual elemento visual chamou atenção demais?
8. Qual elemento importante passou despercebido?
9. Alguma cor, símbolo ou rótulo ficou confuso?
10. Você usaria este material depois de uma sessão de áudio? Por quê?
11. O material parece um resumo, um exercício, um mapa ou outra coisa?
12. O que deveria ser removido?
13. O que deveria ser explicado melhor?
14. Você sentiu falta de áudio ou de correção de pronúncia? O que esperava que o material fizesse?

Encerrar com:

> Se você pudesse mudar uma única coisa nesta aula, o que mudaria primeiro?

## 6. Intervenções permitidas e proibidas

### Intervenções permitidas

O facilitador pode:

- repetir a instrução em português;
- pedir que o participante tente novamente;
- apontar para a intenção comunicativa;
- indicar se a tarefa é sobre saudação, pergunta, resposta ou devolução;
- reduzir o prompt para uma pista de função;
- mostrar a resposta somente depois de uma tentativa;
- repetir uma expressão após a etapa de recuperação;
- registrar uma dúvida para revisão posterior.

### Intervenções proibidas durante a primeira tentativa

O facilitador não deve:

- falar a resposta antes da tentativa;
- completar a frase do participante;
- apontar para a página do mapa completo;
- corrigir tom ou pronúncia a cada sílaba;
- transformar o exercício em repetição simultânea;
- fornecer a tradução palavra por palavra;
- acrescentar vocabulário que não está no escopo;
- declarar que uma estrutura está dominada porque foi reconhecida visualmente.

### Intervenções após falha persistente

Se o participante falhar duas vezes no mesmo prompt, seguir esta sequência:

1. repetir a função em português;
2. mostrar somente a posição da lacuna ou a etiqueta do elemento;
3. dar uma nova tentativa;
4. revelar a resposta;
5. pedir uma repetição única;
6. marcar a célula como “em recuperação”.

Fala sugerida:

> Você ainda não precisa dominar esta célula agora. Vou mostrar o apoio mínimo, faremos uma tentativa e registraremos que ela precisa voltar na revisão.

## 7. Ficha de observação do facilitador

### 7.1 Comportamento por etapa

| Etapa | O que observar | Nota |
|---|---|---|
| Orientação | Entendeu quando usar o mapa? | __________________ |
| Primeira tentativa | Tentou produzir sem resposta? | __________________ |
| Mapa completo | Identificou intenção, fixo e variável? | __________________ |
| Mapa lacunado | Recuperou antes de consultar? | __________________ |
| Recombinador | Produziu três variações? | __________________ |
| Transferência | Aplicou em contexto novo? | __________________ |
| Autoavaliação | Separou reconhecimento de domínio? | __________________ |

### 7.2 Medidas simples

| Métrica | Resultado |
|---|---:|
| Tempo até iniciar a primeira tentativa | ______ s |
| Número de consultas ao mapa completo | ______ |
| Número de pistas dadas pelo facilitador | ______ |
| Variações controladas produzidas | ______ |
| Tentativas de transferência | ______ |
| Transferência sem mapa completo | Sim / Não |
| Conseguiu executar sem explicação extra? | Sim / Parcialmente / Não |

### 7.3 Classificação final por dimensão

| Dimensão | 0 | 1 | 2 |
|---|---|---|---|
| Compreensão | Não reconheceu a função | Reconheceu com apoio | Reconheceu funcionalmente |
| Recuperação | Não produziu | Produziu após pista ou consulta | Produziu antes da consulta |
| Pronúncia funcional | Impediu a compreensão | Compreensível com instabilidade | Funcional para a tarefa |
| Transferência | Repetiu ou não produziu | Transferiu com apoio | Transferiu sem mapa completo |

## 8. Critério de sucesso do piloto

A sessão produz um sinal positivo quando:

- o participante entende o fluxo sem uma explicação individual longa;
- realiza a primeira tentativa antes de ver o mapa completo;
- identifica o elemento variável em **我叫 + nome**;
- consegue produzir pelo menos três variações controladas;
- entende a finalidade do mapa lacunado;
- realiza uma transferência em situação nova;
- percebe uma diferença entre o material e um simples resumo;
- consegue dizer qual tipo de apoio deve diminuir na próxima revisão.

O piloto não precisa produzir pronúncia perfeita. Ele precisa mostrar que o material organiza a prática e permite uma produção funcional. A avaliação tonal detalhada pertence a uma etapa linguística específica e não deve ser inferida apenas pela observação desta aula.

## 9. Decisão após a sessão

Ao final de cada teste, classificar a aula em uma das três situações:

### Prosseguir

Usar quando o participante executa o fluxo com pouca ajuda, realiza a transferência e identifica valor no mecanismo de suporte progressivo.

### Corrigir antes de ampliar

Usar quando o conceito funciona, mas há problemas de densidade, instrução, ordem das páginas, lacunas ou excesso de decoração.

### Reconsiderar o formato

Usar quando o participante apenas lê as respostas, não entende a diferença entre os estados ou não percebe valor além de um resumo. Nesse caso, não produzir as sete aulas restantes. Corrigir primeiro a arquitetura da experiência.

## 10. Encerramento falado

**Fala do facilitador:**

> Obrigado. O teste de hoje não mede se você é um bom ou mau aluno. Ele mostra onde o material consegue ajudar e onde ainda cria esforço desnecessário.
>
> A proposta é que o mapa torne a estrutura visível, mas que a recuperação torne essa estrutura disponível e que a transferência prove se ela pode ser usada em uma situação nova.
>
> Vou usar suas observações para decidir o que deve ser mantido, simplificado ou removido antes da produção das próximas aulas.

## 11. Gabarito reservado do facilitador

Esta seção deve ficar em uma cópia separada da versão entregue ao participante.

```text
你好。
Nǐ hǎo.

你叫什么名字？
Nǐ jiào shénme míngzi?

我叫 + [nome]。
Wǒ jiào + [nome].

你呢？
Nǐ ne?
```

A ordem de consulta do facilitador deve ser:

1. permitir a tentativa;
2. registrar a resposta do participante;
3. oferecer uma pista funcional, se necessária;
4. revelar a forma de apoio;
5. pedir uma nova produção;
6. registrar o nível de suporte usado.

## Referências

[1]: ../README.md "README do projeto Mandarim em Rede"
[2]: ./aula-piloto-01-estrutura.md "Estrutura da Aula-piloto 01 — Mandarim em Rede"
[3]: ./mandarim-em-rede-pdf-01-aulas.md "Mandarim em Rede 01 — Fundamentos de Transferência Oral"
[4]: ./mandarim-em-rede-frame-textual.txt "Frame textual do sistema visual Mandarim em Rede"
[5]: ./plano-acao-mandarim-em-rede-90-dias.md "Plano de Ação de 90 Dias — Mandarim em Rede"
[6]: ./mandarim-em-rede-auditoria-estresse.md "Auditoria de estresse e reconstrução definitiva — Mandarim em Rede"

— **Manus AI**

2026-09-07
