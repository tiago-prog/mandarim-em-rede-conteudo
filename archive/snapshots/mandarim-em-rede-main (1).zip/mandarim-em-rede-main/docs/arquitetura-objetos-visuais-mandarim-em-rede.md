# Arquitetura de objetos visuais — Mandarim em Rede

## Conclusão

A revalidação confirma que a família existente possui uma identidade visual coerente, mas algumas páginas ainda reúnem operações diferentes. O caso mais evidente é o `W1-pratica-de-escrita.svg`, que mistura escrita, prática oral, ordem dos traços e vocabulário. Essa mistura reduz a clareza da página e dificulta sua reutilização.

A nova regra editorial é simples:

> **Cada página deve ter um objeto pedagógico dominante. Os apoios permitidos devem servir a esse objeto, não competir com ele.**

Por isso, a família passa a separar escrita, exercício de caractere, pronúncia, contraste, vocabulário e quiz em moldes próprios. A identidade visual permanece compartilhada, mas a densidade, o espaço de resposta e o verbo de ação mudam conforme a função.

## 1. Regra de separação por objeto

Uma página é aprovada quando o aluno consegue responder, em até cinco segundos, a três perguntas: **o que faço, com qual objeto e qual evidência registro?** O título deve conter um verbo ou uma ação inequívoca. Elementos secundários podem aparecer somente quando ajudam a executar a ação principal.

| Objeto dominante | Ação principal | Não deve ser misturado com |
|---|---|---|
| Escrita de caractere | Escrever o caractere com referência mínima | Exercício oral, vocabulário extenso, quiz |
| Exercício de caractere | Reconhecer, recuperar ou produzir um caractere | Tabela de aula, mapa radial, explicação longa |
| Pronúncia e tons | Ouvir, imitar, comparar e registrar um foco sonoro | Lista de gramática ou grande vocabulário |
| Contraste funcional | Escolher entre duas formas em uma situação | Aula inteira ou mapa completo |
| Vocabulário funcional | Organizar palavras por contexto e função | Grade de escrita ou checklist de domínio |
| Quiz de transferência | Demonstrar recuperação e uso | Resposta visível ou explicação extensa |
| Anotações e revisão | Registrar evidência e próxima ação | Novo conteúdo linguístico |

## 2. Família final de moldes

| Código | Arquivo | Objeto dominante | Estado |
|---|---|---|---|
| C0 | `C0-capa-colecao.svg` | Identidade e promessa da coleção | Mantido e revalidado |
| A0 | `A0-abertura-tematica.svg` | Contextualização de módulo ou aula | Mantido e revalidado |
| R1 | `R1-roteiro-de-aula.svg` | Sequência metodológica da aula | Mantido como template-mãe |
| R2 | `R2-mapa-de-aula.svg` | Relações entre intenção, padrão e transferência | Mantido e revalidado |
| R3 | `R3-recombinacao-oral.svg` | Recombinação de componentes | Mantido e revalidado |
| R4 | `R4-transferencia-autoavaliacao.svg` | Uso em situação nova | Mantido e revalidado |
| R5 | `R5-consolidacao-modulo.svg` | Integração de funções | Mantido e revalidado |
| V1 | `V1-revisao-autoavaliacao.svg` | Verificação de domínio | Mantido e revalidado |
| W1 | `W1-pratica-de-escrita.svg` | Escrita limpa de até três caracteres | Refeito como página exclusiva |
| W2 | `W2-exercicio-de-caractere.svg` | Exercício isolado de reconhecimento e produção | Novo |
| P1 | `P1-pronuncia-e-tons.svg` | Foco auditivo e produção tonal | Novo |
| X1 | `X1-contraste-funcional.svg` | Decisão entre formas próximas | Novo |
| S1 | `S1-vocabulario-funcional.svg` | Vocabulário agrupado por situação | Novo |
| Q1 | `Q1-quiz-de-transferencia.svg` | Quiz sem resposta visível | Novo |
| N1 | `N1-anotacoes-e-revisao.svg` | Registro pós-prática e próxima ação | Novo |

## 3. Decisões específicas para a escrita

`W1` deixa de ser uma página híbrida. Ela contém somente título, instrução de escrita, até três cartões de caracteres, pinyin tonal, sentido funcional, referência externa para ordem dos traços e grades Tianzige vetoriais. Não há prática oral associada, vocabulário complementar ou quadro de frases.

`W2` é a página de exercício de caractere. Ela não tenta ensinar uma aula inteira. O aluno observa uma referência curta, cobre ou ignora o modelo, identifica o caractere a partir de um prompt funcional, escreve de memória e marca o tipo de erro. O espaço de resposta é o objeto central da composição.

A ordem dos traços continua sendo um campo que exige fonte externa verificada. O molde não inventa sequências, animações ou setas de traço.

## 4. Critérios de aprovação visual

Todos os moldes devem preservar A4 vertical, texto editável, caracteres simplificados editáveis, pinyin com tons, camadas nomeadas e ausência de rasterização do conteúdo crítico. Os elementos compartilhados continuam sendo moldura, filete, nuvens marginais, montanhas discretas, rodapé e paleta funcional.

A página deve funcionar em colorido e em escala de cinza. A cor pode orientar, mas cada distinção deve ter também rótulo, borda, posição, hachura, tracejado, checkbox ou outra redundância visual.

## 5. Critérios de aprovação pedagógica

A resposta completa não deve aparecer antes da primeira tentativa quando a página mede recuperação. O apoio deve diminuir conforme a sequência avança: mapa completo, mapa lacunado, prompt mínimo e produção sem mapa. Uma página de escrita pode mostrar o caractere-modelo, porque seu objeto é a forma gráfica; uma página de quiz ou recuperação deve esconder a resposta quando a resposta for a evidência medida.

A arquitetura também preserva a distinção entre material de apoio e áudio principal. O PDF organiza relações, oferece prompts e registra evidências, mas não transcreve nem substitui o áudio externo.

## 6. Protocolo de uso na produção de uma aula

1. Use `A0` para apresentar a função e os objetivos observáveis.
2. Use `R1` para orientar a sequência completa da aula.
3. Use `R2` depois da primeira tentativa para mostrar a estrutura.
4. Use `R3` para trocar componentes controlados.
5. Use `P1`, `X1`, `S1`, `W1` ou `W2` somente quando o objeto correspondente for necessário.
6. Use `R4` para mudar a situação e registrar a transferência.
7. Use `Q1` para testar sem resposta visível.
8. Use `N1` para registrar hesitação, apoio usado e próxima revisão.
9. Use `V1` ou `R5` para revisar uma célula ou integrar um módulo.

## 7. Limites

Separar por objeto não significa criar páginas decorativas ou aumentar o volume sem necessidade. Uma aula pode usar apenas os moldes necessários. O objetivo é impedir que uma única página tente ensinar escrita, pronúncia, vocabulário, recombinação e avaliação ao mesmo tempo.

Os novos moldes são estruturas editoriais. Conteúdo linguístico novo, ordem de traços, pinyin, traduções e respostas devem ser revisados antes da publicação de cada aula.

## Referências

[1]: arquitetura-colecao-pdfs.md "Arquitetura da coleção de PDFs"

[2]: prompt-mestre-refinamento-mandarim-em-rede.md "Prompt-mestre de refinamento — Mandarim em Rede"

[3]: estresse-maximo-moldes-mandarim-em-rede.md "Teste de estresse máximo — Moldes visuais do Mandarim em Rede"

[4]: aula-01-modelo-pronto-para-pdf.md "Aula 1 — Modelo editorial pronto para diagramação"

[5]: ../moldes/README.md "Moldes SVG — Mandarim em Rede"

— **Manus AI**

2026-09-08
