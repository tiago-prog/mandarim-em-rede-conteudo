# Auditoria de estresse e reconstrução definitiva — Mandarim em Rede

## 1. Diagnóstico de fragilidade estrutural

O conceito original tem uma direção correta: preservar o áudio como núcleo e usar mapas para organização e transferência. Contudo, ainda descreve uma intenção de produto mais do que um sistema operacional. As fragilidades abaixo precisam ser resolvidas antes de qualquer produção de conteúdo.

1. **Diferenciação insuficientemente defensável.** “Mapas mentais para Pimsleur” não é, sozinho, uma categoria protegida. Flashcards, pinyin, transcrições, quizzes, áudio, leitura e revisão já aparecem no próprio ecossistema Pimsleur e em concorrentes como Anki e ChinesePod.[1][2][3]
2. **Benefício central ainda abstrato.** “Organizar e recombinar” precisa converter-se em comportamentos observáveis: produzir uma estrutura nova, responder a um estímulo alterado e transferir o padrão para uma situação não vista.
3. **Ausência de unidade pedagógica definida.** O conceito alterna entre lição, mapa, rede, intenção, padrão e sessão sem estabelecer qual é a menor unidade de estudo, revisão e avaliação.
4. **Alinhamento com Pimsleur potencialmente ambíguo.** Referenciar lições sem definir o limite entre indexação legítima, reprodução de conteúdo e sugestão de afiliação cria risco de marca, propriedade intelectual e confiança.
5. **Pimsleur tratado como se fosse apenas áudio.** A oferta atual inclui leitura, flashcards, quizzes, exercícios e Voice Coach; portanto, o diferencial não pode ser simplesmente adicionar uma camada visual.[1]
6. **Pureza Pimsleur formulada de modo incompleto.** Preservar antecipação e recuperação não significa proibir toda representação escrita; significa controlar o momento em que ela aparece e impedir que entregue a resposta antes da tentativa.
7. **Mapas definidos por estética, não por diagnóstico.** O conceito estabelece cores e tipologias, mas não informa qual erro ou operação cognitiva cada mapa pretende corrigir.
8. **Carga cognitiva potencialmente excessiva.** Pinyin, tons, caracteres, tradução, função sintática, variações e alertas para brasileiros podem sobrecarregar o iniciante se forem exibidos simultaneamente.
9. **Não há política de desaparecimento do suporte.** O mapa é descrito como apoio, mas não há protocolo que determine quando retirar tradução, pinyin, ramos e exemplos.
10. **Revisão espaçada sem mecanismo próprio.** Dizer que haverá revisões não define agenda, gatilho de falha, prioridade ou critério de domínio. O Anki já ocupa o território de agendamento adaptativo; não se deve competir com ele.[2]
11. **Transferência social não operacionalizada.** HelloTalk e ambientes de intercâmbio já cobrem contato humano, voz, vídeo e correções. O produto precisa definir como prepara o aluno para esse ambiente, sem prometer substituí-lo.[4]
12. **Ausência de protocolo de feedback fonético.** Um mapa pode sinalizar tons e dificuldades, mas não escuta o aluno nem valida sua produção. Não deve prometer correção de pronúncia que exige áudio, IA validada ou interlocutor.
13. **Público amplo demais.** Iniciante absoluto, usuário intermediário, estudante orientado a HSK e pessoa interessada em conversação não têm a mesma necessidade. O produto precisa escolher um usuário primário.
14. **Dependência estrutural de um ecossistema externo.** Mudanças nas unidades, nomenclatura ou recursos do Pimsleur podem quebrar o alinhamento. A arquitetura deve sobreviver por objetivos comunicativos e padrões, usando referências externas apenas como índice auxiliar.
15. **Evidência pedagógica superestimável.** Há evidência favorável para prática espaçada e concept mapping, mas isso não prova automaticamente ganho de fluência, tons ou transferência. Uma meta-análise recente encontrou efeito positivo para concept mapping, enquanto estudo experimental sobre crianças não encontrou efeito principal consistente de mind mapping; o uso precisa ser ativo e testado.[5][6]
16. **Falta de especificação comercial.** O conceito não define por que alguém pagaria por ele em vez de montar um deck, baixar um mapa ou usar o material oficial.
17. **Ausência de métricas de sucesso.** Não há indicadores de retenção tardia, latência de resposta, recombinação, compreensão e transferência.
18. **Risco de virar um curso concorrente.** Quanto mais explicações, exemplos e sequências independentes forem adicionados, mais o produto deixa de ser companion e passa a disputar a função do áudio.

### Correção estratégica

O produto deve ser redefinido como uma **camada de transferência pós-recuperação**, indexada ao percurso do usuário, independente e não oficial, cujo resultado verificável é a capacidade de **recombinar e aplicar repertório ouvido**. O diferencial não é o mapa pronto; é o sistema que transforma uma recuperação do áudio em produção nova, com retirada progressiva do suporte.

## 2. Teste de pureza metodológica Pimsleur

### O que deve ser preservado

A essência relevante do Pimsleur inclui o Graduated Interval Recall, o Principle of Anticipation, vocabulário nuclear, aprendizagem conversacional e prioridade para escuta e fala.[1] O companion deve preservar três condições:

- o aluno tenta responder antes de ver ou ouvir a resposta;
- o áudio continua sendo a fonte primária de input e o motor da recuperação;
- o material visual entra para organizar, contrastar, recombinar e transferir, não para substituir a prática auditiva.

### Onde o conceito original pode trair o método

**Transcrição antecipada:** mostrar pinyin, tradução ou estrutura completa antes da tentativa reduz a necessidade de recuperação.

**Mapa durante o áudio:** acompanhar visualmente cada frase transforma escuta ativa em leitura guiada e pode ocultar dificuldades auditivas.

**Excesso de gramática:** explicar uma regra antes de o aluno tentar produzir desloca o foco da antecipação para análise declarativa.

**Resposta pronta no mapa:** um mapa totalmente preenchido permite reconhecimento, mas não mede recuperação.

**Repetição visual sem áudio:** repetir a aparência da estrutura pode dar falsa sensação de domínio sem testar percepção tonal ou compreensão.

**Expansão prematura:** oferecer muitas variações antes de o padrão-base estar estável aumenta a carga e enfraquece o vocabulário nuclear.

### Regra de pureza metodológica

> Nenhuma tela, mapa ou explicação pode reduzir a obrigação do aluno de tentar recuperar a resposta. Se o suporte visual entrega a resposta antes da tentativa, ele está metodologicamente mal posicionado.

### Protocolo de uso correto

1. O áudio é realizado sem acompanhamento visual.
2. O aluno registra somente falhas relevantes, sem pausar para consultar cada detalhe.
3. O mapa completo é consultado depois da sessão para organizar o conteúdo.
4. O aluno pratica uma versão incompleta do mapa.
5. O aluno retorna ao áudio ou a um estímulo equivalente e responde sem o mapa.
6. A revisão posterior usa cada vez menos suporte.

O companion não deve alegar reproduzir a “experiência Pimsleur”. Ele deve declarar que **protege seus princípios de recuperação e acrescenta uma camada de transferência**.

## 3. Teste de carga cognitiva e usabilidade real

O conceito original é sustentável apenas se os mapas forem tratados como instrumentos de decisão, e não como pôsteres completos do idioma. O aluno comum não pode precisar interpretar uma rede complexa enquanto tenta lembrar tons, significado e ordem dos constituintes.

### Principais pontos de sobrecarga

- exibição simultânea de caracteres, pinyin, tons, tradução e função gramatical;
- mapas com múltiplas intenções comunicativas;
- excesso de cores competindo por atenção;
- explicações longas ao lado de diagramas;
- referências cruzadas que exigem navegação constante;
- revisões sem prioridade explícita;
- exercícios que pedem criação livre antes de haver repertório suficiente;
- necessidade de aprender a legenda visual antes de aprender mandarim.

### Solução de usabilidade: visualização progressiva

Cada mapa deve possuir quatro estados:

| Estado | O que aparece | Função |
|---|---|---|
| Apoio | intenção, tradução funcional, pinyin e padrão | compreender o sistema após o áudio |
| Recuperação | núcleo e lacunas, sem resposta completa | reconstruir a estrutura |
| Transferência | intenção, contexto e alguns gatilhos | gerar frase nova |
| Independência | somente situação ou prompt oral | demonstrar autonomia |

A regra é simples: **o mapa deve ficar menor à medida que o aluno fica melhor**. Se o produto exige o mesmo mapa completo no final, ele produz dependência.

### Unidade de uso recomendada

A menor unidade deve ser a **célula de transferência**: uma intenção comunicativa, um padrão produtivo, um conjunto pequeno de substituições, uma dificuldade de pronúncia relevante e uma tarefa oral de transferência. Um mapa pode reunir várias células relacionadas, mas cada célula deve ser avaliável isoladamente.

### Limite operacional

Um mapa de uso diário deve conter, como padrão:

- um núcleo;
- no máximo cinco ramos primários;
- no máximo três itens críticos por ramo;
- uma única tarefa principal de recuperação;
- uma única tarefa principal de transferência.

Exceções devem ser justificadas por integração cumulativa, não por desejo de incluir tudo.

## 4. Teste de diferenciação brutal

### Pimsleur

O Pimsleur já oferece áudio, repetição, leitura, flashcards, quizzes, exercícios e Voice Coach. Portanto, “material complementar visual” é uma descrição de formato, não uma vantagem. A posição defensável é: **organização de relações e transferência para usuários brasileiros que já fizeram a recuperação auditiva**.[1]

### Anki

Anki domina flashcards, mídia, personalização, histórico e agendamento de revisão. Não se deve competir prometendo scheduler, deck infinito ou retenção automatizada. O produto deve ocupar a lacuna entre um item lembrado e uma estrutura recombinada em contexto.[2]

### HelloTalk

HelloTalk domina o ambiente social de prática com texto, voz, vídeo, correções e comunidade. Mandarim em Rede deve preparar o aluno para usar esse ambiente, oferecendo prompts de transferência e protocolos de preparação, sem prometer interlocutores ou feedback humano.[4]

### ChinesePod

ChinesePod ocupa biblioteca multimídia, transcrições, vocabulário, diálogo, notas, exercícios e grande variedade de temas. Mandarim em Rede não deve tentar ser uma biblioteca geral ou curso audiovisual. Sua unidade é a rede de relações derivada do repertório do aluno, não uma nova coleção de lições.[3]

### Materiais genéricos de mapas mentais

Mapas genéricos podem resumir, mas não necessariamente provocam recuperação, contraste ou transferência. A vantagem só é defensável se cada mapa tiver uma função diagnóstica, uma versão incompleta, uma tarefa oral e uma regra de retirada do suporte. A literatura recente sugere potencial para concept mapping, mas também exige cautela: mapas não são substitutos automáticos de retrieval practice.[5][6]

### Diferencial final que precisa ser assumido

Mandarim em Rede deve vender uma promessa específica e mensurável:

> **Depois de ouvir e recuperar uma estrutura, o aluno consegue enxergar sua arquitetura, reconstruí-la com menos apoio, recombiná-la em novas frases e prepará-la para uso social.**

Essa promessa é mais estreita que “aprender mandarim”, mas é precisamente por isso mais defensável.

## 5. Elevação dos dez blocos do conceito

### 1. Nome definitivo

**Versão atual:** Mandarim em Rede — Companion visual de mapas mentais para transformar o áudio Pimsleur em fala espontânea.

**Falhas:** o nome é bom, mas “fala espontânea” promete um resultado amplo demais e não comunica não oficialidade.

**Versão aprimorada:**

# Mandarim em Rede
## Sistema visual de transferência oral para estudantes de mandarim que usam Pimsleur

A promessa passa de espontaneidade genérica para transferência oral observável. A relação com Pimsleur é descrita como público-alvo, não como endosso. A comunicação comercial deve acrescentar: **companion independente, não oficial**.

### 2. Posicionamento e proposta de valor

**Versão atual:** transforma áudio em estrutura visual de produção oral.

**Falhas:** poderia descrever dezenas de produtos e não define o momento de uso.

**Versão aprimorada:** Mandarim em Rede é a camada pós-áudio que converte recuperação auditiva em transferência: após tentar responder, o aluno visualiza relações entre intenção, padrão, som, pinyin, tom, significado e variações; depois pratica com suporte decrescente até produzir uma resposta nova sem consultar o mapa.

### 3. Pilares pedagógicos

**Versão atual:** oito bons princípios, porém parcialmente sobrepostos.

**Falhas:** falta mensuração e separação entre princípio, formato e resultado.

**Versão aprimorada:** os pilares devem ser regras de design testáveis, apresentados na seção 6.

### 4. Arquitetura conceitual

**Versão atual:** cinco camadas macro, da orientação à consolidação.

**Falhas:** mistura organização editorial com progressão cognitiva e não define o papel de cada artefato.

**Versão aprimorada:** a arquitetura final deve ser composta por quatro planos simultâneos: índice de percurso, células de transferência, mapas de rede e protocolos de revisão. Ver seção 7.

### 5. Sistema de mapas

**Versão atual:** seis tipos, oito cores e regras de hierarquia.

**Falhas:** tipologia pode gerar excesso de formatos; o código de cores pode tornar-se decoração; mapa completo ainda é tratado como objeto principal.

**Versão aprimorada:** reduzir para quatro famílias funcionais e obrigar cada mapa a ter versão completa, versão de recuperação e versão de transferência. Ver seção 8.

### 6. Público-alvo

**Versão atual:** varia de iniciante absoluto a iniciante avançado.

**Falhas:** amplitude excessiva e ausência de comportamento de compra.

**Versão aprimorada:** usuário primário é adulto brasileiro iniciante ou falso iniciante que já utiliza Pimsleur pelo menos quatro vezes por semana, valoriza fala, não quer começar por caracteres e sente dificuldade em reutilizar frases fora da sequência do áudio.

### 7. Jornada de uso

**Versão atual:** preparação, áudio, reconstrução, recombinação, reteste e registro.

**Falhas:** ainda é uma rotina idealizada sem limite temporal e sem critérios de parada.

**Versão aprimorada:** a jornada deve caber em 25–35 minutos, separar claramente áudio de consulta visual e terminar sempre com uma produção sem suporte. O aluno não deve abrir o mapa durante o bloco principal de áudio.

### 8. Excelência e anti-padrões

**Versão atual:** lista extensa de boas práticas.

**Falhas:** vários itens são aspiracionais e não auditáveis.

**Versão aprimorada:** cada exigência deve ser convertida em teste: “cada mapa tem prompt de recuperação”, “cada cor tem uma função”, “nenhuma página exige leitura durante o áudio”, “cada unidade tem critério de domínio”.

### 9. Tom e identidade

**Versão atual:** instrutor calmo, preciso e pragmático.

**Falhas:** correta, mas genérica; não define comportamento editorial.

**Versão aprimorada:** a voz deve ser diagnóstica: nomeia a operação, mostra o erro provável, dá uma tentativa, reduz o suporte e declara o limite do material. Não elogia exposição; reconhece desempenho observável.

### 10. Resumo executivo

**Versão atual:** forte, porém ainda descreve potencial.

**Falhas:** não explicita a tese competitiva, o não-oficial, os limites de evidência e as métricas.

**Versão aprimorada:** ver a seção 10, que define o produto como sistema de transferência e não como PDF de mapas.

## 6. Redefinição dos oito pilares pedagógicos

### Pilar 1 — Antecipação inviolável

**Regra:** nenhuma resposta completa, transcrição ou tradução funcional pode aparecer antes da primeira tentativa do aluno.

**Teste:** em toda célula, deve existir uma etapa de tentativa sem resposta visível. Se o aluno pode concluir o exercício apenas reconhecendo a página, a célula falha.

### Pilar 2 — Uma célula, uma operação

**Regra:** cada célula de transferência deve treinar uma operação dominante: perguntar, negar, confirmar, localizar, pedir, descrever, combinar ou modificar.

**Teste:** o editor deve completar a frase “o aluno está treinando para fazer X”. Se houver dois verbos principais, dividir a célula.

### Pilar 3 — Recombinação limitada e produtiva

**Regra:** toda estrutura ensinada deve distinguir componentes fixos, substituíveis e opcionais.

**Teste:** após dominar o modelo, o aluno deve gerar pelo menos três variações controladas sem receber uma frase inteira pronta.

### Pilar 4 — Progressão do suporte ao desaparecimento

**Regra:** cada célula precisa ter estados de apoio, recuperação, transferência e independência.

**Teste:** deve existir uma versão em que o mapa entrega somente intenção, contexto ou gatilho; a versão completa não pode ser a única forma de prática.

### Pilar 5 — Áudio como fonte primária

**Regra:** o mapa nunca deve ser necessário para executar o bloco principal de escuta e resposta.

**Teste:** o aluno consegue realizar a sessão sem abrir o PDF; o PDF é usado depois para organizar e transferir.

### Pilar 6 — Contraste orientado a erro brasileiro

**Regra:** toda explicação em português deve existir para prevenir uma confusão concreta entre o mandarim e o português brasileiro, ou entre dois elementos do mandarim.

**Teste:** se a nota não muda uma decisão de produção ou compreensão, ela deve ser removida.

### Pilar 7 — Recuperação cumulativa

**Regra:** conteúdo novo deve reativar conteúdo anterior em combinações diferentes, sem transformar toda revisão em repetição da ordem original.

**Teste:** cada bloco de consolidação deve conter pelo menos uma tarefa que combine células de momentos distintos.

### Pilar 8 — Domínio medido por transferência

**Regra:** considerar uma célula dominada somente quando o aluno compreende, recupera, pronuncia de modo funcional e transfere a estrutura para situação nova.

**Teste:** o registro de domínio deve separar as quatro dimensões; reconhecimento visual isolado nunca é aprovação.

## 7. Arquitetura final de alto desempenho

### Plano A — Índice de percurso

Organiza o material por objetivos e referências de percurso, sem copiar diálogos, roteiros ou conteúdo protegido. A referência a Pimsleur deve funcionar como índice de uso: “use depois do bloco correspondente”, não como reprodução da lição.

### Plano B — Células de transferência

Cada célula contém apenas:

- intenção comunicativa;
- padrão produtivo;
- elementos fixos e substituíveis;
- nota de pronúncia ou tom, quando necessária;
- contraste crítico, quando necessário;
- prompt de recuperação;
- prompt de transferência;
- critério de domínio.

### Plano C — Mapas de rede

Os mapas conectam células por função, estrutura, contraste, pronúncia e recorrência. A rede mostra relações; não deve ser um sumário visual de todas as informações disponíveis.

### Plano D — Protocolos de revisão

A revisão é organizada por desempenho, não apenas por calendário. Uma célula que falha em transferência retorna a um mapa de recuperação; uma célula que falha em tom recebe revisão auditiva, não mais explicação textual.

### Evolução do mapa ao longo do tempo

| Fase | Suporte visual | Exigência do aluno |
|---|---|---|
| 1. Orientação | mapa completo e tradução funcional | identificar intenção e arquitetura |
| 2. Recuperação | lacunas em componentes variáveis | reconstruir a frase após tentativa |
| 3. Recombinação | núcleo, intenção e opções limitadas | produzir variações controladas |
| 4. Transferência | contexto novo e poucos gatilhos | usar o padrão fora da sequência original |
| 5. Independência | somente situação, intenção ou estímulo auditivo | responder sem mapa |

### Critério de passagem

O aluno só avança uma célula para independência quando consegue:

- responder sem consultar a estrutura completa;
- realizar pelo menos três recombinações funcionais;
- reconhecer a estrutura no áudio;
- manter desempenho aceitável em revisão tardia;
- utilizar o padrão em uma situação que não replica o exemplo original.

### Métricas de produto

O produto deve ser validado por quatro indicadores:

1. **Retenção tardia:** desempenho após intervalo, não logo após estudo.
2. **Latência de recuperação:** tempo até iniciar uma resposta funcional.
3. **Recombinação:** número de variações corretas produzidas.
4. **Transferência:** desempenho em prompt novo, preferencialmente com avaliação auditiva e oral independente.

A hipótese do produto deve ser testada comparando áudio isolado, áudio mais mapa passivo e áudio mais mapa com recuperação ativa. Sem esse teste, não se deve afirmar que o mapa causa melhora.

## 8. Sistema de Mapas Mentais 2.0

### Quatro famílias, não seis tipos dispersos

#### A. Mapa de função

Mostra o que o aluno quer fazer e os caminhos linguísticos disponíveis. É o ponto de entrada comunicativo.

#### B. Mapa de padrão

Mostra ordem, componentes fixos, substituições e extensões. É o mecanismo de recombinação.

#### C. Mapa de contraste

Mostra duas ou mais opções que o aluno tende a confundir. É o mecanismo de discriminação e correção.

#### D. Mapa de consolidação

Liga células antigas e novas em uma tarefa de transferência. É o mecanismo de integração.

Pronúncia, tons, vocabulário e notas culturais não devem formar mapas autônomos por padrão. Eles entram como camadas dentro dessas quatro famílias e só ganham um mapa separado quando a dificuldade justificar.

### Hierarquia obrigatória

1. **Centro:** operação ou intenção única.
2. **Primeiro anel:** estrutura e decisões essenciais.
3. **Segundo anel:** substituições, contrastes ou extensões.
4. **Margem de controle:** alerta de erro, status de suporte e tarefa oral.
5. **Conexão externa:** referência a células relacionadas.

### Código de cores 2.0

- **Azul-escuro:** intenção ou operação comunicativa.
- **Azul-claro:** estrutura fixa e ordem dos constituintes.
- **Verde:** elemento substituível ou variável.
- **Laranja:** som, pinyin, tom e instrução auditiva.
- **Vermelho:** contraste crítico ou erro previsível.
- **Cinza:** tradução e informação de apoio, sempre removível.
- **Dourado:** revisão, transferência e critério de domínio.

A cor não pode ser o único sinal de significado. Todo elemento colorido deve também ter rótulo ou forma consistente, garantindo acessibilidade e impressão em escala de cinza.

### Regras de ouro

1. **Se não gera uma tentativa oral, não é mapa pedagógico; é ilustração.**
2. **Se o mapa pode ser estudado sem áudio e ainda parece completo, provavelmente ele está substituindo o método.**
3. **Se todas as respostas estão visíveis, o mapa não mede recuperação.**
4. **Se uma cor representa mais de uma função, a legenda falhou.**
5. **Se há mais de uma intenção central, há mais de um mapa.**
6. **Se uma nota não previne uma decisão errada, ela deve sair.**
7. **Se o mapa não encolhe com o progresso, ele cria dependência.**
8. **Se o aluno precisa ler um parágrafo para entender o mapa, a arquitetura visual falhou.**
9. **Se a estrutura não pode ser recombinada, ela é um exemplo, não um padrão.**
10. **Se o mapa não aponta para um teste de transferência, seu ciclo pedagógico está incompleto.**

### Formatos mínimos de cada mapa

Cada mapa deve existir em três versões editoriais:

- **Mapa de orientação:** completo, usado após o áudio.
- **Mapa de recuperação:** lacunado, usado para reconstrução.
- **Mapa de transferência:** reduzido a intenção, contexto e gatilhos.

Não são três conteúdos diferentes. São três níveis de suporte da mesma rede.

## 9. Critérios de excelência finais

### O material DEVE ter

- posicionamento explícito como companion independente e não oficial;
- uma promessa limitada à transferência e recombinação, não à fluência garantida;
- áudio como motor primário e mapa como camada posterior ou intermediária;
- unidade editorial definida como célula de transferência;
- referência ao percurso do usuário sem reproduzir conteúdo protegido;
- um teste oral associado a cada célula;
- versão completa, lacunada e reduzida de cada mapa;
- critérios de domínio separados para compreensão, recuperação, pronúncia funcional e transferência;
- hierarquia visual consistente e acessível;
- cores com semântica fixa e redundância textual/formal;
- distinção entre elementos fixos, substituíveis e opcionais;
- notas em português apenas quando alteram uma decisão de compreensão ou produção;
- protocolo explícito de retirada gradual do suporte;
- revisão cumulativa baseada em desempenho;
- preparação para situações sociais sem fingir ser uma comunidade;
- limites claros sobre o que o mapa não pode corrigir sozinho;
- validação com retenção tardia, recombinação e prompts novos;
- compatibilidade com impressão e tela;
- linguagem adulta, direta e diagnosticamente útil;
- rastreabilidade editorial de cada decisão linguística;
- proteção contra associação indevida com a marca Pimsleur;
- uma experiência diária possível em 25–35 minutos;
- uma forma de o usuário saber quando parar de consultar o mapa.

### O material NUNCA deve ter

- alegação de oficialidade, endosso ou parceria sem licença;
- reprodução integral de diálogos, roteiros, áudios ou materiais proprietários;
- mapa completo apresentado antes da primeira tentativa;
- acompanhamento visual obrigatório durante o áudio principal;
- lista de vocabulário sem função de uso;
- mapa com objetivo apenas decorativo;
- página superlotada para demonstrar riqueza de conteúdo;
- promessa de pronúncia corrigida por mera leitura;
- scheduler tentando imitar o Anki;
- biblioteca multimídia tentando imitar o ChinesePod;
- comunidade tentando imitar o HelloTalk;
- curso autônomo tentando substituir o Pimsleur;
- tradução palavra por palavra tratada como regra;
- mistura de caracteres, pinyin, tons e tradução sem hierarquia;
- exercício que testa somente reconhecimento visual;
- avanço baseado em exposição ou sensação de familiaridade;
- explicação gramatical sem operação oral associada;
- revisão que repete sempre a mesma ordem e o mesmo exemplo;
- uso de cor sem significado estável;
- dependência permanente do português;
- afirmação de eficácia causal sem teste do produto;
- exemplo que não informa uma escolha linguística;
- tom motivacional que mascara ausência de evidência;
- introdução de caracteres como requisito prematuro para fala;
- excesso de variações antes da estabilidade do padrão-base;
- promessa de substituir contato humano ou feedback especializado;
- confusão entre lembrar uma frase e saber transferir uma estrutura.

## 10. Conceito final estressado — versão definitiva

**Mandarim em Rede** é um sistema visual independente e não oficial para adultos brasileiros que usam Pimsleur e conseguem repetir parte do repertório, mas ainda não conseguem reutilizá-lo fora da sequência do áudio. O produto não é um curso paralelo, um deck, uma biblioteca multimídia ou uma comunidade: é a camada de transferência entre recuperar uma estrutura e aplicá-la em uma situação nova. Cada unidade é uma célula de transferência que liga intenção comunicativa, padrão, som, pinyin, tom, significado, contraste e variação, sempre com uma tarefa oral mensurável. O áudio continua sendo a fonte primária de escuta e recuperação; o mapa só entra depois ou entre tentativas e nunca entrega a resposta antes da antecipação. Cada mapa evolui de completo para lacunado, reduzido e finalmente dispensável. O valor premium está na curadoria contrastiva para brasileiros, na arquitetura de recombinação e na preparação para uso social, não na quantidade de páginas ou cores. O produto deve provar sua utilidade por retenção tardia, latência, recombinação e transferência, sem prometer fluência, pronúncia corrigida ou eficácia automática. Seu resultado final é um aluno menos dependente da ordem do áudio e mais capaz de gerar mandarim funcional a partir de relações compreendidas e recuperadas.

## Referências

[1]: https://www.pimsleur.com/the-pimsleur-method/ "Pimsleur — The Pimsleur Method"
[2]: https://apps.ankiweb.net/ "Anki — Official Website"
[3]: https://www.chinesepod.com/ "ChinesePod — Official Website"
[4]: https://www.hellotalk.com/en "HelloTalk — Official Website"
[5]: https://link.springer.com/article/10.1186/s40862-025-00331-2 "Concept Mapping in Second-Language Learning — Meta-analysis"
[6]: https://pmc.ncbi.nlm.nih.gov/articles/PMC3827082/ "Retrieval Practice and Mind Mapping — Experimental Study"
