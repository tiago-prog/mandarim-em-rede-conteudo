# Mandarim em Rede
## Especificação consolidada do produto, sistema pedagógico e linguagem visual

### Versão de trabalho para estresse posterior

---

## 1. Definição central

**Mandarim em Rede** é um sistema editorial e pedagógico de companions visuais independentes para brasileiros que estudam mandarim com apoio de áudio estruturado, especialmente Pimsleur.

O produto não é uma transcrição, uma apostila gramatical, um substituto do áudio nem um conjunto de páginas decorativas. É uma camada de **transferência oral**: depois de ouvir e tentar responder, o aluno usa mapas mentais e exercícios de recombinação para reconstruir padrões, substituir elementos e produzir em situações novas.

> **O áudio introduz; o mapa organiza; a recuperação disponibiliza; a recombinação amplia; a transferência comprova.**

A proposta será executada por meio de PDFs e templates visuais com identidade premium, mas o valor central está na relação entre **intenção comunicativa, padrão de fala, suporte visual progressivo e produção sem olhar**.

O material será descrito como:

> **Companion visual independente e não oficial para estudantes brasileiros de mandarim.**

Ele não é afiliado, endossado, patrocinado ou autorizado pela Pimsleur.

---

## 2. Problema que o produto resolve

O aluno pode compreender uma lição de áudio e ainda não conseguir reutilizar o padrão em uma situação diferente. Isso ocorre porque o repertório fica preso à ordem original, à voz, ao contexto ou à sequência de perguntas da lição.

O projeto resolve quatro dores conectadas:

| Dor do aluno | Resposta do sistema |
|---|---|
| “Eu reconheço, mas não consigo produzir.” | Prompts de intenção e recuperação oral |
| “Eu sei a frase, mas não consigo alterá-la.” | Mapas com componentes fixos e substituíveis |
| “Eu me perco entre pinyin, significado e uso.” | Tabela funcional e hierarquia visual |
| “Eu não sei quando realmente domino.” | Critérios observáveis de produção e transferência |

A transformação prometida não é acumular mais vocabulário. É tornar o repertório existente **reutilizável, recombinável e disponível para interação**.

---

## 3. Princípio de alinhamento com o áudio Pimsleur

O áudio continua sendo a fonte principal de escuta, antecipação, recuperação e prática oral. O companion é usado **depois da tentativa**, não como roteiro para acompanhar passivamente a faixa.

A relação correta é:

```text
SESSÃO DE ÁUDIO
      ↓
TENTATIVA SEM APOIO VISUAL
      ↓
CONSULTA DO MAPA
      ↓
RECONSTRUÇÃO DO PADRÃO
      ↓
RECOMBINAÇÃO CONTROLADA
      ↓
TRANSFERÊNCIA EM SITUAÇÃO NOVA
      ↓
REVISÃO COM MENOS APOIO
```

O material nunca deve incentivar o aluno a ler a resposta antes de tentar. Também não deve reproduzir diálogos, transcrições, áudios, vozes ou roteiros proprietários.

O conteúdo será organizado por **funções comunicativas e padrões produtivos**, e não por reprodução direta de lições externas. Referências a percurso ou nível podem ser auxiliares, mas o índice principal deve ser funcional.

---

## 4. Conceito final de aula

Uma aula do Mandarim em Rede é uma unidade de transferência oral centrada em uma função comunicativa.

> **A aula começa com uma intenção, torna visível um padrão, separa seus componentes, exige recuperação e termina com uma produção em contexto novo.**

Cada aula deve ter um objetivo mensurável. Um objetivo aceitável descreve comportamento observável:

> “Ao final, o aluno consegue realizar uma troca curta usando um padrão trabalhado, substituir pelo menos três elementos e produzir uma variação sem consultar o mapa completo.”

### Estrutura canônica da aula

```text
1. Objetivo de fala
2. Mapa mental principal
3. Padrão fixo e elementos substituíveis
4. Exemplos funcionais
5. Foco tonal ou fonético necessário
6. Recombinação controlada
7. Produção oral sem olhar
8. Critério de domínio
9. Conexões cumulativas
```

A aula deve possuir uma única operação cognitiva dominante por página. O conjunto completo pode alternar orientação, recuperação, recombinação, contraste, transferência e avaliação, mas não deve misturar todas essas operações com a mesma intensidade em uma única superfície.

### Limite de carga

Uma aula padrão deve trabalhar:

- uma função comunicativa principal;
- um padrão central;
- três a seis elementos variáveis;
- um contraste relevante;
- um foco tonal ou fonético prioritário;
- uma tarefa final de transferência.

O uso visual e oral ideal é de aproximadamente 12 a 20 minutos, além da sessão de áudio realizada separadamente.

---

## 5. Arquitetura cognitiva dos mapas

O mapa mental é o sistema nervoso do produto. Ele não é uma ilustração adicional nem um índice decorativo.

### Tipos de mapa

| Tipo | Função |
|---|---|
| Mapa de intenção | Mostra o objetivo comunicativo central |
| Mapa de padrão | Separa ordem fixa e posições substituíveis |
| Mapa de contraste | Expõe confusões de som, tom, ordem ou sentido |
| Mapa de recombinação | Mostra quais elementos podem ser trocados |
| Mapa de transferência | Conecta o padrão a uma situação nova |
| Mapa integrador | Consolida várias funções em uma interação maior |

### Estados de apoio

Todo núcleo relevante deve poder ser exibido em três níveis:

```text
MAPA COMPLETO → MAPA LACUNADO → PROMPT MÍNIMO
```

O mapa completo orienta. O mapa lacunado exige reconstrução. O prompt mínimo testa a autonomia.

O suporte deve diminuir conforme o domínio aumenta. Se o aluno sempre vê função, caracteres, pinyin, tradução e resposta ao mesmo tempo, ocorre reconhecimento visual, não recuperação ativa.

### Componentes obrigatórios de um mapa de padrão

```text
INTENÇÃO
   ↓
ESTRUTURA FIXA
   ↓
ELEMENTO SUBSTITUÍVEL
   ↓
VARIAÇÃO CONTROLADA
   ↓
CONTRASTE OU ALERTA
   ↓
PRODUÇÃO EM SITUAÇÃO NOVA
```

O sistema deve marcar de forma visível:

- **fixo:** ordem ou expressão que deve permanecer;
- **substituível:** elemento que pode mudar;
- **opcional:** expansão que não é requisito da aula;
- **alerta:** erro provável ou contraste relevante;
- **transferência:** tarefa que comprova uso independente.

---

## 6. Conteúdo linguístico

O produto usará exclusivamente:

- caracteres chineses simplificados;
- pinyin com marcas tonais;
- tradução funcional em português brasileiro;
- exemplos autorais ou devidamente licenciados;
- vocabulário essencial para a função da aula.

O conteúdo não deve assumir a forma de gramática tradicional. Explicações gramaticais só entram quando esclarecem uma escolha que afeta a produção.

### Tabela linguística padrão

A tabela-base derivada da página autoral terá quatro colunas:

| Função | Mandarim | Pinyin | Sentido funcional |
|---|---|---|---|
| [ação comunicativa] | [caracteres] | [pinyin tonal] | [tradução natural] |

Essa tabela é uma ferramenta de organização, não o exercício completo. Ela deve ser seguida por recuperação e recombinação.

### Pronúncia e tons

O sistema não promete corrigir pronúncia apenas pela leitura. Ele organiza a atenção do aluno e indica o que escutar, repetir e comparar.

Para tons, separar três competências:

```text
1. discriminar ao ouvir;
2. recuperar o tom da expressão;
3. produzir em palavra, frase e contexto.
```

A cor nunca será o único marcador de tom. Pinyin tonal, contraste explícito e áudio legítimo devem trabalhar juntos.

Para brasileiros, os alertas devem priorizar interferências que alterem a compreensão ou a produção, sem transformar cada aula em treinamento fonético exaustivo.

---

## 7. Identidade visual consolidada

A página autoral enviada é a fonte principal de direção visual. As referências anteriores servem como repertório auxiliar, mas não devem substituir a gramática autoral já estabelecida.

### Linguagem visual

A identidade combina:

- estética chinesa tradicional refinada;
- design editorial educacional contemporâneo;
- sensação premium, calma e organizada;
- alta legibilidade;
- ornamentação controlada;
- espaço negativo funcional.

A estética não deve ser infantil, excessivamente temática ou dependente de personagens.

### Paleta funcional

| Uso | Cor de referência |
|---|---|
| Azul-marinho | `#173754` |
| Creme | `#F8F2E7` |
| Dourado | `#C99E4A` |
| Coral | `#C94D3F` |
| Cinza-azulado | `#8A96A0` |
| Texto escuro | `#24323D` |

Os valores podem ser refinados no arquivo de design. A regra superior é preservar contraste e consistência.

### Significado das cores

| Cor | Significado funcional |
|---|---|
| Azul-marinho | estrutura, orientação, processo e segurança |
| Creme | área de leitura e trabalho |
| Dourado | resultado, transferência, conquista e destaque |
| Coral/vermelho | alerta, contraste e acento cultural |
| Verde ou azul-esverdeado | elementos substituíveis e variação |
| Cinza-azulado | textura, montanha e informação secundária |

A cor deve ser acompanhada de rótulo, posição, ícone ou padrão visual. O sistema precisa funcionar em escala de cinza.

### Moldura

A moldura azul-marinho com filete dourado é a assinatura da coleção. Ela deve existir em duas intensidades:

- **completa:** capa, abertura, separadores e mapas conceituais;
- **reduzida:** exercícios, fichas de escrita e páginas densas.

Nuvens, montanhas e ornamentos pertencem às margens. Nunca devem invadir pinyin, caracteres, respostas ou áreas de escrita.

---

## 8. Sistema de páginas e moldes

O núcleo operacional é formado por cinco moldes derivados da página autoral.

### R1 — Roteiro de aula

É o template-mãe. Contém:

- título funcional;
- objetivo do roteiro;
- faixa de processo;
- orientação curta;
- resultado desejado;
- conteúdo linguístico em tabela;
- textura de fundo controlada;
- rodapé e identificação de módulo.

### R2 — Mapa de aula

Contém:

- função no núcleo;
- mapa completo;
- mapa lacunado;
- legenda de fixo/substituível/alerta/transferência;
- instrução de uso;
- critério de domínio.

### R3 — Recombinação oral

Contém:

- padrão fixo;
- elementos variáveis;
- seis ou menos combinações controladas;
- prompts em português funcional;
- espaço de preparação;
- produção oral sem olhar.

### R4 — Transferência e autoavaliação

Contém:

- situação nova;
- tarefa sem mapa completo;
- checklist observável;
- escala de apoio usado;
- registro de erro;
- próxima revisão.

### R5 — Consolidação de módulo

Contém:

- mapa integrador;
- funções já trabalhadas;
- contrastes prioritários;
- tarefa cumulativa de produção;
- critério de domínio do módulo.

### Moldes acessórios

A coleção pode incluir:

- capa;
- abertura temática;
- página de proposta de valor;
- ficha de escrita de caracteres;
- separador de módulo;
- página de notas.

Esses elementos apoiam a experiência, mas não definem o núcleo pedagógico.

---

## 9. Arquitetura de uma página

Cada página operacional deve possuir três zonas:

```text
ZONA A — ORIENTAÇÃO
Título, função, tempo e objetivo.

ZONA B — OPERAÇÃO
Mapa, tabela, prompt ou exercício principal.

ZONA C — FECHAMENTO
Critério, revisão, transferência ou próxima ação.
```

A página autoral atual é classificada como **R1 — Roteiro de Aula**, e não como molde universal. Sua estrutura completa deve ser preservada para roteiros, mas compactada para exercícios.

### Faixa de processo

A faixa azul-marinho com a sequência metodológica é um componente proprietário do sistema visual do projeto. Ela deve existir em três versões:

- completa para roteiro;
- resumida para abertura;
- numerada para exercício.

### Caixa de resultado

A caixa dourada deve sempre expressar um comportamento observável. Ela não deve dizer apenas “aprender cumprimentos”; deve indicar a produção esperada, a condição e o nível de suporte.

---

## 10. Editabilidade e produção

O arquivo-mestre deve ser construído com objetos separáveis. Uma imagem achatada não é um template editável.

### Camadas do arquivo-mestre

```text
1. Fundo
2. Moldura e ornamentos
3. Estrutura de caixas e tabelas
4. Conteúdo linguístico
5. Exercícios e respostas
6. Metadados e rodapé
```

O criador deve poder alterar título, número, caracteres, pinyin, tradução, quantidade de linhas, mapa, QR code e conteúdo sem recriar a página inteira.

### Placeholders de produção

```text
[TÍTULO FUNCIONAL]
[OBJETIVO MENSURÁVEL]
[MAPA COMPLETO]
[MAPA LACUNADO]
[PROMPT DE INTENÇÃO]
[RESPOSTA — REVELAR APÓS TENTATIVA]
[CONTRASTE PRINCIPAL]
[TAREFA DE TRANSFERÊNCIA]
[CRITÉRIO DE DOMÍNIO]
```

A IA pode gerar fundos, ornamentos, montanhas, nuvens e ilustrações. O texto exato, pinyin, caracteres, tabelas, grades e mapas devem ser inseridos em uma ferramenta de edição.

---

## 11. PDF 01 dentro do sistema

O primeiro PDF é **Mandarim em Rede 01 — Fundamentos de Transferência Oral**.

Ele contém oito aulas principais e duas consolidações, organizadas em dois módulos:

```text
MÓDULO 1 — entrar na interação
MÓDULO 2 — pedir, localizar e organizar uma situação
```

A sequência didática vai de:

```text
identidade → compreensão → reparo → identificação → pedido →
localização → tempo → capacidade → preferência → transferência
```

O PDF usa os moldes R1 a R5, não uma página única repetida mecanicamente.

Cada aula deve conter uma tabela funcional, mapa de orientação, recombinações controladas, foco tonal necessário, tarefa sem olhar e critério de domínio.

---

## 12. Controle de qualidade

O sistema passa por quatro níveis de validação.

### Qualidade linguística

- caracteres simplificados corretos;
- pinyin com marcas tonais corretas;
- tradução natural em português brasileiro;
- frases adequadas à função;
- revisão por pessoa qualificada em mandarim;
- atenção a mudanças tonais e tons neutros quando relevantes.

### Qualidade pedagógica

- objetivo observável;
- tentativa antes da resposta;
- recombinação real;
- transferência para contexto novo;
- suporte que diminui;
- critério de domínio verificável.

### Qualidade visual

- hierarquia evidente;
- texto legível;
- ornamentos fora da área operacional;
- contraste em cor e escala de cinza;
- pinyin sem quebras inadequadas;
- tabelas e linhas consistentes.

### Qualidade de produção

- edição sem reconstrução da página;
- componentes reutilizáveis;
- exportação adequada para PDF;
- margens seguras;
- impressão colorida e monocromática testadas;
- versão de tela testada em celular e computador.

---

## 13. Critérios de sucesso do sistema

O sistema estará pronto para produção em série quando:

- um novo título couber sem quebrar o cabeçalho;
- uma aula com quatro ou oito linhas couber na mesma família de tabela;
- a página puder ser preenchida por outra pessoa sem explicação extensa;
- o aluno identificar a ação principal em até cinco segundos;
- a resposta não aparecer antes da tentativa;
- o mapa funcionar em versão completa, lacunada e mínima;
- a página funcionar em tela, impressão colorida e escala de cinza;
- a identidade permanecer consistente em cinco aulas diferentes;
- a decoração puder ser reduzida ou desligada;
- a produção de uma nova página for predominantemente preenchimento, não redesenho.

---

## 14. Limites absolutos

O projeto não deve:

- reproduzir transcrições ou diálogos proprietários;
- prometer oficialidade ou endosso da Pimsleur;
- depender de texto gerado diretamente dentro de imagens;
- tratar o mapa como decoração sem função de recuperação;
- transformar todas as aulas em explicações gramaticais;
- usar cor como único código de informação;
- colocar ornamento onde o aluno precisa escrever ou falar;
- preencher páginas apenas para ocupar espaço;
- confundir checklist de familiaridade com domínio oral;
- lançar uma coleção grande antes de testar os três primeiros moldes.

---

## 15. Ordem de implementação

A implementação consolidada deve seguir esta ordem:

### Etapa 1 — Congelar o sistema visual

Transformar a página autoral em R1 editável, fixando moldura, paleta, tipografia, espaçamentos, tabela e faixa de processo.

### Etapa 2 — Criar os componentes derivados

Construir R2, R3, R4 e R5 usando a mesma gramática visual.

### Etapa 3 — Testar com uma aula real

Preencher os moldes com a Aula 1 e verificar leitura, pinyin, tabela, espaço e sequência de uso.

### Etapa 4 — Testar com conteúdos diferentes

Aplicar o sistema a uma aula de apresentação, uma de pedidos e uma de localização. Ajustar somente regras do sistema, não fazer soluções isoladas.

### Etapa 5 — Testar produção e impressão

Validar edição, exportação, tela, celular, colorido, escala de cinza e margens.

### Etapa 6 — Produzir o PDF 01

Usar somente componentes aprovados e registrar qualquer exceção necessária.

### Etapa 7 — Estressar o sistema completo

Depois do primeiro PDF prototipado, executar uma auditoria de conteúdo, usabilidade, visual, editabilidade, produção e mercado.

---

## 16. Síntese final

Mandarim em Rede é um sistema de companions visuais que transforma áudio em produção oral transferível. Sua unidade fundamental é a aula de transferência, não a página de vocabulário. Cada aula começa com uma intenção, organiza um padrão em um mapa, distingue o que é fixo e substituível, exige recuperação e termina em situação nova.

A página autoral enviada é a origem visual oficial do sistema: moldura azul-marinho, creme, dourado, nuvens, montanhas, faixa de processo, caixa de resultado e tabela funcional. Ela deve ser convertida em templates editáveis, não reproduzida como imagem achatada.

A IA será usada para ativos de atmosfera e ilustração, enquanto o texto, pinyin, caracteres, tabelas, exercícios e relações dos mapas permanecerão sob controle editorial. O primeiro produto será um PDF modular, com oito aulas e duas consolidações, produzido por componentes reutilizáveis.

O sistema só será considerado bem-sucedido quando a estética reforçar a ação pedagógica, a edição puder ser feita sem reconstrução, a impressão permanecer legível e o aluno conseguir passar de mapa completo a produção sem olhar.

> **O visual cria o território. O mapa mostra as relações. A recuperação constrói acesso. A fala comprova domínio.**
