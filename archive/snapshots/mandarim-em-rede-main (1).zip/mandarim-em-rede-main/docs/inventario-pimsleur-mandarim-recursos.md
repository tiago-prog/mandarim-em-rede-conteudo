# Inventário de materiais para Pimsleur Mandarin e recursos complementares

**Data da pesquisa:** 7 de setembro de 2026  
**Escopo:** materiais oficiais, companions não oficiais, recursos orais complementares, mapas mentais, SRS, recursos para brasileiros e comunidades.  
**Critério:** priorizei produção oral, compreensão auditiva, recuperação ativa, espaçamento, rastreabilidade e utilidade prática. Materiais de fã não são tratados como oficiais.

## Nota metodológica

**Oficial** significa hospedado ou comercializado pela Pimsleur/Simon & Schuster. **Licenciado/comercial** significa distribuído por marketplace, biblioteca ou revendedor, sem implicar que a plataforma tenha produzido o conteúdo. **Fã/comunidade** significa criado por usuários, professores ou sites independentes. **Acadêmico** significa estudo, curso institucional ou material publicado por instituição. Confiança alta indica existência e escopo verificáveis, não eficácia pedagógica comprovada.

A oferta oficial atual usa a nomenclatura **Chinese (Mandarin), Levels 1–5**. A página oficial informa 30 lições conversacionais por nível e aproximadamente 100 exercícios de leitura no conjunto. Catálogos antigos utilizam **Phase/Unit**, **Course/Level**, CDs e outras distribuições. A equivalência completa entre as edições antigas e o aplicativo atual não foi encontrada em uma ficha editorial única.

---

# 1. Inventário completo de Pimsleur Mandarin

## 1.1 Materiais oficiais atuais

| Material | Status e formato | Cobertura | Valor para produção oral | Limitações |
|---|---|---|---|---|
| [Learn to Speak Chinese (Mandarin)](https://www.pimsleur.com/learn-chinese-mandarin/) | Oficial; app/web, lições de áudio, leituras, flashcards, quizzes, Voice Coach, role-play e offline | Levels 1–5; 30 lições conversacionais por nível, segundo a página | **Muito alto.** A própria Pimsleur declara Principle of Anticipation, Graduated Interval Recall, participação ativa e foco em escuta/fala | É descrição comercial; não apresenta estudo independente específico de Mandarin, currículo lição a lição ou equivalência HSK/CEFR |
| [Lifetime Access: Chinese Mandarin](https://www.pimsleur.com/learn-chinese-mandarin/lifetime-subscription/) | Oficial Premium; compra vitalícia no app/web | Levels 1–5; a página informa cerca de 15 horas e 30 lições por nível | **Muito alto.** Inclui áudio, flashcards, Quick Match, Speed Round, Speak Easy, Voice Coach e transcrições para role-play | Recursos, preço e condições dependem da plataforma e da licença comercial |
| [Chinese Mandarin Audio Monthly](https://www.pimsleur.com/learn-chinese-mandarin/subscription-audio/) | Oficial; assinatura de áudio, incluindo CarPlay e Android Auto | A página específica não discrimina níveis; a página geral descreve Levels 1–5 | **Alto.** É a versão mais diretamente hands-free e audio-first | A tabela informa ausência de vários recursos Premium; não se deve presumir que inclua leituras, flashcards ou Voice Coach |
| [The Pimsleur Method](https://www.pimsleur.com/the-pimsleur-method/) | Oficial; página metodológica, não curso separado | Transversal aos cursos | **Muito alto como referência metodológica.** Define antecipação, recuperação graduada, vocabulário nuclear e conversação | É posicionamento institucional, não validação independente de eficácia |
| [Ways to Use Active Recall for Faster Language Learning](https://www.pimsleur.com/blog/ways-to-use-active-recall-for-faster-language-learning/) | Oficial; artigo editorial | Transversal | Explica active recall, falar a resposta, flashcards, Quick Match, Speed Round e Speak Easy | Não é específico de mandarim e não apresenta resultados experimentais |

### Avaliação oficial

O núcleo oficial é o material mais alinhado ao Pimsleur e deve permanecer como fonte primária de áudio, ritmo, antecipação e pronúncia. O companion visual não deve substituir as lições nem competir com os recursos oficiais de revisão. A oportunidade está em organizar relações entre estruturas e preparar transferência para situações novas.

## 1.2 Edições antigas e distribuições licenciadas

| Material | Status | Utilidade | Cautelas |
|---|---|---|---|
| [Pimsleur Chinese Mandarin Audiobooks — Audible](https://www.audible.com/series/Pimsleur-Mandarin-Chinese-Audiobooks/B01CRMRLRI) | Marketplace/licenciado; série de audiolivros | A página lista volumes de cinco lições, cobrindo Levels 1–5 | Disponibilidade e recursos variam por região; não equivale automaticamente ao Premium atual |
| [Chinese (Man) Phase 1, Unit 01](https://www.audible.com/pd/Chinese-Man-Phase-1-Unit-01-Audiobook/B0038KRF1G) | Edição legada em marketplace | Confirma a nomenclatura Phase/Unit e o desenho de uma unidade de áudio | Uma unidade não permite reconstruir a progressão; não mapear automaticamente para o app atual |
| [Basic Course Level 1 Lessons 1–10](https://www.audioeditions.com/pimsleur-chinese-mandarin-basic-course-level-1-lessons-1-10) | Pacote físico/CD legado | Útil para documentar edições antigas e revisão dentro das lições | DRM, app proprietário e disponibilidade histórica; não contém recursos Premium |
| [Pimsleur Chinese Mandarin Level 3 MP3](https://share.libbyapp.com/title/389991) | Catálogo de biblioteca/OverDrive | Ficha informa 30 lições, cerca de 16 horas e 60 minutos de leitura de pinyin | Edição de 2010; disponibilidade depende da biblioteca; não é curso atual do app |

## 1.3 O que não foi localizado no material oficial

Não foi encontrada uma ficha editorial direta que mapeie de forma completa **Levels 1–5, Phase/Unit, Course/Level, CDs, ISBNs e revisões**. Também não foi encontrado estudo acadêmico independente específico que meça retenção, pronúncia, tons, produção espontânea ou equivalência CEFR/HSK do Pimsleur Mandarin.

Não foi verificado nenhum companion oficial exportável, mapa mental oficial, transcrição atual autorizada ou deck de Anki oficial distribuído separadamente. A Pimsleur oferece recursos internos no próprio aplicativo, mas isso não equivale a uma licença de material externo.

---

# 2. Melhores companions encontrados

## 2.1 Decks de Anki

| Material | Formato e escopo | Pontos fortes | Pontos fracos | Alinhamento |
|---|---|---|---|---|
| [Pimsleur Chinese (Mandarin) — AnkiWeb](https://ankiweb.net/shared/info/2002391726) | Deck de aproximadamente 47 MB, 2.055 notas/áudios aparentes; descrição menciona cinco unidades, 150 lições e 30 bônus | Recuperação bidirecional, áudio e SRS do Anki; maior cobertura encontrada | Descrição incompleta; edição, fonte, licença e qualidade do áudio não são claras; vocabulário não é diálogo | **Alto** para recall/SRS; **médio** para oralidade |
| [Pimsleur Mandarin I — Caleb Plakun](https://ankiweb.net/shared/info/915822283) | 299 notas, 293 áudios; simplificado, tradicional, pinyin, inglês e unidade | Frases, áudio e cartões “Listen and Repeat” aproximam-se da prática oral | Áudio autogerado pelo Google Translate; pinyin e tradicional automáticos podem conter erros; Mandarin I apenas | **Alto** para frases/SRS; **médio** para oralidade |
| [Pimsleur Mandarin Chinese 1, 2 & 3](https://ankiweb.net/shared/info/1938448573) | Deck de 65 MB, 507 áudios, cursos 1–3 conforme o autor | Combina caracteres, pinyin, significado, exemplos e voz | O autor declara ter transcrito e recortado vozes; licença e revisão não demonstradas | **Alto** para revisão; cautela jurídica e editorial |
| [Pimsleur Mandarin 1 English](https://ankiweb.net/shared/info/21579434) | 216 notas, sem áudio/imagens, definições, pinyin e measure words | Simples, pequeno e explicitamente suplementar | Versão de 2018; sem áudio; sentidos extras podem afastar-se do contexto | **Médio** para recall; **baixo** para oralidade |

### Julgamento

O deck de cinco unidades é o mais promissor para revisão lexical ampla. O deck de Mandarin I com frases é o mais próximo de um companion oral, mas exige auditoria de pinyin, tons e áudio. Nenhum deck substitui a sequência de antecipação, o ritmo e o feedback do curso oficial.

## 2.2 Quizlet, Brainscape e materiais de revisão

| Material | Escopo | Avaliação |
|---|---|---|
| [Pimsleur Mandarin Chinese 1: Lessons 1–15](https://quizlet.com/173548496/pimsleur-mandarin-chinese-1-lessons-1-15-flash-cards/) | 105 termos, pinyin/inglês, Flashcards/Learn/Test | Bom para revisão rápida; não lista áudio nem SRS equivalente ao Anki |
| [Pimsleur Mandarin Chinese Level II](https://quizlet.com/162193813/pimsleur-mandarin-chinese-level-ii-vocabulary-words-flash-cards/) | 142 termos, caracteres, pinyin e inglês | Escopo verificável, mas há typos e inconsistências aparentes; conferir no áudio |
| [Pimsleur Mandarin Chinese Level 3](https://quizlet.com/812864273/pimsleur-mandarin-chinese-level-3-flash-cards/) | 122 termos, hanzi e pinyin | Útil como índice lexical; sem áudio, fala ou edição claramente identificada |
| [Pimsleur Mandarin 4](https://quizlet.com/642982824/pimsleur-mandarin-4-flash-cards/) | 430 termos | Um dos conjuntos mais amplos; predominantemente textual e sem feedback oral |
| [Pimsleur Mandarin Level 5 Lessons 1–30](https://quizlet.com/818304211/vocab-pimsleur-mandarin-level-5-lessons-1-30-flash-cards/) | 230 termos | Escopo de Level 5 explicitamente indicado; sem áudio, frases completas ou licença visível |
| [Mandarin Chinese Pimsleur — Brainscape](https://www.brainscape.com/packs/mandarin-chinese-pimsleur-3128170) | 210 cartões de Mandarin 1, com sistema adaptativo | Melhor que um conjunto estático para revisão; não documenta áudio ou feedback |

## 2.3 Transcrições e notas

| Material | Escopo | Avaliação |
|---|---|---|
| [Stanford — Course I transcript](https://theory.stanford.edu/~trevisan/chinese/pimsleur-transcript-1.pdf) | PDF de 19 páginas, unidades 1–30, pinyin e hanzi; metadados de 2005 | Útil apenas depois da tentativa oral; antigo, não oficial, sem áudio, sem autoria clara e sem revisão garantida |
| [Stanford — Course II transcript](https://theory.stanford.edu/~trevisan/chinese/pimsleur-transcript-2.pdf) | PDF de 20 páginas, unidades 2-01 a 2-30b | Mesmo valor e mesmas limitações do Course I |
| [Stanford — Course III transcript](https://theory.stanford.edu/~trevisan/chinese/pimsleur-transcript-3.pdf) | PDF de 19 páginas, unidades 3-01 a 3-30 | Útil como apoio pós-escuta; edição antiga e sem equivalência atual confirmada |
| [Stanford — vocabulary I, II e III](https://theory.stanford.edu/~trevisan/chinese/pimsleur-words-1.pdf) | Listas compactas de caracteres, pinyin e glosas | Baixa utilidade oral; há anomalias visíveis em pelo menos uma glosa; requer conferência |
| [Talk To Me In Chinese — Level 4](https://talktomeinchinese.wordpress.com/2017/02/14/vocabulary-and-dialogue-from-pimsleur-mandarin-level-4/) | HTML/PDF com diálogo, simplificado/tradicional, pinyin, inglês, classificadores e notas | Melhor que lista isolada; cobertura parcial, sem áudio e sem prova de coleção completa |
| [Pleco Forums — Mandarin 1 Study Phrases](http://www.plecoforums.com/threads/pimsleur-mandarin-1-study-phrases.2591/) | TXT de frases, colaboração e revisões comunitárias | Bom para construir cartões próprios; erros e licença não verificados |
| [Pleco Forums — Mandarin 2 Study Phrases](http://www.plecoforums.com/threads/pimsleur-mandarin-2-study-phrases-now-complete.2592/) | TXT de frases do curso II | Útil como índice legado; não é áudio, não é oficial e pode reproduzir material protegido |
| [Scribd — Companion Tapescript](https://www.scribd.com/doc/245463038/Pimsleur-Chinese-I-Companion-Tapescript) | Documento de 234 páginas | Existência verificável, mas conteúdo interno, autorização, integridade e qualidade não foram auditados; baixa confiança para uso pedagógico |

### Avaliação das transcrições

Não foi encontrado transcript completo, atual e claramente autorizado para Levels IV–V. Os PDFs Stanford são referências históricas de edição antiga, não fontes oficiais. O uso alinhado ao Pimsleur exige **tentar responder antes de consultar o texto** e não acompanhar a lição visualmente em tempo real.

---

# 3. Lacunas identificadas

1. **Transcrição atual autorizada:** não há uma solução pública verificável que cubra todos os níveis atuais com pinyin, hanzi, tradução, áudio e revisão editorial.
2. **Níveis IV–V:** as lacunas são maiores nos níveis avançados; o material encontrado para Level 4 é parcial e não foi encontrado companion atual verificável para Level 5.
3. **Mapa visual ligado ao áudio:** não foi encontrado sistema que una explicitamente áudio Pimsleur, mapa de relações, recuperação ativa, recombinação e espaçamento.
4. **Adaptação ao brasileiro:** não foi localizado um recurso aberto em português brasileiro que integre diagnóstico da interferência do português, tons, aspiração, recuperação e SRS.
5. **Tons em fala conectada:** muitos recursos tratam tons isolados; tom neutro, sandhi tonal, redução e coarticulação aparecem pouco.
6. **Feedback confiável:** nenhum companion comunitário oferece feedback humano ou validação independente de reconhecimento de voz para brasileiros.
7. **Controle editorial:** decks e listas de fãs frequentemente não informam edição, fonte, revisão, licença ou qualidade do áudio.
8. **Correspondência entre versões:** não existe matriz pública confiável conciliando Phase/Unit, Course/Level, Basic Course, CDs e Levels 1–5 atuais.
9. **Transferência:** a maioria dos materiais revisa palavras ou frases, mas não mede uso em contexto novo, latência de resposta ou produção espontânea.
10. **Semi-oficialidade:** não foi encontrado companion de terceiro com endosso verificável da Pimsleur.

Essas lacunas sustentam a oportunidade de **Mandarim em Rede**, desde que ele não seja vendido como mais um PDF, deck ou transcrição. O diferencial precisa ser a camada de transferência: mapa pós-áudio, versão lacunada, recombinação controlada, redução progressiva do apoio e preparação para uso social.

---

# 4. Recursos complementares de alta qualidade

## 4.1 Fala e compreensão auditiva

| Recurso | Por que merece consideração | Limitações |
|---|---|---|
| [Glossika Chinese](https://ai.glossika.com/) | Frases completas, SRS explícito, gravação da própria voz e opções Beijing/Taiwan; forte complemento para prática distribuída | Menos antecipação aberta que Pimsleur; sem feedback humano e com assinatura após teste |
| [Yoyo Chinese](https://yoyochinese.com/) | Currículo estruturado, áudio normal/lento, diálogos, flashcards, quizzes e ferramenta de pinyin | Comercial; promessas de progresso são claims do fornecedor |
| [ChinesePod](https://www.chinesepod.com/) | Biblioteca ampla, diálogos, replay linha a linha, pronúncia, vídeo e exercícios; seis níveis | Não é uma sequência única; SRS não é claramente documentado |
| [Mandarin Corner](https://mandarincorner.org/listen-to-audio-with-transcript/) | Histórias, entrevistas e podcasts com transcrições, do iniciante a níveis mais altos | A dificuldade varia; sem SRS integrado ou feedback oral |
| [Du Chinese](https://duchinese.net/l/graded-reading) | Histórias graduadas, áudio natural, tradução sob demanda e dicionário | É principalmente leitura com áudio; produção precisa ser adicionada |
| [The Chairman’s Bao](https://www.thechairmansbao.com/) | Notícias graduadas, áudio humano, exercícios e flashcards | Comercial; não oferece conversação individual |
| [Fluentide](https://fluentide.com/chinese/listening-practice) | Sequência clara: ouvir sem texto, revelar suporte, repetir e fazer shadowing | SRS não documentado; projeto e disponibilidade podem mudar |
| [MIT Chinese III](https://ocw.mit.edu/courses/21g-103-chinese-iii-regular-fall-2018/pages/syllabus/) | Curso acadêmico com tarefas orais, diálogos, memorização e prática de sala | Exige livro, disciplina e idealmente professor |
| [FSI Standard Chinese](https://www.fsi-language-courses.org/chinese/) | Grande volume de PDFs e áudio, com material histórico de acesso aberto no catálogo | Antigo, pouco amigável e sem SRS moderno |
| [Peace Corps Chinese](https://www.fsi-language-courses.org/chinese/courses/peace-corps-chinese-mandarin-language-course/) | Curto, situacional e recomenda pausar, repetir e produzir | Cobertura limitada e material histórico |
| [MIT Foundation Course](https://ocw.mit.edu/courses/res-21g-003-learning-chinese-a-foundation-course-in-mandarin-spring-2011/) | Livro online e áudio, com separação explícita entre oralidade e escrita | Curso acadêmico antigo, requer organização externa |
| [NTU Start From Scratch](https://www.coursera.org/learn/learn-chinese-mandarin) | Situações práticas para iniciantes e instituição verificável | Curso curto, dependente da plataforma e sem SRS demonstrado |
| [Chinese Grammar Wiki](https://resources.allsetlearning.com/chinese/grammar/Main_Page) | Excelente apoio para compreender estruturas que aparecem no áudio | Não é recurso de escuta/fala; deve ser usado pontualmente |
| [Anki-xiehanzi](https://github.com/krmanik/Anki-xiehanzi) | Decks HSK antigos e HSK 3.0, áudio, hanzi, pinyin e SRS offline | Não é Pimsleur; alguns áudios podem faltar e as licenças variam |

## 4.2 Mapas mentais e organização visual

| Recurso | Utilidade | Limitações |
|---|---|---|
| [ChinesePod Character Mind Map: 学](https://www.chinesepod.com/lesson/character-mind-map-%E5%AD%A6-learn) | Conecta um caractere a palavras relacionadas, com vídeo, áudio, transcrição e exercícios | Exemplo isolado, não sistema completo de currículo |
| [Mandarin Blueprint — Mind Mapping](https://www.mandarinblueprint.com/blog/beginners-guide-to-mind-mapping-for-language-learning/) | Explica como combinar componentes, significado, pinyin, tons e frases | Guia de método, sem SRS ou feedback oral |
| [Chinese4Kids — Mind Maps](https://chinese4kids.net/use-mind-maps-to-learn-chinese-vocabulary/) | Mostra agrupamentos temáticos, antônimos e redes de vocabulário | Essencialmente visual; sem áudio ou métricas |
| [Hacking Chinese — 100 radicals](https://www.hackingchinese.com/kickstart-your-character-learning-with-the-100-most-common-radicals/) | Lista visual com exemplos e versões PDF/TXT | Radical é índice de escrita, não necessariamente pista de pronúncia |
| [HanziCraft](https://hanzicraft.com/) | Decomposição de caracteres, componentes, pinyin, frequência, palavras e listas | Não oferece diálogo nem feedback de fala |
| [HanziGraph](https://hanzigraph.com/) | Grafos de colocações, frases, flashcards e intervalos de revisão; exportação para Anki | Protótipo, HSK 2.0 e sem áudio nativo claro |
| [Interactive Pinyin Chart](https://yoyochinese.com/chinese-learning-tools/Mandarin-Chinese-pronunciation-lesson/pinyin-chart-table) | Mapa fonológico com áudio, tons, pares tonais e gravação | Não é mapa semântico nem SRS |
| [Chinese Track Tone Practice](https://www.chinesetrack.com/current/tone-practice) | Gráfico tonal, listening, digitação e verificador por IA | A validade do escore e dos intervalos não é independente |
| [Hacking Chinese Guide to Mandarin Tones](https://www.hackingchinese.com/the-hacking-chinese-guide-to-mandarin-tones/) | Bom guia de tom lexical, entonação e limitações do treino isolado | Não é programa de revisão estruturado |

A conclusão é clara: há mapas de caracteres, listas visuais e decompositores, mas quase nenhum sistema integra **mapa semântico + áudio + recuperação oral + espaçamento + transferência**.

## 4.3 Recursos para brasileiros e interferência do português

| Recurso | Utilidade | Limitações |
|---|---|---|
| [O ensino de mandarim no Brasil — USP](https://teses.usp.br/teses/disponiveis/48/48134/tde-07122012-110235/publico/corpo.pdf) | Melhor fonte encontrada sobre interferência segmental: aspiração, pinyin, IPA e contrastes como b/p, d/t, z/c, zh/ch, j/q e g/k | Dissertação de 2012; não mede Pimsleur, SRS ou tons de forma completa |
| [Decifrando o Pinyin — Instituto Confúcio Unesp](https://www.institutoconfucio.com.br/decifrando-o-pinyin/) | Explica inicial, final, tons e o risco de ler grafemas latinos como português | Não oferece sequência de prática ou feedback |
| [Chinês Ex-machina — Instituto Confúcio Unesp](https://www.institutoconfucio.com.br/chines-ex-machina/) | Curadoria de Pinyin Trainer, Pleco, Du Chinese e Anki | Guia de 2020; apps e preços podem ter mudado |
| [Dicas para os tons — Duolingo](https://blog.duolingo.com/pt/tons-do-chines/) | Explica tons, tom neutro, entonação, imitação e sandhi | Editorial; não é diagnóstico específico de brasileiros |
| [Companheiros de viagem — Revista Instituto Confúcio](https://revista.institutoconfucio.com.br/companheiros-de-viagem/) | Relatos de brasileiros e recomendações de progressão de sílaba a diálogo | Depoimentos, não estudo controlado |
| [Ensino dos caracteres aos aprendizes brasileiros — UFT](https://sistemas.uft.edu.br/periodicos/index.php/portodasletras/article/download/6637/17082/44900) | Contextualiza pinyin, tons e caracteres para brasileiros | Foco principal em escrita |
| [Guia de pronúncia para brasileiros — Falou](https://falou.com/academy/pt/guides/como-praticar-pronuncia-em-chines) | Aborda tons, zh/ch/sh/r, ü, gravação e prática oral | Conteúdo promocional; claims de IA e progresso não são independentes |
| [Guia Talkpal para brasileiros](https://talkpal.ai/pt-pt/mandarim-para-brasileiros-guia-pratico-para-aprender-chines-facil-e-rapido/) | Identifica tons, q/x/zh e prática com nativos | URL pt-PT e conteúdo promocional; sem SRS comprovado |

---

# 5. Fontes e grau de confiabilidade

| Categoria | Fontes principais | Confiabilidade |
|---|---|---|
| Produto e método | Pimsleur oficial e Simon & Schuster | **Alta** para recursos e posicionamento; não é evidência independente de eficácia |
| Edições e catálogos | Audible, Audio Editions, Libby/OverDrive | **Alta** para existência e metadados; **média** para equivalência atual |
| Decks e companions | AnkiWeb, Quizlet, Brainscape, Stanford, Pleco Forums, Talk To Me In Chinese | **Alta** para existência visível; **média/baixa** para correção, completude e licença |
| Cursos complementares | Yoyo, Glossika, ChinesePod, Mandarin Corner, Du Chinese, TCB | **Alta** para recursos declarados; claims de eficácia devem ser tratados como marketing |
| Instituições | MIT OCW, Harvard, Instituto Confúcio, USP, UFT, NTU/Coursera | **Alta** para autoria/escopo publicados; material antigo ou curadoria não implica endosso de terceiros |
| Comunidades | Reddit, fóruns, italki, Forumosa, blogs e YouTube | **Baixa a média**; úteis para descobrir rotinas, limitações e nomenclaturas, não para provar eficácia |

---

# Recomendação final de seleção

Para um estudante de mandarim que usa Pimsleur, a combinação mais rigorosa é:

1. **Curso oficial Pimsleur** para escuta, antecipação, recuperação e pronúncia.
2. **Um deck Anki com áudio**, usado somente para revisar material já ouvido e conferido.
3. **Yoyo Chinese, Glossika ou ChinesePod** para ampliar prática oral, variação de vozes e padrões.
4. **Mandarin Corner, Du Chinese ou The Chairman’s Bao** para input mais longo e graduado.
5. **Yoyo Pinyin Chart, Chinese Track e Hacking Chinese Tones** para pronúncia e tons.
6. **USP, Instituto Confúcio Unesp e Revista Instituto Confúcio** para compreender dificuldades específicas de brasileiros.
7. **Mandarim em Rede** como camada de transferência: mapas pós-áudio, células de recombinação, revisão com suporte decrescente e preparação para uso social.

## O que não recomendo como fonte principal

Não recomendo transcrições de Scribd, mirrors desconhecidos, decks sem autor ou arquivos com áudio recortado como fonte principal. Não recomendo usar PDFs Stanford, listas Quizlet ou vocabulário de fã antes da tentativa oral. Não recomendo tratar um deck como equivalente a uma lição Pimsleur, nem assumir que HSK, CEFR, DLI ou FSI correspondem diretamente aos Levels 1–5.

## Alerta de copyright e segurança

Pimsleur é conteúdo proprietário de Simon & Schuster/Pimsleur. Transcrições, PDFs, áudio, ripagens, cortes de voz, decks derivados e redistribuição de diálogos podem infringir direitos autorais ou termos de serviço. Um link público, um espelho acadêmico ou um upload no AnkiWeb/Quizlet/Scribd não é autorização. Use preferencialmente o app/site oficial, Audible autorizado, revendedor legítimo ou biblioteca. O arquivo Slow Chinese declara CC BY-NC-ND 4.0, que não autoriza derivados nem uso comercial. Em downloads de terceiros, use fontes reconhecíveis, não execute instaladores desconhecidos, faça backup antes de importar decks e confira licenças de áudio e dados. Recursos com microfone, IA ou conversa podem processar voz; leia as políticas de privacidade antes de enviar gravações.

---

# Referências principais

[1]: https://www.pimsleur.com/learn-chinese-mandarin/ "Pimsleur Chinese Mandarin"
[2]: https://www.pimsleur.com/learn-chinese-mandarin/lifetime-subscription/ "Pimsleur Lifetime Access"
[3]: https://www.pimsleur.com/the-pimsleur-method/ "The Pimsleur Method"
[4]: https://ankiweb.net/shared/info/2002391726 "Pimsleur Chinese Mandarin AnkiWeb"
[5]: https://ankiweb.net/shared/info/915822283 "Pimsleur Mandarin I AnkiWeb"
[6]: https://theory.stanford.edu/~trevisan/chinese/pimsleur-transcript-1.pdf "Pimsleur Mandarin Course I Transcript"
[7]: https://www.chinesepod.com/ "ChinesePod"
[8]: https://ai.glossika.com/ "Glossika"
[9]: https://yoyochinese.com/ "Yoyo Chinese"
[10]: https://mandarincorner.org/listen-to-audio-with-transcript/ "Mandarin Corner Audio with Transcript"
[11]: https://www.thechairmansbao.com/ "The Chairman’s Bao"
[12]: https://teses.usp.br/teses/disponiveis/48/48134/tde-07122012-110235/publico/corpo.pdf "O ensino de mandarim no Brasil"
[13]: https://www.institutoconfucio.com.br/decifrando-o-pinyin/ "Decifrando o Pinyin"
[14]: https://hanzigraph.com/ "HanziGraph"
[15]: https://www.hackingchinese.com/the-hacking-chinese-guide-to-mandarin-tones/ "The Hacking Chinese Guide to Mandarin Tones"
[16]: https://ocw.mit.edu/courses/21g-103-chinese-iii-regular-fall-2018/pages/syllabus/ "MIT Chinese III"
[17]: https://www.fsi-language-courses.org/chinese/ "FSI Standard Chinese"
[18]: https://www.reddit.com/r/ChineseLanguage/comments/1e3ifv7/progress-after-all-30-lessons-from-pimsleur-mandarin/ "Pimsleur Mandarin community report"
