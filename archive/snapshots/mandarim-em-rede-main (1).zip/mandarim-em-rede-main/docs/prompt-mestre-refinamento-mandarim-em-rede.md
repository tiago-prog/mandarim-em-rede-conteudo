# Prompt-mestre de refinamento — Mandarim em Rede

## Instrução de uso

Use este documento como briefing principal para refinar o sistema visual, os moldes e os arquivos editoriais do projeto Mandarim em Rede. Antes de alterar qualquer arquivo, leia este documento inteiro, o `README.md` raiz, o `conceito-consolidado-mandarim-em-rede.md`, o `analise-pagina-autoral-base-mandarim-em-rede.md`, o `estresse-maximo-moldes-mandarim-em-rede.md` e todos os arquivos da pasta `moldes/`.

A imagem `referencias/first-page.png` é a principal referência autoral visual. Ela não deve ser tratada como uma sugestão genérica. Ela é a página-mãe do sistema. Preserve sua lógica de composição, hierarquia, proporções, atmosfera, moldura e relação entre instrução, processo, resultado e conteúdo linguístico.

Não substitua automaticamente o sistema por um design genérico, por uma página cheia de ilustrações ou por uma imagem gerada com texto. O objetivo é refinar uma identidade já definida, tornando-a mais consistente, editável, legível, escalável e pronta para produção.

---

# 1. Contexto do produto

Mandarim em Rede é um sistema de companions visuais independentes e não oficiais para brasileiros que estudam mandarim com apoio de áudio estruturado, especialmente Pimsleur.

O material não é uma transcrição, não é uma apostila gramatical, não substitui o áudio e não deve sugerir afiliação, autorização ou endosso da Pimsleur.

A função pedagógica é transformar repertório ouvido em produção oral transferível:

```text
áudio → tentativa sem apoio → mapa mental → reconstrução →
recombinação → transferência → produção sem olhar
```

A unidade principal é a **aula de transferência oral**. O mapa mental é o sistema de organização cognitiva. O layout deve tornar visível a função, o padrão, os elementos fixos, os elementos substituíveis, os contrastes e a tarefa de produção.

---

# 2. Objetivo do refinamento

Refine todos os moldes existentes para que formem um sistema editorial único, profissional e reutilizável. O resultado precisa ser adequado para:

- criação de PDFs educacionais premium;
- preenchimento posterior pelo criador;
- edição de textos, pinyin, caracteres, tabelas, exercícios e mapas;
- impressão A4 colorida;
- impressão A4 em escala de cinza;
- leitura em notebook e celular;
- expansão para dezenas de páginas sem redesenho manual completo;
- uso por alunos brasileiros de mandarim;
- integração com áudio externo sem reproduzir material proprietário.

Não entregue apenas páginas visualmente bonitas. Entregue uma **gramática visual editável**.

---

# 3. Arquivos que devem ser lidos e respeitados

Leia e use como fontes internas do projeto:

```text
README.md
docs/conceito-consolidado-mandarim-em-rede.md
docs/analise-pagina-autoral-base-mandarim-em-rede.md
docs/estresse-maximo-moldes-mandarim-em-rede.md
moldes/README.md
moldes/C0-capa-colecao.svg
moldes/A0-abertura-tematica.svg
moldes/R1-roteiro-de-aula.svg
moldes/R2-mapa-de-aula.svg
moldes/R3-recombinacao-oral.svg
moldes/R4-transferencia-autoavaliacao.svg
moldes/R5-consolidacao-modulo.svg
moldes/V1-revisao-autoavaliacao.svg
moldes/W1-pratica-de-escrita.svg
referencias/first-page.png
```

A página `referencias/first-page.png` tem prioridade visual sobre referências externas. Os demais documentos definem a função pedagógica, os riscos, a editabilidade e os critérios de qualidade.

---

# 4. Página-mãe autoral

A página-mãe apresenta a estrutura:

```text
[AULA / TÍTULO FUNCIONAL]
          ↓
[OBJETIVO DO ROTEIRO]
          ↓
[FLUXO METODOLÓGICO]
          ↓
[ORIENTAÇÃO DE USO]
          ↓
[RESULTADO DESEJADO]
          ↓
[CONTEÚDO LINGUÍSTICO EM TABELA]
```

Preserve estes elementos conceituais e visuais:

1. Título grande, centralizado, azul-marinho, com hierarquia editorial forte.
2. Filete horizontal dourado abaixo do título.
3. Fundo principal creme, limpo e confortável para leitura.
4. Moldura externa azul-marinho profunda.
5. Filete interno dourado fino.
6. Ornamentos de nuvens chinesas nos cantos e margens.
7. Montanhas em baixa opacidade como textura de fundo.
8. Cabeçalhos de seção numerados em azul-marinho.
9. Faixa azul-marinho para o fluxo de aprendizagem.
10. Caixa creme/bege para orientação de uso.
11. Caixa dourada para resultado desejado.
12. Tabela linguística com cabeçalho azul-marinho e células creme.
13. Espaço negativo inferior suficiente para manter calma visual ou receber uma próxima ação.
14. Rodapé discreto com nome da coleção, módulo e número da página.

Não substitua a página por um estilo infantil, futurista, minimalista frio, corporativo genérico, neon, fotográfico ou excessivamente ornamentado.

---

# 5. Paleta obrigatória

Use esta paleta como base consistente. Pequenas variações de tom são aceitáveis somente se melhorarem contraste ou impressão.

| Função | Cor | Uso |
|---|---|---|
| Azul-marinho | `#173754` | moldura, títulos, cabeçalhos, fluxo, estrutura |
| Creme | `#F8F2E7` | fundo principal, células e áreas de trabalho |
| Dourado | `#C99E4A` | filetes, resultado, ornamentos, destaque |
| Coral | `#C94D3F` | nuvens, alertas e acentos culturais |
| Cinza-azulado | `#8A96A0` | montanhas, névoa e texturas secundárias |
| Texto escuro | `#24323D` | corpo, instruções e traduções |
| Verde funcional | `#367D86` | elementos substituíveis e variações |
| Creme claro | `#FFFDF8` | tabelas, caixas de resposta e áreas de exercício |

Regras:

- Não usar cor saturada em excesso.
- Não colocar texto pequeno sobre textura.
- Não usar cor como único mecanismo de significado.
- Todo código de cor deve possuir também rótulo, posição, ícone ou padrão visual.
- O material precisa continuar compreensível em escala de cinza.

---

# 6. Estilo de fundo e ornamentos

## Fundo

O fundo deve ser creme marfim, com aparência de papel editorial premium, mas sem textura forte. A leitura precisa permanecer limpa.

Use montanhas chinesas em aquarela muito suave, cinza-azuladas, com baixa opacidade, preferencialmente nas bordas inferiores ou laterais. As montanhas não devem aparecer atrás de títulos, pinyin, caracteres, tabelas ou campos de resposta.

Use névoa e lua clara apenas como elementos de capa, abertura ou separador. Não use uma lua grande em páginas densas de exercícios.

## Nuvens chinesas

As nuvens devem ser estilizadas, lineares e elegantes, inspiradas em ornamentos tradicionais chineses, sem copiar uma ilustração específica.

Use dois tratamentos:

- nuvem coral/vermelha com detalhe dourado para capa, abertura e páginas de destaque;
- nuvem linear dourada ou azul-clara para páginas operacionais.

As nuvens devem permanecer nas margens. Não colocar nuvens atrás de texto ou dentro da área de resposta.

## Moldura

A moldura azul-marinho é uma assinatura de marca, não um preenchimento aleatório. Deve ter:

- margem segura para impressão doméstica;
- filete interno dourado fino;
- cantos com acabamento geométrico discreto;
- possibilidade de alternar entre versão completa e versão reduzida.

Use moldura completa em capa, abertura, mapa mestre e consolidação. Use moldura reduzida em exercícios, revisão e prática de escrita.

## Ornamentos proibidos

Não usar:

- dragões, guerreiros, templos em excesso ou clichês visuais dominantes;
- personagens infantis como elemento obrigatório;
- excesso de lanternas, flores ou objetos temáticos;
- ornamentos que pareçam clipart;
- elementos que reduzam a área editável;
- textura escura atrás de conteúdo.

---

# 7. Tipografia e hierarquia

Use uma combinação editorial legível:

- título: serifada elegante ou serifada editorial, azul-marinho;
- seções e instruções: sans-serif robusta e legível;
- caracteres chineses: fonte compatível com chinês simplificado;
- pinyin: fonte que suporte todas as marcas tonais;
- corpo: sans-serif de alta legibilidade.

Não invente ou substitua caracteres chineses. Não use fontes que quebrem diacríticos, tons ou formas simplificadas.

Hierarquia obrigatória:

```text
Título da página
  ↓
Título da seção
  ↓
Instrução da tarefa
  ↓
Conteúdo ou exercício
  ↓
Critério, resposta ou próxima ação
```

O aluno deve identificar a tarefa principal em até cinco segundos. Toda página operacional precisa conter um verbo de ação visível, como:

```text
OUÇA
TENTE RESPONDER
RECONSTRUA
RECOMBINE
FALE SEM OLHAR
REVISE
AVALIE
```

---

# 8. Regras de editabilidade

Não achate texto, tabela, mapa, exercício ou QR code em uma imagem.

O arquivo-mestre deve manter camadas ou objetos separados para:

```text
1. fundo
2. moldura
3. nuvens e ornamentos
4. montanhas e névoa
5. caixas e divisórias
6. títulos
7. texto instrucional
8. caracteres chineses
9. pinyin
10. traduções
11. exercícios
12. mapas e conexões
13. QR code e metadados
14. rodapé
```

Qualquer pessoa autorizada deve conseguir substituir:

- título;
- número da aula;
- nome do módulo;
- caracteres;
- pinyin;
- tradução;
- número de linhas da tabela;
- itens dos exercícios;
- rótulos do mapa;
- data de revisão;
- QR code;
- número da página.

Se uma alteração exigir recriar a página inteira, o molde não está suficientemente editável.

---

# 9. Sistema pedagógico que o layout deve sustentar

Cada página deve ter uma função pedagógica explícita.

| Tipo de página | Ação dominante |
|---|---|
| R1 — Roteiro | orientar a sequência |
| R2 — Mapa | visualizar relações |
| R3 — Recombinação | trocar componentes e produzir |
| R4 — Transferência | usar em situação nova |
| R5 — Consolidação | integrar funções |
| V1 — Revisão | verificar domínio |
| W1 — Escrita | apoiar reconhecimento de caracteres |

Todo mapa deve poder existir em três estados:

```text
MAPA COMPLETO → MAPA LACUNADO → PROMPT MÍNIMO
```

O layout deve tornar evidente quando a resposta ainda está escondida. Não mostrar prompt e resposta com a mesma hierarquia visual.

---

# 10. Especificação dos moldes

## C0 — Capa da coleção

Objetivo: apresentar a identidade da coleção.

Deve conter áreas editáveis para:

```text
MANDARIM EM REDE
[SUBTÍTULO]
[PROMESSA]
[EDIÇÃO / PDF / MÓDULO]
```

Usar azul-marinho predominante, moldura creme/dourada, nuvens coral/douradas nos cantos, montanhas suaves e uma área central limpa.

Não inserir texto gerado por imagem. A tipografia deve ser editável.

## A0 — Abertura temática

Objetivo: abrir uma lição e apresentar contexto, função e objetivos.

Deve conter:

- título funcional;
- caracteres principais;
- área de ilustração temática;
- três objetivos observáveis;
- área para instrução ou QR code inserido posteriormente;
- moldura e ornamentos em nível médio/alto.

A ilustração temática deve ocupar uma faixa controlada, sem competir com os objetivos.

## R1 — Roteiro de aula

Objetivo: conduzir a primeira experiência de transferência.

Manter a arquitetura autoral:

```text
objetivo → fluxo → orientação → resultado → tabela linguística
```

A faixa metodológica deve comunicar:

```text
ouvir → tentar responder → consultar o mapa → reconstruir →
recombinar → transferir → produzir sem olhar
```

A caixa dourada deve conter um resultado mensurável, não uma promessa vaga.

A tabela deve usar as colunas:

```text
Função | Mandarim | Pinyin | Sentido funcional
```

## R2 — Mapa de aula

Objetivo: visualizar intenção, padrão, componentes e transferência.

Deve conter mapa completo, mapa lacunado e legenda com:

```text
FIXO | SUBSTITUÍVEL | ALERTA | TRANSFERÊNCIA
```

O mapa não deve ser uma ilustração sem relações editáveis. Linhas, nós, rótulos e cores devem ser alteráveis.

## R3 — Recombinação oral

Objetivo: fazer o aluno produzir variações.

Deve conter:

- prompt de intenção;
- bloco de estrutura fixa;
- bloco de elemento substituível;
- bloco de alerta;
- quatro a seis variações;
- instrução para falar antes de consultar;
- tarefa final sem olhar.

As áreas de exercício devem ser maiores que os ornamentos.

## R4 — Transferência e autoavaliação

Objetivo: comprovar uso em situação nova.

Deve conter:

- situação nova;
- tempo estimado;
- quantidade de elementos a usar;
- produção oral de 30–60 segundos;
- checklist de ações observáveis;
- próxima revisão e erro principal.

Não transformar o checklist em mensagem motivacional sem evidência.

## R5 — Consolidação de módulo

Objetivo: integrar várias funções.

Deve conter:

- mapa integrador com até seis ramos principais;
- tarefa cumulativa de 60–90 segundos;
- contrastes prioritários;
- critério de domínio do módulo;
- área para registrar quais apoios ainda foram necessários.

## V1 — Revisão e autoavaliação

Objetivo: revisar capacidade, não apenas familiaridade.

Deve conter:

- checklist de ações observáveis;
- resumo funcional compacto;
- teste rápido sem resposta visível;
- área de anotações;
- próxima ação de revisão.

## W1 — Prática de escrita

Objetivo: apoiar reconhecimento e escrita de caracteres sem deslocar o foco oral.

Deve conter:

- até três caracteres principais;
- pinyin tonal;
- sentido funcional;
- grades de prática precisas;
- vocabulário complementar limitado;
- instrução sobre ordem dos traços.

A grade deve ser vetorial e editável. Não gerar linhas de escrita por IA.

---

# 11. Regras para caracteres, pinyin e português

Não gerar ou alterar caracteres chineses por aproximação visual. Use apenas caracteres simplificados corretos.

Não gerar pinyin sem marcas tonais quando o campo exigir tom. Verifique:

- acentos;
- ü quando aplicável;
- espaçamento entre palavras;
- tom neutro;
- mudanças tonais contextualizadas;
- quebras de linha entre palavras, nunca no meio de sílabas.

Use português brasileiro natural. Não traduzir palavra por palavra quando isso produzir uma frase artificial.

Todo conteúdo linguístico deve ser revisado separadamente da revisão visual.

---

# 12. Uso correto de IA de imagem

Use geração de imagem somente para:

- fundos;
- montanhas;
- névoa;
- nuvens;
- ornamentos;
- ilustrações temáticas;
- ativos de capa;
- texturas decorativas.

Não use geração de imagem para:

- textos longos;
- pinyin;
- caracteres chineses específicos;
- tabelas;
- grades;
- mapas mentais com relações exatas;
- QR codes;
- campos editáveis;
- instruções de exercício.

Se um ativo for gerado, mantenha-o separado do conteúdo editorial e nomeie-o de modo claro.

---

# 13. Critérios de refinamento visual

Refine, mas não descaracterize. O refinamento deve melhorar:

- alinhamento;
- margens;
- contraste;
- equilíbrio de espaços;
- escala dos títulos;
- legibilidade do pinyin;
- consistência das caixas;
- consistência de rodapé;
- comportamento em diferentes quantidades de texto;
- possibilidade de impressão;
- aparência em celular.

Não refine adicionando elementos apenas porque existe espaço vazio. O espaço vazio é parte da experiência.

Não torne todas as páginas idênticas. Mantenha a mesma gramática, mas permita que capa, roteiro, mapa, exercício e revisão tenham densidades diferentes.

---

# 14. Processo obrigatório de trabalho

Execute na seguinte ordem:

1. Ler todos os documentos e moldes.
2. Inspecionar a referência autoral.
3. Auditar a estrutura atual dos SVGs.
4. Definir tokens visuais comuns.
5. Corrigir R1 primeiro, pois ele é o template-mãe.
6. Derivar R2, R3, R4 e R5 de R1.
7. Ajustar C0, A0, V1 e W1 sem romper a mesma identidade.
8. Preservar placeholders editáveis.
9. Validar títulos longos e tabelas com quatro, seis e oito linhas.
10. Verificar impressão colorida e escala de cinza.
11. Verificar leitura em celular.
12. Gerar previews somente para inspeção.
13. Corrigir falhas reais, sem inventar complexidade.
14. Atualizar `moldes/README.md` com o sistema final.
15. Criar um changelog do refinamento.
16. Fazer commit descritivo no GitHub.

Não apagar a versão anterior sem preservá-la. Se houver alteração estrutural importante, criar uma pasta `moldes/backup-v1/` ou usar histórico Git.

---

# 15. Critérios objetivos de aprovação

O refinamento só está aprovado se todos os itens forem verdadeiros:

- o layout continua reconhecível como Mandarim em Rede;
- R1 mantém a sequência objetivo → fluxo → orientação → resultado → conteúdo;
- todos os SVGs permanecem editáveis;
- nenhum conteúdo crítico está achatado como imagem;
- títulos longos não quebram a moldura;
- tabelas funcionam com diferentes quantidades de linhas;
- pinyin permanece legível;
- caracteres chineses permanecem editáveis;
- mapas têm estados completo, lacunado e mínimo;
- exercícios deixam clara a ação principal;
- a resposta não aparece antes da tentativa;
- ornamentos não invadem áreas de trabalho;
- a página funciona em impressão colorida;
- a página continua compreensível em escala de cinza;
- a identidade não depende de uma ilustração específica;
- o sistema consegue gerar pelo menos cinco aulas sem redesenho estrutural;
- o README explica como usar e editar os moldes;
- o GitHub contém os arquivos refinados, a referência e o changelog.

---

# 16. Proibições absolutas

Não faça nenhuma destas coisas:

- não transformar o material em uma apostila gramatical;
- não copiar ou reproduzir conteúdo proprietário da Pimsleur;
- não declarar parceria, autorização ou oficialidade;
- não substituir o layout autoral por um template genérico;
- não gerar o PDF inteiro como uma única imagem;
- não inserir texto longo com IA de imagem;
- não usar cor como único código;
- não usar caracteres chineses inventados ou incorretos;
- não colocar pinyin sem revisão;
- não sacrificar editabilidade por uma aparência mais bonita;
- não encher áreas vazias com ornamentos;
- não criar mapas ilegíveis com excesso de ramos;
- não reduzir a área de resposta para acomodar decoração;
- não remover a sequência metodológica;
- não apagar versões anteriores sem preservação no Git.

---

# 17. Entregáveis finais esperados

Ao terminar o refinamento, o repositório deve conter:

```text
moldes/
├── C0-capa-colecao.svg
├── A0-abertura-tematica.svg
├── R1-roteiro-de-aula.svg
├── R2-mapa-de-aula.svg
├── R3-recombinacao-oral.svg
├── R4-transferencia-autoavaliacao.svg
├── R5-consolidacao-modulo.svg
├── V1-revisao-autoavaliacao.svg
├── W1-pratica-de-escrita.svg
├── README.md
├── CHANGELOG.md
└── backup-v1/   se houver alteração estrutural

referencias/
└── first-page.png

docs/
└── este prompt e as especificações conceituais existentes
```

Inclua no `CHANGELOG.md` uma tabela com arquivo, alteração, justificativa e impacto na editabilidade ou na pedagogia.

Faça commit no GitHub somente depois de verificar todos os arquivos e manter o histórico.

---

# 18. Resultado esperado

O resultado final deve parecer uma evolução cuidadosa da página autoral, não uma substituição de identidade.

Ele deve transmitir:

```text
premium sem ostentação
tradicional sem clichê
visual sem poluição
estrutura sem rigidez
clareza sem infantilização
tecnologia sem aparência genérica
```

A regra final é:

> **Preserve a alma visual da página autoral. Reforce a função pedagógica. Torne tudo editável. Reduza o que distrai. Melhore o que escala.**

Antes de encerrar, informe no changelog quais decisões foram tomadas, quais arquivos foram alterados e quais limitações ainda permanecem.
