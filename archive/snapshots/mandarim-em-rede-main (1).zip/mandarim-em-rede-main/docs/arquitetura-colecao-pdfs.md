# Mandarim em Rede
## Arquitetura da coleção de PDFs

### Da escuta à produção oral organizada

O **Mandarim em Rede** é uma coleção de companions visuais independentes e não oficiais para estudantes brasileiros de mandarim. Os PDFs não seguem uma sequência tradicional de gramática. Cada volume trabalha uma capacidade comunicativa e transforma estruturas ouvidas em produção oral recombinada.

A lógica da coleção é:

> **O áudio introduz. O aluno tenta. O mapa organiza. A recombinação amplia. A transferência demonstra o uso.**

O estudante não deve abrir o mapa para acompanhar o áudio principal. Primeiro ele escuta e tenta responder. Depois consulta o material visual, reconstrói a estrutura, troca componentes e usa o padrão em uma situação nova.

---

## 1. Como usar a coleção

Cada PDF funciona como uma camada posterior ou intermediária ao estudo auditivo. O material visual não substitui o áudio, o professor, o interlocutor, o feedback especializado ou o estudo sistemático.

A sequência de uso de todos os volumes é:

```text
1. escolher uma função comunicativa;
2. ouvir o material principal sem acompanhar o PDF;
3. tentar responder antes de consultar a solução;
4. visualizar a estrutura no mapa de orientação;
5. reconstruir o padrão no mapa lacunado;
6. recombinar componentes fixos e substituíveis;
7. observar um contraste relevante;
8. aplicar o padrão em um contexto novo;
9. produzir sem o mapa completo;
10. registrar o desempenho e revisar depois.
```

### Regra central

> **A resposta só deve aparecer depois da primeira tentativa do estudante.**

Se o aluno consegue concluir uma atividade apenas reconhecendo a resposta impressa, a atividade não está medindo recuperação oral. O conteúdo visual deve ajudar o estudante a organizar relações, não entregar a solução antes da tentativa.

---

## 2. O ciclo pedagógico de cada aula

Cada aula deve trabalhar uma única operação comunicativa principal. A operação pode ser cumprimentar, pedir, negar, localizar, confirmar, expressar preferência ou reparar uma falha de compreensão.

| Etapa | O que o estudante faz | Recurso do PDF | Evidência procurada |
|---|---|---|---|
| 1. Função | Entende o que precisa conseguir fazer | Ficha de objetivo | Consegue nomear a ação comunicativa |
| 2. Áudio | Escuta e tenta responder | Referência ao áudio principal | Mantém a antecipação |
| 3. Tentativa | Produz o que consegue lembrar | Prompt sem resposta | Inicia uma resposta antes da consulta |
| 4. Orientação | Visualiza intenção e arquitetura | Mapa completo | Identifica fixos, slots e extensões |
| 5. Recuperação | Reconstrói a estrutura | Mapa lacunado | Produz antes de conferir |
| 6. Recombinação | Troca componentes controlados | Tabela de variações | Produz pelo menos três variações |
| 7. Contraste | Escolhe entre formas que geram confusão | Quadro de contraste | Evita uma decisão previsível de erro |
| 8. Transferência | Usa o padrão em situação nova | Prompt mínimo | Produz fora do exemplo original |
| 9. Independência | Responde sem o mapa completo | Situação ou estímulo oral | Depende apenas de poucos gatilhos |
| 10. Revisão | Retorna depois de um intervalo | Ficha de registro | Mantém desempenho sem reensino imediato |

### Resultado de uma aula

A aula não é concluída quando o estudante reconhece a frase ou repete o exemplo. Ela é concluída quando ele consegue:

- compreender a função comunicativa;
- recuperar o padrão antes de consultar a resposta;
- substituir componentes dentro de limites controlados;
- produzir pelo menos três variações funcionais;
- lidar com o contraste principal da aula;
- aplicar a estrutura em uma situação nova;
- responder com apoio visual reduzido.

---

## 3. A unidade de conteúdo: célula de transferência

A menor unidade editorial da coleção é a **célula de transferência**. Cada célula deve treinar uma única operação dominante.

Uma célula completa contém:

| Campo | Pergunta que o editor deve responder |
|---|---|
| Intenção | O que o estudante quer fazer? |
| Padrão | Como o mandarim realiza essa ação? |
| Elementos fixos | O que permanece estável? |
| Slots substituíveis | O que pode ser trocado? |
| Extensão opcional | O que pode ser acrescentado depois do núcleo? |
| Pronúncia | O que precisa ser ouvido ou produzido com atenção? |
| Contraste | O que o brasileiro tende a confundir? |
| Recuperação | O que o estudante deve produzir antes de ver a resposta? |
| Transferência | Como a situação será alterada? |
| Domínio | Que comportamento mostra que a célula foi aprendida? |

### Exemplo de célula

**Intenção:** dizer o próprio nome.

**Padrão:**

```text
我叫 + [nome]。
Wǒ jiào + [nome].
Eu me chamo + [nome].
```

**Elemento fixo:** `我叫 Wǒ jiào`.

**Slot substituível:** `[nome]`.

**Extensão:** `你呢？ Nǐ ne? — E você?`

**Recuperação:** “Diga que você se chama Paulo.”

**Transferência:** “Você entrou em uma sala on-line. Diga seu nome usando um nome diferente dos exemplos.”

**Domínio:** o estudante produz a estrutura com pelo menos três nomes ou situações sem consultar o mapa completo.

---

## 4. Os recursos didáticos usados nos PDFs

Para manter uma experiência consistente, cada volume deve reutilizar uma biblioteca de recursos visuais e atividades.

### 4.1 Mapa de orientação

É a versão completa da rede. Aparece depois da tentativa inicial. Deve mostrar:

- intenção comunicativa;
- padrão central;
- elementos fixos;
- slots substituíveis;
- extensões opcionais;
- foco de pronúncia;
- contraste principal;
- tarefa de transferência.

O mapa de orientação não deve parecer um pôster com todas as informações do idioma. Ele deve ser curto o suficiente para ser compreendido em aproximadamente dois minutos.

### 4.2 Mapa lacunado

É a versão de recuperação. Mantém a intenção e parte da estrutura, mas retira respostas que o estudante precisa reconstruir.

Exemplo:

```text
Dizer o próprio nome:
________ 叫 + [nome]
```

O aluno deve falar antes de preencher ou conferir. A lacuna deve representar uma decisão linguística real, não apenas uma palavra retirada de forma aleatória.

### 4.3 Prompt mínimo

É a versão de transferência. Mostra apenas:

- situação;
- intenção;
- poucos gatilhos;
- restrição ou mudança de contexto.

Exemplo:

> Você conheceu uma pessoa nova em uma reunião on-line. Cumprimente, pergunte o nome, diga o seu e devolva a pergunta. Use um nome que não apareceu nos exemplos.

### 4.4 Quadro de padrão

Organiza uma estrutura produtiva por partes.

| Parte | Papel | Exemplo |
|---|---|---|
| Fixo | Mantém a ordem e a operação | `我叫 Wǒ jiào` |
| Variável | Pode ser substituído | `[nome]` |
| Opcional | Amplia a resposta | `你呢？ Nǐ ne?` |
| Contraste | Evita uma escolha errada | `你` não é `我` |

### 4.5 Quadro de contraste

O contraste deve mostrar uma decisão acionável. Não deve ser uma explicação gramatical abstrata.

| Situação | Forma mais adequada | Forma a evitar nesta função | Decisão do estudante |
|---|---|---|---|
| Dizer que não entendeu uma ocorrência específica | `我没听懂。` | `我不听懂。` | Usar `没` para ocorrência ou resultado não realizado |
| Dizer que não gosta de café | `我不喜欢咖啡。` | `我没喜欢咖啡。` | Usar `不` para preferência ou estado habitual |

### 4.6 Caixa de pronúncia

A caixa deve indicar o que ouvir, imitar ou comparar. Ela não deve prometer correção automática por leitura.

Modelo:

> **Foco auditivo:** `叫 jiào` tem quarto tom, curto e descendente. Ouça a expressão completa e compare sua gravação com o áudio disponível. O pinyin informa o alvo, mas não substitui feedback.

### 4.7 Tabela de recombinação

A tabela mostra como produzir variações sem introduzir uma grande quantidade de vocabulário novo.

| Núcleo fixo | Slot 1 | Slot 2 | Produção |
|---|---|---|---|
| `我叫` | Ana | — | `我叫安娜。` |
| `我叫` | Paulo | — | `我叫保罗。` |
| `我叫` | outro nome | — | produção livre controlada |

### 4.8 Ficha de autoavaliação

Cada célula deve ser avaliada em quatro dimensões separadas:

| Dimensão | Pergunta |
|---|---|
| Compreensão | Entendi a função quando ouvi ou vi o contexto? |
| Recuperação | Produzi antes de consultar a resposta? |
| Pronúncia funcional | A produção foi compreensível para a tarefa? |
| Transferência | Usei o padrão em uma situação nova? |

---

## 5. Ordem recomendada da coleção

A coleção deve avançar do uso básico de estruturas para a integração e a interação social. Cada volume deve reaproveitar células anteriores.

| Volume | Título | Função principal |
|---|---|---|
| PDF 01 | Fundamentos de Transferência Oral | Apresentar o método e estabelecer funções comunicativas básicas |
| PDF 02 | Tons em Contexto | Trabalhar tons, ritmo e fala conectada dentro de expressões úteis |
| PDF 03 | Perguntar, Confirmar e Negar | Manter uma conversa por meio de perguntas, respostas e negações |
| PDF 04 | Recombinação de Padrões | Transformar frases conhecidas em estruturas produtivas |
| PDF 05 | Pronúncia para Brasileiros | Trabalhar sons, pinyin e interferências articulatórias do português |
| PDF 06 | Revisão Cumulativa por Mapas | Integrar células antigas e novas com suporte reduzido |
| PDF 07 | Preparação para Interação Social | Preparar o estudante para usar o mandarim com interlocutores reais |

A prioridade da coleção não indica que o estudante deva dominar um volume inteiro antes de abrir o seguinte. Ela indica que os conceitos são introduzidos em uma ordem que reduz sobrecarga e cria dependências úteis.

---

# 6. PDF 01 — Fundamentos de Transferência Oral

## 6.1 Função do volume

O PDF 01 apresenta o sistema Mandarim em Rede e oferece um primeiro conjunto de células de transferência. O foco não é cobrir todo o mandarim inicial. O foco é demonstrar como uma estrutura ouvida pode ser recuperada, recombinada e usada em situação nova.

### Resultado esperado do PDF 01

Ao concluir o volume, o estudante deverá conseguir realizar interações curtas envolvendo apresentação, origem, idioma, reparo, identificação, pedidos, localização, horários, capacidade e preferência, com apoio visual progressivamente reduzido.

## 6.2 Estrutura geral do PDF 01

| Bloco | Conteúdo |
|---|---|
| Abertura | Posicionamento, limites e como usar o companion |
| Mapa mestre | Áudio, tentativa, mapa, recombinação e transferência |
| Módulo 1 | Entrar na interação |
| Consolidação 1 | Combinar apresentação, identificação e reparo |
| Módulo 2 | Pedir, localizar e organizar uma situação |
| Consolidação 2 | Organizar uma interação completa |
| Revisão | Protocolo de 14 dias |
| Fechamento | Autoavaliação, quiz e próximos passos |

## 6.3 Passo a passo do Módulo 1

### Aula 1 — Entrar na interação

**Função:** cumprimentar, perguntar o nome, dizer o próprio nome e devolver a pergunta.

**Padrões centrais:**

```text
你好。
Nǐ hǎo.
Olá.

你叫什么名字？
Nǐ jiào shénme míngzi?
Qual é o seu nome?

我叫 + [nome]。
Wǒ jiào + [nome].
Eu me chamo + [nome].

你呢？
Nǐ ne?
E você?
```

**Recombinações:** usar nomes diferentes, inverter papéis, iniciar uma apresentação em um encontro presencial ou on-line.

**Contrastes:** `我` e `你`; pergunta em mandarim versus ordem literal do português.

**Saída observável:** realizar uma troca de quatro falas sem consultar o mapa completo.

### Aula 2 — Dizer de onde você é e que idioma fala

**Função:** identificar origem, nacionalidade e idioma.

**Padrões centrais:**

```text
你是哪国人？
Nǐ shì nǎ guó rén?
De que país você é?

我是 + [país]人。
Wǒ shì + [país] rén.
Eu sou [nacionalidade].

你说什么语言？
Nǐ shuō shénme yǔyán?
Que idioma você fala?

我说 + [idioma]。
Wǒ shuō + [idioma].
Eu falo [idioma].
```

**Slots:** países, nacionalidades e idiomas.

**Contraste:** `是 shì` identifica ou classifica; `说 shuō` indica falar um idioma.

**Saída observável:** responder sobre origem e idioma usando pelo menos dois conjuntos de slots.

### Aula 3 — Reparar uma falha de compreensão

**Função:** dizer que entendeu, não entendeu ou pedir repetição.

**Padrões centrais:**

```text
我听懂了。
Wǒ tīng dǒng le.
Agora eu entendi.

我没听懂。
Wǒ méi tīng dǒng.
Eu não entendi.

请再说一遍。
Qǐng zài shuō yí biàn.
Por favor, diga mais uma vez.
```

**Slots:** repetir, falar mais devagar, ajustar volume ou esclarecer uma palavra.

**Contrastes:** `没` para uma ocorrência ou resultado não realizado; `不` para hábito, preferência, intenção ou negação geral.

**Saída observável:** pedir reparo sem abandonar a interação.

### Aula 4 — Perguntar o que é e confirmar uma informação

**Função:** identificar objetos, pessoas e posse.

**Padrões centrais:**

```text
这是什么？
Zhè shì shénme?
O que é isto?

这是 + [objeto]。
Zhè shì + [objeto].
Isto é [objeto].

那是什么？
Nà shì shénme?
O que é aquilo?

这是 + [pessoa] 的 + [objeto]。
Zhè shì + [pessoa] de + [objeto].
Isto é o [objeto] de [pessoa].
```

**Slots:** objeto, pessoa, posição e posse.

**Contrastes:** `这` e `那`; `是` para identificação; `在` para localização.

**Saída observável:** identificar três objetos e expressar duas relações de posse.

### Consolidação 1 — Entrar, identificar e reparar

O estudante deve combinar células das Aulas 1 a 4 em uma sequência curta:

1. iniciar uma apresentação;
2. perguntar a origem ou o idioma;
3. identificar um objeto ou uma pessoa;
4. dizer que não entendeu;
5. pedir repetição;
6. continuar a interação.

A consolidação deve usar prompts, não um diálogo fechado. O estudante pode escolher nomes, países, idiomas e objetos dentro de um conjunto limitado.

## 6.4 Passo a passo do Módulo 2

### Aula 5 — Dizer o que quer e fazer um pedido simples

**Função:** expressar desejo e pedir algo.

**Padrões centrais:**

```text
我想 + [ação]。
Wǒ xiǎng + [ação].
Eu quero / gostaria de [ação].

我要 + [item]。
Wǒ yào + [item].
Eu quero [item].

请给我 + [item]。
Qǐng gěi wǒ + [item].
Por favor, me dê [item].
```

**Slots:** bebidas, comidas e objetos.

**Contraste:** `想` expressa desejo ou intenção; `要` apresenta uma necessidade ou escolha mais direta, dependendo do contexto.

**Saída observável:** fazer cinco pedidos e recusar ou ajustar um deles.

### Aula 6 — Perguntar onde algo está

**Função:** localizar pessoas e objetos.

**Padrões centrais:**

```text
[algo]在哪儿？
[algo] zài nǎr?
Onde está [algo]?

[algo]在哪里？
[algo] zài nǎlǐ?
Onde está [algo]?

[algo]在 + [lugar]。
[algo] zài + [lugar].
[algo] está em [lugar].
```

**Slots:** pessoa, objeto, aqui, ali, dentro, fora e lugares conhecidos.

**Contraste:** `在` indica localização; `是` identifica ou classifica.

**Saída observável:** fazer e responder perguntas sobre pelo menos seis localizações.

### Aula 7 — Organizar horário e combinar um encontro

**Função:** propor, aceitar ou recusar um horário.

**Padrões centrais:**

```text
你明天有时间吗？
Nǐ míngtiān yǒu shíjiān ma?
Você tem tempo amanhã?

我们三点见，可以吗？
Wǒmen sān diǎn jiàn, kěyǐ ma?
Podemos nos encontrar às três horas?

我没有时间。
Wǒ méiyǒu shíjiān.
Eu não tenho tempo.
```

**Slots:** hoje, amanhã, manhã, tarde, noite e horários.

**Extensões:** aceitar, recusar e propor outro horário.

**Saída observável:** fazer três propostas, recusar uma e negociar uma alternativa.

### Aula 8 — Dizer o que sabe fazer e o que prefere

**Função:** expressar capacidade e preferência.

**Padrões centrais:**

```text
我会 + [ação]。
Wǒ huì + [ação].
Eu sei / consigo [ação].

我能 + [ação]。
Wǒ néng + [ação].
Eu consigo / posso [ação].

我喜欢 + [opção]。
Wǒ xǐhuan + [opção].
Eu gosto de [opção].

你喜欢茶还是咖啡？
Nǐ xǐhuan chá háishi kāfēi?
Você prefere chá ou café?
```

**Contrastes:** `会`, `能` e `可以`; `喜欢` e `想`; `还是` em perguntas de escolha.

**Saída observável:** responder sobre capacidade e escolher entre pelo menos duas opções.

### Consolidação 2 — Organizar uma interação completa

O estudante deve resolver uma situação nova que combine:

- um pedido;
- uma localização;
- um horário;
- uma preferência ou capacidade;
- uma confirmação ou recusa;
- pelo menos uma produção sem o mapa completo.

A consolidação deve durar entre 60 e 90 segundos e ser realizada duas vezes. Na segunda tentativa, o estudante deve receber menos apoio.

## 6.5 Revisão de 14 dias do PDF 01

| Dia | Suporte | Tarefa |
|---:|---|---|
| 1 | Mapa completo | Identificar intenção, padrão e slots depois do áudio |
| 2 | Mapa lacunado | Reconstruir os componentes fixos e variáveis |
| 3 | Mapa lacunado | Produzir três variações por célula prioritária |
| 4 | Prompt mínimo | Usar uma situação nova com poucos gatilhos |
| 5 | Sem mapa completo | Combinar duas células antigas |
| 6 | Mapa reduzido | Reparar uma falha de compreensão em uma interação |
| 7 | Sem mapa completo | Fazer uma consolidação de 60 segundos |
| 8 | Mapa lacunado | Retomar as células com menor desempenho |
| 9 | Prompt mínimo | Alternar pedido, localização e horário |
| 10 | Sem mapa completo | Responder a uma situação social nova |
| 11 | Áudio + registro | Identificar uma dificuldade de compreensão ou tom |
| 12 | Mapa reduzido | Produzir três variações sem consultar a resposta completa |
| 13 | Sem mapa completo | Realizar uma consolidação de 90 segundos |
| 14 | Situação nova | Repetir a avaliação final e comparar a dependência visual |

A revisão deve ser orientada por desempenho. Uma célula que falhou em compreensão retorna ao áudio. Uma célula que falhou em recuperação retorna ao mapa lacunado. Uma célula que falhou em transferência recebe um prompt mais controlado, não uma explicação mais longa.

---

# 7. PDFs seguintes: objetivos e passo a passo

## PDF 02 — Tons em Contexto

### Objetivo

Desenvolver percepção e produção funcional dos tons dentro de palavras e frases frequentes. O volume não deve tratar tom como desenho isolado nem prometer correção sem escuta e feedback.

### Progressão

1. reconhecer a função dos tons em palavras conhecidas;
2. diferenciar os quatro tons em pares controlados;
3. praticar tom neutro em expressões frequentes;
4. observar o terceiro tom em fala conectada;
5. ouvir mudanças de `不` e `一`;
6. trabalhar ritmo e entonação de frases;
7. contrastar sílabas que o brasileiro tende a neutralizar;
8. transferir o foco tonal para frases novas.

### Recursos didáticos

- mapa de contorno tonal associado a palavras e não a desenhos abstratos;
- tabela de comparação auditiva;
- pares mínimos curtos;
- microdrills de escuta e repetição;
- espaço para gravação e autoavaliação;
- quiz de identificação auditiva;
- aviso de que leitura não comprova correção.

## PDF 03 — Perguntar, Confirmar e Negar

### Objetivo

Ensinar o estudante a abrir, confirmar, negar e corrigir informações durante uma conversa.

### Progressão

1. formar perguntas de sim ou não com `吗`;
2. devolver ou manter o tópico com `呢`;
3. confirmar uma informação;
4. responder de modo curto e completo;
5. negar hábito, preferência ou intenção com `不`;
6. negar ocorrência, resultado ou posse com `没`;
7. distinguir `不是`, `不要` e `没有`;
8. escolher alternativas com `还是`;
9. transferir as operações para uma conversa nova.

### Recursos didáticos

- tabela afirmação → pergunta;
- quadro `不` × `没`;
- cartões de confirmação e correção;
- exercício de resposta curta e resposta completa;
- quiz de seleção contextual;
- tarefa final de reparo e confirmação.

## PDF 04 — Recombinação de Padrões

### Objetivo

Fazer o estudante perceber que uma frase conhecida pode ser uma estrutura produtiva, com partes fixas e partes substituíveis.

### Progressão

1. identificar o núcleo fixo;
2. separar slots substituíveis;
3. controlar a troca de sujeito;
4. controlar a troca de objeto;
5. acrescentar lugar ou tempo;
6. adicionar uma extensão opcional;
7. combinar duas células já estudadas;
8. produzir variações sem repetir o exemplo original;
9. retirar o suporte até restar apenas o contexto.

### Recursos didáticos

- tabelas de slots;
- cartões de substituição;
- mapas de padrão;
- exercícios de arranjo e escolha;
- quadro “fixo × variável × opcional”;
- quiz de identificação de componentes;
- desafio de produção em tempo limitado.

## PDF 05 — Pronúncia para Brasileiros

### Objetivo

Trabalhar sons e contrastes articulatórios que afetam a compreensão de brasileiros.

### Progressão

1. compreender o pinyin como sistema próprio;
2. ouvir e produzir `q`, `x` e `j`;
3. contrastar `zh`, `ch`, `sh` e `r`;
4. diferenciar aspiração e não aspiração;
5. trabalhar `ü` em palavras frequentes;
6. distinguir finais `-n` e `-ng`;
7. revisar tons dentro de expressões;
8. trabalhar ritmo e agrupamento de fala;
9. aplicar os contrastes em frases novas.

### Recursos didáticos

- diagrama simples de posição articulatória;
- tabela de contraste auditivo;
- gravação e comparação;
- microdrills curtos;
- pares de palavras e frases;
- quiz de identificação de som;
- ficha de limites e feedback.

## PDF 06 — Revisão Cumulativa por Mapas

### Objetivo

Integrar células antigas e novas em situações de transferência, reduzindo a dependência do mapa completo.

### Progressão

1. revisar por função comunicativa;
2. revisar por contraste;
3. combinar células de módulos diferentes;
4. alterar pessoa, objeto, lugar e tempo;
5. responder a prompts sem roteiro;
6. realizar consolidações de 60 segundos;
7. realizar consolidações de 90 segundos;
8. medir retenção tardia;
9. registrar a redução de consultas ao mapa.

### Recursos didáticos

- mapas de consolidação;
- matriz de células antigas e novas;
- cartões de situação;
- calendário de revisão;
- ficha de latência e dependência visual;
- quiz de integração;
- tarefa final de transferência cumulativa.

## PDF 07 — Preparação para Interação Social

### Objetivo

Preparar o estudante para usar o repertório com interlocutores reais, sem fingir que o PDF é uma comunidade ou substitui feedback humano.

### Progressão

1. iniciar uma conversa;
2. manter o turno;
3. devolver uma pergunta;
4. pedir esclarecimento;
5. pedir para falar mais devagar;
6. confirmar se entendeu;
7. reagir a uma resposta inesperada;
8. expressar concordância ou dúvida;
9. encerrar a conversa;
10. preparar prompts para tutor, intercâmbio ou aplicativo de conversação.

### Recursos didáticos

- cartões de abertura e reparo;
- roteiros incompletos, nunca diálogos fechados para decorar;
- prompts de resposta inesperada;
- quadro de cortesia e registro;
- simulações curtas;
- quiz de escolha de estratégia;
- checklist para prática com interlocutor real.

---

# 8. Modelo fixo de uma aula

Toda aula da coleção deve seguir o mesmo esqueleto para reduzir a carga de navegação do estudante.

## Página 1 — Objetivo de fala

Apresentar:

- uma única função comunicativa;
- resultado observável;
- pré-requisito;
- duração esperada;
- aviso para realizar o áudio sem o PDF aberto.

## Página 2 — Primeira tentativa

Apresentar um prompt sem caracteres, pinyin ou tradução completa. O estudante deve tentar antes de consultar a solução.

## Página 3 — Mapa de orientação

Mostrar a intenção, o padrão, os elementos fixos, os slots, as extensões e o contraste.

## Página 4 — Padrões e exemplos

Apresentar caracteres simplificados, pinyin com tons e tradução natural brasileira.

## Página 5 — Recuperação lacunada

Retirar respostas específicas e solicitar produção oral antes da conferência.

## Página 6 — Recombinação

Oferecer de três a cinco variações controladas. Não aumentar a quantidade de vocabulário apenas para tornar a página mais cheia.

## Página 7 — Contraste ou foco auditivo

Trabalhar uma decisão relevante. Não incluir explicações que não mudem uma ação de compreensão ou produção.

## Página 8 — Transferência

Alterar situação, pessoa, objeto, lugar, tempo ou necessidade. A tarefa não deve ser uma cópia do exemplo.

## Página 9 — Produção sem o mapa

Fechar o mapa completo e responder usando apenas situação, intenção ou poucos gatilhos.

## Página 10 — Registro e quiz

Registrar desempenho, responder ao quiz e indicar o que deve ser revisado.

---

# 9. Quiz de fechamento do método

## Instruções

Responda sem consultar as páginas anteriores. O quiz verifica se você entendeu como usar o material. Ele não substitui a produção oral.

### Parte A — Escolha a alternativa correta

**1. Quando o estudante deve consultar o mapa completo?**

A. Antes de ouvir o áudio.

B. Durante cada frase do áudio.

C. Depois de ouvir e fazer uma primeira tentativa.

D. Somente depois de terminar todos os PDFs.

**2. Qual é a função principal do mapa de orientação?**

A. Decorar todas as frases do idioma.

B. Mostrar a arquitetura da intenção, do padrão e dos componentes.

C. Substituir a prática auditiva.

D. Apresentar uma lista de regras gramaticais.

**3. O que é um slot substituível?**

A. Uma parte fixa da frase.

B. Um erro de pronúncia.

C. Um espaço que pode receber valores diferentes dentro de um padrão estável.

D. Uma tradução literal.

**4. Qual é o objetivo da recombinação?**

A. Fazer o estudante copiar o exemplo várias vezes.

B. Fazer o estudante produzir variações controladas do padrão.

C. Introduzir o maior número possível de palavras novas.

D. Testar apenas reconhecimento visual.

**5. O que acontece quando o estudante falha em transferência?**

A. Ele deve receber uma explicação gramatical mais longa.

B. Ele deve avançar para o próximo PDF.

C. A tarefa deve ser reduzida ou melhor controlada antes de aumentar a explicação.

D. A célula deve ser considerada dominada.

**6. O que significa “o suporte diminui”?**

A. O texto fica cada vez menor até desaparecer sem motivo.

B. O estudante passa do mapa completo ao lacunado, ao prompt mínimo e à produção independente.

C. O PDF deixa de apresentar qualquer exemplo.

D. O áudio deixa de ser necessário.

**7. Qual é o papel do áudio na coleção?**

A. Servir apenas como decoração ou trilha sonora.

B. Ser a fonte principal de escuta e antecipação.

C. Ser substituído pelos mapas.

D. Corrigir automaticamente toda a pronúncia.

**8. Qual deve ser a estrutura de uma célula de transferência?**

A. Lista de palavras, tradução literal e explicação longa.

B. Intenção, padrão, slots, possível contraste, recuperação, transferência e domínio.

C. Apenas uma ilustração e uma frase.

D. Um diálogo completo para memorizar.

**9. O que o mapa de transferência deve mostrar?**

A. Todas as respostas completas do capítulo.

B. Uma situação, uma intenção e poucos gatilhos.

C. A tradução palavra por palavra de todas as frases.

D. Uma lista alfabética de vocabulário.

**10. Qual resultado é compatível com a promessa do projeto?**

A. Fluência garantida em qualquer situação.

B. Correção automática de pronúncia apenas pela leitura.

C. Maior capacidade de reconstruir, recombinar e transferir estruturas ouvidas.

D. Substituição de professor, áudio e interlocutor.

### Parte B — Verdadeiro ou falso

**11.** O estudante deve acompanhar visualmente o áudio principal para não esquecer a resposta.  
( ) Verdadeiro  ( ) Falso

**12.** Um mapa completo que nunca se reduz pode criar dependência.  
( ) Verdadeiro  ( ) Falso

**13.** Uma lista de vocabulário pode ser considerada uma célula de transferência mesmo sem uma tarefa oral.  
( ) Verdadeiro  ( ) Falso

**14.** O domínio deve considerar compreensão, recuperação, pronúncia funcional e transferência.  
( ) Verdadeiro  ( ) Falso

**15.** A tradução em português deve sempre ser palavra por palavra.  
( ) Verdadeiro  ( ) Falso

### Parte C — Aplicação prática

**16.** Você estudou o padrão abaixo:

```text
我叫 + [nome]。
Wǒ jiào + [nome].
Eu me chamo + [nome].
```

Escreva três valores possíveis para o slot `[nome]` e produza oralmente as três frases.

**17.** Crie um prompt de transferência para o padrão acima. A situação deve ser diferente do exemplo original.

**18.** Você não entendeu uma frase durante uma interação. Qual é o próximo passo mais adequado: abandonar a conversa, consultar o mapa completo imediatamente ou pedir reparo e continuar tentando?

**19.** Explique, com suas palavras, a diferença entre mapa de orientação, mapa lacunado e prompt mínimo.

**20.** Escolha uma célula já estudada e combine-a com outra célula em uma situação nova. Registre quais elementos permaneceram fixos e quais foram substituídos.

---

## Gabarito

### Parte A

| Questão | Resposta |
|---:|---|
| 1 | C |
| 2 | B |
| 3 | C |
| 4 | B |
| 5 | C |
| 6 | B |
| 7 | B |
| 8 | B |
| 9 | B |
| 10 | C |

### Parte B

| Questão | Resposta |
|---:|---|
| 11 | Falso |
| 12 | Verdadeiro |
| 13 | Falso |
| 14 | Verdadeiro |
| 15 | Falso |

### Parte C — respostas esperadas

**16.** Qualquer três nomes válidos dentro do escopo da aula. O importante é manter `我叫` fixo e substituir somente o nome.

**17.** Exemplo: “Você entrou em uma sala on-line e precisa se apresentar a uma pessoa nova. Diga que se chama Paulo, depois repita usando outro nome sem consultar o mapa completo.”

**18.** Pedir reparo e continuar tentando. A célula de sobrevivência deve manter a interação ativa.

**19.** O mapa de orientação mostra a estrutura completa depois da tentativa. O mapa lacunado remove respostas para exigir reconstrução. O prompt mínimo mostra apenas situação, intenção e poucos gatilhos para testar independência.

**20.** A resposta deve identificar uma célula anterior, uma célula nova, os componentes fixos, os slots substituídos e a situação de transferência.

### Interpretação do resultado

| Resultado | Interpretação |
|---:|---|
| 17–20 | Você compreendeu o sistema e pode avançar para produção sem o mapa completo. |
| 13–16 | Você entendeu a lógica geral, mas deve revisar os estados de suporte e os critérios de domínio. |
| 9–12 | Retorne ao mapa mestre e refaça uma aula com atenção à sequência de tentativa e recuperação. |
| 0–8 | Releia como o companion deve ser usado antes de iniciar uma nova unidade. |

O resultado do quiz não substitui a produção oral. A evidência principal continua sendo a capacidade de recuperar, recombinar e transferir o padrão.

---

# 10. O que a coleção não pretende fazer

Os PDFs não pretendem:

- substituir o curso ou áudio principal;
- reproduzir diálogos, transcrições, roteiros, vozes ou áudios proprietários;
- ensinar todos os caracteres desde o início;
- cobrir toda a gramática do mandarim;
- criar um novo sistema de repetição espaçada;
- substituir Anki;
- substituir professor, tutor ou interlocutor;
- prometer fluência geral;
- prometer fala espontânea em qualquer situação;
- corrigir automaticamente a pronúncia apenas com texto;
- funcionar como comunidade de conversação;
- apresentar mapas completos como conteúdo suficiente para domínio.

O projeto deve manter uma promessa mais precisa:

> **Depois de ouvir e tentar recuperar uma estrutura, o estudante consegue visualizar sua arquitetura, reconstruí-la com menos apoio, recombiná-la e usá-la em uma situação nova.**

---

# 11. Checklist editorial antes da publicação

Antes de fechar qualquer PDF, verifique cada item abaixo.

| Verificação | Pergunta de aprovação |
|---|---|
| Função | A unidade trabalha uma única operação comunicativa? |
| Padrão | O exemplo pode gerar novas frases? |
| Slots | Os componentes substituíveis têm limites claros? |
| Antecipação | O estudante pode tentar antes de ver a resposta? |
| Caracteres | Os caracteres simplificados foram revisados? |
| Pinyin | O pinyin usa marcas tonais ou indica tom neutro quando necessário? |
| Tradução | A tradução é natural no português brasileiro? |
| Pronúncia | A nota orienta a escuta sem prometer correção por leitura? |
| Contraste | O contraste previne uma decisão real de erro? |
| Recuperação | Existe uma versão lacunada da estrutura? |
| Recombinação | Há pelo menos três variações controladas? |
| Transferência | Existe um contexto novo, e não apenas outro exemplo? |
| Domínio | O critério separa compreensão, recuperação, pronúncia e transferência? |
| Revisão | O conteúdo reaparece depois de um intervalo? |
| Acessibilidade | O significado não depende apenas das cores? |
| Impressão | A página continua legível em escala de cinza? |
| Não oficialidade | A publicação não sugere afiliação, endosso ou autorização de terceiros? |
| Direitos | Não há reprodução reconhecível de material proprietário? |

---

## Frase-âncora da coleção

> **O áudio introduz. A antecipação exige uma tentativa. O mapa organiza as relações. A recombinação amplia o padrão. A transferência demonstra o uso. A independência dispensa o mapa.**

## Referências

[1]: ./mandarim-em-rede-pdf-01-aulas.md "Mandarim em Rede 01 — Fundamentos de Transferência Oral"

[2]: ./mandarim-em-rede-auditoria-estresse.md "Auditoria de estresse e reconstrução definitiva — Mandarim em Rede"

[3]: ./mandarim-em-rede-frame-textual.txt "Frame textual do sistema visual Mandarim em Rede"

[4]: ./plano-acao-mandarim-em-rede-90-dias.md "Plano de Ação de 90 Dias — Mandarim em Rede"

[5]: ./aula-piloto-01-estrutura.md "Estrutura da Aula-piloto 01 — Mandarim em Rede"

[6]: ./roteiro-apresentacao-aula-piloto-01.md "Roteiro de apresentação da Aula-piloto 01 — Mandarim em Rede"

— **Manus AI**

2026-09-08
