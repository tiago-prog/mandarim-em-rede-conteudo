# Análise de viabilidade e implementação — Mandarim em Rede

## Conclusão executiva

O projeto **é viável de implementar**, mas o repositório ainda está na fase de definição editorial e pedagógica. O material existente já descreve uma proposta coerente: usar o áudio como fonte primária e transformar repertório recuperado em recombinação oral por meio de mapas com suporte progressivamente reduzido. As imagens fornecidas reforçam essa proposta com uma identidade visual adequada para um produto editorial de aprendizagem.

A implementação mais segura não é começar por um aplicativo completo. O caminho recomendado é produzir primeiro um **PDF editorial validável**, com duas aulas-piloto e um sistema visual reutilizável. Em seguida, o mesmo conteúdo estruturado poderá alimentar uma experiência web interativa. Um aplicativo nativo, autenticação, sincronização, áudio próprio e avaliação automática de pronúncia devem ficar para uma fase posterior.

A viabilidade geral pode ser resumida da seguinte forma:

| Dimensão | Avaliação | Observação |
|---|---|---|
| Conceito pedagógico | **Boa** | O ciclo de áudio, recuperação, recombinação e transferência está bem definido. |
| Conteúdo inicial | **Boa, com revisão necessária** | O PDF 01 já contém oito aulas, mas exige revisão linguística independente. |
| Identidade visual | **Boa para material editorial** | As imagens fornecem uma direção clara de capa, fundo e linguagem visual. |
| Implementação de PDF | **Alta** | É a primeira entrega tecnicamente simples e mais alinhada ao estágio atual. |
| Aplicação web interativa | **Viável após modelagem do conteúdo** | O conteúdo precisa deixar de existir apenas como Markdown corrido. |
| Aplicativo nativo completo | **Viável, mas prematuro** | Adiciona sincronização, distribuição, áudio, analytics e manutenção. |
| Correção automática de pronúncia | **Alto risco** | Não deve ser prometida sem áudio, modelo validado e critérios linguísticos claros. |
| Risco autoral e de marca | **Controlável** | Depende de manter o produto independente e não reproduzir materiais proprietários. |

## 1. O que já existe e o que ainda falta

O repositório atual é composto exclusivamente por documentação. Não há código de interface, banco de dados, componentes reutilizáveis, arquivos de áudio, imagens versionadas ou pipeline de geração do PDF. Isso não impede a implementação, mas define o ponto de partida: antes de programar a experiência final, é necessário converter a especificação conceitual em um modelo de conteúdo e em um sistema visual executável.

| Já disponível | Ainda necessário |
|---|---|
| Posicionamento do produto | Modelo estruturado de uma célula de transferência |
| Princípios pedagógicos | Template visual completo, lacunado e mínimo |
| Especificação textual dos mapas | Biblioteca de componentes gráficos reutilizáveis |
| Oito aulas do PDF 01 | Revisão linguística e editorial independente |
| Protocolo de revisão de 14 dias | Critérios de avaliação e registro de uso |
| Plano de 90 dias | Amostra de usuários para teste beta |
| Direção visual de capa e fundo | Arquivos visuais em resolução adequada para impressão |

A principal lacuna não é a falta de ideias. É a falta de uma camada intermediária entre o texto editorial e a interface: uma estrutura de dados que permita gerar a mesma célula em diferentes estados de suporte.

## 2. Leitura das referências visuais

### 2.1 Fundo decorativo `bg-fundo-prime.png`

A primeira imagem apresenta uma moldura vertical em azul-marinho, fundo marfim, detalhes lineares em dourado e vermelho e paisagens montanhosas em baixa opacidade. A linguagem evoca uma referência chinesa tradicional sem depender de uma ilustração literal de caracteres ou caligrafia.

Essa imagem funciona bem como **abertura de seção, folha de rosto, página de exercício especial ou moldura de material impresso**. Ela não deve ser aplicada como fundo integral de todas as páginas, porque a ornamentação pode competir com mapas, pinyin, caracteres e instruções de recuperação. O uso contínuo também pode reduzir a legibilidade, aumentar o consumo de tinta e tornar a interface digital visualmente pesada.

A imagem possui 1414 × 2000 pixels, aproximadamente 171 pixels por polegada quando ajustada ao formato A4. Essa resolução é suficiente para visualização em tela e para uma impressão simples, mas fica abaixo de uma preparação gráfica robusta para impressão de alta qualidade. Para a versão comercial impressa, recomenda-se recriar a moldura como vetor ou obter uma exportação de aproximadamente 2480 × 3508 pixels para 300 pixels por polegada.

### 2.2 Capa `CadernodeMandarimAppVisual(21x29.7cm).png`

A segunda imagem apresenta uma capa editorial contemporânea. Ela combina fundo off-white, título grande em azul-marinho, subtítulo em verde-sálvia, formas orgânicas, um caminho ascendente e cartões que representam etapas de aprendizagem. Os acentos terracota, verde e dourado complementam o azul principal.

O caminho visual é especialmente compatível com o projeto porque comunica **progressão**. Os cartões também podem ser reinterpretados como as etapas do método: ouvir, recuperar, visualizar, recombinar e transferir. A capa, portanto, não é apenas decorativa; ela já contém uma metáfora visual coerente com a arquitetura pedagógica do repositório.

A direção visual deve ser preservada com uma distinção importante: a capa pode ser expressiva, mas as páginas de estudo precisam ser mais funcionais. O material interno deve priorizar hierarquia, contraste, espaço para tentativa e separação clara entre resposta, lacuna e prompt. O estilo orgânico da capa não deve resultar em páginas cheias de ilustrações que dificultem a recuperação oral.

### 2.3 Compatibilidade entre as imagens e o sistema pedagógico

As imagens são compatíveis com o projeto em três aspectos. A paleta permite diferenciar intenção, estrutura, variação, alerta auditivo, contraste e revisão. O caminho ascendente representa a redução gradual do suporte. A composição editorial sustenta a ideia de um caderno de acompanhamento, em vez de um curso audiovisual concorrente.

Há também três riscos de design. O primeiro é a utilização excessiva de elementos tradicionais, que pode produzir uma estética genérica de “produto sobre China” em vez de uma ferramenta de aprendizagem para brasileiros. O segundo é a dependência da cor, que prejudicaria impressão em escala de cinza e pessoas com baixa distinção cromática. O terceiro é a resolução raster das imagens, que pode gerar bordas suaves ou artefatos em uma impressão comercial.

A solução é usar cor junto com rótulos, símbolos, forma e posição. O sistema textual já propõe essa redundância por meio dos códigos `[N]`, `[F]`, `[V]`, `[A]`, `[X]`, `[T]` e `[R]`. Esse princípio deve ser mantido na versão visual.

## 3. Produto recomendado por etapas

### Etapa 1 — PDF editorial validável

A primeira entrega deve ser o **Mandarim em Rede 01 — Fundamentos de Transferência Oral**, com uma versão curta e diagramada. O conteúdo do repositório já aponta para oito aulas, um mapa mestre, três estados de suporte, revisão cumulativa, protocolo de 14 dias e autoavaliação.

O PDF deve conter, no mínimo:

1. uma página de posicionamento e limites do companion;
2. um mapa mestre do ciclo de estudo;
3. duas aulas-piloto totalmente diagramadas;
4. em cada aula, mapa completo, mapa lacunado, recombinação, contraste e transferência;
5. uma ficha de autoavaliação em quatro dimensões;
6. uma amostra do protocolo de revisão;
7. a identificação clara como material independente e não oficial.

Depois da validação, as duas aulas-piloto podem ser expandidas para as oito aulas já descritas no arquivo `docs/mandarim-em-rede-pdf-01-aulas.md`. Essa etapa reduz o risco de diagramar 35 a 50 páginas antes de verificar se o fluxo é compreendido pelos usuários.

### Etapa 2 — Leitor web interativo

Se o PDF demonstrar valor, a experiência pode evoluir para uma aplicação web responsiva ou PWA. A primeira versão não precisa de uma rede social, de um scheduler sofisticado ou de um sistema de correção automática. Ela precisa tornar os três estados de suporte mais fáceis de usar.

A experiência mínima poderia oferecer:

- seleção de uma célula de transferência;
- exibição do mapa completo após a tentativa;
- modo lacunado com campos ou cartões ocultos;
- prompt mínimo para transferência;
- registro manual de compreensão, recuperação, pronúncia funcional e transferência;
- redução visual do suporte conforme o progresso;
- links ou instruções para o áudio legítimo que o aluno já utiliza;
- modo de impressão ou exportação da aula.

A aplicação deve funcionar sem abrir o mapa durante o bloco principal de áudio. O produto não deve transformar o áudio em leitura guiada.

### Etapa 3 — Recursos avançados

Somente após uso real e métricas consistentes devem ser considerados login, sincronização entre dispositivos, notificações, dashboard, biblioteca de conteúdo e recursos de áudio. A gravação da voz do aluno pode ser útil como diário de prática, mas não deve ser apresentada como correção confiável por si só.

A avaliação automática de tons e pronúncia é uma linha de produto separada. Ela exigiria especificação fonética, dados de teste, critérios para variedades de fala, tratamento de ruído e validação com especialistas. Não é uma extensão trivial do mapa visual.

## 4. Arquitetura técnica sugerida

### 4.1 Modelo de conteúdo

Cada célula de transferência deve ser armazenada como uma unidade independente. Um modelo inicial poderia conter os seguintes campos:

```text
id
module
lesson
communicative_intent
objective
prerequisites
fixed_parts
variable_parts
optional_parts
pinyin
characters
functional_translation
audio_focus
contrast_note
orientation_map
recovery_map
transfer_prompt
recombination_prompts
mastery_criteria
related_cells
review_schedule
```

O conteúdo editorial poderia continuar sendo mantido em Markdown, mas a produção do PDF e a futura aplicação seriam mais seguras se as informações operacionais fossem extraídas para YAML ou JSON. Assim, a mesma célula poderia gerar uma página impressa, uma tela de recuperação e um prompt mínimo sem duplicar o conteúdo manualmente.

### 4.2 Sistema de design

A direção visual deve ser formalizada em tokens e componentes, não apenas em imagens de referência. O sistema mínimo deve definir:

| Elemento | Regra recomendada |
|---|---|
| Fundo | Off-white ou branco quente nas páginas de estudo; fundo ilustrado reservado para aberturas. |
| Estrutura | Azul-claro ou azul-marinho, sempre acompanhada de rótulo textual. |
| Variável | Verde-sálvia ou verde equivalente, com marcação visual própria. |
| Áudio e tons | Laranja ou terracota, com ícone e texto. |
| Contraste | Vermelho reservado para erros e distinções críticas. |
| Apoio removível | Cinza, com menor peso visual. |
| Revisão e transferência | Dourado, usado para ação e domínio, não para decoração geral. |
| Tipografia | Fonte sans-serif legível para português e pinyin, combinada com fonte CJK testada para caracteres simplificados. |
| Impressão | Contraste suficiente em escala de cinza e margens compatíveis com impressoras domésticas. |
| Acessibilidade | Nunca depender somente de cor; usar rótulo, símbolo, forma ou posição. |

Para o PDF final, a composição deve ser vetorial sempre que possível. A imagem de fundo pode permanecer rasterizada, mas não deve ser o único elemento responsável por estruturar o conteúdo.

### 4.3 Pipeline de produção

Uma arquitetura de produção adequada seria:

```text
conteúdo estruturado
        ↓
componentes de célula e mapa
        ↓
renderização para tela e impressão
        ↓
PDF A4 + versão web responsiva
        ↓
teste linguístico, visual e de uso
```

Para o primeiro PDF, uma implementação editorial baseada em HTML/CSS para impressão ou Typst pode ser suficiente. Para a futura aplicação, os mesmos dados podem alimentar uma interface React ou outra camada web. O ponto essencial é não codificar cada página como uma peça isolada.

## 5. O que deve ser validado antes de programar o aplicativo

A documentação já define bons critérios de decisão. O projeto deve avançar somente depois de testar duas aulas-piloto com estudantes reais. O teste deve observar comportamento, não apenas elogios à estética.

| Pergunta | Sinal de validação |
|---|---|
| O usuário entende o fluxo sem explicação individual? | O material é executável de forma autônoma. |
| O usuário tenta responder antes de consultar? | O layout protege a antecipação. |
| O usuário diferencia mapa completo e lacunado? | Os estados de suporte são compreensíveis. |
| O usuário produz pelo menos três variações? | O padrão é realmente recombinável. |
| O usuário consegue aplicar a estrutura em contexto novo? | Há transferência, não apenas reconhecimento. |
| A consulta ao mapa completo diminui? | O suporte está desaparecendo. |
| O usuário percebe valor além de um resumo? | Existe diferencial comercial. |
| Um revisor qualificado aprova pinyin, tons e traduções? | O conteúdo não cristaliza erros. |

As metas iniciais descritas no plano de 90 dias — como compreensão autônoma do fluxo por pelo menos 70% dos usuários — são adequadas como critérios internos de decisão. Elas não devem ser apresentadas como prova científica de eficácia.

## 6. Riscos principais e mitigação

### Risco autoral e de marca

O material deve continuar organizado por função comunicativa, padrão e objetivo, e não por reprodução de diálogos, roteiros, transcrições ou áudios de terceiros. A expressão “companion independente e não oficial” precisa aparecer na capa, na página de venda e nos créditos. A relação com Pimsleur deve indicar o público de uso, sem sugerir parceria ou endosso.

### Risco pedagógico

Um mapa completo pode facilitar reconhecimento e reduzir recuperação. A resposta é manter a sequência após o áudio: tentativa, consulta, reconstrução, recombinação e transferência. Cada unidade precisa ter estados progressivos e uma tarefa sem suporte.

### Risco linguístico

Pinyin, tons, caracteres e tradução funcional precisam de revisão por alguém qualificado em mandarim. A documentação contém decisões linguísticas que podem ser boas, mas um produto comercial não deve depender de uma única revisão do autor.

### Risco de escopo

O produto pode crescer até virar curso, biblioteca, deck ou aplicativo de conversação. Esse desvio reduziria o foco e aumentaria a complexidade. O primeiro produto deve vender uma transformação restrita: **usar repertório já ouvido em uma situação nova**.

### Risco visual

A capa é forte, mas uma página de aprendizagem precisa dar prioridade à ação oral. Elementos decorativos devem recuar quando houver prompt, lacuna, contraste ou critério de domínio. O fundo ornamental deve ser usado como camada de marca, não como plano constante para todo o conteúdo.

### Risco de promessa tecnológica

O mapa organiza, sinaliza e orienta. Ele não escuta o aluno nem comprova pronúncia correta. A aplicação pode registrar uma autoavaliação ou uma gravação para comparação manual, mas não deve prometer feedback fonético automático sem uma solução validada.

## 7. Plano de implementação recomendado

| Fase | Entrega | Resultado esperado |
|---|---|---|
| 0. Preparação | Revisão linguística, inventário de ativos, definição de licença e público | Escopo seguro e conteúdo confiável |
| 1. Protótipo visual | Uma aula em três estados, usando a paleta e a linguagem das imagens | Verificar se a estética ajuda a tarefa |
| 2. Piloto | Duas aulas diagramadas e testadas sem explicação do criador | Validar compreensão, recuperação e transferência |
| 3. PDF 01 | Oito aulas, revisão, versão A4 e versão para tela | Primeiro produto comercial utilizável |
| 4. Validação beta | 10–15 usuários, registro de falhas, entrevistas e intenção de compra | Decidir se há valor suficiente para continuar |
| 5. Web interativa | Células estruturadas, estados de suporte e progresso manual | Aumentar utilidade sem ampliar o escopo indevidamente |
| 6. Recursos avançados | Áudio, sincronização e analytics, se justificados | Evoluir com base em uso real |

## Decisão recomendada

A recomendação é **implementar**, mas começar pelo produto editorial e não pelo aplicativo completo. O material textual já é suficiente para construir um protótipo visual. As imagens fornecem uma identidade coerente para capa, abertura de módulos e elementos de progressão. O maior trabalho restante é transformar a ideia em unidades testáveis, diagramar duas aulas e comprovar que os usuários conseguem passar do mapa à produção oral.

A ordem prática recomendada é:

1. preservar a direção visual da capa, mas simplificar as páginas internas;
2. converter uma aula em um componente de célula de transferência;
3. produzir os três estados: completo, lacunado e prompt mínimo;
4. testar o fluxo com pelo menos três estudantes;
5. corrigir a arquitetura antes de diagramar o restante;
6. concluir o PDF 01 somente depois do sinal de uso;
7. estruturar o conteúdo em dados antes de construir uma aplicação interativa.

Em síntese, **o projeto está pronto para um protótipo editorial e ainda não está pronto para um aplicativo completo**. Essa diferença é positiva: o próximo passo pode ser pequeno, mensurável e reversível, enquanto preserva a possibilidade de uma plataforma digital futura.

## Referências

[1]: ../README.md "README do projeto Mandarim em Rede"
[2]: ./mandarim-em-rede-auditoria-estresse.md "Auditoria de estresse e reconstrução definitiva — Mandarim em Rede"
[3]: ./mandarim-em-rede-frame-textual.txt "Frame textual do sistema visual Mandarim em Rede"
[4]: ./mandarim-em-rede-pdf-01-aulas.md "Mandarim em Rede 01 — Fundamentos de Transferência Oral"
[5]: ./plano-acao-mandarim-em-rede-90-dias.md "Plano de Ação de 90 Dias — Mandarim em Rede"
[6]: https://www.pimsleur.com/the-pimsleur-method/ "Pimsleur — The Pimsleur Method"
[7]: https://apps.ankiweb.net/ "Anki — Official Website"
[8]: https://www.hellotalk.com/en "HelloTalk — Official Website"
[9]: https://link.springer.com/article/10.1186/s40862-025-00331-2 "Concept Mapping in Second-Language Learning — Meta-analysis"
[10]: https://pmc.ncbi.nlm.nih.gov/articles/PMC3827082/ "Retrieval Practice and Mind Mapping — Experimental Study"

> **Observação:** as conclusões visuais desta análise foram baseadas nas duas referências fornecidas na conversa: `bg-fundo-prime.png` e `CadernodeMandarimAppVisual(21x29.7cm).png`.

— **Manus AI**

2026-09-07
