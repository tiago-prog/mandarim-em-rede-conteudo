# Aula-piloto 01 — Estrutura recomendada

## Mandarim em Rede 01 — Fundamentos de Transferência Oral

### Tema

**Cumprimentar, perguntar o nome e dizer o próprio nome.**

### Função da aula

Iniciar uma interação curta e identificar as pessoas envolvidas.

### Hipótese que a aula deve testar

Depois de realizar o áudio principal e consultar o material apenas após a tentativa, o aluno consegue reconstruir um padrão simples, substituir o nome de uma pessoa, devolver a pergunta com **你呢？** e usar a estrutura em uma situação nova sem consultar o mapa completo.

## 1. Decisão de escopo

A primeira aula-piloto deve testar o **método visual e oral**, não demonstrar todo o conteúdo possível sobre apresentações. Por isso, o núcleo deve ser limitado a quatro operações:

1. cumprimentar;
2. perguntar o nome;
3. dizer o próprio nome;
4. devolver a pergunta.

As expressões **你好吗？**, **我很好。** e **很高兴认识你。** podem aparecer como extensões opcionais. Elas não devem ser necessárias para concluir a aula-piloto, porque adicionam vocabulário antes de o fluxo principal estar validado.

O piloto não deve incluir uma explicação extensa de gramática, uma lista ampla de nomes ou um bloco de caracteres. Os caracteres entram como apoio visual; o objetivo principal é a produção oral.

## 2. Conteúdo linguístico mínimo

| Função | Mandarim | Pinyin | Sentido funcional | Papel no mapa |
|---|---|---|---|---|
| Cumprimentar | 你好。 | **Nǐ hǎo.** | Olá. | Estrutura fixa |
| Perguntar o nome | 你叫什么名字？ | **Nǐ jiào shénme míngzi?** | Qual é o seu nome? | Estrutura fixa |
| Responder | 我叫 + nome。 | **Wǒ jiào + [nome].** | Eu me chamo + nome. | Padrão com variável |
| Devolver a pergunta | 你呢？ | **Nǐ ne?** | E você? | Extensão curta |

### Extensões opcionais

| Função | Mandarim | Pinyin | Sentido funcional |
|---|---|---|---|
| Perguntar como a pessoa está | 你好吗？ | **Nǐ hǎo ma?** | Tudo bem com você? |
| Responder | 我很好。 | **Wǒ hěn hǎo.** | Estou bem. |
| Encerrar a apresentação | 很高兴认识你。 | **Hěn gāoxìng rènshi nǐ.** | Prazer em conhecer você. |

As extensões devem ser visualmente marcadas como **opcionais**. A primeira tarefa de transferência não deve depender delas.

## 3. Estrutura recomendada do piloto

A versão de teste pode ter uma capa e **oito páginas instrucionais**. A ordem abaixo protege a antecipação, apresenta o mapa depois da tentativa e conduz o aluno até uma produção independente.

| Página | Função | Estado do suporte | Resultado esperado |
|---:|---|---|---|
| Capa | Identificar a aula e a identidade visual | Sem conteúdo de resposta | O aluno entende o tema. |
| 1 | Explicar o objetivo e o protocolo | Orientação | O aluno sabe que deve fazer o áudio sem abrir o PDF. |
| 2 | Ativar e tentar responder | Prompt mínimo | O aluno produz uma primeira tentativa sem ver a solução. |
| 3 | Mostrar a arquitetura da aula | Mapa completo | O aluno entende a relação entre intenção e padrão. |
| 4 | Organizar as estruturas essenciais | Apoio controlado | O aluno reconhece fixos, variável e extensão. |
| 5 | Reconstruir a estrutura | Mapa lacunado | O aluno recupera o padrão sem simplesmente copiar. |
| 6 | Produzir variações | Recombinação | O aluno gera pelo menos três frases controladas. |
| 7 | Aplicar em cenário novo | Prompt mínimo | O aluno transfere o padrão para uma situação não idêntica. |
| 8 | Registrar desempenho | Sem mapa completo | O aluno e o teste registram compreensão, recuperação, pronúncia e transferência. |

## 4. Conteúdo de cada página

### Capa

A capa pode usar a direção visual da imagem fornecida: fundo off-white, azul-marinho, verde-sálvia, terracota e dourado. O fundo ornamental com montanhas deve aparecer como moldura ou elemento de abertura, não atrás de todo o conteúdo didático.

Texto sugerido:

> **Mandarim em Rede 01**  
> **Aula 1 — Entrar na interação**  
> Cumprimentar, perguntar o nome e dizer o próprio nome

Rodapé obrigatório:

> Companion visual independente e não oficial para estudantes brasileiros de mandarim. Não afiliado, endossado ou autorizado pela Pimsleur.

### Página 1 — Objetivo e protocolo

A página deve responder a três perguntas: o que o aluno vai conseguir fazer, quando usar o PDF e como saberá que concluiu.

Texto sugerido:

> **Ao final desta aula, você deverá conseguir:**
>
> - cumprimentar uma pessoa;
> - perguntar o nome dela;
> - dizer seu próprio nome;
> - devolver a pergunta com **你呢？**;
> - realizar uma troca curta sem ler a resposta.
>
> **Use nesta ordem:**
>
> 1. faça a sessão principal de áudio sem acompanhar este PDF;
> 2. tente produzir o que lembrar;
> 3. consulte o mapa completo;
> 4. pratique o mapa lacunado;
> 5. produza três variações;
> 6. faça a tarefa de transferência sem olhar o mapa completo.

Usar uma faixa visual destacada para a regra:

> **O mapa entra depois da tentativa. Ele organiza a estrutura, mas não substitui a escuta.**

### Página 2 — Primeira tentativa sem resposta

Esta página deve ser deliberadamente incompleta. A resposta completa não pode aparecer no mesmo campo visual do prompt.

Título:

> **Antes de consultar: o que você consegue produzir?**

Prompt de ativação:

> Imagine que você acabou de conhecer uma pessoa. Sem abrir outra página, tente produzir oralmente:
>
> 1. uma saudação;
> 2. uma pergunta sobre o nome;
> 3. uma resposta com seu nome;
> 4. uma devolução da pergunta.

Registro rápido:

| Item | Consegui iniciar? | Hesitei? | Precisei consultar? |
|---|---|---|---|
| Saudação | ☐ | ☐ | ☐ |
| Pergunta do nome | ☐ | ☐ | ☐ |
| Meu nome | ☐ | ☐ | ☐ |
| Devolver a pergunta | ☐ | ☐ | ☐ |

Não incluir pinyin, tradução ou caracteres da resposta nesta página. O objetivo é testar a antecipação e produzir uma linha de base.

### Página 3 — Mapa completo de orientação

Esta página apresenta a rede somente depois da primeira tentativa.

Núcleo:

> **[N] INICIAR UMA INTERAÇÃO E IDENTIFICAR PESSOAS**

Ramos:

```text
[N] Iniciar uma interação
        │
        ├── [F] Cumprimentar
        │       └── 你好 — Nǐ hǎo.
        │
        ├── [F] Perguntar o nome
        │       └── 你叫什么名字？— Nǐ jiào shénme míngzi?
        │
        ├── [V] Dizer o próprio nome
        │       └── 我叫 + [nome] — Wǒ jiào + [nome].
        │
        ├── [O] Devolver a pergunta
        │       └── 你呢？— Nǐ ne?
        │
        ├── [A] Foco auditivo
        │       ├── 叫 jiào: quarto tom, curto e descendente
        │       ├── 名字 míngzi: segunda sílaba geralmente neutra
        │       └── nǐ hǎo: ouvir a realização conectada, frequentemente ní hǎo
        │
        ├── [X] Contraste
        │       └── não montar a pergunta seguindo a ordem literal do português
        │
        └── [R] Transferência
                └── realizar uma apresentação com nome diferente
```

O mapa deve usar os códigos e as cores do projeto, mas não pode depender apenas das cores. Cada ramo deve possuir rótulo textual e símbolo.

### Página 4 — Padrões e vocabulário funcional

A página deve mostrar apenas o vocabulário necessário para executar a aula.

#### Padrão A — Saudação

```text
你好。
Nǐ hǎo.
Olá.
```

#### Padrão B — Perguntar o nome

```text
你叫什么名字？
Nǐ jiào shénme míngzi?
Qual é o seu nome?
```

#### Padrão C — Responder

```text
我叫 + [nome]。
Wǒ jiào + [nome].
Eu me chamo + [nome].
```

#### Padrão D — Devolver a pergunta

```text
你呢？
Nǐ ne?
E você?
```

Vocabulário funcional:

| Elemento | Função |
|---|---|
| 你 **nǐ** | você |
| 我 **wǒ** | eu |
| 叫 **jiào** | chamar-se; chamar |
| 什么 **shénme** | o que; qual |
| 名字 **míngzi** | nome |
| 呢 **ne** | partícula para devolver a pergunta |

A tradução deve ser funcional. Não transformar a página em uma tabela palavra por palavra para memorizar.

### Página 5 — Mapa lacunado de recuperação

O mapa lacunado deve manter a intenção, a estrutura e os gatilhos, mas retirar as respostas que o aluno precisa recuperar.

Exemplo:

```text
[N] Iniciar uma interação

1. Cumprimentar:
   ________

2. Perguntar o nome:
   你叫 ________ ________？

3. Dizer o próprio nome:
   ________ 叫 + [nome]

4. Devolver a pergunta:
   你 ________？
```

Instrução:

> Cubra ou ignore a página 4. Diga cada resposta em voz alta antes de escrever ou conferir. Se precisar consultar, marque a célula como “em recuperação”, não como dominada.

Para uma versão digital, as lacunas podem ser reveladas somente depois de uma tentativa. Para impressão, a resposta deve ser deslocada para uma página posterior ou apresentada em uma seção de conferência separada.

### Página 6 — Recombinador controlado

A página deve separar claramente o que permanece fixo do que pode ser substituído.

Padrão-base:

```text
我叫 + [nome]。
```

Substituições mínimas:

1. diga que você se chama **Ana**;
2. diga que você se chama **Paulo**;
3. escolha outro nome e produza a frase sem olhar.

Sequências de interação:

1. Cumprimente alguém e diga seu nome.
2. Pergunte o nome de uma pessoa chamada Ana.
3. Pergunte o nome de uma pessoa chamada Paulo.
4. Diga seu nome e devolva a pergunta com **你呢？**.
5. Faça uma troca de quatro falas: saudação, pergunta, resposta e devolução da pergunta.

Regra editorial:

> A aula deve oferecer substituições suficientes para demonstrar produtividade, mas não tantos nomes ou expressões que o aluno passe a estudar vocabulário em vez de praticar o padrão.

### Página 7 — Contraste e transferência

A página deve conter um único contraste principal e um cenário novo.

#### Contraste principal

O aluno brasileiro pode tentar montar uma pergunta equivalente a “como você chama seu nome?” seguindo a ordem do português. A página deve mostrar que **你叫什么名字？** é uma estrutura própria do mandarim e precisa ser recuperada como padrão, não montada palavra por palavra.

#### Foco auditivo

- **叫 jiào:** quarto tom, curto e descendente;
- **好 hǎo:** terceiro tom em forma lexical;
- **名字 míngzi:** a segunda sílaba costuma ser neutra;
- **你呢 nǐ ne:** a partícula **呢** não recebe o mesmo peso de uma sílaba tônica plena.

A instrução deve ser limitada ao que muda uma decisão de escuta ou produção. Não prometer correção de pronúncia por leitura.

#### Tarefa de transferência

> Você chega a um encontro on-line e entra em uma sala com uma pessoa que ainda não conhece. Produza, sem consultar o mapa completo:
>
> 1. uma saudação;
> 2. uma pergunta sobre o nome;
> 3. uma resposta usando um nome que não apareceu nos exemplos;
> 4. **你呢？** para devolver a pergunta;
> 5. uma segunda rodada usando outro nome.

Critério de transferência: a situação deve mudar, mas a operação comunicativa deve permanecer a mesma.

### Página 8 — Critério de domínio e autoavaliação

A página final não deve mostrar o mapa completo. Ela deve registrar desempenho.

| Dimensão | Pergunta de autoavaliação | Resultado |
|---|---|---|
| Compreensão | Reconheci a função quando ouvi? | 0 / 1 / 2 |
| Recuperação | Produzi antes de consultar? | 0 / 1 / 2 |
| Pronúncia funcional | Mantive os focos de **叫**, **名字** e **你呢**? | 0 / 1 / 2 |
| Transferência | Usei a estrutura com nome e situação novos? | 0 / 1 / 2 |

Legenda:

- **0:** ainda não consigo;
- **1:** consigo com hesitação ou apoio;
- **2:** consigo sem consultar o mapa completo.

Aula concluída significa:

- produzir a saudação sem hesitação prolongada;
- perguntar o nome sem traduzir palavra por palavra;
- responder com pelo menos dois nomes diferentes;
- devolver a pergunta com **你呢？**;
- realizar a troca em um contexto novo;
- usar o mapa completo apenas como apoio, não como roteiro permanente.

## 5. Regras de design para o piloto

### Proteger a antecipação

A primeira tentativa deve estar antes de qualquer resposta completa. No PDF, separar o prompt e o mapa completo em páginas diferentes. Na versão web, exigir uma ação de tentativa antes de habilitar a resposta.

### Reduzir a densidade

Usar no máximo um objetivo comunicativo, um padrão central, três ou quatro variáveis, um contraste e um foco auditivo prioritário. O piloto deve ser fácil de executar, mesmo que pareça menos “completo”.

### Usar as imagens de forma funcional

A capa pode seguir a referência visual recebida. O fundo ornamental pode ser usado na capa, na abertura do módulo e na página de encerramento. As páginas de recuperação devem usar fundo claro e limpo, com espaço visível para lacunas e anotações.

### Manter a redundância semântica

Cada categoria deve ter cor, rótulo e símbolo. A legenda recomendada é:

| Categoria | Cor | Símbolo |
|---|---|---|
| Intenção | Azul-marinho | `[N]` |
| Estrutura fixa | Azul-claro | `[F]` |
| Elemento variável | Verde | `[V]` |
| Som e tom | Laranja/terracota | `[A]` |
| Contraste | Vermelho | `[X]` |
| Apoio removível | Cinza | `[T]` |
| Revisão e transferência | Dourado | `[R]` |

## 6. Como avaliar o piloto

O teste deve ser feito com pelo menos três estudantes sem explicar a página verbalmente. Registrar:

- onde o aluno começa;
- se ele tenta responder antes de consultar;
- quais elementos parecem igualmente importantes;
- se entende a diferença entre mapa completo e lacunado;
- quantas variações produz;
- se consegue realizar o prompt novo;
- se o aluno descreve o material como “resumo” ou como ferramenta de produção;
- quais pontos de pinyin, tom e tradução geram dúvida.

O piloto passa para a próxima etapa se a maioria dos usuários conseguir executar o fluxo sem instrução adicional relevante e se a tarefa de transferência for entendida como uma ação diferente de repetir os exemplos. O objetivo não é obter elogios à capa; é observar se o mapa provoca recuperação e produção.

## 7. Resultado esperado

A primeira aula-piloto deve demonstrar o seguinte ciclo:

```text
ouvir → tentar responder → consultar o mapa → reconstruir →
substituir o nome → produzir uma troca nova → registrar o domínio
```

Se esse ciclo funcionar, a mesma arquitetura poderá ser reutilizada nas aulas seguintes. Se não funcionar, deve-se corrigir a sequência, a densidade ou a linguagem visual antes de produzir as outras sete aulas.

## Referências

[1]: ../README.md "README do projeto Mandarim em Rede"
[2]: ./mandarim-em-rede-pdf-01-aulas.md "Mandarim em Rede 01 — Fundamentos de Transferência Oral"
[3]: ./mandarim-em-rede-frame-textual.txt "Frame textual do sistema visual Mandarim em Rede"
[4]: ./plano-acao-mandarim-em-rede-90-dias.md "Plano de Ação de 90 Dias — Mandarim em Rede"
[5]: ./mandarim-em-rede-auditoria-estresse.md "Auditoria de estresse e reconstrução definitiva — Mandarim em Rede"

— **Manus AI**

2026-09-07
