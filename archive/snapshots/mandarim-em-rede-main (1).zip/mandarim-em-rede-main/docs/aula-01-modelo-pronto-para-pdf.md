# MANDARIM EM REDE
## Aula 1 — Cumprimentar e dizer o próprio nome

### Modelo editorial pronto para diagramação em PDF

**Função comunicativa:** iniciar uma interação e identificar as pessoas envolvidas.  
**Nível:** iniciante absoluto.  
**Duração visual e oral estimada:** 12 a 20 minutos, além do áudio principal.  
**Estado do suporte:** completo → lacunado → mínimo → sem mapa completo.

> **Companion visual independente e não oficial para estudantes brasileiros de mandarim.**

---

# Guia de produção visual

Este documento separa o conteúdo em páginas para facilitar a diagramação. Cada página contém uma intenção pedagógica, texto pronto e orientação de layout.

### Paleta semântica sugerida

| Elemento | Cor | Função |
|---|---|---|
| Intenção comunicativa | Azul-marinho | Indica o que o aluno quer fazer |
| Estrutura fixa | Azul-claro | Indica ordem e componentes estáveis |
| Slot substituível | Verde-sálvia | Indica o que pode ser trocado |
| Som, pinyin e tom | Terracota/laranja | Indica foco auditivo |
| Contraste ou alerta | Vermelho | Indica erro previsível |
| Apoio removível | Cinza | Indica tradução e explicação temporárias |
| Transferência e domínio | Dourado | Indica ação final e critério de avanço |

A cor nunca deve ser o único sinal. Cada categoria deve receber também um rótulo, um símbolo ou uma forma própria para continuar compreensível em escala de cinza.

---

# PÁGINA 1 — Cabeçalho e objetivo de fala

## Título da página

# AULA 1 — CUMPRIMENTAR E DIZER O PRÓPRIO NOME

### Subtítulo

**Iniciar uma interação em mandarim.**

### Objetivo de fala

Ao final desta aula, você deverá conseguir:

1. cumprimentar uma pessoa;
2. perguntar o nome dela;
3. dizer o seu próprio nome;
4. devolver a pergunta com **你呢？**;
5. realizar essa troca com dois nomes diferentes, sem consultar o mapa completo.

### Resultado observável

> **Você consegue realizar duas trocas curtas de quatro falas:**
>
> ```text
> saudação → pergunta do nome → resposta → devolução da pergunta
> ```
>
> A produção não precisa ser perfeita ou nativa. Ela precisa ser funcional, compreensível para a tarefa e realizada com apoio visual reduzido.

### Regra de uso

> **Primeiro tente. Depois consulte o mapa.**

Faça o áudio principal sem acompanhar este PDF. O material visual entra depois da primeira tentativa para organizar, recombinar e testar a transferência.

### Elemento visual recomendado

Usar um bloco dourado com a sequência:

```text
OUVIR → TENTAR → MAPA → RECOMBINAR → TRANSFERIR
```

### Espaço de ativação

Antes de consultar as próximas páginas, tente dizer em voz alta uma saudação e seu nome.

**O que consegui produzir?**

```text
____________________________________________________________
____________________________________________________________
```

---

# PÁGINA 2 — Passo a passo da aula

## Como usar esta aula

Siga a sequência. Não pule diretamente para a tabela de respostas.

### Passo 1 — Ouvir

Realize sua sessão principal de áudio sem acompanhar o PDF.

### Passo 2 — Tentar

Depois do áudio, tente dizer em voz alta:

- uma saudação;
- uma pergunta sobre o nome;
- seu próprio nome;
- uma devolução da pergunta.

### Passo 3 — Consultar

Abra o mapa completo e observe como as quatro ações se conectam.

### Passo 4 — Reconstruir

Use o mapa lacunado. Fale antes de preencher ou conferir as lacunas.

### Passo 5 — Recombinar

Troque o nome e produza novas versões do mesmo padrão.

### Passo 6 — Transferir

Feche o mapa completo e use a estrutura em uma situação nova.

### Passo 7 — Registrar

Marque o que você conseguiu compreender, recuperar, pronunciar e transferir.

### Ordem visual do suporte

```text
MAPA COMPLETO → MAPA LACUNADO → PROMPT MÍNIMO → SEM MAPA COMPLETO
```

> **O mapa começa completo e termina dispensável.**

---

# PÁGINA 3 — Mapa mental de orientação: versão completa

## Núcleo da intenção comunicativa

```text
[N] INICIAR UMA INTERAÇÃO
```

### Mapa principal

```text
                              [N]
                   INICIAR UMA INTERAÇÃO
                              │
       ┌──────────────────────┼──────────────────────┐
       │                      │                      │
       ▼                      ▼                      ▼
 [F] CUMPRIMENTAR     [F] PERGUNTAR O NOME    [S] DIZER O NOME
       │                      │                      │
    你好。              你叫什么名字？          我叫 + [nome]
    Nǐ hǎo.             Nǐ jiào shénme          Wǒ jiào + [nome]
                         míngzi?
       └──────────────────────┼──────────────────────┘
                              ▼
                    [O] DEVOLVER A PERGUNTA
                              │
                           你呢？
                           Nǐ ne?
                              │
                              ▼
                    [R] PRODUZIR EM SITUAÇÃO NOVA
```

### Legenda do mapa

| Marca | Significado | Nesta aula |
|---|---|---|
| `[N]` | Núcleo | iniciar uma interação |
| `[F]` | Fixo | saudação e pergunta do nome |
| `[S]` | Substituível | nome dentro de `我叫 + [nome]` |
| `[O]` | Opcional | devolver a pergunta |
| `[A]` | Auditivo | tons e pronúncia |
| `[X]` | Contraste | padrão do mandarim versus ordem literal do português |
| `[R]` | Resultado | produzir em uma situação nova |

### O que permanece fixo

```text
你好。
你叫什么名字？
我叫
你呢？
```

### O que pode ser trocado

```text
我叫 + [nome]
```

O aluno troca apenas o nome. A estrutura **我叫** permanece estável.

---

# PÁGINA 4 — Padrões e frases-chave

## 1. Cumprimentar

```text
你好。
Nǐ hǎo.
Olá.
```

| Elemento | Papel |
|---|---|
| `你好` | Estrutura fixa |
| Função | Abrir uma interação |
| Pode ser trocado? | Não é necessário trocar nesta aula |

## 2. Perguntar o nome

```text
你叫什么名字？
Nǐ jiào shénme míngzi?
Qual é o seu nome?
```

| Elemento | Papel |
|---|---|
| `你叫什么名字？` | Estrutura fixa nesta aula |
| Função | Perguntar o nome do interlocutor |
| Pode ser trocado? | Não antes de o padrão estar estável |

## 3. Dizer o próprio nome

```text
我叫 + [nome]。
Wǒ jiào + [nome].
Eu me chamo + [nome].
```

| Elemento | Papel |
|---|---|
| `我叫` | Fixo |
| `[nome]` | Substituível |
| Função | Informar o próprio nome |

## 4. Devolver a pergunta

```text
你呢？
Nǐ ne?
E você?
```

| Elemento | Papel |
|---|---|
| `你呢？` | Expressão curta e estável |
| Função | Devolver o foco ao interlocutor |
| Pode ser trocado? | Não é necessário trocar nesta aula |

### Troca completa

```text
A: 你好。
   Nǐ hǎo.
   Olá.

B: 你好。
   Nǐ hǎo.
   Olá.

A: 你叫什么名字？
   Nǐ jiào shénme míngzi?
   Qual é o seu nome?

B: 我叫安娜。你呢？
   Wǒ jiào Ānnà. Nǐ ne?
   Eu me chamo Ana. E você?
```

> Consulte esta troca somente depois de fazer sua primeira tentativa. Ela é um modelo de organização, não um roteiro para decorar.

---

# PÁGINA 5 — Vocabulário funcional essencial

Use apenas o vocabulário necessário para realizar a função desta aula.

| Caractere | Pinyin | Função nesta aula | Exemplo |
|---|---|---|---|
| 你 | **nǐ** | você | `你呢？` |
| 我 | **wǒ** | eu | `我叫...` |
| 叫 | **jiào** | chamar-se; chamar | `我叫...` |
| 什么 | **shénme** | o que; qual | `什么名字` |
| 名字 | **míngzi** | nome | `你的名字` não é necessário nesta aula |
| 呢 | **ne** | devolver o foco ao interlocutor | `你呢？` |

### Nota de economia

Não é necessário estudar agora uma lista de nomes chineses. Você pode usar seu próprio nome em português ou um nome fornecido pelo exercício. O objetivo desta aula é praticar a estrutura oral, não aprender uma lista de nomes.

### Espaço para registrar seu nome de prática

```text
Meu nome de prática 1: ______________________________________

Meu nome de prática 2: ______________________________________
```

---

# PÁGINA 6 — Pontos críticos de pronúncia e tons

## A. `你好 — Nǐ hǎo`

Na forma lexical, as duas sílabas aparecem com terceiro tom: `nǐ hǎo`. Em fala conectada, a primeira costuma ser realizada com contorno de segundo tom, aproximando-se de `ní hǎo`.

### Faça

- ouça a expressão completa;
- imite o fluxo da fala;
- trate a forma escrita como referência, não como pronúncia mecânica.

### Evite

- pronunciar `nǐ` como um “ni” português sem contorno tonal;
- separar as duas sílabas de modo excessivamente artificial;
- aplicar a regra sem ouvir a expressão.

## B. `叫 — jiào`

`叫 jiào` recebe o quarto tom, com queda curta e definida.

### Para brasileiros

O `j` do pinyin não deve ser lido automaticamente como o `j` de “já” ou “jogo”. A referência principal deve ser o áudio.

## C. `什么 — shénme`

A primeira sílaba tem segundo tom. A segunda costuma ser átona ou neutra na fala corrente.

```text
shén-me
```

Não dê o mesmo peso às duas sílabas.

## D. `名字 — míngzi`

`míng` recebe segundo tom. `zi` costuma ser neutro.

Não faça a segunda sílaba tão forte quanto a primeira.

## E. `你呢 — Nǐ ne`

`呢 ne` é uma partícula geralmente átona. Ela não precisa receber o mesmo destaque de `nǐ`.

### Quadro rápido de tons

| Forma | Tom principal | Instrução funcional |
|---|---|---|
| nǐ | 3º na forma lexical | ouvir a realização em `nǐ hǎo` |
| hǎo | 3º | não transformar em queda do 4º tom |
| jiào | 4º | queda curta e definida |
| shén | 2º | movimento ascendente |
| míng | 2º | movimento ascendente |
| zi | neutro | sílaba mais leve |
| ne | neutro | partícula leve |

> **Limite importante:** o pinyin ajuda a visualizar o alvo, mas não comprova nem corrige a pronúncia sozinho. Para avaliar sua produção, use áudio, gravação própria, feedback humano ou uma ferramenta adequada.

### Nota de escuta

```text
O objetivo não é falar como um nativo nesta primeira aula.
O objetivo é produzir uma troca compreensível e continuar praticando.
```

---

# PÁGINA 7 — Mapa mental lacunado

## Instrução

Cubra a Página 4. Diga cada resposta em voz alta antes de preencher ou conferir.

### Mapa lacunado 1 — Sequência principal

```text
[N] INICIAR UMA INTERAÇÃO

1. Cumprimentar:
   ________。

2. Perguntar o nome:
   你叫 ________ ________？

3. Dizer o próprio nome:
   ________ 叫 + [nome]。

4. Devolver a pergunta:
   你 ________？
```

### Mapa lacunado 2 — Componentes

```text
[F] Estrutura fixa da resposta:
   我 ________

[S] Parte substituível:
   ______________________________

[O] Expressão para devolver a pergunta:
   你 ________？
```

### Mapa lacunado 3 — Troca inteira

Complete oralmente:

```text
A: ________。
   Nǐ hǎo.

B: 你好。
   ____________________

A: 你叫什么名字？
   ____________________

B: 我叫 ____________________。你呢？
   ____________________
```

### Registro da recuperação

| Parte | Produzi antes de consultar? | Precisei consultar? |
|---|---|---|
| Saudação | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Pergunta do nome | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Meu nome | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Devolução | ☐ Sim ☐ Não | ☐ Sim ☐ Não |

---

# PÁGINA 8 — Exercícios de recombinação

## Instrução geral

Produza oralmente. Não copie uma frase inteira antes de tentar. Em cada exercício, mantenha a parte fixa e troque somente o elemento indicado.

### Exercício 1 — O núcleo permanece

Diga três vezes:

```text
我叫 + seu nome
```

Na segunda vez, faça sem olhar. Na terceira, diga com ritmo natural.

### Exercício 2 — Troque o nome

Produza:

| Rodada | Slot substituível | Sua produção oral |
|---:|---|---|
| 1 | Ana | ☐ |
| 2 | Paulo | ☐ |
| 3 | outro nome | ☐ |

Estrutura de apoio:

```text
我叫 + [nome]。
```

### Exercício 3 — Pergunte e responda

Imagine três interlocutores diferentes. Para cada um:

1. diga `你好`;
2. pergunte `你叫什么名字？`;
3. responda com `我叫 + nome`;
4. acrescente `你呢？`.

| Rodada | Nome usado | Fiz a sequência completa? |
|---:|---|---|
| 1 | __________________ | ☐ |
| 2 | __________________ | ☐ |
| 3 | __________________ | ☐ |

### Exercício 4 — Responda a uma pergunta

Leia apenas a pergunta e responda em voz alta:

```text
你叫什么名字？
```

Sua resposta deve conter:

```text
我叫 + [nome] + 你呢？
```

### Exercício 5 — Mude o contexto

Faça a troca completa em duas situações:

| Situação | Produzi sem o mapa completo? |
|---|---|
| Conhecer alguém presencialmente | ☐ |
| Entrar em uma sala on-line | ☐ |

O contexto muda. A função e o padrão permanecem.

### Exercício 6 — Gatilhos mínimos

Use somente os gatilhos abaixo:

```text
cumprimentar → perguntar nome → seu nome → devolver
```

Faça uma troca. Depois repita com um nome diferente.

---

# PÁGINA 9 — Mapa mínimo e tarefa de transferência

## Mapa mental de transferência: versão mínima

```text
[N] pessoa nova

cumprimentar
→ perguntar nome
→ dizer seu nome
→ devolver pergunta
```

Não há resposta completa nesta versão. Use apenas a intenção e a sequência.

## Tarefa de produção oral — sem olhar

### Situação

Você acaba de entrar em uma sala on-line e conhece uma pessoa pela primeira vez.

### Tarefa

Realize duas trocas curtas:

1. cumprimente a pessoa;
2. pergunte o nome dela;
3. diga seu próprio nome;
4. devolva a pergunta com `你呢？`;
5. repita usando um nome diferente.

### Procedimento numerado

1. feche o mapa completo;
2. prepare-se por até 20 segundos;
3. faça a primeira troca;
4. faça uma pausa;
5. repita com outro nome;
6. grave a segunda tentativa, se possível;
7. registre o nível de apoio utilizado.

### Registro da tarefa

| Item | Primeira tentativa | Segunda tentativa |
|---|---|---|
| Iniciei a saudação | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Perguntei o nome | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Disse meu nome | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Devolvi a pergunta | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Usei nome diferente | ☐ Sim ☐ Não | ☐ Sim ☐ Não |
| Consultei o mapa completo | ☐ Sim ☐ Não | ☐ Sim ☐ Não |

### Apoio permitido

Se você travar, olhe apenas para estes gatilhos:

```text
saudação → nome da outra pessoa → seu nome → devolução
```

Tente novamente antes de reabrir o mapa completo.

### Resultado da transferência

```text
Consegui realizar a troca?  ☐ Sim  ☐ Parcialmente  ☐ Ainda não

O que ficou mais difícil?
____________________________________________________________
____________________________________________________________
```

---

# PÁGINA 10 — Critério de domínio

## Checklist de avanço

Marque somente o que você realmente consegue fazer.

### Compreensão

- [ ] Entendo que a função desta aula é iniciar uma interação.
- [ ] Reconheço a função de `你好`.
- [ ] Reconheço a função de `你叫什么名字？`.
- [ ] Reconheço a função de `我叫 + nome`.
- [ ] Reconheço a função de `你呢？`.

### Recuperação

- [ ] Tentei produzir antes de consultar a resposta.
- [ ] Consigo perguntar o nome sem montar a frase palavra por palavra em português.
- [ ] Consigo dizer meu nome com `我叫`.
- [ ] Consigo devolver a pergunta com `你呢？`.

### Recombinação

- [ ] Produzi pelo menos três nomes ou variações controladas.
- [ ] Mantive `我叫` fixo enquanto troquei o nome.
- [ ] Consegui realizar a sequência com dois nomes diferentes.

### Pronúncia funcional

- [ ] Consigo produzir `jiào` com uma queda curta do quarto tom.
- [ ] Não dou peso excessivo às sílabas neutras de `shénme`, `míngzi` e `ne`.
- [ ] Minha produção é compreensível para a tarefa com o apoio de áudio ou feedback disponível.

### Transferência

- [ ] Realizei uma troca em uma situação nova.
- [ ] Realizei a troca sem o mapa completo.
- [ ] Precisei de menos apoio na segunda tentativa.

## Decisão

Conte os itens marcados.

```text
Total: ______ / 19
```

| Resultado | Próximo passo |
|---:|---|
| 16–19 | Avance e mantenha esta aula na revisão cumulativa. |
| 11–15 | Avance apenas se a tarefa de transferência foi funcional; revise os itens não marcados. |
| 0–10 | Retorne ao mapa lacunado e repita a tarefa em uma situação mais controlada. |

> O número é um guia de estudo, não uma prova científica. Se você reconhece tudo, mas não consegue produzir, a célula ainda precisa de recuperação.

---

# PÁGINA 11 — Espaço para anotações do aluno

## Minhas anotações

### O que eu consegui produzir

```text
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
```

### Onde eu hesitei

```text
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
```

### Um nome que pratiquei

```text
____________________________________________________________
```

### Uma situação nova para revisar

```text
____________________________________________________________
____________________________________________________________
```

### Minha próxima revisão será em

```text
Data: ____ / ____ / ______
```

### Observação sobre o áudio ou pronúncia

```text
____________________________________________________________
____________________________________________________________
____________________________________________________________
```

---

# PÁGINA 12 — Conexão com o sistema

## A primeira célula da rede

Esta aula é a porta de entrada do sistema **Mandarim em Rede**. Ela estabelece o modelo que será reutilizado nos próximos volumes:

```text
intenção → padrão → recuperação → recombinação → transferência
```

### O que esta aula inaugura

- a intenção comunicativa como centro do mapa;
- a separação entre componentes fixos e substituíveis;
- a tentativa antes da consulta;
- o uso do pinyin como apoio, não como substituto do áudio;
- a passagem do mapa completo para o mapa mínimo;
- o domínio medido por produção e transferência.

### O que será expandido depois

| Próxima etapa | Expansão |
|---|---|
| Aula 2 | origem, nacionalidade e idioma |
| Aula 3 | dizer que entendeu, não entendeu e pedir repetição |
| Aula 4 | identificar objetos e expressar posse |
| Consolidação 1 | combinar apresentação, identidade e reparo |
| Módulo 2 | pedir, localizar e organizar situações |

A expressão `我叫 + nome` reaparecerá como uma célula anterior. O estudante deverá combinar o padrão de apresentação com novas intenções, em vez de repetir sempre a mesma sequência.

### Frase-âncora

> **O mapa torna a estrutura visível. A recombinação torna a estrutura flexível. A transferência demonstra que ela pode ser usada.**

---

# PÁGINA 13 — Quiz de fechamento

## Instruções

Responda sem consultar as páginas anteriores. O quiz verifica se você entendeu a função e o uso do material. Ele não substitui a produção oral.

### Parte A — Escolha uma alternativa

**1. Qual é a intenção central desta aula?**

A. Localizar um objeto.  
B. Iniciar uma interação e identificar as pessoas.  
C. Fazer um pedido.  
D. Combinar um horário.

**2. Qual parte pode ser trocada em `我叫 + [nome]`?**

A. `我`  
B. `叫`  
C. `[nome]`  
D. `你呢`

**3. Qual expressão significa “E você?” nesta aula?**

A. `你好`  
B. `你叫什么名字？`  
C. `我叫`  
D. `你呢？`

**4. Quando o aluno consulta o mapa completo?**

A. Antes de ouvir.  
B. Depois da primeira tentativa.  
C. Durante cada frase do áudio.  
D. Somente depois de concluir o PDF.

**5. Qual sequência representa a troca central?**

A. pedido → recusa → localização → despedida.  
B. saudação → pergunta do nome → resposta → devolução da pergunta.  
C. origem → horário → preferência → pedido.  
D. objeto → posse → preço → compra.

### Parte B — Complete oralmente

**6. Cumprimente uma pessoa.**

```text
____________________________
```

**7. Pergunte o nome da pessoa.**

```text
____________________________
```

**8. Diga que você se chama Ana ou Paulo.**

```text
____________________________
```

**9. Devolva a pergunta.**

```text
____________________________
```

### Parte C — Aplicação

**10. Crie uma situação nova em que você usaria a sequência completa.**

```text
Situação:
____________________________________________________________
____________________________________________________________
```

Depois produza a troca em voz alta sem consultar o mapa completo.

---

# PÁGINA 14 — Gabarito e encerramento

## Gabarito da Parte A

| Questão | Resposta |
|---:|---|
| 1 | B |
| 2 | C |
| 3 | D |
| 4 | B |
| 5 | B |

## Respostas esperadas da Parte B

```text
6. 你好。
   Nǐ hǎo.
   Olá.

7. 你叫什么名字？
   Nǐ jiào shénme míngzi?
   Qual é o seu nome?

8. 我叫安娜。 / 我叫保罗。
   Wǒ jiào Ānnà. / Wǒ jiào Bǎoluó.
   Eu me chamo Ana. / Eu me chamo Paulo.

9. 你呢？
   Nǐ ne?
   E você?
```

Na Questão 10, qualquer situação nova é válida se o aluno conseguir manter a intenção e realizar a sequência sem copiar um diálogo fechado.

## Encerramento

Nesta primeira aula, você não precisa saber falar sobre tudo. Você precisa conseguir realizar uma pequena ação com estrutura:

```text
你好 → 你叫什么名字？ → 我叫 + [nome] → 你呢？
```

> **Ouça. Tente. Organize. Recombine. Transfira. Produza sem olhar.**

---

## Referências de produção

[1]: ./mandarim-em-rede-pdf-01-aulas.md "Mandarim em Rede 01 — Fundamentos de Transferência Oral"

[2]: ./mandarim-em-rede-auditoria-estresse.md "Auditoria de estresse e reconstrução definitiva — Mandarim em Rede"

[3]: ./mandarim-em-rede-frame-textual.txt "Frame textual do sistema visual Mandarim em Rede"

[4]: ./banco-pedagogico/01-banco-pedagogico-final.md "Banco pedagógico final — Mandarim em Rede"

[5]: ./aula-01-cumprimentar-e-dizer-o-proprio-nome.md "Aula 1 — Cumprimentar e dizer o próprio nome"

— **Manus AI**

2026-09-08
