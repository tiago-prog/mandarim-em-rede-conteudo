# Plano de Ação de 90 Dias — Mandarim em Rede

## 1. Visão geral do plano

### Objetivo principal

Nos primeiros 90 dias, o objetivo não deve ser produzir uma coleção completa para todos os níveis do Pimsleur. O objetivo deve ser validar e lançar **um primeiro PDF curto, rigoroso e comercialmente utilizável**, capaz de demonstrar o diferencial central do projeto: transformar repertório auditivo já praticado em **recombinação oral com apoio visual progressivamente reduzido**.

O plano deve validar simultaneamente quatro hipóteses:

1. Usuários brasileiros do Pimsleur sentem falta de organização visual e transferência.
2. Eles entendem como usar um mapa mental pós-áudio.
3. A unidade de transferência é suficientemente útil para justificar um produto pago.
4. O processo pode ser executado sem reproduzir diálogos, transcrições ou áudios proprietários da Pimsleur.

### Resultado esperado ao final dos 90 dias

Ao final do período, deve existir:

- um PDF 01 finalizado e lançado em versão comercial inicial;
- um sistema visual e pedagógico reutilizável para os próximos PDFs;
- um grupo de usuários-teste que tenha concluído o protótipo;
- dados de uso, compreensão, retenção e intenção de compra;
- uma página de venda com posicionamento claro como **companion independente e não oficial**;
- uma decisão objetiva sobre continuar, ajustar, expandir ou interromper a linha.

O resultado não é “ter muitos PDFs”. É provar que o primeiro produto resolve uma dor real sem comprometer a integridade metodológica ou jurídica do projeto.

---

## 2. Definição do conceito de aula — versão final

### 2.1 O que caracteriza uma aula

Uma aula de Mandarim em Rede não é uma transcrição de uma lição Pimsleur, uma lista de vocabulário ou uma explicação gramatical independente.

> **Uma aula é uma unidade de transferência oral que parte de uma função comunicativa, organiza um padrão produtivo em um mapa mental, orienta a recuperação ativa e termina com a produção de uma variação em contexto novo.**

A aula deve funcionar como complemento do áudio que o aluno já ouviu. Para evitar dependência de conteúdo proprietário, ela deve ser descrita por **funções, estruturas e objetivos linguísticos**, não por reprodução integral de diálogos ou faixas.

### 2.2 Estrutura padrão de cada aula

Cada aula deve conter obrigatoriamente os seguintes elementos:

#### A. Ficha de orientação

Apresenta:

- função comunicativa;
- resultado esperado;
- pré-requisito ou conhecimento anterior;
- relação com o percurso do aluno;
- aviso de uso: realizar o áudio principal sem consultar o PDF.

#### B. Mapa mental de orientação

Mostra a arquitetura da aula com:

- intenção central;
- padrão de frase;
- elementos fixos;
- elementos substituíveis;
- extensões opcionais;
- ponto tonal ou fonético relevante;
- contraste crítico;
- ligação com mapa anterior.

O mapa deve ser curto o suficiente para ser compreendido em menos de dois minutos.

#### C. Célula de recuperação

O aluno recebe um prompt de intenção ou contexto e tenta produzir a estrutura antes de consultar a resposta.

O material deve separar visualmente:

- o que é fixo;
- o que pode variar;
- o que não deve ser traduzido literalmente;
- quais elementos não devem ser confundidos.

#### D. Recombinador controlado

O aluno pratica substituições limitadas dentro do padrão. Cada aula deve exigir pelo menos três variações produtivas, mas sem introduzir vocabulário excessivo.

#### E. Foco auditivo e tonal

Inclui somente os alertas de pronúncia necessários para a aula. O PDF pode apresentar pinyin tonal e instruções de escuta, mas não deve alegar corrigir a produção do aluno apenas pela leitura.

#### F. Mapa de contraste

Mostra uma confusão provável:

- duas formas semelhantes;
- dois tons confundíveis;
- uma ordem de palavras influenciada pelo português;
- uma distinção entre intenção comunicativa e tradução literal.

#### G. Transferência

Apresenta uma situação nova que não replica o exemplo de orientação. O aluno deve produzir sem consultar o mapa completo.

#### H. Critério de domínio

A aula só é considerada concluída quando o aluno consegue:

- compreender a função quando escuta;
- recuperar o padrão sem olhar a resposta;
- produzir pelo menos três variações controladas;
- manter pronúncia funcional nos pontos trabalhados;
- usar a estrutura em um contexto novo.

### 2.3 Integração do mapa mental na aula

O mapa deve aparecer em três estados:

```text
MAPA COMPLETO → MAPA LACUNADO → PROMPT MÍNIMO
orientação       recuperação       transferência
```

O mapa completo serve para organizar o conteúdo depois do áudio. O mapa lacunado exige que o aluno reconstrua relações. O prompt mínimo testa se o aluno consegue agir sem depender do material.

O PDF não deve instruir o aluno a acompanhar visualmente o áudio principal. A sequência correta é:

```text
1. realizar o áudio sem o PDF;
2. registrar dificuldades;
3. consultar o mapa completo;
4. praticar o mapa lacunado;
5. realizar a tarefa de transferência;
6. revisar posteriormente com menos apoio.
```

### 2.4 Duração e carga cognitiva ideal

Cada aula deve exigir aproximadamente **12 a 20 minutos de trabalho visual e oral**, além da lição de áudio que o aluno já realiza separadamente.

O limite recomendado por aula é:

- uma função comunicativa principal;
- um padrão central;
- três a seis elementos variáveis;
- no máximo um contraste principal;
- um foco tonal ou fonético prioritário;
- uma tarefa de transferência.

Uma aula que precise de mais de 20 minutos para ser compreendida deve ser dividida, salvo quando se tratar de uma revisão cumulativa explicitamente planejada.

### 2.5 Domínio e revisão

A aula deve ser revisitada em quatro momentos:

```text
mesmo dia → dia seguinte → três a sete dias depois → revisão cumulativa
```

A revisão não deve repetir apenas o mesmo exemplo. Ela deve alternar:

- intenção → mandarim;
- áudio → significado;
- significado → produção;
- padrão → substituição;
- contexto novo → transferência.

---

## 3. Ideias e priorização dos primeiros PDFs

A linha inicial deve ter poucos produtos, cada um com função clara. Não se deve começar por um “curso completo” nem tentar cobrir cinco níveis do Pimsleur.

| Prioridade | Nome provisório | Objetivo pedagógico | Público específico | Complexidade | Potencial de validação/venda | Alinhamento core |
|---|---|---|---|---|---|---|
| 1 | **Mandarim em Rede — Fundamentos de Transferência Oral** | Ensinar o sistema de uso e demonstrar como transformar padrões já ouvidos em produção recombinada | Usuário brasileiro iniciante que já utiliza Pimsleur e sente dependência da ordem do áudio | Média | **Muito alto.** Testa a proposta central com escopo controlado | **Máximo** |
| 2 | **Mandarim em Rede — Tons em Contexto** | Integrar percepção, recuperação e produção funcional de tons em palavras e frases | Iniciante que reconhece vocabulário, mas confunde tons | Média-alta | Alto, se houver áudio complementar legítimo ou instruções claras para usar o áudio do aluno | Muito alto |
| 3 | **Mandarim em Rede — Perguntar, Confirmar e Negar** | Organizar funções comunicativas de alto uso e suas variações | Iniciante que quer interagir rapidamente em situações cotidianas | Média | Alto, por ter promessa prática e fácil de comunicar | Muito alto |
| 4 | **Mandarim em Rede — Recombinação de Padrões** | Treinar substituição de componentes fixos, variáveis e opcionais | Aluno que completou uma sequência inicial do áudio, mas não cria frases novas | Alta | Alto para usuários mais comprometidos; menor mercado inicial | Máximo |
| 5 | **Mandarim em Rede — Pronúncia para Brasileiros** | Trabalhar interferências do português, pinyin, aspiração e contrastes selecionados | Brasileiros com dificuldade fonética específica | Média-alta | Médio-alto, mas exige rigor e eventualmente áudio/feedback adicional | Alto |
| 6 | **Mandarim em Rede — Revisão Cumulativa por Mapas** | Integrar conteúdos de várias unidades em tarefas de recuperação e transferência | Usuário que já possui repertório acumulado e precisa consolidar | Alta | Médio; melhor como segundo ou terceiro produto | Muito alto |
| 7 | **Mandarim em Rede — Preparação para Interação Social** | Preparar prompts e estratégias de aplicação em intercâmbios, aulas e conversas | Aluno iniciante-intermediário que pretende usar HelloTalk ou tutor | Média | Médio; depende de uma base anterior | Alto |

### Decisão de priorização

O PDF 01 deve ser o produto mais abrangente em **sistema**, mas não em quantidade de conteúdo. Ele precisa ensinar o formato, validar o comportamento e oferecer uma pequena amostra suficientemente útil para o aluno perceber a transformação.

O PDF 02 deve explorar tons somente depois de a experiência básica de mapas, recuperação e transferência estar validada. Um produto tonal exige maior controle de áudio e pode gerar expectativas de feedback que um PDF, sozinho, não consegue cumprir.

---

## 4. PDF 01 — definição detalhada

### 4.1 Nome definitivo sugerido

# **Mandarim em Rede 01**
## **Fundamentos de Transferência Oral**
### *Como transformar padrões auditivos em produção recombinada com mapas mentais*

Descrição comercial obrigatória:

> **Companion visual independente e não oficial para estudantes brasileiros de mandarim que utilizam o Pimsleur.**

### 4.2 Escopo exato

#### O que entra

- explicação curta do sistema Mandarim em Rede;
- instruções de uso antes, depois e entre sessões de áudio;
- oito a dez células de transferência;
- funções comunicativas iniciais de alto valor;
- mapas de função e de padrão;
- componentes fixos, variáveis e opcionais;
- pinyin tonal somente quando necessário;
- contrastes de alto risco para brasileiros;
- exercícios de recuperação ativa;
- três variações controladas por célula;
- uma tarefa de transferência por célula;
- protocolo de revisão distribuída;
- ficha de autoavaliação;
- referências externas e aviso de não oficialidade;
- índice por função comunicativa, não por reprodução de lições proprietárias.

#### O que fica de fora

- transcrição integral ou parcial de lições Pimsleur sem licença;
- reprodução de diálogos, áudios, vozes ou roteiros proprietários;
- promessa de afiliação, endosso ou parceria com Pimsleur;
- curso completo de escrita de hanzi;
- cobertura de todos os tons e todos os fonemas do mandarim;
- explicações gramaticais extensas;
- banco amplo de vocabulário;
- correção automática de pronúncia;
- SRS embutido ou tentativa de competir com o Anki;
- preparação para HSK como promessa principal;
- conversação humana substituta;
- material para todos os níveis de uma vez.

### 4.3 Quantidade estimada

A versão inicial deve conter:

- **8 aulas principais**;
- **1 mapa mestre do sistema**;
- **8 mapas de orientação**;
- **8 mapas lacunados**;
- **8 prompts mínimos de transferência**;
- **1 revisão cumulativa final**;
- **1 protocolo de revisão de 14 dias**;
- aproximadamente **35 a 50 páginas**, dependendo do design e do nível de espaço visual.

Não ultrapassar esse volume na primeira versão sem dados de uso que justifiquem a expansão.

### 4.4 Estrutura interna completa

#### Bloco 1 — Como usar o companion

- o que é e o que não é;
- relação entre áudio e PDF;
- regra de antecipação;
- como usar mapas completos, lacunados e mínimos;
- como registrar falhas.

#### Bloco 2 — Mapa mestre

Mostra o ciclo:

```text
ÁUDIO → RECUPERAÇÃO → MAPA → RECOMBINAÇÃO → TRANSFERÊNCIA
```

#### Bloco 3 — Oito aulas

Cada aula deve seguir o modelo:

```text
Função → Padrão → Mapa completo → Recuperação →
Recombinação → Contraste → Transferência → Domínio
```

#### Bloco 4 — Revisão cumulativa

Combina células anteriores em prompts de intenção e situações novas. A revisão não deve introduzir grande quantidade de vocabulário novo.

#### Bloco 5 — Plano de 14 dias

Indica quais mapas e tarefas revisar em cada dia, com redução de suporte visual.

#### Bloco 6 — Autoavaliação

O aluno classifica cada célula em:

- compreensão auditiva;
- recuperação;
- pronúncia funcional;
- transferência.

#### Bloco 7 — Limites e fontes

Inclui aviso de que o produto é independente, não oficial, e não substitui o áudio, feedback humano ou avaliação profissional.

### 4.5 Diferencial principal

O diferencial não é “ter mapas coloridos”. É oferecer um **sistema de três estados de suporte** que faz o aluno passar de uma estrutura visível para uma resposta oral independente.

A promessa do PDF 01 deve ser:

> **Você não vai apenas revisar o que ouviu; vai aprender a enxergar o padrão, reconstruí-lo e usá-lo em uma situação nova.**

---

## 5. Cronograma de execução — 90 dias

### Fase 1 — Validação do problema e definição do escopo

#### Dias 1–7

**Entregáveis:**

- perfil do usuário primário;
- lista de dores prioritárias;
- promessa do PDF 01;
- decisão formal sobre o que não será incluído;
- matriz de riscos autorais e pedagógicos.

**Responsabilidade solo:** entrevistar ou questionar pelo menos 8–12 estudantes brasileiros que utilizam áudio para aprender mandarim. Perguntar sobre rotina, dificuldades, uso de transcrições, confusão tonal, dependência da ordem das lições e disposição para pagar por um companion.

**Marco de passagem:** não avançar se o problema “não consigo reutilizar o que ouvi” não aparecer com frequência suficiente ou se o público não for claramente identificável.

#### Dias 8–14

**Entregáveis:**

- especificação final da aula;
- oito funções comunicativas selecionadas;
- template de mapa completo, lacunado e mínimo;
- padrão visual e legenda;
- modelo de autoavaliação;
- página simples de interesse ou lista de espera.

**Marco de passagem:** produzir uma aula-piloto completa e testá-la informalmente com pelo menos três pessoas.

### Fase 2 — Protótipo pedagógico

#### Dias 15–28

**Entregáveis:**

- duas aulas-piloto totalmente diagramadas;
- mapas nos três estados;
- prompts de recuperação e transferência;
- protocolo de revisão;
- registro dos erros observados.

**Teste:** o usuário deve conseguir entender a aula sem explicação oral do criador. Se o autor precisa explicar o mapa pessoalmente, o PDF ainda não está claro.

**Marco de passagem:** pelo menos 70% dos testadores devem conseguir executar o fluxo sem instrução adicional relevante.

### Fase 3 — Produção do conteúdo mínimo

#### Dias 29–42

**Entregáveis:**

- oito aulas em versão textual completa;
- revisão linguística independente;
- checagem de pinyin, tons, tradução funcional e exemplos;
- revisão de não reprodução de conteúdo proprietário;
- primeira versão integral do PDF.

**Responsabilidade solo:** separar claramente autoria pedagógica própria de qualquer referência externa. Não transcrever nem parafrasear diálogos proprietários de maneira reconhecível.

### Fase 4 — Design, acessibilidade e teste interno

#### Dias 43–56

**Entregáveis:**

- PDF diagramado;
- versão para tela e impressão;
- legenda de símbolos e cores;
- índice funcional;
- links e referências revisados;
- formulário de feedback;
- protocolo de teste.

**Testes internos:**

- impressão em escala de cinza;
- leitura em tela de celular e notebook;
- verificação de contraste;
- checagem de pinyin e caracteres;
- remoção de páginas redundantes;
- teste de compreensão sem explicação oral.

### Fase 5 — Beta fechado

#### Dias 57–70

**Participantes:** 10–15 usuários brasileiros que já utilizam Pimsleur ou outro áudio estruturado de mandarim.

**Procedimento:**

- questionário inicial;
- uso do PDF por 7–10 dias;
- registro de tempo, falhas e páginas consultadas;
- uma tarefa de transferência antes e depois;
- entrevista final curta;
- coleta de objeções de compra.

**Marco de passagem:** identificar pelo menos três padrões de erro recorrentes e corrigi-los antes do lançamento. O objetivo do beta não é obter elogios, mas encontrar falhas de instrução, densidade e usabilidade.

### Fase 6 — Ajuste e pré-lançamento

#### Dias 71–80

**Entregáveis:**

- versão 1.0 revisada;
- página de venda;
- descrição de não oficialidade;
- política de acesso e atualização;
- amostra gratuita de duas aulas ou uma aula parcial;
- preço inicial e hipótese de oferta;
- sequência de comunicação para lista de espera.

**Decisão comercial:** não iniciar com assinatura. O primeiro PDF deve ser uma compra simples ou uma oferta beta de baixo risco, para validar disposição de pagar.

### Fase 7 — Lançamento e análise

#### Dias 81–90

**Entregáveis:**

- lançamento para lista de espera;
- acompanhamento de vendas e dúvidas;
- coleta de feedback dos primeiros compradores;
- relatório de métricas;
- decisão sobre PDF 02.

**Marco final:** decidir entre:

- escalar e criar PDF 02;
- revisar profundamente o PDF 01;
- reposicionar o produto;
- interromper a linha se a dor não for suficientemente forte.

---

## 6. Critérios de qualidade e validação

### 6.1 Critérios mínimos para lançamento

O PDF 01 só deve ser lançado se cumprir todos os critérios abaixo:

- cada aula possuir uma função comunicativa única;
- cada aula possuir mapa completo, lacunado e mínimo;
- cada aula exigir produção oral antes da consulta da resposta;
- cada aula possuir pelo menos três recombinações controladas;
- cada aula terminar com transferência em contexto novo;
- nenhuma página depender de transcrição proprietária não autorizada;
- nenhum elemento sugerir oficialidade ou endosso da Pimsleur;
- pinyin, tons, caracteres e traduções terem sido revisados por pessoa qualificada;
- o PDF ser legível em tela e impressão;
- o aluno conseguir usar o material sem explicação pessoal do criador;
- o material declarar claramente seus limites;
- o fluxo diário caber em até 20 minutos de uso visual e oral, além do áudio principal.

### 6.2 Métricas pedagógicas mínimas

No beta, registrar:

| Métrica | Meta inicial |
|---|---:|
| Usuários que entendem o fluxo sem explicação individual | ≥ 70% |
| Usuários que completam pelo menos 6 das 8 aulas | ≥ 60% |
| Usuários que realizam a tarefa de transferência | ≥ 70% dos que concluem a aula |
| Usuários que conseguem produzir três variações em pelo menos metade das aulas | ≥ 60% |
| Redução da consulta ao mapa completo até o final do teste | tendência clara de redução |
| Usuários que identificam valor específico além de “resumo” | ≥ 70% |
| Intenção de compra ou recomendação após o beta | medir; não tratar como prova única |

Essas metas são critérios de decisão inicial, não evidência científica de eficácia. O primeiro ciclo serve para descobrir problemas e estimar sinal de valor.

### 6.3 Testes recomendados

#### Teste de compreensão

Entregar uma aula sem explicação verbal e observar se o usuário sabe por onde começar.

#### Teste de antecipação

Verificar se o layout permite que o usuário tente responder antes de ver a solução.

#### Teste de densidade

Perguntar qual elemento o usuário não conseguiu ignorar ou compreender. Se todos os elementos parecem igualmente importantes, a hierarquia falhou.

#### Teste de transferência

Usar um contexto novo. O aluno não deve apenas repetir o exemplo que acabou de ver.

#### Teste de retenção tardia

Repetir uma tarefa após pelo menos três dias sem reensinar a estrutura.

#### Teste de linguagem

Revisar com alguém que domine mandarim e com alguém que represente o público brasileiro. O primeiro verifica correção; o segundo verifica clareza e interferências.

#### Teste de compra

Antes do lançamento amplo, apresentar a promessa, uma amostra e um preço realista. Intenção declarada sem oferta real não valida mercado.

---

## 7. Riscos e mitigações

| Risco | Impacto | Mitigação |
|---|---|---|
| Escopo excessivo | Atraso e PDF superficial | Limitar o PDF 01 a oito aulas e um único resultado principal |
| Produto virar transcrição | Risco autoral e dependência do Pimsleur | Organizar por função e padrão; não reproduzir diálogos, áudio ou roteiros proprietários |
| Associação indevida com Pimsleur | Risco jurídico e perda de confiança | Usar “companion independente e não oficial” em capa, página de venda e rodapé |
| Mapa virar releitura passiva | Baixa transferência | Exigir estados lacunado e mínimo, tentativa oral e tarefa final |
| Excesso de informação visual | Abandono e baixa retenção | Um objetivo por aula, poucos ramos, suporte progressivo e testes de densidade |
| Pinyin/tons incorretos | Treino de erros | Revisão linguística independente e fonte de áudio legítima; não confiar em decks de fãs sem auditoria |
| Promessa de correção tonal | Frustração e claims indevidos | Declarar que o PDF organiza e orienta; feedback exige áudio, ferramenta validada ou pessoa qualificada |
| Competição com Anki | Produto sem diferencial | Não vender SRS; vender arquitetura de transferência e curadoria para brasileiros |
| Dependência excessiva do Pimsleur | Fragilidade do negócio | Indexar por função e padrão; referências ao percurso devem ser auxiliares, não estrutura proprietária |
| Público pequeno demais | Baixa venda | Validar primeiro com usuários de Pimsleur, mas manter o conteúdo utilizável por estudantes de áudio estruturado em geral |
| Confundir mapa de caracteres com mapa oral | Desvio do conceito | Priorizar função, padrão, som e produção; caracteres entram apenas quando agregarem valor |
| Beta com amigos elogiosos | Falso sinal de mercado | Incluir usuários sem relação pessoal com o criador e medir comportamento, não apenas opinião |
| Produto bonito, mas não útil | Reputação fraca | Testar transferência, retenção tardia e redução de consulta ao mapa |
| Tradução literal inadequada | Interferência do português | Usar tradução funcional e explicar apenas diferenças que mudam a produção |
| Acesso ou pagamento complicado | Conversão baixa | Entrega simples, arquivo claro, instruções objetivas e suporte mínimo definido |

---

## 8. Próximos passos imediatos — próximos 7 a 14 dias

### Dias 1–2 — Fechar a tese do produto

1. Registrar a promessa final: **transformar repertório ouvido em produção recombinada**.
2. Definir o usuário primário: adulto brasileiro iniciante que já usa Pimsleur.
3. Escrever a lista de exclusões do PDF 01.
4. Confirmar que o produto será independente e não oficial.

### Dias 3–4 — Validar a dor

5. Entrevistar ou questionar 8–12 usuários reais.
6. Perguntar quais materiais usam depois do áudio.
7. Identificar se a dor principal é esquecimento, tons, falta de transcrição, falta de recombinação ou ausência de prática social.
8. Perguntar quanto tempo e dinheiro aceitariam investir em um companion.

### Dias 5–6 — Selecionar o conteúdo mínimo

9. Escolher oito funções comunicativas, sem tentar cobrir um nível inteiro.
10. Definir pré-requisitos e ordem de progressão.
11. Mapear cada função em uma célula de transferência.
12. Marcar quais itens exigem revisão tonal ou contraste para brasileiros.

### Dias 7–8 — Construir o sistema visual

13. Criar um template de mapa completo.
14. Criar o mesmo mapa em versão lacunada.
15. Criar a versão de prompt mínimo.
16. Definir legenda de símbolos, cores e regras de acessibilidade.

### Dias 9–10 — Produzir duas aulas-piloto

17. Escrever duas aulas sem transcrever ou reproduzir material proprietário.
18. Inserir prompts de recuperação e transferência.
19. Criar a autoavaliação de quatro dimensões.
20. Verificar se cada aula cabe em 12–20 minutos.

### Dias 11–12 — Testar com usuários

21. Entregar as duas aulas a pelo menos três estudantes.
22. Observar onde eles param, consultam e pedem explicação.
23. Perguntar o que pareceu ser “resumo” e o que pareceu gerar produção.
24. Corrigir a arquitetura, não apenas a redação.

### Dias 13–14 — Decidir e congelar o escopo

25. Revisar o protótipo com um consultor de mandarim ou professor qualificado.
26. Corrigir pinyin, tons, tradução funcional e exemplos.
27. Fechar o índice das oito aulas.
28. Criar a primeira versão da página de lista de espera.
29. Definir o próximo marco: PDF completo em 42 dias.

## Decisão operacional final

O próximo trabalho não é produzir dezenas de mapas. É provar, com duas aulas-piloto, que o aluno:

```text
ouve → tenta responder → entende a rede →
reconstrói o padrão → cria uma variação →
usa o padrão em contexto novo
```

Se esse comportamento ocorrer sem explicação individual e for percebido como valioso, o PDF 01 merece ser produzido. Se não ocorrer, deve-se corrigir o conceito antes de ampliar o catálogo.
