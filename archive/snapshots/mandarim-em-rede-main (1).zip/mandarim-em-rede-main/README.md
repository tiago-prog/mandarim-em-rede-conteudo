# Mandarim em Rede

Projeto de companion visual independente e não oficial para brasileiros que estudam mandarim com apoio de áudio estruturado, incluindo Pimsleur.

## Conteúdo do repositório

- **Conceito e auditoria:** definição estratégica, posicionamento, princípios pedagógicos e análise crítica.
- **Sistema visual textual:** arquitetura dos mapas mentais e representação em texto puro.
- **Pesquisa de mercado e referências:** inventário de materiais Pimsleur Mandarin e recursos complementares.
- **Plano de execução:** plano priorizado de 90 dias para validação e lançamento dos primeiros PDFs.
- **PDF 01:** material completo das aulas de *Fundamentos de Transferência Oral*.
- **Sistema de moldes:** quinze moldes SVG A4 editáveis, referência autoral preservada, páginas separadas por objeto, documentação, validação e previews em `moldes/`.

## Princípios do projeto

O projeto usa mapas mentais como estrutura cognitiva e a recuperação ativa como prática. Cada unidade parte de uma função comunicativa, organiza um padrão produtivo, propõe recombinações controladas e termina com produção oral em contexto novo.

O material é complementar: não substitui o áudio principal, feedback humano, ferramentas de pronúncia ou o estudo sistemático. O projeto não é afiliado, endossado ou autorizado pela Pimsleur.

## Arquivos principais

- `docs/mandarim-em-rede-auditoria-estresse.md`
- `docs/mandarim-em-rede-frame-textual.txt`
- `docs/inventario-pimsleur-mandarim-recursos.md`
- `docs/plano-acao-mandarim-em-rede-90-dias.md`
- `docs/mandarim-em-rede-pdf-01-aulas.md`
- `docs/prompt-mestre-refinamento-mandarim-em-rede.md`
- `docs/conceito-consolidado-mandarim-em-rede.md`
- `docs/analise-pagina-autoral-base-mandarim-em-rede.md`
- `docs/estresse-maximo-moldes-mandarim-em-rede.md`
- `docs/arquitetura-objetos-visuais-mandarim-em-rede.md`
- `moldes/README.md`
- `moldes/CHANGELOG.md`

## Status

Sistema editorial v2 em construção: definição, pesquisa, arquitetura do PDF 01 e família de moldes SVG editáveis separada por objeto pedagógico. Próximas etapas: revisão linguística independente, prova física A4, teste beta com usuários brasileiros e preenchimento de aulas reais.
