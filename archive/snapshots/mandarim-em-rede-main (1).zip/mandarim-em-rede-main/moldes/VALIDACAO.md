# Validação visual e estrutural — Moldes Mandarim em Rede

## Resultado geral

A família v1 foi renderizada integralmente em colorido e escala de cinza. Os nove moldes preservam uma gramática visual comum: moldura azul-marinho, filete dourado, fundo creme, títulos editoriais, caixas funcionais, montanhas discretas e rodapé consistente.

## Inspeção da prancha colorida

A prancha confirma que C0, A0, R1–R5, V1 e W1 são reconhecíveis como uma única coleção. Capa, abertura, roteiro, mapa, recombinação, transferência, consolidação, revisão e escrita apresentam densidades diferentes sem romper a identidade. As áreas de trabalho permanecem maiores que os ornamentos. Os elementos culturais ficam nas margens. Pinyin e caracteres não aparecem sobre as montanhas.

## Inspeção em escala de cinza

A hierarquia permanece legível. Títulos, caixas, bordas, setas, checkboxes e posições continuam distinguindo as funções mesmo sem cor. A diferença semântica não depende exclusivamente de azul, verde, coral ou dourado. Os preenchimentos coloridos perdem distinção cromática, mas são compensados por rótulos como FIXO, SUBSTITUÍVEL, ALERTA e TRANSFERÊNCIA.

## Correções aplicadas antes da renderização

| Molde | Correção | Motivo |
|---|---|---|
| R1 | A área clara da tabela passou a começar abaixo do cabeçalho azul | Evitar que o preenchimento cobrisse a faixa de cabeçalho |
| R1 | O slot `[nome]` foi movido para a linha de `我叫` | Associar a variável à célula correta |
| R2 | O slot `[nome]` passou a ser um objeto separado dentro do nó substituível | Preservar editabilidade e semântica do componente |
| R3 | O slot `[nome]` passou a ser uma caixa separada de `我叫` | Evitar tratar texto português como parte dos caracteres chineses |

## Critérios aprovados

- A4 vertical com `210mm × 297mm` e `viewBox="0 0 794 1123"`;
- XML válido nos nove SVGs;
- texto, pinyin e caracteres como elementos `<text>/<tspan>`;
- ausência de `<image>` e `<foreignObject>`;
- camadas nomeadas para edição;
- renderização colorida concluída;
- renderização em escala de cinza concluída;
- identidade consistente entre os nove moldes;
- R1 preserva objetivo → fluxo → orientação → resultado → tabela;
- R2 apresenta mapa completo, lacunado e mínimo;
- R3 apresenta seis variações e instrução de tentativa;
- R4 e V1 usam checklists observáveis;
- W1 usa grades vetoriais e não inventa ordem de traços.

## Limitações pendentes

A inspeção em prancha não substitui prova física A4, revisão linguística independente, teste em Inkscape, Figma, Affinity Designer e Illustrator, teste de fontes em outros sistemas ou estudo de usabilidade com alunos. A expansão de R1 para seis e oito linhas está documentada, mas precisa ser testada em uma instância preenchida antes da produção comercial.

## Previews

- `previews/contato-color.png` — visão conjunta dos nove moldes coloridos;
- `previews/contato-grayscale.png` — visão conjunta dos nove moldes em escala de cinza;
- `previews/color/` — arquivos individuais coloridos;
- `previews/grayscale/` — arquivos individuais em escala de cinza.

## Referências

[1]: ../referencias/first-page.png "Página autoral-base — Mandarim em Rede"

[2]: ../docs/estresse-maximo-moldes-mandarim-em-rede.md "Estresse máximo dos moldes — Mandarim em Rede"

[3]: ./README.md "Moldes SVG — Mandarim em Rede"

— **Manus AI**

2026-09-08

## Inspeção individual de R1 e R2

A inspeção do R1 confirmou que o cabeçalho azul da tabela voltou a aparecer, o slot `[nome]` está associado à linha `我叫` e a sequência pedagógica permanece clara. O título longo ainda cabe dentro da margem segura na instância nominal.

A inspeção do R2 encontrou um defeito bloqueador: a linha única de reconstrução no mapa lacunado ultrapassava a borda direita da página. A correção necessária é dividir a reconstrução em duas linhas, mantendo as lacunas e a ordem da troca sem reduzir excessivamente o tamanho do hanzi.

## Segunda inspeção individual

O R2 corrigido passou: a reconstrução lacunada foi dividida em duas linhas, permanece dentro da caixa e mantém o tamanho do hanzi. O R3 apresenta boa hierarquia operacional e seis variações editáveis, mas seu placeholder de título `RECOMBINE — [PADRÃO FUNCIONAL]` ultrapassou as margens. O título será reduzido para `RECOMBINE — [PADRÃO]`; funções longas devem usar o subtítulo ou uma quebra manual documentada.

## Terceira inspeção individual

O R3 corrigido passou: `RECOMBINE — [PADRÃO]` permanece dentro da margem segura e preserva a ação dominante. O slot `[nome]` aparece como objeto separado de `我叫`, e as seis variações continuam legíveis. A capa C0 passou na inspeção: mantém área central limpa, contraste forte, tipografia editável, identidade premium e declaração discreta de independência. As montanhas não interferem no conteúdo principal.

## Estresse do R1

Foram geradas instâncias derivadas do R1 com seis linhas, oito linhas e título funcional longo em duas linhas. A prancha `previews/contato-stress-r1.png` confirma que a tabela permanece dentro da moldura nos dois casos de expansão e que o título longo em duas linhas não invade o filete nem a área de conteúdo. O caso de oito linhas reduz a densidade tipográfica conforme previsto; antes de uma publicação comercial, o conteúdo real deve ser revisado em prova A4 para confirmar conforto de leitura.


## Revalidação v2 por objeto

A revalidação foi ampliada de nove para quinze SVGs. Além dos moldes de coleção, roteiro, mapa, recombinação, transferência, consolidação, revisão e escrita, a família agora possui páginas exclusivas para exercício de caractere (`W2`), pronúncia e tons (`P1`), contraste funcional (`X1`), vocabulário funcional (`S1`), quiz de transferência (`Q1`) e anotações e revisão (`N1`).

O `W1` foi refeito como página limpa de escrita. Ele mantém somente o objeto gráfico da escrita, com até três caracteres, pinyin tonal, sentido funcional, grades vetoriais e campo de ordem dos traços verificada externamente. Foram removidos prática oral associada, frases de aula e vocabulário complementar.

O validador passou a verificar quinze arquivos, seus conteúdos mínimos e regras negativas de separação. Resultado: **15 moldes aprovados na validação estrutural e funcional**.

A separação por objeto está especificada em `docs/arquitetura-objetos-visuais-mandarim-em-rede.md`.


## Inspeção visual v2

As pranchas finais `contato-color.png` e `contato-grayscale.png` confirmam que os quinze moldes pertencem à mesma família, mas apresentam ações diferentes. `W1` agora é visualmente uma página limpa de escrita; `W2` concentra exercícios de recuperação de caracteres; `P1`, `X1`, `S1`, `Q1` e `N1` têm blocos próprios e não dependem de inserir texto em uma página de outra função.

A hierarquia permanece legível em escala de cinza. Os novos cartões de escrita, exercícios, quadros de contraste, tabela de vocabulário, quiz e ficha de revisão mantêm bordas, rótulos, linhas e posições como sinais redundantes. Nenhuma nova página usa ilustração ou ornamento para ocupar o espaço central de resposta.


## Inspeção individual de escrita

`W1-pratica-de-escrita.svg` foi conferido em tamanho individual. O título cabe, os três cartões de referência estão separados das grades e a parte inferior mantém ordem dos traços e linhas de anotação sem inserir prática oral ou vocabulário de aula. O espaço negativo central permanece intencional para manter a página calma e permitir escrita manual.

`W2-exercicio-de-caractere.svg` foi conferido em tamanho individual. Os três exercícios têm prompt, cinco grades, classificação de erro e conferência posterior. A página não revela o caractere antes da tentativa e não se mistura com uma tabela de aula.


## Inspeção individual de pronúncia e quiz

`P1-pronuncia-e-tons.svg` mantém três cartões de foco sonoro, cada um com caractere, pinyin, sentido e registro de escuta. A área de anotação inferior é suficiente e a página não tenta ensinar uma lista gramatical.

`Q1-quiz-de-transferencia.svg` mantém seis prompts, linhas de resposta, registro de apoio e resultado. A instrução de não consultar a solução está acima dos exercícios e não há gabarito exposto na mesma página.
