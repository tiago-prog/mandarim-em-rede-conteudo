#!/usr/bin/env python3
"""Gera moldes SVG A4 editáveis separados por objeto pedagógico."""

from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SVG = "http://www.w3.org/2000/svg"
INK = "http://www.inkscape.org/namespaces/inkscape"
ET.register_namespace("", SVG)
ET.register_namespace("inkscape", INK)

COLORS = {
    "navy": "#173754",
    "cream": "#F8F2E7",
    "gold": "#C99E4A",
    "coral": "#C94D3F",
    "mist": "#8A96A0",
    "ink": "#24323D",
    "variable": "#367D86",
    "paper": "#FFFDF8",
}

REQUIRED_LAYERS = [
    ("background", "background"),
    ("frame", "frame"),
    ("ornaments", "ornaments"),
    ("mountains", "mountains"),
    ("boxes", "boxes"),
    ("titles", "titles"),
    ("instructional-text", "instructional-text"),
    ("chinese", "chinese"),
    ("pinyin", "pinyin"),
    ("translations", "translations"),
    ("exercises", "exercises"),
    ("maps", "maps"),
    ("qr-metadata", "qr-metadata"),
    ("footer", "footer"),
]

CSS = f""".title{{font-family:Georgia,\"Noto Serif\",serif;font-size:36px;font-weight:700;fill:{COLORS['navy']};letter-spacing:.2px}}
.subtitle{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:17px;fill:{COLORS['ink']}}}
.h2{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:18px;font-weight:700;fill:{COLORS['navy']};letter-spacing:.4px}}
.h3{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:13px;font-weight:700;fill:{COLORS['navy']};letter-spacing:.7px}}
.body{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:14px;fill:{COLORS['ink']}}}
.small{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:11px;fill:{COLORS['ink']}}}
.tiny{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:9px;fill:{COLORS['ink']}}}
.hanzi{{font-family:\"Noto Sans CJK SC\",\"Microsoft YaHei\",\"PingFang SC\",sans-serif;font-size:24px;fill:{COLORS['navy']}}}
.hanzi-lg{{font-family:\"Noto Sans CJK SC\",\"Microsoft YaHei\",\"PingFang SC\",sans-serif;font-size:45px;fill:{COLORS['navy']}}}
.pinyin{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:14px;fill:{COLORS['coral']}}}
.translation{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:13px;fill:{COLORS['mist']}}}
.white{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:13px;fill:{COLORS['paper']}}}
.white-small{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:10px;fill:{COLORS['paper']}}}
.variable{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:14px;font-weight:700;fill:{COLORS['variable']}}}
.label-navy{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:10px;font-weight:700;fill:{COLORS['navy']}}}
.label-white{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:10px;font-weight:700;fill:{COLORS['paper']}}}
.footer{{font-family:Arial,\"Noto Sans\",sans-serif;font-size:9px;fill:{COLORS['mist']}}}
"""


def q(tag: str) -> str:
    return f"{{{SVG}}}{tag}"


def element(tag: str, **attrs: str) -> ET.Element:
    return ET.Element(q(tag), {key: str(value) for key, value in attrs.items()})


def add(parent: ET.Element, tag: str, **attrs: str) -> ET.Element:
    child = element(tag, **attrs)
    parent.append(child)
    return child


def text(parent: ET.Element, x: float, y: float, value: str, cls: str, anchor: str | None = None, **attrs: str) -> ET.Element:
    values = {"x": x, "y": y, "class": cls, **attrs}
    if anchor:
        values["text-anchor"] = anchor
    node = add(parent, "text", **values)
    node.text = value
    return node


def tspan(parent: ET.Element, x: float, dy: float, value: str) -> ET.Element:
    node = add(parent, "tspan", x=x, dy=dy)
    node.text = value
    return node


def group(root: ET.Element, ident: str, label: str | None = None) -> ET.Element:
    node = add(root, "g", id=ident, **{f"{{{INK}}}groupmode": "layer", f"{{{INK}}}label": label or ident})
    return node


def rect(parent: ET.Element, x: float, y: float, width: float, height: float, fill: str = "none", stroke: str = "none", sw: float = 0, rx: float = 0, **attrs: str) -> ET.Element:
    return add(parent, "rect", x=x, y=y, width=width, height=height, fill=fill, stroke=stroke, **{"stroke-width": sw, "rx": rx}, **attrs)


def line(parent: ET.Element, x1: float, y1: float, x2: float, y2: float, stroke: str, sw: float = 1, **attrs: str) -> ET.Element:
    return add(parent, "line", x1=x1, y1=y1, x2=x2, y2=y2, stroke=stroke, **{"stroke-width": sw}, **attrs)


def base(title_value: str, desc: str, reduced_frame: bool = True) -> tuple[ET.ElementTree, dict[str, ET.Element]]:
    root = ET.Element(q("svg"), {"width": "210mm", "height": "297mm", "viewBox": "0 0 794 1123"})
    title_node = add(root, "title")
    title_node.text = title_value
    desc_node = add(root, "desc")
    desc_node.text = desc
    metadata = add(root, "metadata", id="document-metadata")
    metadata.text = "Mandarim em Rede · molde SVG editável · v2 separada por objeto pedagógico."
    defs = add(root, "defs")
    style = add(defs, "style")
    style.text = CSS
    marker = add(defs, "marker", id="arrow", viewBox="0 0 10 10", refX="8", refY="5", markerWidth="6", markerHeight="6", orient="auto-start-reverse")
    add(marker, "path", d="M 0 0 L 10 5 L 0 10 z", fill=COLORS["gold"])

    layers: dict[str, ET.Element] = {}
    bg = group(root, "background")
    rect(bg, 0, 0, 794, 1123, COLORS["cream"])
    frame = group(root, "frame")
    rect(frame, 30, 30, 734, 1063, "none", COLORS["navy"], 2.0 if not reduced_frame else 1.8, 8)
    rect(frame, 40, 40, 714, 1043, "none", COLORS["gold"], 1.0 if not reduced_frame else 0.9, 5)
    ornaments = group(root, "ornaments")
    cloud = "M 49 115 h 42 c 12 0 15 -10 5 -13 c -7 -4 -14 -2 -15 3 c -3 -8 -14 -8 -19 0 c -3 4 -1 10 4 10 h 42"
    add(ornaments, "path", d=cloud, stroke=COLORS["gold"], fill="none", **{"stroke-width": "1.8"})
    add(ornaments, "path", d="M 58 123 h 33 c 8 0 11 -6 3 -9", stroke=COLORS["gold"], fill="none", **{"stroke-width": "1"})
    add(ornaments, "path", d="M 637 970 h 40 c 12 0 15 -9 5 -13 c -6 -4 -14 -2 -15 3 c -3 -7 -14 -7 -18 0 c -3 4 -1 9 4 9 h 40", stroke=COLORS["gold"], fill="none", **{"stroke-width": "1.8"})
    mountains = group(root, "mountains")
    add(mountains, "path", d="M 45 1040 Q 150 880 250 1010 T 455 965 T 750 1015 L 750 1080 L 45 1080 Z", stroke=COLORS["mist"], fill=COLORS["mist"], opacity="0.12", **{"stroke-width": "1"})
    add(mountains, "path", d="M 45 1075 Q 170 930 275 1045 T 500 1000 T 750 1060", stroke=COLORS["mist"], fill="none", opacity="0.18", **{"stroke-width": "1.5"})
    for ident, label in REQUIRED_LAYERS[4:13]:
        layers[ident] = group(root, ident, label)
    footer = group(root, "footer")
    line(footer, 56, 1068, 738, 1068, COLORS["gold"], 0.8)
    text(footer, 56, 1085, "MANDARIM EM REDE · companion visual independente e não oficial", "footer")
    text(footer, 738, 1085, "[módulo] · Aula [nº] · p. [nº]", "footer", "end")
    layers["footer"] = footer
    return ET.ElementTree(root), layers


def title_block(layers: dict[str, ET.Element], title_value: str, subtitle_value: str, title_size: int = 36) -> None:
    titles = layers["titles"]
    node = text(titles, 397, 102, title_value, "title", "middle", style=f"font-size:{title_size}px")
    line(titles, 190, 126, 604, 126, COLORS["gold"], 2)
    text(titles, 397, 153, subtitle_value, "subtitle", "middle")


def checkbox(parent: ET.Element, x: float, y: float, label: str, color: str = "navy") -> None:
    rect(parent, x, y, 15, 15, COLORS["paper"], COLORS[color], 1, 0)
    text(parent, x + 25, y + 13, label, "small")


def grid(parent: ET.Element, x: float, y: float, columns: int, rows: int, size: float = 42, gap: float = 5) -> None:
    for row in range(rows):
        for column in range(columns):
            xx = x + column * (size + gap)
            yy = y + row * (size + gap)
            rect(parent, xx, yy, size, size, "none", COLORS["mist"], 0.9, 0)
            line(parent, xx + size / 2, yy, xx + size / 2, yy + size, COLORS["mist"], 0.45, **{"stroke-dasharray": "3 3"})
            line(parent, xx, yy + size / 2, xx + size, yy + size / 2, COLORS["mist"], 0.45, **{"stroke-dasharray": "3 3"})
            line(parent, xx, yy, xx + size, yy + size, COLORS["mist"], 0.35, **{"stroke-dasharray": "3 3"})
            line(parent, xx + size, yy, xx, yy + size, COLORS["mist"], 0.35, **{"stroke-dasharray": "3 3"})


def write_svg(tree: ET.ElementTree, filename: str) -> None:
    path = ROOT / filename
    tree.write(path, encoding="utf-8", xml_declaration=False)
    ET.parse(path)
    print(f"OK  {path.relative_to(ROOT)}")


def build_w1() -> ET.ElementTree:
    tree, layers = base("W1 — Prática de escrita", "Página limpa para escrever até três caracteres com pinyin, sentido funcional e grades editáveis.")
    title_block(layers, "PRÁTICA DE ESCRITA — [FUNÇÃO]", "Escreva o caractere. Mantenha a página limpa.", 34)
    ins = layers["instructional-text"]
    rect(ins, 58, 187, 678, 64, COLORS["paper"], COLORS["navy"], 1, 6)
    text(ins, 78, 215, "COMO USAR", "h3")
    text(ins, 190, 215, "Observe o modelo, diga o pinyin e escreva sem copiar uma frase inteira.", "body")

    cards = layers["chinese"]
    py = layers["pinyin"]
    tr = layers["translations"]
    ex = layers["exercises"]
    chars = [("你", "nǐ", "você"), ("我", "wǒ", "eu"), ("叫", "jiào", "chamar-se")]
    xs = [58, 284, 510]
    for x, (hanzi, pinyin, meaning) in zip(xs, chars):
        rect(cards, x, 278, 204, 112, COLORS["paper"], COLORS["navy"], 1, 6)
        text(cards, x + 102, 320, hanzi, "hanzi-lg", "middle")
        text(py, x + 102, 350, pinyin, "pinyin", "middle")
        text(tr, x + 102, 374, meaning, "translation", "middle")
        text(ex, x + 10, 432, "ESCREVA", "h3")
        grid(ex, x + 10, 452, 4, 4, 38, 5)
    note = layers["boxes"]
    rect(note, 58, 760, 678, 120, "#FDF8EE", COLORS["gold"], 1, 6)
    text(note, 78, 790, "ORDEM DOS TRAÇOS", "h2")
    text(note, 78, 820, "Inserir somente uma sequência verificada externamente.", "body")
    text(note, 78, 848, "Fonte: [URL / livro / professor]     Data de verificação: ____ / ____ / ______", "small")
    text(note, 78, 900, "NOTAS DE FORMA", "h3")
    line(note, 78, 920, 716, 920, COLORS["mist"], 0.8)
    line(note, 78, 950, 716, 950, COLORS["mist"], 0.8)
    # Keep required layers explicit and the page single-purpose.
    return tree


def build_w2() -> ET.ElementTree:
    tree, layers = base("W2 — Exercício de caractere", "Página isolada para reconhecer, recuperar e registrar caracteres sem misturar a aula inteira.")
    title_block(layers, "EXERCÍCIO DE CARACTERE — [FUNÇÃO]", "Reconheça. Recupere. Escreva.", 32)
    ins = layers["instructional-text"]
    rect(ins, 58, 187, 678, 78, COLORS["paper"], COLORS["navy"], 1, 6)
    text(ins, 78, 216, "PROMPT FUNCIONAL", "h3")
    text(ins, 235, 216, "[situação / intenção que o caractere ajuda a realizar]", "body")
    text(ins, 78, 245, "Fale ou pense antes de escrever. A conferência fica abaixo da tentativa.", "small")
    ex = layers["exercises"]
    prompts = ["[o que você quer dizer?]", "[qual caractere apareceu no áudio?]", "[qual forma completa esta expressão?]"]
    for idx, prompt in enumerate(prompts, 1):
        y = 300 + (idx - 1) * 176
        rect(ex, 58, y, 678, 148, COLORS["paper"], COLORS["navy"], 1, 6)
        text(ex, 78, y + 29, f"0{idx}", "h3")
        text(ex, 125, y + 29, prompt, "body")
        text(ex, 78, y + 62, "ESCREVA DE MEMÓRIA", "label-navy")
        grid(ex, 78, y + 77, 5, 1, 38, 5)
        text(ex, 330, y + 105, "Tipo de erro:", "small")
        checkbox(ex, 415, y + 96, "forma", "coral")
        checkbox(ex, 490, y + 96, "traço", "coral")
        checkbox(ex, 565, y + 96, "memória", "coral")
    boxes = layers["boxes"]
    rect(boxes, 58, 850, 678, 110, "#FDF8EE", COLORS["gold"], 1, 6)
    text(boxes, 78, 880, "CONFERÊNCIA POSTERIOR", "h2")
    text(boxes, 78, 910, "[resposta verificada]     [pinyin]     [sentido funcional]", "body")
    text(boxes, 78, 940, "O que mudou entre minha tentativa e a referência? __________________________", "small")
    return tree


def build_p1() -> ET.ElementTree:
    tree, layers = base("P1 — Pronúncia e tons", "Página operacional para ouvir, imitar, registrar e revisar um foco de pronúncia.")
    title_block(layers, "PRONÚNCIA E TONS — [FOCO]", "Ouça. Imite. Compare.", 34)
    ins = layers["instructional-text"]
    rect(ins, 58, 187, 678, 72, "#FDF8EE", COLORS["coral"], 1, 6)
    text(ins, 78, 216, "FOCO AUDITIVO", "h3")
    text(ins, 225, 216, "[tom / final / ritmo / mudança contextual]", "body")
    text(ins, 78, 244, "O pinyin informa o alvo; o áudio e a comparação orientam a produção.", "small")
    rows = layers["exercises"]
    examples = [("[汉字]", "[pinyin com tons]", "[sentido]"), ("[汉字]", "[pinyin com tons]", "[sentido]"), ("[汉字]", "[pinyin com tons]", "[sentido]")]
    for idx, (hanzi, pinyin, meaning) in enumerate(examples, 1):
        y = 300 + (idx - 1) * 150
        rect(rows, 58, y, 678, 118, COLORS["paper"], COLORS["navy"], 1, 6)
        text(rows, 78, y + 28, f"0{idx}", "h3")
        text(rows, 125, y + 33, hanzi, "hanzi-lg")
        text(rows, 235, y + 30, pinyin, "pinyin")
        text(rows, 235, y + 58, meaning, "translation")
        text(rows, 430, y + 30, "Ouvi o contorno?", "small")
        checkbox(rows, 430, y + 44, "sim", "variable")
        checkbox(rows, 500, y + 44, "não", "coral")
        text(rows, 430, y + 88, "[nota de escuta]", "small")
    notes = layers["boxes"]
    rect(notes, 58, 790, 678, 150, "none", COLORS["gold"], 1, 6)
    text(notes, 78, 820, "REGISTRE UMA DIFERENÇA", "h2")
    text(notes, 78, 850, "Minha produção ficou: [mais alta / mais baixa / mais curta / mais longa]", "body")
    text(notes, 78, 885, "Próxima comparação: [áudio / gravação / interlocutor]", "small")
    line(notes, 78, 915, 716, 915, COLORS["mist"], 0.8)
    return tree


def build_x1() -> ET.ElementTree:
    tree, layers = base("X1 — Contraste funcional", "Página isolada para escolher entre formas próximas em uma situação comunicativa.")
    title_block(layers, "CONTRASTE FUNCIONAL — [DECISÃO]", "Escolha a forma antes de consultar.", 31)
    ins = layers["instructional-text"]
    rect(ins, 58, 187, 678, 76, COLORS["paper"], COLORS["navy"], 1, 6)
    text(ins, 78, 216, "SITUAÇÃO", "h3")
    text(ins, 180, 216, "[qual decisão o falante precisa tomar?]", "body")
    text(ins, 78, 244, "Não memorize uma regra abstrata. Relacione cada forma a uma intenção.", "small")
    boxes = layers["boxes"]
    rect(boxes, 58, 300, 324, 260, "#EEF6F2", COLORS["variable"], 1, 7)
    rect(boxes, 412, 300, 324, 260, "#FCEEEB", COLORS["coral"], 1, 7)
    text(boxes, 78, 332, "FORMA A", "h2")
    text(boxes, 78, 370, "[汉字]", "hanzi-lg")
    text(boxes, 78, 406, "[pinyin com tons]", "pinyin")
    text(boxes, 78, 442, "[sentido funcional]", "translation")
    text(boxes, 78, 488, "USE QUANDO", "h3")
    text(boxes, 78, 518, "[situação / intenção A]", "body")
    text(boxes, 432, 332, "FORMA B", "h2")
    text(boxes, 432, 370, "[汉字]", "hanzi-lg")
    text(boxes, 432, 406, "[pinyin com tons]", "pinyin")
    text(boxes, 432, 442, "[sentido funcional]", "translation")
    text(boxes, 432, 488, "USE QUANDO", "h3")
    text(boxes, 432, 518, "[situação / intenção B]", "body")
    ex = layers["exercises"]
    rect(ex, 58, 610, 678, 230, COLORS["paper"], COLORS["navy"], 1, 7)
    text(ex, 78, 640, "DECIDA ANTES DE CONSULTAR", "h2")
    scenarios = ["[cenário 1]", "[cenário 2]", "[cenário 3]", "[cenário 4]"]
    for idx, scenario in enumerate(scenarios, 1):
        y = 675 + (idx - 1) * 38
        text(ex, 78, y, f"0{idx}  {scenario}", "small")
        checkbox(ex, 430, y - 13, "A", "variable")
        checkbox(ex, 500, y - 13, "B", "coral")
        text(ex, 585, y, "motivo: ______", "tiny")
    text(ex, 78, 885, "CONTRASTE EM UMA FRASE", "h3")
    line(ex, 78, 910, 716, 910, COLORS["mist"], 0.8)
    return tree


def build_s1() -> ET.ElementTree:
    tree, layers = base("S1 — Vocabulário funcional", "Página para organizar vocabulário por contexto, intenção e possibilidade de combinação.")
    title_block(layers, "VOCABULÁRIO FUNCIONAL — [CONTEXTO]", "Organize por uso. Não memorize uma lista solta.", 31)
    ins = layers["instructional-text"]
    rect(ins, 58, 187, 678, 72, COLORS["paper"], COLORS["navy"], 1, 6)
    text(ins, 78, 216, "SITUAÇÃO", "h3")
    text(ins, 180, 216, "[onde / com quem / para fazer o quê]", "body")
    text(ins, 78, 244, "Cada item deve ter uma função e uma combinação possível.", "small")
    boxes = layers["boxes"]
    top = 300
    row_h = 72
    headers = [(78, "FUNÇÃO"), (225, "MANDARIM"), (390, "PINYIN"), (560, "SENTIDO / COMBINAÇÃO")]
    rect(boxes, 58, top, 678, 42, COLORS["navy"], COLORS["navy"], 1, 2)
    for x, label in headers:
        text(boxes, x, top + 26, label, "label-white")
    for idx in range(7):
        y = top + 42 + idx * row_h
        rect(boxes, 58, y, 678, row_h, COLORS["paper"], "#D7CDBB", 0.8, 0)
        for x in (210, 370, 540):
            line(boxes, x, y, x, y + row_h, "#D7CDBB", 0.8)
        text(boxes, 70, y + 27, f"[função {idx + 1}]", "small")
        text(boxes, 225, y + 30, "[汉字]", "hanzi")
        text(boxes, 385, y + 27, "[pinyin]", "pinyin")
        text(boxes, 555, y + 22, "[sentido]", "small")
        text(boxes, 555, y + 45, "[combinação]", "tiny")
    ex = layers["exercises"]
    rect(ex, 58, 900, 678, 62, "#EEF6F2", COLORS["variable"], 1, 6)
    text(ex, 78, 928, "ATIVAÇÃO", "h3")
    text(ex, 170, 928, "Escolha três itens e produza uma frase funcional.", "body")
    text(ex, 78, 950, "Itens escolhidos: ____  ____  ____", "small")
    return tree


def build_q1() -> ET.ElementTree:
    tree, layers = base("Q1 — Quiz de transferência", "Página de quiz sem resposta visível para medir recuperação, contraste e uso em situação nova.")
    title_block(layers, "QUIZ DE TRANSFERÊNCIA — [TEMA]", "Responda sem consultar a solução.", 32)
    ins = layers["instructional-text"]
    rect(ins, 58, 187, 678, 72, "#FDF8EE", COLORS["gold"], 1, 6)
    text(ins, 78, 216, "AÇÃO", "h3")
    text(ins, 145, 216, "Fale, escolha ou reconstrua antes de olhar qualquer apoio.", "body")
    text(ins, 78, 244, "Tempo sugerido: [5–8 min]     Apoio inicial: [nenhum / mínimo]", "small")
    ex = layers["exercises"]
    prompts = ["[intenção comunicativa 1]", "[reconstrua o padrão 2]", "[escolha entre formas 3]", "[troque o slot 4]", "[situação nova 5]", "[responda ao interlocutor 6]"]
    for idx, prompt in enumerate(prompts, 1):
        y = 300 + (idx - 1) * 92
        rect(ex, 58, y, 678, 72, COLORS["paper"], COLORS["navy"], 0.9, 5)
        text(ex, 78, y + 25, f"0{idx}", "h3")
        text(ex, 125, y + 25, prompt, "body")
        line(ex, 125, y + 48, 690, y + 48, COLORS["mist"], 0.8)
        text(ex, 125, y + 65, "Apoio usado: ______", "tiny")
    boxes = layers["boxes"]
    rect(boxes, 58, 880, 678, 80, "none", COLORS["coral"], 1, 6)
    text(boxes, 78, 910, "RESULTADO", "h2")
    text(boxes, 205, 910, "Acertos funcionais: ____ / 6     Precisei consultar: ____ vezes", "body")
    text(boxes, 78, 940, "Próxima revisão: [data / molde / áudio]", "small")
    return tree


def build_n1() -> ET.ElementTree:
    tree, layers = base("N1 — Anotações e revisão", "Página limpa para registrar evidências da prática e escolher a próxima revisão.")
    title_block(layers, "ANOTAÇÕES E REVISÃO — [AULA]", "Registre evidência. Escolha a próxima ação.", 32)
    ins = layers["instructional-text"]
    rect(ins, 58, 187, 678, 70, COLORS["paper"], COLORS["navy"], 1, 6)
    text(ins, 78, 216, "PÓS-PRÁTICA", "h3")
    text(ins, 190, 216, "O que aconteceu quando tentei produzir sem o apoio completo?", "body")
    ex = layers["exercises"]
    rect(ex, 58, 295, 324, 260, COLORS["paper"], COLORS["navy"], 1, 6)
    rect(ex, 412, 295, 324, 260, COLORS["paper"], COLORS["variable"], 1, 6)
    text(ex, 78, 327, "O QUE CONSEGUI PRODUZIR", "h3")
    for y in (360, 395, 430, 465, 500):
        line(ex, 78, y, 360, y, COLORS["mist"], 0.8)
    text(ex, 432, 327, "ONDE HESITEI", "h3")
    for y in (360, 395, 430, 465, 500):
        line(ex, 432, y, 714, y, COLORS["mist"], 0.8)
    boxes = layers["boxes"]
    rect(boxes, 58, 610, 678, 150, "#FDF8EE", COLORS["gold"], 1, 6)
    text(boxes, 78, 640, "APOIO UTILIZADO", "h2")
    checkbox(boxes, 78, 660, "mapa completo", "navy")
    checkbox(boxes, 210, 660, "mapa lacunado", "variable")
    checkbox(boxes, 350, 660, "prompt mínimo", "gold")
    checkbox(boxes, 490, 660, "sem mapa completo", "coral")
    text(boxes, 78, 710, "Erro principal ou foco de revisão: _________________________________", "body")
    text(boxes, 78, 740, "Próxima ação: [reouvir / recombinar / contrastar / transferir]", "small")
    maps = layers["maps"]
    rect(maps, 58, 815, 678, 145, "none", COLORS["navy"], 1, 6)
    text(maps, 78, 845, "PRÓXIMA REVISÃO", "h2")
    text(maps, 78, 880, "Data: ____ / ____ / ______    Molde: __________    Duração: ______", "body")
    line(maps, 78, 915, 716, 915, COLORS["mist"], 0.8)
    text(maps, 78, 945, "O que precisará estar diferente na próxima tentativa?", "small")
    return tree


def main() -> None:
    outputs = {
        "W1-pratica-de-escrita.svg": build_w1(),
        "W2-exercicio-de-caractere.svg": build_w2(),
        "P1-pronuncia-e-tons.svg": build_p1(),
        "X1-contraste-funcional.svg": build_x1(),
        "S1-vocabulario-funcional.svg": build_s1(),
        "Q1-quiz-de-transferencia.svg": build_q1(),
        "N1-anotacoes-e-revisao.svg": build_n1(),
    }
    for filename, tree in outputs.items():
        write_svg(tree, filename)


if __name__ == "__main__":
    main()
