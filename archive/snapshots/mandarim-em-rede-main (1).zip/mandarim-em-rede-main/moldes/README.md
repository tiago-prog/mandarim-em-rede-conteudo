# Moldes SVG — Mandarim em Rede

## Escopo e origem

Esta pasta contém a **v1 construída do zero** de uma família de nove moldes A4 editáveis, baseada na lógica composicional da página autoral `referencias/first-page.png` e nos documentos pedagógicos do projeto. Não havia moldes SVG anteriores nesta pasta; portanto, este conjunto não é apresentado como refinamento de SVGs inexistentes. O sistema é um companion visual independente e não oficial: não transcreve nem substitui áudio, professor, feedback humano ou ferramentas de pronúncia.

A gramática visual preserva a sequência autoral **objetivo → fluxo → orientação → resultado → conteúdo**, com densidade ajustada à ação dominante de cada página. Texto, pinyin, caracteres, tabelas, grades, linhas e nós permanecem como objetos SVG separados; a referência rasterizada não é incorporada ao layout.

## Inventário

| Arquivo | Ação dominante | Moldura |
|---|---|---|
| `C0-capa-colecao.svg` | Apresentar coleção, promessa e edição | Completa, escura |
| `A0-abertura-tematica.svg` | Abrir tema, função e objetivos | Completa |
| `R1-roteiro-de-aula.svg` | Orientar a sequência de transferência | Completa; template-mãe |
| `R2-mapa-de-aula.svg` | Visualizar relações e três níveis de suporte | Completa |
| `R3-recombinacao-oral.svg` | Produzir variações controladas | Reduzida |
| `R4-transferencia-autoavaliacao.svg` | Usar em situação nova e registrar evidência | Reduzida |
| `R5-consolidacao-modulo.svg` | Integrar até seis funções | Completa |
| `V1-revisao-autoavaliacao.svg` | Verificar domínio e próxima ação | Reduzida |
| `W1-pratica-de-escrita.svg` | Escrever até três caracteres em página limpa | Reduzida |
| `W2-exercicio-de-caractere.svg` | Reconhecer, recuperar e registrar caracteres | Reduzida |
| `P1-pronuncia-e-tons.svg` | Ouvir, imitar e registrar um foco sonoro | Reduzida |
| `X1-contraste-funcional.svg` | Escolher entre formas próximas em contexto | Reduzida |
| `S1-vocabulario-funcional.svg` | Organizar vocabulário por uso | Reduzida |
| `Q1-quiz-de-transferencia.svg` | Testar recuperação e transferência sem resposta | Reduzida |
| `N1-anotacoes-e-revisao.svg` | Registrar evidência e próxima revisão | Reduzida |
| `create_object_templates.py` | Gerar os moldes separados por objeto | Não se aplica |
| `create_stress_fixtures.py` | Gerar instâncias de estresse do R1 | Não se aplica |
| `validate_templates.py` | Validar estrutura XML, camadas, dimensões e conteúdo obrigatório | Não se aplica |
| `VALIDACAO.md` | Registrar inspeção visual, correções e limitações | Não se aplica |

Todos os quinze moldes usam `width="210mm"`, `height="297mm"` e `viewBox="0 0 794 1123"`. Os textos ficam em `<text>/<tspan>` e os desenhos são vetoriais, sem imagens achatadas e sem IA de imagem.

## Separação por objeto

Cada página tem um objeto pedagógico dominante. `W1` é somente escrita limpa. `W2` é somente exercício de caractere. `P1` concentra pronúncia e tons. `X1` trabalha uma decisão contrastiva. `S1` organiza vocabulário por contexto. `Q1` mede recuperação e transferência. `N1` registra a evidência da prática e a próxima revisão. Esses moldes não devem receber blocos de outra operação apenas para preencher espaço.

A arquitetura completa está documentada em [`docs/arquitetura-objetos-visuais-mandarim-em-rede.md`](../docs/arquitetura-objetos-visuais-mandarim-em-rede.md).

## Tokens visuais

| Token | Valor | Uso e redundância em grayscale |
|---|---|---|
| `navy` | `#173754` | Moldura, títulos, cabeçalhos, conexões; forma e rótulo |
| `cream` | `#F8F2E7` | Fundo editorial; contraste de área |
| `gold` | `#C99E4A` | Filetes, resultado, transferência; borda e seta |
| `coral` | `#C94D3F` | Alertas, nuvens e foco auditivo; rótulo ALERTA |
| `mist` | `#8A96A0` | Montanhas, linhas de registro e apoio secundário |
| `ink` | `#24323D` | Texto de leitura |
| `variable` | `#367D86` | Slots substituíveis; borda e rótulo SUBSTITUÍVEL |
| `paper` | `#FFFDF8` | Células, cartões e respostas |

A cor nunca é o único código. Os significados também usam rótulos, posição, bordas, hachuras/linhas tracejadas, checkboxes e setas. A alternância de contorno e preenchimento permite impressão em escala de cinza.

## Camadas e edição

Cada SVG possui grupos Inkscape identificáveis por `id` e `inkscape:label`: `background`, `frame`, `ornaments`, `mountains`, `boxes`, `titles`, `instructional-text`, `chinese`, `pinyin`, `translations`, `exercises`, `maps`, `qr-metadata` e `footer`. Em moldes cuja função não exige um grupo, o grupo está vazio e serve como ponto de extensão.

Abra o SVG no Inkscape, Figma (importação SVG), Affinity Designer ou Illustrator. No painel de camadas, substitua diretamente os objetos de texto. Não converta texto em contorno se a editabilidade for necessária. Os textos funcionais da Aula 1 — `你好。 Nǐ hǎo. Olá.`, `你叫什么名字？ Nǐ jiào shénme míngzi? Qual é o seu nome?`, `我叫` com o slot visual `[nome]` e `你呢？ Nǐ ne? E você?` — são exemplos autorais editáveis; revise conteúdo linguístico antes de publicar.

Os comentários XML curtos em cada arquivo apontam o conteúdo crítico. O QR deve ser inserido em `qr-metadata` como objeto separado, nunca como texto ou página achatada. O placeholder `[nome]` é um slot visual em verde funcional, separado de `我叫`; não há sinal `+` escrito como se fizesse parte de caracteres chineses.

## Validação automatizada

Execute na raiz do repositório:

```bash
python3 moldes/validate_templates.py
```

O script verifica os quinze arquivos obrigatórios, XML bem formado, tamanho A4, `viewBox`, elementos `title`, `desc` e `defs`, camadas nomeadas, tokens de cor, textos editáveis, ausência de raster incorporado, conteúdo funcional mínimo e a separação de conteúdo da página W1. A aprovação estrutural não substitui a inspeção visual ou a prova física.

## Previews de inspeção

Os previews são derivados dos SVGs e não substituem os arquivos-mestre:

- `previews/contato-color.png` reúne os quinze moldes coloridos;
- `previews/contato-grayscale.png` reúne os quinze moldes em escala de cinza;
- `previews/color/` contém os renders individuais coloridos;
- `previews/grayscale/` contém os renders individuais sem cor.

Edite sempre o SVG correspondente. Os PNGs servem somente para inspeção rápida, revisão em GitHub e comparação visual.

## Duplicar um molde

1. Copie o arquivo para um novo nome seguindo a convenção abaixo.
2. Edite primeiro `titles`, depois `instructional-text` e só então conteúdo linguístico, exercícios ou mapa.
3. Preserve a moldura, os grupos, os tokens e o rodapé; substitua `[módulo]`, `[nº]`, `[tema]`, `[nome]`, datas e critérios.
4. Em R1, mantenha a ordem objetivo → fluxo → orientação → resultado → tabela.
5. Faça uma tentativa sem resposta visível antes de inserir ou conferir o apoio completo.
6. Valide XML e renderize uma cópia local no editor de destino antes de exportar.

### Expansão da tabela R1

A tabela nominal tem quatro linhas e quatro colunas: **Função | Mandarim | Pinyin | Sentido funcional**. Para seis ou oito linhas, duplique as linhas vetoriais existentes dentro de `boxes`, mantenha as colunas em `x=58, 216, 384, 546, 736`, ajuste apenas a altura do intervalo e quebre pinyin entre palavras, nunca no meio de uma sílaba. Em oito linhas, priorize corpo mínimo ainda legível e encurte traduções; não reduza a margem segura nem a área de resultado.

## Tipografia e fontes

Títulos usam `Georgia, "Noto Serif", serif`; corpo usa `Arial, "Noto Sans", sans-serif`; CJK usa `"Noto Sans CJK SC", "Microsoft YaHei", "PingFang SC", sans-serif`; pinyin usa `Arial, "Noto Sans", sans-serif`. Instale uma fonte CJK e uma fonte com diacríticos tonais quando possível. A pilha de fallback reduz o risco de perda de `ǐ`, `ǎ`, `ō`, `ü` e caracteres simplificados, mas a renderização final deve ser conferida no sistema de destino.

## Exportação A4 e grayscale

Exporte como A4 vertical em 210 × 297 mm, preservando o viewBox e sem rasterizar texto. Mantenha margem segura aproximada de 50–60 unidades para conteúdo crítico; a moldura é ornamental e fica afastada da área de texto. Confira escala de 100%, sem `fit to artwork`, e faça um teste em PDF. Para grayscale, verifique se títulos, rótulos, contornos, tracejados, setas e preenchimentos ainda distinguem FIXO, SUBSTITUÍVEL, ALERTA e TRANSFERÊNCIA. Evite colocar pinyin sobre montanhas ou textura.

## Convenção de nomes

Use `C0`, `A0`, `R1`–`R5`, `V1` e `W1`, seguido de hífen e slug curto em português: `R3-recombinacao-oral.svg`. Não inclua datas ou nomes de aluno no molde; registre versões no `CHANGELOG.md`.

## Limites conhecidos

Os moldes não verificam pronúncia, ordem de traços, correção de novos caracteres, qualidade de QR, quebra de fonte ou experiência do aluno. W1 e W2 exibem explicitamente campos para ordem de traços verificada externamente e não inventam sequências. R1 foi dimensionado para quatro linhas; seis e oito linhas exigem o ajuste descrito acima. A validação automática confirma XML, dimensões, namespaces, grupos, elementos textuais e separação nominal de objetos, mas não substitui prova física, revisão linguística, inspeção em Inkscape/Figma/Affinity/Illustrator ou teste com usuários.

## Checklist antes de publicar

- [ ] A4 vertical e viewBox preservados.
- [ ] Título, módulo, aula e número de página substituídos.
- [ ] Texto, hanzi, pinyin, tabelas, mapas e QR continuam editáveis.
- [ ] Primeira tentativa ocorre antes da resposta completa.
- [ ] Mapa existe em completo, lacunado e prompt mínimo quando aplicável.
- [ ] Título longo, pinyin tonal e tradução foram conferidos.
- [ ] R1 foi testado com quatro, seis e oito linhas.
- [ ] Ornamentos não invadem trabalho nem pinyin.
- [ ] Colorido e grayscale foram conferidos.
- [ ] Fontes CJK e tonais estão disponíveis no destino.
- [ ] W1 recebeu fonte externa verificada caso a ordem dos traços seja publicada.
- [ ] O PDF final não declara afiliação, autorização ou oficialidade da Pimsleur.
