#!/usr/bin/env python3
"""Valida a estrutura mínima dos moldes SVG do Mandarim em Rede."""

from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SVG_NS = "http://www.w3.org/2000/svg"
INKSCAPE_NS = "http://www.inkscape.org/namespaces/inkscape"

FILES = [
    "C0-capa-colecao.svg",
    "A0-abertura-tematica.svg",
    "R1-roteiro-de-aula.svg",
    "R2-mapa-de-aula.svg",
    "R3-recombinacao-oral.svg",
    "R4-transferencia-autoavaliacao.svg",
    "R5-consolidacao-modulo.svg",
    "V1-revisao-autoavaliacao.svg",
    "W1-pratica-de-escrita.svg",
    "W2-exercicio-de-caractere.svg",
    "P1-pronuncia-e-tons.svg",
    "X1-contraste-funcional.svg",
    "S1-vocabulario-funcional.svg",
    "Q1-quiz-de-transferencia.svg",
    "N1-anotacoes-e-revisao.svg",
]

REQUIRED_LAYERS = {
    "background",
    "frame",
    "ornaments",
    "mountains",
    "boxes",
    "titles",
    "instructional-text",
    "chinese",
    "pinyin",
    "translations",
    "exercises",
    "maps",
    "qr-metadata",
    "footer",
}

REQUIRED_COLORS = {
    "#173754",
    "#F8F2E7",
    "#C99E4A",
    "#C94D3F",
    "#8A96A0",
    "#24323D",
    "#367D86",
    "#FFFDF8",
}

CONTENT_RULES = {
    "R1-roteiro-de-aula.svg": [
        "OBJETIVO DO ROTEIRO",
        "ORIENTAÇÃO DE USO",
        "RESULTADO DESEJADO",
        "Função",
        "Mandarim",
        "Pinyin",
        "Sentido funcional",
    ],
    "R2-mapa-de-aula.svg": [
        "MAPA COMPLETO",
        "MAPA LACUNADO",
        "PROMPT MÍNIMO",
        "FIXO",
        "SUBSTITUÍVEL",
        "ALERTA",
        "TRANSFERÊNCIA",
    ],
    "R3-recombinacao-oral.svg": [
        "FALE ANTES DE CONSULTAR",
        "VARIAÇÕES CONTROLADAS",
        "TAREFA SEM OLHAR",
    ],
    "R4-transferencia-autoavaliacao.svg": [
        "SITUAÇÃO NOVA",
        "CHECKLIST OBSERVÁVEL",
        "PRÓXIMA REVISÃO",
    ],
    "R5-consolidacao-modulo.svg": [
        "MAPA INTEGRADOR",
        "TAREFA CUMULATIVA",
        "CRITÉRIO DE DOMÍNIO",
    ],
    "V1-revisao-autoavaliacao.svg": [
        "CHECKLIST DE DOMÍNIO",
        "TESTE RÁPIDO",
        "PRÓXIMA AÇÃO",
    ],
    "W1-pratica-de-escrita.svg": [
        "PRÁTICA DE ESCRITA",
        "ESCREVA",
        "ORDEM DOS TRAÇOS",
    ],
    "W2-exercicio-de-caractere.svg": [
        "EXERCÍCIO DE CARACTERE",
        "ESCREVA DE MEMÓRIA",
        "CONFERÊNCIA POSTERIOR",
    ],
    "P1-pronuncia-e-tons.svg": [
        "PRONÚNCIA E TONS",
        "FOCO AUDITIVO",
        "Ouvi o contorno?",
        "REGISTRE UMA DIFERENÇA",
    ],
    "X1-contraste-funcional.svg": [
        "CONTRASTE FUNCIONAL",
        "FORMA A",
        "FORMA B",
        "DECIDA ANTES DE CONSULTAR",
    ],
    "S1-vocabulario-funcional.svg": [
        "VOCABULÁRIO FUNCIONAL",
        "FUNÇÃO",
        "ATIVAÇÃO",
    ],
    "Q1-quiz-de-transferencia.svg": [
        "QUIZ DE TRANSFERÊNCIA",
        "RESULTADO",
        "Apoio usado",
    ],
    "N1-anotacoes-e-revisao.svg": [
        "ANOTAÇÕES E REVISÃO",
        "PÓS-PRÁTICA",
        "O QUE CONSEGUI PRODUZIR",
        "ONDE HESITEI",
        "PRÓXIMA REVISÃO",
    ],
}

FORBIDDEN_CONTENT = {
    "W1-pratica-de-escrita.svg": [
        "PRÁTICA ORAL ASSOCIADA",
        "VOCABULÁRIO LIMITADO",
        "你叫什么名字？",
    ],
}


def qname(namespace: str, tag: str) -> str:
    return f"{{{namespace}}}{tag}"


def validate_file(path: Path) -> list[str]:
    errors: list[str] = []
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError as exc:
        return [f"XML inválido: {exc}"]

    if root.tag != qname(SVG_NS, "svg"):
        errors.append("raiz não é <svg>")
    if root.attrib.get("width") != "210mm":
        errors.append("width deve ser 210mm")
    if root.attrib.get("height") != "297mm":
        errors.append("height deve ser 297mm")
    if root.attrib.get("viewBox") != "0 0 794 1123":
        errors.append("viewBox deve ser 0 0 794 1123")

    for tag in ("title", "desc", "defs"):
        if root.find(qname(SVG_NS, tag)) is None:
            errors.append(f"<{tag}> ausente")

    layer_labels = {
        element.attrib.get(qname(INKSCAPE_NS, "label"), "").split(" (")[0]
        for element in root.findall(f".//{qname(SVG_NS, 'g')}")
    }
    missing_layers = REQUIRED_LAYERS - layer_labels
    if missing_layers:
        errors.append("camadas ausentes: " + ", ".join(sorted(missing_layers)))

    if root.findall(f".//{qname(SVG_NS, 'image')}"):
        errors.append("<image> raster não permitido")
    if root.findall(f".//{qname(SVG_NS, 'foreignObject')}"):
        errors.append("<foreignObject> não permitido")
    if not root.findall(f".//{qname(SVG_NS, 'text')}"):
        errors.append("nenhum texto editável encontrado")

    source = path.read_text(encoding="utf-8")
    missing_colors = REQUIRED_COLORS - {color for color in REQUIRED_COLORS if color in source}
    if missing_colors:
        errors.append("tokens de cor ausentes: " + ", ".join(sorted(missing_colors)))

    for required_text in CONTENT_RULES.get(path.name, []):
        if required_text not in source:
            errors.append(f"conteúdo obrigatório ausente: {required_text}")

    for forbidden_text in FORBIDDEN_CONTENT.get(path.name, []):
        if forbidden_text in source:
            errors.append(f"conteúdo de outro objeto encontrado: {forbidden_text}")

    return errors


def main() -> int:
    all_errors: dict[str, list[str]] = {}
    for filename in FILES:
        path = ROOT / filename
        if not path.exists():
            all_errors[filename] = ["arquivo ausente"]
            continue
        errors = validate_file(path)
        if errors:
            all_errors[filename] = errors
        else:
            print(f"OK  {filename}")

    if all_errors:
        print("\nFALHAS", file=sys.stderr)
        for filename, errors in all_errors.items():
            print(f"- {filename}", file=sys.stderr)
            for error in errors:
                print(f"  - {error}", file=sys.stderr)
        return 1

    print(f"\n{len(FILES)} moldes aprovados na validação estrutural e funcional.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
