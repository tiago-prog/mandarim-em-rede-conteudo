# CHANGELOG — Moldes Mandarim em Rede

## v1 — 2026-09-08

Versão construída do zero com base na página autoral, pois não havia moldes SVG anteriores na pasta `moldes/`. A implementação preserva a lógica visual e pedagógica da referência sem incorporar sua rasterização e sem afirmar refinamento de SVGs inexistentes.

| arquivo | alteração | justificativa | impacto e limitações |
|---|---|---|---|
| `C0-capa-colecao.svg` | Capa premium com área central limpa, moldura, nuvens, montanhas suaves, promessa e edição editáveis. | Apresentar a coleção sem depender de texto em imagem ou ilustração dominante. | Texto e ornamentos editáveis; a capa não substitui revisão de marca ou prova de impressão. |
| `A0-abertura-tematica.svg` | Abertura com título funcional, quatro exemplos chineses, faixa vetorial controlada, três objetivos e reserva de QR. | Contextualizar a aula e tornar o resultado observável desde o início. | A ilustração é geométrica e deliberadamente limitada; QR real deve ser inserido externamente. |
| `R1-roteiro-de-aula.svg` | Template-mãe na sequência objetivo → fluxo → orientação → resultado → tabela de quatro colunas, com Aula 1 como exemplo. | Converter a arquitetura autoral em um molde repetível para dezenas de aulas. | Quatro linhas vêm prontas; seis ou oito exigem ajuste de altura conforme README. |
| `R2-mapa-de-aula.svg` | Mapa com nós e conexões editáveis em estados completo, lacunado e prompt mínimo, mais legenda semântica. | Tornar visível a redução progressiva do suporte e preservar a função do mapa. | Limitado a relações simples e cinco/seis ramos por legibilidade; conteúdo novo precisa de revisão pedagógica. |
| `R3-recombinacao-oral.svg` | Prompt de intenção, fixo, substituível, alerta, seis variações, checkboxes, instrução “FALE ANTES DE CONSULTAR” e tarefa sem olhar. | Priorizar produção oral e recombinação controlada em vez de cópia visual. | Variações usam slots genéricos; não são um roteiro proprietário nem prova de pronúncia. |
| `R4-transferencia-autoavaliacao.svg` | Situação nova, meta de 30–60 s, contagem de elementos, checklist observável, erro principal, próxima revisão e nível de apoio. | Medir transferência funcional com evidência registrável. | A autoavaliação não substitui feedback humano ou áudio; tempo é alvo editorial. |
| `R5-consolidacao-modulo.svg` | Mapa integrador de até seis ramos, tarefa cumulativa de 60–90 s, contrastes, domínio e apoios usados. | Integrar células sem transformar a página em mapa decorativo. | Seis ramos são teto visual; módulos densos devem ser divididos em páginas. |
| `V1-revisao-autoavaliacao.svg` | Checklist de compreensão, recuperação, pronúncia funcional e transferência, resumo, teste sem resposta visível, notas e próxima ação. | Avaliar capacidade e dependência de suporte, não apenas familiaridade. | A validação é estrutural; revisão linguística e teste com usuários permanecem pendentes. |
| `W1-pratica-de-escrita.svg` | Até três caracteres, pinyin tonal, sentido funcional, grades Tianzige vetoriais e vocabulário limitado. | Apoiar reconhecimento e escrita sem deslocar o foco oral. | A ordem de traços permanece placeholder explícito e deve ser verificada externamente; não foi inventada. |
| `moldes/README.md` | Documentação de estrutura, tokens, camadas, edição, duplicação, fontes, exportação, grayscale, expansão de R1, nomes, limites e checklist. | Tornar a gramática visual operável por outra pessoa autorizada. | Ainda requer validação prática em múltiplos editores e impressora física. |
| `moldes/CHANGELOG.md` | Registro da origem v1, decisões, justificativas, impactos e limitações pendentes. | Manter rastreabilidade sem alegar refinamento de arquivos que não existiam. | Não substitui histórico Git nem relatório de teste de usuário. |
| `moldes/validate_templates.py` | Validador reutilizável de XML, A4, viewBox, camadas, tokens, texto editável e conteúdo mínimo. | Tornar a verificação estrutural repetível antes de cada publicação. | Não mede qualidade linguística, legibilidade subjetiva ou compatibilidade integral com editores. |
| `moldes/VALIDACAO.md` | Registro das inspeções em colorido, grayscale e tamanho individual. | Preservar achados e correções do controle de qualidade. | A inspeção de preview não substitui impressão física ou teste com usuários. |
| `moldes/previews/` | Renders coloridos, grayscale e duas pranchas de contato. | Facilitar revisão visual sem achatar os arquivos-mestre. | PNGs são derivados; toda edição deve ocorrer no SVG. |

## Validação realizada

Os nove SVGs foram validados com `moldes/validate_templates.py`. Foram conferidos XML bem formado, dimensões A4, `viewBox`, namespace Inkscape, `<title>`, `<desc>`, `<defs>`, texto selecionável, paleta declarada, grupos obrigatórios, conteúdo funcional mínimo e ausência de raster embutido. Os nove moldes também foram renderizados em colorido e escala de cinza.

A inspeção visual encontrou e corrigiu três falhas reais: a camada clara que cobria o cabeçalho azul da tabela R1, o slot `[nome]` posicionado na linha errada de R1 e a linha lacunada de R2 que ultrapassava a borda direita. O slot variável também foi separado de `我叫` em R2 e R3. O título de R3 foi reduzido para permanecer dentro da margem segura.

Esta validação não substitui prova de impressão, revisão de fontes, verificação linguística independente ou inspeção interativa em todos os editores-alvo.

## Pendências conscientes

- Revisar cada novo conteúdo linguístico com fonte competente antes de publicar uma aula.
- Inserir somente QR e ordem de traços verificados externamente.
- Testar importação e edição em Inkscape, Figma, Affinity e Illustrator.
- Fazer prova física A4, além de teste de leitura em celular.
- Ajustar R1 para seis e oito linhas em um editor visual quando houver conteúdo real.


## v2 — 2026-09-08 · Revalidação e separação por objeto

A v2 revalida a família inteira e separa páginas que antes poderiam acumular operações. A regra passou a ser: uma página, um objeto pedagógico dominante; os apoios só permanecem quando servem diretamente à ação principal.

| arquivo | alteração | justificativa | impacto e limitações |
|---|---|---|---|
| `W1-pratica-de-escrita.svg` | Refeito como página limpa de escrita, com até três caracteres, pinyin tonal, sentido funcional e grades vetoriais. | Evitar que escrita, prática oral e vocabulário disputem a mesma página. | Ordem dos traços continua dependendo de fonte externa verificada. |
| `W2-exercicio-de-caractere.svg` | Novo molde para reconhecer, recuperar e escrever caracteres de memória. | Separar exercício de caractere da página de referência gráfica. | A resposta só aparece na conferência posterior; o conteúdo real deve ser revisado. |
| `P1-pronuncia-e-tons.svg` | Novo molde para foco auditivo, imitação, comparação e registro. | Isolar uma decisão de pronúncia ou tom sem misturar uma aula inteira. | Não substitui áudio nem feedback de pronúncia. |
| `X1-contraste-funcional.svg` | Novo molde com Forma A, Forma B e cenários de decisão. | Transformar contraste em escolha comunicativa acionável. | Cada contraste precisa de revisão linguística independente. |
| `S1-vocabulario-funcional.svg` | Novo molde para vocabulário agrupado por função, combinação e situação. | Evitar listas alfabéticas e manter o vocabulário ligado à fala. | A tabela possui sete linhas nominais; módulos maiores devem ser divididos. |
| `Q1-quiz-de-transferencia.svg` | Novo quiz sem resposta visível, com seis prompts e registro de apoio. | Medir recuperação, contraste e transferência, não reconhecimento. | O gabarito deve ser mantido em página ou arquivo separado quando necessário. |
| `N1-anotacoes-e-revisao.svg` | Novo molde para registrar produção, hesitação, apoio usado e próxima ação. | Dar uma página própria à evidência pós-prática. | Registro subjetivo não substitui observação de desempenho. |
| `create_object_templates.py` | Gerador dos novos moldes separados por objeto. | Permitir manutenção e duplicação sem desenhar tudo manualmente. | O gerador é uma ferramenta de produção; os SVGs gerados continuam sendo os arquivos editáveis. |
| `validate_templates.py` | Ampliado de nove para quinze moldes, incluindo regras de conteúdo obrigatório e bloqueio de mistura no W1. | Tornar a revalidação completa e repetível. | Validação automática não mede experiência do aluno nem revisão linguística. |
| `docs/arquitetura-objetos-visuais-mandarim-em-rede.md` | Nova especificação da família por objeto dominante. | Registrar quando usar cada página e o que não misturar. | A aplicação final depende do preenchimento de aulas reais. |

### Resultado da revalidação

Os quinze SVGs foram aprovados em XML, A4 vertical, `viewBox`, camadas Inkscape, tokens de cor, texto editável, ausência de `<image>`/`<foreignObject>` e conteúdo funcional mínimo. O W1 foi verificado também contra conteúdo de prática oral, vocabulário e frases de aula que não pertencem à sua função exclusiva.

A família agora contém páginas distintas para escrita, exercício de caractere, pronúncia e tons, contraste, vocabulário funcional, quiz e anotações. A identidade visual permanece compartilhada, mas a ação dominante e o espaço de resposta são específicos.
