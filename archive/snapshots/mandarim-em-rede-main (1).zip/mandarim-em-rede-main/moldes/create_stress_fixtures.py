#!/usr/bin/env python3
"""Gera instâncias de inspeção para R1 com 6/8 linhas e título longo."""

from copy import deepcopy
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "previews" / "stress"
SOURCE = ROOT / "R1-roteiro-de-aula.svg"
SVG = "http://www.w3.org/2000/svg"
INK = "http://www.inkscape.org/namespaces/inkscape"

ET.register_namespace("", SVG)
ET.register_namespace("inkscape", INK)


def q(tag: str) -> str:
    return f"{{{SVG}}}{tag}"


def svg_element(tag: str, **attributes: str) -> ET.Element:
    return ET.Element(q(tag), attributes)


def text_element(x: float, y: float, text: str, css_class: str, **attributes: str) -> ET.Element:
    element = svg_element(
        "text",
        x=str(x),
        y=str(y),
        **{"class": css_class},
        **attributes,
    )
    element.text = text
    return element


def find_by_id(root: ET.Element, element_id: str) -> ET.Element:
    for element in root.iter():
        if element.attrib.get("id") == element_id:
            return element
    raise RuntimeError(f"Elemento ausente: {element_id}")


def build_table_variant(base: ET.ElementTree, rows: int) -> ET.ElementTree:
    tree = deepcopy(base)
    root = tree.getroot()
    group = find_by_id(root, "boxes-3")
    group.clear()
    group.attrib.update({"id": "boxes-3", f"{{{INK}}}groupmode": "layer", f"{{{INK}}}label": "boxes (3)"})

    left, right = 58.0, 736.0
    top, bottom = 635.0, 885.0
    header_bottom = 677.0
    columns = [58.0, 216.0, 384.0, 546.0, 736.0]
    row_height = (bottom - header_bottom) / rows

    group.append(svg_element("rect", x="58", y="677", width="678", height="208", fill="#FFFDF8", stroke="#173754", **{"stroke-width": "1", "rx": "0"}))
    for x in columns[1:-1]:
        group.append(svg_element("line", x1=str(x), y1=str(top), x2=str(x), y2=str(bottom), stroke="#D7CDBB", **{"stroke-width": "1"}))
    group.append(svg_element("line", x1=str(left), y1=str(header_bottom), x2=str(right), y2=str(header_bottom), stroke="#D7CDBB", **{"stroke-width": "1"}))
    for index in range(1, rows + 1):
        y = header_bottom + row_height * index
        group.append(svg_element("line", x1=str(left), y1=f"{y:.2f}", x2=str(right), y2=f"{y:.2f}", stroke="#D7CDBB", **{"stroke-width": "1"}))

    headers = [(137, "Função"), (300, "Mandarim"), (465, "Pinyin"), (641, "Sentido funcional")]
    for x, label in headers:
        group.append(text_element(x, 662, label, "label-white", **{"text-anchor": "middle"}))

    data = [
        ("Cumprimentar", "你好。", "Nǐ hǎo.", "Olá."),
        ("Perguntar o nome", "你叫什么名字？", "Nǐ jiào shénme míngzi?", "Qual é o seu nome?"),
        ("Dizer o nome", "我叫 [nome]。", "Wǒ jiào [nome].", "Eu me chamo [nome]."),
        ("Devolver", "你呢？", "Nǐ ne?", "E você?"),
        ("Pedir repetição", "请再说一遍。", "Qǐng zài shuō yí biàn.", "Diga mais uma vez."),
        ("Não entender", "我没听懂。", "Wǒ méi tīng dǒng.", "Eu não entendi."),
        ("Confirmar", "可以吗？", "Kěyǐ ma?", "Pode ser?"),
        ("Localizar", "在哪儿？", "Zài nǎr?", "Onde está?"),
    ][:rows]

    if rows == 8:
        hanzi_size, pinyin_size, body_size = 15, 9, 8.7
    else:
        hanzi_size, pinyin_size, body_size = 17, 10, 9.5

    for index, (function, hanzi, pinyin, translation) in enumerate(data):
        center_y = header_bottom + row_height * (index + 0.5) + 4
        group.append(text_element(137, center_y, function, "small", style=f"font-size:{body_size}px", **{"text-anchor": "middle"}))
        group.append(text_element(300, center_y + 1, hanzi, "hanzi", style=f"font-size:{hanzi_size}px", **{"text-anchor": "middle"}))
        group.append(text_element(465, center_y, pinyin, "pinyin", style=f"font-size:{pinyin_size}px", **{"text-anchor": "middle"}))
        group.append(text_element(641, center_y, translation, "small", style=f"font-size:{body_size}px", **{"text-anchor": "middle"}))

    return tree


def build_long_title_variant(base: ET.ElementTree) -> ET.ElementTree:
    tree = deepcopy(base)
    root = tree.getroot()
    group = find_by_id(root, "titles")
    title = group.find(q("text"))
    if title is None:
        raise RuntimeError("Título ausente")
    title.clear()
    title.attrib.update({"x": "397", "y": "82", "class": "title", "text-anchor": "middle", "style": "font-size:29px"})
    first = svg_element("tspan", x="397", y="82")
    first.text = "AULA 8 — DIZER QUANDO ALGO ACONTECE"
    second = svg_element("tspan", x="397", y="116")
    second.text = "E COMBINAR UM ENCONTRO"
    title.extend([first, second])
    line = group.find(q("line"))
    if line is not None:
        line.attrib.update({"y1": "135", "y2": "135"})
    return tree


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    base = ET.parse(SOURCE, parser=parser)

    variants = {
        "R1-estresse-6-linhas.svg": build_table_variant(base, 6),
        "R1-estresse-8-linhas.svg": build_table_variant(base, 8),
        "R1-estresse-titulo-longo.svg": build_long_title_variant(base),
    }

    for filename, tree in variants.items():
        path = OUT / filename
        tree.write(path, encoding="utf-8", xml_declaration=False)
        ET.parse(path)
        print(f"OK  {path.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
