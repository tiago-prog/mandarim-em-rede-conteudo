# Build B02 — lote PDF-first

Este diretório foi produzido por `scripts/build_pdf_batch.py` a partir de um manifesto de lote.

O resultado contém uma capa editorial parametrizada, seguida pelas páginas pedagógicas do perfil `b-family-workbook-v1`. O total é de 11 páginas A4. O lote não inclui áudio.

A capa recebe do JSON o código, o título, o tipo de material, a edição, a primeira estrutura em hanzi, o pinyin e o sentido funcional.
